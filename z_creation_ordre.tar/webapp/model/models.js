sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device"
], function (JSONModel, Device) {
    "use strict";

    return {

        createDeviceModel: function () {
            var oModel = new JSONModel(Device);
            oModel.setDefaultBindingMode("OneWay");
            return oModel;
        },
        //create the order creation model 
        createCreationModel: function () {
            var data = {
                "AUART": "",
                "AUARTList": [
                    {
                        "AUART_TXT": "OT Correctif/ Renouvellement PUMA",
                        "AUART": "ZCO1"
                    }, {
                        "AUART_TXT": "Travaux d'adaptation PUMA",
                        "AUART": "ZADP"
                    }, {
                        "AUART_TXT": "Travaux d'évolution",
                        "AUART": "ZPR1"
                    }
                ],
                "ILART": "",
                "ILART_TXT": "",
                "KTEXT": "",
                "FEGRP": "",
                "URGRP": "",
                "PARC": "",
                "ZZETAT_COMP": "",
                "ZZDISPO": "",
                "isLoaded": false
            };
            var oModel = new JSONModel(data);
            return oModel;
        },
        createRefreshModel: function () {
            var data = {
                "refresh": false
            };
            var oModel = new JSONModel(data);
            return oModel;
        },

        createCompressionModel: function () {
            var data = {
                "Compression": false
            };
            var oModel = new JSONModel(data);
            return oModel;
        }

    };
});
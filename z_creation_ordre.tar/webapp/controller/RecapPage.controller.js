sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
    // @ts-ignore
], function (BaseController, JSONModel, History, formatter, MessageBox, MessageToast) {
    "use strict";

    return BaseController.extend("com.grtgaz.puma.fiori.zcreationordre.controller.RecapPage", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function () {
            var oData = this.getOwnerComponent().getModel("orderCreationModel").getData();
            if (oData.KTEXT === "") {
                this.getRouter().navTo("worklist");
            }
        },

        onExit: function () {
            if (this._userStatusHelp) {
                this._userStatusHelp.destroy();
            }
        },
        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */
        onBeforeRendering: function () {
            var sOrderType = this.getOwnerComponent().getModel("orderCreationModel").getProperty("/AUART");
            if (sOrderType === "ZCO2" || sOrderType === "ZADP" || sOrderType === "ZPR1") {
                this.getView().byId("profPanneForm").setVisible(false);
            } else {
                this.getView().byId("profPanneForm").setVisible(true);
            }
        },

        handleCreateOrder: function () {
            var orderType = this.getView().getModel("orderCreationModel").getProperty("/AUART");
            if (orderType === "ZPR1" || orderType === "ZPR2" || orderType === "ZADP") {
                this._CreateOrder("");
            } else if (orderType === "ZCO2") {
                var status = {},
                    ltStatus = [];
                status.STAT = "E0004";
                status.AUART = "ZCO2";
                ltStatus.push(status);
                this._CreateOrder(ltStatus);
            } else {
                var aFilters = [];
                if (!this._userStatusHelp) {
                    this._userStatusHelp = this._instantiateFragment("com.grtgaz.puma.fiori.zcreationordre.view.fragments.userStatusHelp");
                }

                this._userStatusHelp.open();

                var ordertype = this.getView().byId("orderType").getValue();
                if (ordertype) {
                    // @ts-ignore
                    aFilters.push(new sap.ui.model.Filter("AUART", sap.ui.model.FilterOperator.EQ, ordertype));
                    sap.ui.getCore().byId("userStatusHelp").bindAggregation("items", {
                        path: "/OrderStatusSet",
                        factory: function () {
                            // @ts-ignore
                            return new sap.m.StandardListItem({
                                selected: false,
                                title: "{TXT30}",
                                description: "{STAT}",
                                type: "Active"
                            });
                        },
                        filters: aFilters
                    });
                    if (ordertype === "ZCO1") {
                        // @ts-ignore
                        sap.ui.getCore().byId("userStatusHelp").setMultiSelect(true);
                    }

                } else {
                    sap.m.MessageBox.error(
                        this.getView().getModel("i18n").getResourceBundle().getText("noFilterValueArticle")

                    );

                }

            }
        },

        //instantiate  xml fragment 
        _instantiateFragment: function (FragmentName) {
            var FragmentInstance;
            // @ts-ignore
            FragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
            this.getView().addDependent(this.FragmentInstance);
            FragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
            FragmentInstance.setModel(this.getView().getModel());
            return FragmentInstance;

        },
        handleUserStatusSelection: function (oEvent) {
            var ltStatus = this._prepareStatus(oEvent);
            this._CreateOrder(ltStatus);

            //this._CreateOrder(oEvent.getParameter("selectedItem").getDescription());
        },

        _prepareStatus: function (oEvent) {
            var ordertype, ltStatus = [],
                selectedItems = [],
                status = {};
            ordertype = this.getView().byId("orderType").getValue();
            if (ordertype === "ZCO1") {
                selectedItems = oEvent.getParameter("selectedItems");
                for (var i = 0; i < selectedItems.length; i++) {
                    // @ts-ignore
                    status = {};
                    status.STAT = selectedItems[i].getDescription();
                    status.AUART = this.getView().byId("orderType").getValue();
                    ltStatus.push(status);
                }
            } else {
                // @ts-ignore
                status = {};
                status.STAT = oEvent.getParameter("selectedItem").getDescription();
                status.AUART = this.getView().byId("orderType").getValue();
                ltStatus.push(status);
            }
            return ltStatus;
        },

        _CreateOrder: function (Status) {
            var OrderCreation = this._prepareOrderCreationObject(Status);
            this.getModel().create("/OrderSet", OrderCreation, {
                success: function (oData, response) {

                    var msg, messagePart1, messagePart2, label1, label2, link1, link2,
                        Order = oData.AUFNR,
                        Avis = oData.QMNUM,
                        oZmNotification = oData.QMNUM_ZM;
                    if (oZmNotification) {
                        var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                            hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                target: {
                                    semanticObject: "Zgestion_AVIS",
                                    action: "display"
                                },
                                params: {
                                    "QMNUM": oZmNotification
                                }

                            })) || ""; // generate the Hash to display the order creation app 
                        oCrossAppNavigator.toExternal({
                            target: {
                                shellHash: hash
                            }
                        }); // navigate to order app 	

                        msg = this.getView().getModel("i18n").getResourceBundle().getText("Number") + " " + "l'ordre est  : " + Order;
                        if (Avis) {
                            msg = ". " + msg + " l'avis est : " + Avis;
                        }
                        MessageToast.show(msg);
                        return;
                    }

                    if (Order) {
                        msg = this.getView().getModel("i18n").getResourceBundle().getText("Number");
                        messagePart1 = msg + " " + "l'ordre est  : ";
                        // @ts-ignore
                        label1 = new sap.m.Label({
                            text: messagePart1
                        });
                        // @ts-ignore
                        link1 = new sap.m.Link({
                            text: Order,
                            press: function (oEvent) {
                                var sOrder = oEvent.getSource().getText(),
                                    oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                                    hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                        target: {
                                            semanticObject: "ZGESTION_OT",
                                            action: "display"
                                        },
                                        params: {
                                            "AUFNR": sOrder
                                        }

                                    })) || ""; // generate the Hash to display the order creation app 
                                oCrossAppNavigator.toExternal({
                                    target: {
                                        shellHash: hash
                                    }
                                }); // navigate to order app 
                                this._messageDialog.close();
                            }.bind(this)
                        });
                    }

                    if (Avis) {
                        messagePart2 = ". " + msg + " l'avis est : ";
                        // @ts-ignore
                        label2 = new sap.m.Label({
                            text: messagePart2
                        });
                        // @ts-ignore
                        link2 = new sap.m.Link({
                            text: Avis,
                            press: function (oEvent) {
                                var sNotification = oEvent.getSource().getText(),
                                    oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                                    hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                        target: {
                                            semanticObject: "Zgestion_AVIS",
                                            action: "display"
                                        },
                                        params: {
                                            "QMNUM": sNotification
                                        }

                                    })) || ""; // generate the Hash to display the order creation app 
                                oCrossAppNavigator.toExternal({
                                    target: {
                                        shellHash: hash
                                    }
                                }); // navigate to order app 
                                this._messageDialog.close();
                            }.bind(this)
                        });
                    }

                    if (Order || Avis) {

                        // @ts-ignore
                            var that = this ; 
                            this._messageDialog = new sap.m.Dialog({
                                title: this.getView().getModel("i18n").getResourceBundle().getText("orderCreationsuccess"),
                                type: 'Message',
                                state: 'Success',
                                // @ts-ignore
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
                                        var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                            target: {
                                                semanticObject: "Shell",
                                                action: "home"
                                            }

                                        })) || ""; // generate the Hash to display the order creation app 
                                        oCrossAppNavigator.toExternal({
                                            target: {
                                                shellHash: hash
                                            }
                                        }); // navigate to order creation app 
                                        that._messageDialog.close();
                                    }
                                }),
                                afterClose: function () {
                                    that._messageDialog.destroy();
                                }

                            });
                        






                        var horizontalLayout = new sap.ui.layout.HorizontalLayout();
                        if (link1) {
                            horizontalLayout.addContent(label1);
                            horizontalLayout.addContent(link1);
                        }
                        if (link2) {
                            horizontalLayout.addContent(label2);
                            horizontalLayout.addContent(link2);
                        }
                        this._messageDialog.addContent(horizontalLayout);
                        this._messageDialog.open();

                    } else {
                        var errorList;
                        // @ts-ignore
                        errorList = $.parseJSON(response.headers["sap-message"]).details;
                        // @ts-ignore
                        var dialog = new sap.m.Dialog({
                            // @ts-ignore
                            title: $.parseJSON(response.headers["sap-message"]).message,
                            type: 'Message',
                            state: 'Error',
                            // @ts-ignore
                            beginButton: new sap.m.Button({
                                text: 'OK',
                                press: function () {
                                    dialog.close();
                                }
                            }),
                            afterClose: function () {
                                dialog.destroy();
                            }
                        });
                        var verticallayout = new sap.ui.layout.VerticalLayout();
                        // @ts-ignore
                        verticallayout.addContent(new sap.m.Text({
                            text: this.getView().getModel("i18n").getResourceBundle().getText("messageErreur") + ":"
                        }));

                        verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        for (var i = 0; i < errorList.length; i++) {
                            // @ts-ignore
                            var msg = "\u2022" + errorList[i].message + "\n";
                            // @ts-ignore
                            var x = new sap.m.Text({
                                text: msg
                            });
                            verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                            verticallayout.addContent(x);
                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        }
                        dialog.addContent(verticallayout);
                        dialog.open();
                    }
                }.bind(this),
                // @ts-ignore
                error: function (Error) {

                }.bind(this)
            });

        },
        _constructCommentLines: function (aCommentLines, sComment) {
            var aLines = aCommentLines;

            if (sComment.length <= 132) {
                aLines.push(this._createObjectTable(sComment));
            } else {
                aLines.push(this._createObjectTable(sComment.slice(0, 131)));
                aLines = this._constructCommentLines(aLines, sComment.slice(132, sComment.length));
            }
            return aLines;
        },
        _createObjectTable: function (sString) {
            var oObject = {};
            if (sString) {
                oObject.TDLINE = sString;
            }
            return oObject;

        },

        _prepareOrderCreationObject: function (status) {
            var OrderCreation = {},
                aCommentLines = [];

            if (status) {
                OrderCreation.OrderStatusSet = status;
            }

            //note 
            // GMAO-277
            /*var sNoteDesignation = this.getPropertyValue("noteDesignation");
            if (sNoteDesignation) {
                OrderCreation.MFTEXT = sNoteDesignation;
            }*/
            OrderCreation.MFTEXT = this.getModel("orderCreationModel").getProperty("/MFTEXT");
            
            var aComment = this._constructCommentLines(aCommentLines, this.getPropertyValue("noteComment"));
            if (aComment && aComment[0].TDLINE) {
                OrderCreation.LineSet = aComment;
            }
            var bNoteSup = this.getModel("orderCreationModel").getProperty("/NOTE_OT_SUP");
            if (bNoteSup === "true") {
                OrderCreation.NOTE_OT_SUP = "X";
            } else {
                OrderCreation.NOTE_OT_SUP = "";
            }

            /////
            var orderDesignation = this.getPropertyValue("orderDesignation");
            if (orderDesignation) {
                OrderCreation.KTEXT = orderDesignation;
            }

            var orderType = this.getPropertyValue("orderType");
            if (orderType) {
                OrderCreation.AUART = orderType;
            }

            var ordreParent = this.getModel("orderCreationModel").getProperty("/MAUFNR");
            if (ordreParent) {
                OrderCreation.MAUFNR = ordreParent;
            }

            var workType = this.getModel("orderCreationModel").getProperty("/ILART");
            if (workType) {
                OrderCreation.ILART = workType;
            }

            var technicalPoste = this.getModel("orderCreationModel").getProperty("/TPLNR");
            if (technicalPoste) {
                OrderCreation.TPLNR = technicalPoste;
            }

            var Equipement = this.getModel("orderCreationModel").getProperty("/EQUNR");
            if (Equipement) {
                OrderCreation.EQUNR = Equipement;
            }

            var posteResponsable = this.getPropertyValue("posteResponsable");
            if (posteResponsable) {
                OrderCreation.VAPLZ = posteResponsable;
            }

            var WorkDivision = this.getPropertyValue("WorkDivision");
            if (WorkDivision) {
                OrderCreation.VAWRK = WorkDivision;
            }

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
			// DEBUT MODIFICATION GMAO-123
			// Fait le : 02/06/2021
			// Fait Par : Hajer Cheikhrouhou
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
			var GrpGamme = this.getPropertyValue("GrpGamme");
			if (GrpGamme)
			{
				OrderCreation.PLNNR = GrpGamme ;
			}
			var CptGrpGamme = this.getPropertyValue("CptGrpGamme");
			if (CptGrpGamme)
			{
				OrderCreation.PLNAL = CptGrpGamme ;
			}
			var GrpGammeType = this.getPropertyValue("GrpGammeTy");
				if (GrpGammeType)
			{
				OrderCreation.PLNTY = GrpGammeType ;
			}
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
			// FIN MODIFICATION GMAO-123
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

            if (orderType === "ZCO1") {

                var failure = this.getModel("orderCreationModel").getProperty("/CodeFailure");
                if (failure) {
                    OrderCreation.FECOD = failure;
                }

                var failureGroup = this.getModel("orderCreationModel").getProperty("/FEGRP");
                if (failureGroup) {
                    OrderCreation.FEGRP = failureGroup;
                }

                var cause = this.getModel("orderCreationModel").getProperty("/CodeCause");
                if (cause) {
                    OrderCreation.URCOD = cause;
                }

                var causeGroup = this.getModel("orderCreationModel").getProperty("/URGRP");
                if (causeGroup) {
                    OrderCreation.URGRP = causeGroup;
                }

                var pickerDatdebID = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy HH:mm"
                }).format(this.getModel("orderCreationModel").getProperty("/StartDate"), false).split(" ");
                if (pickerDatdebID) {
                    OrderCreation.AUSVN = pickerDatdebID[0];
                    OrderCreation.AUZTV = pickerDatdebID[1];
                }

                var pickerDateEndID = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy HH:mm"
                }).format(this.getModel("orderCreationModel").getProperty("/endDate"), false).split(" ");

                if (pickerDateEndID) {
                    OrderCreation.AUSBS = pickerDateEndID[0];
                    OrderCreation.AUZTB = pickerDateEndID[1];
                }

                var checkBoxStop = this.getModel("orderCreationModel").getProperty("/checkBoxStop");
                if (checkBoxStop === true) {
                    OrderCreation.MSAUS = "X";
                } else {
                    OrderCreation.MSAUS = "";
                }

                var stopTimeInput = this.getPropertyValue("stopTimeInput");
                if (stopTimeInput) {
                    OrderCreation.EAUSZT = stopTimeInput;
                }
            }
            return OrderCreation;

        },

        getPropertyValue: function (idProperty) {
            return this.getView().byId(idProperty).getValue();
        },

        onNavBack: function () {
            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);
            }

        }


    });

});
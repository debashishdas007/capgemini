jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.MultiSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.SimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode")
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.OrderTypeSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.OrderTypeFilterSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.WorkTypeFilterOnOrderTypeSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationCorSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentCreateSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.table.DefaillanceSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.table.CauseSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.WorkCenterSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.observer.ISubscriber");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.GammePreventiveSearchHelp");

sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/MultiSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/OrderTypeSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/OrderTypeFilterSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkTypeFilterOnOrderTypeSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkCenterSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationCorSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentCreateSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/table/DefaillanceSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/table/CauseSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/GammePreventiveSearchHelp"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MultiSelectionMode, SimpleSelectionMode, ObjectSimpleSelectionMode, OrderTypeSearchHelp,
    OrderTypeFilterSearchHelp, WorkTypeFilterOnOrderTypeSearchHelp, WorkCenterSearchHelp, FunctionalLocationCorSearchHelp, EquipmentCreateSearchHelp,
    DefaillanceSearchHelp, CauseSearchHelp, GammePreventiveSearchHelp
) {
    "use strict";

    return BaseController.extend("com.grtgaz.puma.fiori.zcreationordre.controller.Worklist", {

        formatter: formatter,

        metadata: {
            interfaces: ["com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/observer/ISubscriber"]
        },

        /**
         * - - - - -
         * Ajout de la récupération des paramètres de départ pour l'application des points de mesure
         * Auteur des modifications : PISSOTTE Alexandre
         * Date des modifications : 29/07/2020
         * - - - - -
         */
        onInit: function() {
            this._toggleResponPlantSection(true);
            this._toogleResponPlantHelp(true);
            var startupParams = this.getOwnerComponent().getComponentData()?.startupParameters;
            var orderCreationModel = this.getOwnerComponent().getModel("orderCreationModel");

            // Récupération des paramètres de départ lorsque l'on provient de l'application des Points de Mesure
            if (startupParams?.ILART && startupParams?.ILART_TXT) {
                if (startupParams.TPLNR[0]) {
                    orderCreationModel.setProperty("/TPLNR", startupParams.TPLNR[0]);
                }
                if (startupParams.PLTXT[0]) {
                    orderCreationModel.setProperty("/PLTXT", decodeURIComponent(startupParams.PLTXT[0]));
                }
                if (startupParams.EQUNR[0]) {
                    orderCreationModel.setProperty("/EQUNR", startupParams.EQUNR[0]);
                }
                if (startupParams.EQKTX[0]) {
                    orderCreationModel.setProperty("/EQKTX", decodeURIComponent(startupParams.EQKTX[0]));
                }
                orderCreationModel.setProperty("/AUART", "ZCO1");
                orderCreationModel.setProperty("/VAPLZ", startupParams.VAPLZ[0]);
                orderCreationModel.setProperty("/VAWRK", startupParams.WAWRK[0]);
                this._setWorkType(startupParams.ILART[0], decodeURIComponent(startupParams.ILART_TXT[0]));

                orderCreationModel.setProperty("/isLoaded", true);

            }

            if (startupParams?.AUART) {
                orderCreationModel.setProperty("/AUART", startupParams.AUART[0]);
                orderCreationModel.setProperty("/TPLNR", startupParams.TPLNR[0]);
                orderCreationModel.setProperty("/PLTXT", decodeURIComponent(startupParams.PLTXT[0]));
                orderCreationModel.setProperty("/EQUNR", startupParams.EQUNR[0]);
                orderCreationModel.setProperty("/EQKTX", decodeURIComponent(startupParams.EQKTK[0]));
                orderCreationModel.setProperty("/VAPLZ", startupParams.VAPLZ[0]);
                orderCreationModel.setProperty("/VAWRK", startupParams.WAWRK[0]);
                orderCreationModel.setProperty("/MAUFNR", startupParams.AUFNR[0]);
                orderCreationModel.setProperty("/NOTE_OT_SUP", startupParams.NOTE_OT_SUP[0]);
                orderCreationModel.setProperty("/isLoaded", true);

                this._setDefaultWorkType(orderCreationModel.getProperty("/AUART"));
            }

            this._DeactivateSecondStep();

            this.getOwnerComponent().getModel().attachBatchRequestSent(this._onBatchRequestSent, this);
            this.getOwnerComponent().getModel().attachBatchRequestCompleted(this._onBatchRequestCompleted, this);
        },

        update: function() {
            var sOrderType = this.getView().getModel("orderCreationModel").getProperty("/AUART");

            // this._setDefaultWorkType(sOrderType);

            // this.InfoStepVagenlidation();

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
			/*
				TICKET JIRA GMAO-280
				Lors de la création d'un OT d'adaptation ZADP sur FIORI, l'utilisateur arrive sur les 
				étapes 2 "Note" et 3 "Profil panne" alors que ce sont des étapes pour l'OT correctif 
				ZCO1 uniquement.
				
				De plus, tant qu'un champ n'est pas renseigné dans l'étape 3, l'utilisateur est bloqué et ne 
				peut créer son OT d'adaptation ZADP.
				
				Fait le  : 17/03/2021
				Fait par : Hajer CHEIKHROUHOU
			*/
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-280
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if (sOrderType === "ZCO2" || sOrderType === "ZADP") {
                this.getView().byId("noteStep").setNextStep("");

            } else if (sOrderType === "ZCO1") {
                // Ajout l'étape du profil de panne après l'étape des notes
                this.getView().byId("noteStep").setNextStep(this.getView().byId("ProfilPanneStep"));
            } else if (sOrderType === 'ZPR1') {
                this.getView().byId("noteStep").setNextStep(this.getView().byId("SelGammeStep"));
            }

            this.getView().byId("createOrderWizard").discardProgress(this.getView().byId("genInfoStep"));

            this.getView().getModel("orderCreationModel").setProperty("/AUART", sOrderType);

            this._setDefaultWorkType(sOrderType);

            // GMAO-277
            /*var OrderModel = this.getOwnerComponent().getModel("orderCreationModel");
            if (sOrderType === "ZCO2" && OrderModel.getProperty("/NOTE_OT_SUP") === "true") {
                this.getView().byId("noteDesignation").setEnabled(false);
            }*/


            this.genInfoStepValidation();
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-280
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        },

        /**
         * Event handler for navigating back.
         * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
         * If not, it will navigate to the shell home
         * @public
         */
        onNavBack: function() {
            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: "#Shell-home"
                    }
                });
            }
        },

        _DeactivateSecondStep: function() {
            var OrderModel = this.getOwnerComponent().getModel("orderCreationModel"),
                sOrderType = OrderModel.getProperty("/AUART");

            if (sOrderType === "ZCO2" || sOrderType === "ZADP") {
                this.getView().byId("genInfoStep").setNextStep("");				// GMAO-280 (+)
                this.getView().byId("noteStep").setNextStep("");
                // this.getView().byId("orderType").setEnabled(false);			// GMAO-280 (-)
            }
            // GMAO-277
            /*if (sOrderType === "ZCO2" && OrderModel.getProperty("/NOTE_OT_SUP") === "true") {
                this.getView().byId("noteDesignation").setEnabled(false);
            }*/
            if (sOrderType === "ZPR1") {
                this.getView().byId("noteStep").setNextStep(this.getView().byId("SelGammeStep"))
            }
        },

        _onBatchRequestSent: function() {
            if (!this._oGlobalBusyIndicator) {
                this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            }
            this._oGlobalBusyIndicator.open();
        },

        _onBatchRequestCompleted: function() {
            this._oGlobalBusyIndicator.close();
        },

        onExit: function() {
            var aFragments = [this._technicalObjectHelp, this._EquipementValueHelp, this._workTypeHelp,
            this._workCenterPlantHelp, this._workLeadHelp, this._pmPlannerGroupHelp, this._LocalisationPlantHelp,
            this._LocalisationHelp, this._OperatingSectorHelp, this._ClassHelp, this._articleHelp, this._storeHelp,
            this.classCategoryHelp, this._equipementClassHelp, this._failureValueHelp, this._causeValueHelp,
            this._groupStateValueHelp, this._impactDispoValueHelp
            ];
            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }

        },

        _destroyFragmentInstance: function(FragmentInstance) {
            var oFragmentInstance = FragmentInstance;
            oFragmentInstance.destroy();
        },

        //instantiate  xml fragment 
        _instantiateFragment: function(FragmentName) {
            var FragmentInstance;
            FragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
            this.getView().addDependent(this.FragmentInstance);
            FragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
            FragmentInstance.setModel(this.getView().getModel());
            FragmentInstance.setModel(this.getView().getModel("orderCreationModel"), "orderCreationModel");
            return FragmentInstance;

        },

        //search an input value from a list of elements 
        _searchElementFromSelectDialogList: function(oEvent, FilterName) {
            var sValue, oFilter, oBinding;
            sValue = oEvent.getParameter("value").toUpperCase();
            oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
            oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },

        /**
         * Navigate to details page 
         * 
         * @public
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-288
         * Par : Alexandre PISSOTTE (APY)
         * Date : 19/01/2022
         * Motif : Coches statuts systèmes bloquées
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        wizardCompletedHandler: function() {
            
            if (this.getOwnerComponent().getComponentData()?.startupParameters?.VAPLZ) {
                var sValpz = this.getOwnerComponent().getComponentData().startupParameters.VAPLZ[0];                
            }

            if (this.getOwnerComponent().getComponentData()?.startupParameters?.WAWRK) {
                var sWawrk = this.getOwnerComponent().getComponentData().startupParameters.WAWRK[0];
            }
            

            this.getView().byId("createOrderWizard").discardProgress(this.getView().byId("genInfoStep")); // GMAO-572 ano : Button vérifier disparait prés navigation back
           if (sValpz === this.getView().getModel("orderCreationModel").getProperty("/VAPLZ") && sWawrk === this.getView().getModel("orderCreationModel").getProperty("/VAWRK") &&
                this.getView().getModel("orderCreationModel").getProperty("/AUART") === "ZCO2") {

                sap.m.MessageBox.warning(this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("posteDeTravailNonModifie"), {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function(oAction) {
                        if (oAction === sap.m.MessageBox.Action.NO) {
                            this.getView().byId("createOrderWizard").discardProgress(this.getView().byId("genInfoStep"));
                        } else {
                            this.getRouter().navTo("RecapPage");
                        }
                    }.bind(this)
                });

            } else {
                this.getRouter().navTo("RecapPage");
                 }
        },

        ///////////////////////////////////////////////////////////////////////////////////////////////////// WIZARD STEP ONE ///////////////////////////////////////////////////////////////////////////

        genInfoStepValidation: function() {
            var validation = true,
                technicalPoste, Equipement, startDateInput,
                inputId = ["orderDesignation", "orderType", "workType", "workCenterResponsable", "plant"];

            for (var i = 0; i < inputId.length; i++) {
                if (this.getView().byId(inputId[i]).getValue()) {
                    this.getView().byId(inputId[i]).setValueState("None");
                } else {
                    this.getView().byId(inputId[i]).setValueState("Error");
                    validation = false;
                }
            }

            technicalPoste = this.getView().byId("technicalPoste").getValue();
            Equipement = this.getView().byId("Equipement").getValue();

            if (technicalPoste || Equipement) {
                this.getView().byId("technicalPoste").setValueState("None");
                this.getView().byId("Equipement").setValueState("None");
            } else {
                this.getView().byId("technicalPoste").setValueState("Error");
                this.getView().byId("Equipement").setValueState("Error");
                validation = false;
            }

            if (validation === true) {
                this.getView().byId("genInfoStep").setValidated(true);
                this.getView().byId("noteStep").setValidated(true);
                this._validateThirdStep();
            } else {
                this._invalidateThirdStep();
                this.getView().byId("noteStep").setValidated(false);
                this.getView().byId("genInfoStep").setValidated(false);
            }
        },

        noteStepValidation: function() {
            // GMAO-277
            /*var sNoteDesignation = this.getView().byId("noteDesignation").getValue(),
                sNoteComment = this.getView().byId("noteComment").getValue(),
                bEnabled = this.getView().byId("noteDesignation").getEnabled();
            if (sNoteComment && !sNoteDesignation && bEnabled) {
                this._invalidateThirdStep();
                this.getView().byId("noteStep").setValidated(false);
                this.getView().byId("noteDesignation").setValueState("Error");

            } else {
                this._validateThirdStep();
                this.getView().byId("noteStep").setValidated(true);
                this.getView().byId("noteDesignation").setValueState("None");
            }*/
            if (this.getView().byId("noteComment").getValue()) {
                var oOrderModel = this.getOwnerComponent().getModel("orderCreationModel");
                oOrderModel.setProperty("/MFTEXT", this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("noteStepTitle"));
            }
            this._validateThirdStep();
        },

        _invalidateThirdStep: function() {
            var sOrderType = this.getOwnerComponent().getModel("orderCreationModel").getProperty("/AUART");
            if (sOrderType === "ZCO1") {
                this.getView().byId("ProfilPanneStep").setValidated(false);
            }
        },

        _validateThirdStep: function() {
            var startDateInput,
                sOrderType = this.getOwnerComponent().getModel("orderCreationModel").getProperty("/AUART");
            if (sOrderType === "ZCO1") {
                startDateInput = this.getView().byId("pickerDatdebID").getDateValue();
                if (!startDateInput) {
                    this.getView().byId("pickerDatdebID").setDateValue(new Date());
                }
                this.getView().byId("ProfilPanneStep").setValidated(true);
            }

        },

        _toggleResponPlantSection: function(svalue) {
            this.getView().byId("workCenterResponsable").setEnabled(svalue);
            this.getView().byId("plant").setEnabled(svalue);
        },

        _toogleResponPlantHelp: function(svalue) {
            this.getView().byId("workCenterResponsable").setShowValueHelp(svalue);
            this.getView().byId("plant").setShowValueHelp(svalue);
        },

        // Display order type Help dialog  
        orderTypeHelp: function() {

            if (!this._orderTypeHelp) {
                this._orderTypeHelp = new OrderTypeFilterSearchHelp(
                    this,
                    new SimpleSelectionMode(
                        this.getView().getModel("orderCreationModel"),
                        "/AUART"
                    )
                );
                this._orderTypeHelp.subscribe(this);
            }
            this._orderTypeHelp.open();
        },


        // display work type help dialog 
        workTypeHelp: function() {
            this._workTypeHelp = new WorkTypeFilterOnOrderTypeSearchHelp( // GMAO-342
                this,
                new SimpleSelectionMode(
                    this.getView().getModel("orderCreationModel"),
                    "/ILART",
                    "/ILATX"    // GMAO-342
                ),
                function() {
                    return this.getView().getModel("orderCreationModel").getProperty("/AUART"); // GMAO-342
                }.bind(this)
            );
            this._workTypeHelp.subscribe(this);
            this._workTypeHelp.open();
        },

        _setWorkType: function(workTypeId, WorkTypeDescription) {
            var oCreationModel = this.getOwnerComponent().getModel("orderCreationModel"),
                workTypeDisplayText;
            oCreationModel.setProperty("/ILART", workTypeId);
            if (WorkTypeDescription && workTypeId) {
                workTypeDisplayText = workTypeId + "-" + WorkTypeDescription;
            } else {
                workTypeDisplayText = "";
            }

            oCreationModel.setProperty("/ILART_TXT", workTypeDisplayText);
        },

        _setDefaultWorkType: function(orderType) {
            var sWorkTypeId, sWorkTypeDescription;
            var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

            switch (orderType) {
                case "ZCO1": // GMAO-342
                    var oModel = this.getOwnerComponent().getModel("orderCreationModel");
                    if (oModel.getProperty("/ILATX") == oResourceBundle.getText("renWorkTypeDescription")) {
                        sWorkTypeId = oResourceBundle.getText("renWorkTypeId");
                        sWorkTypeDescription = oResourceBundle.getText("renWorkTypeDescription");
                    } else {
                        sWorkTypeId = oResourceBundle.getText("corWorkTypeId");
                        sWorkTypeDescription = oResourceBundle.getText("corWorkTypeDescription");
                    }
                    break;
                case "ZCO2":
                    sWorkTypeId = oResourceBundle.getText("corWorkTypeId");
                    sWorkTypeDescription = oResourceBundle.getText("corWorkTypeDescription");
                    break;
                case "ZADP":
                    sWorkTypeId = oResourceBundle.getText("rajWorkTypeId");
                    sWorkTypeDescription = oResourceBundle.getText("rajWorkTypeDescription");
                    break;
                case "ZPR1":
                    sWorkTypeId = oResourceBundle.getText("preWorkTypeId");
                    sWorkTypeDescription = oResourceBundle.getText("preWorkTypeDescription");
                    break;
                default:
                    sWorkTypeId = "";
                    sWorkTypeDescription = "";
                    break;
            }

            this._setWorkType(sWorkTypeId, sWorkTypeDescription);
        },

        SelGammeStepValidation: function() {
            var bValidation = true;

            if (this.getView().byId("InputGrpGamme").getValue()) {
                this.getView().byId("InputGrpGamme").setValueState("None");
            } else {
                this.getView().byId("InputGrpGamme").setValueState("Error");
                bValidation = false;
            }

            if (bValidation === true) {
                this.getView().byId("SelGammeStep").setValidated(true);
            } else {
                this.getView().byId("SelGammeStep").setValidated(false);
            }
        },

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-123
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        GammeValueHelp: function() {
            var gamme = new GammePreventiveSearchHelp(this, new ObjectSimpleSelectionMode(this.getView().getModel("orderCreationModel"), function(oObject) {
                this.getView().getModel("orderCreationModel").setProperty("/GrpGamme", oObject.PLNNR);
                this.getView().getModel("orderCreationModel").setProperty("/CptGrpGamme", oObject.PLNAL);
                this.getView().getModel("orderCreationModel").setProperty("/GrpGammeTy", oObject.PLNTY);
                this.getView().getModel("orderCreationModel").setProperty("/GrpGammeTxt", oObject.KTEXT);
                this.SelGammeStepValidation();
            }.bind(this)));

            gamme.open();
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // Fin MODIFICATION GMAO-123
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////// Technical Object help dialog methods //////////////////////////////////////////

        // Display technical object help dialog 
        technicalObjectValueHelp: function() {

            this._technicalObjectHelp = new FunctionalLocationCorSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("orderCreationModel"),
                    function(oObject) {
                        var oModel = this.getView().getModel("orderCreationModel");
                        oModel.setProperty("/TPLNR", oObject.TPLNR);
                        oModel.setProperty("/PLTXT", oObject.PLTXT);
                        oModel.setProperty("/VAPLZ", oObject.ARBPL);
                        oModel.setProperty("/VAWRK", oObject.WERKS);
                        oModel.setProperty("/INGRP", oObject.INGRP);

                        oModel.setProperty("/EQUNR", "");
                        oModel.setProperty("/EQKTX", "");
                        oModel.setProperty("/PERNR", "");

                        oModel.setProperty("/FEGRP", "");
                        oModel.setProperty("/CodeFailure", "");
                        oModel.setProperty("/LabelFailure", "");
                        oModel.setProperty("/URGRP", "");
                        oModel.setProperty("/CodeCause", "");
                        oModel.setProperty("/LabelCause", "");

                    }.bind(this)
                ),
                this.getView().getModel("orderCreationModel").getProperty("/TPLNR")
            );

            this._technicalObjectHelp.subscribe(this);
            this._technicalObjectHelp.open();
        },




        ////////////////////////////////////////Equipement value Help Dialog Methods//////////////////////////////////////////

        //Display equipement dialog help 
        EquipementValueHelp: function() {

            this._EquipementValueHelp = new EquipmentCreateSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("orderCreationModel"),
                    function(oObject) {
                        var oModel = this.getView().getModel("orderCreationModel");
                        oModel.setProperty("/EQUNR", oObject.EQUNR);
                        oModel.setProperty("/EQKTX", oObject.EQKTX);
                        oModel.setProperty("/TPLNR", oObject.TPLNR);
                        oModel.setProperty("/PLTXT", oObject.PLTXT);
                        oModel.setProperty("/VAPLZ", oObject.ARBPL);
                        oModel.setProperty("/VAWRK", oObject.WERKS);
                        oModel.setProperty("/INGRP", oObject.INGRP);

                        oModel.setProperty("/FEGRP", "");
                        oModel.setProperty("/CodeFailure", "");
                        oModel.setProperty("/LabelFailure", "");
                        oModel.setProperty("/URGRP", "");
                        oModel.setProperty("/CodeCause", "");
                        oModel.setProperty("/LabelCause", "");

                    }.bind(this)
                ),
                this.getView().getModel("orderCreationModel").getProperty("/TPLNR")
            );
            this._EquipementValueHelp.subscribe(this);
            this._EquipementValueHelp.open();

        },



        ///////////////////////////////  work center reponsable /plant help dialog methods /////////////////////////////////////////

        workCenterPlantValueHelp: function() {
            var oModel = this.getView().getModel("orderCreationModel");

            if (!this._workCenterPlantHelp) {

                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
                    oModel.setProperty("/VAPLZ", oObject.ARBPL);
                    oModel.setProperty("/VAWRK", oObject.WERKS);
                    this.genInfoStepValidation();

                }.bind(this));
                this._workCenterPlantHelp = new WorkCenterSearchHelp(this, oObjectSelectionMode);

            }
            this._workCenterPlantHelp.open();
        },






        ///////////////////////////////////////////////// WIZARD STEP TWO /////////////////////////////////////////////////

        // checkbox selection event handler 
        onStopSelectionChange: function(oEvent) {
            var isSelected, returnResponse;

            isSelected = oEvent.getParameter("selected");

            returnResponse = this._performDatesCheck(isSelected);

            if (returnResponse === false) {
                this.getView().byId("stopTimeInput").setValue("");
                return;
            }

            this.getView().byId("stopTimeInput").setValue(this._calculateDatesdifference());
            this.getView().byId("ProfilPanneStep").setValidated(true);

        },

        //calculate dates difference unit hour  
        _calculateDatesdifference: function() {
            var startDay, endDay, oneDay, def;

            startDay = this.getView().byId("pickerDatdebID").getDateValue();

            endDay = this.getView().byId("pickerDateEndID").getDateValue();

            oneDay = 1000 * 60 * 60;
            def = (endDay - startDay) / oneDay;
            return def.toFixed(2);
        },

        //verify check box selection and dates
        _performDatesCheck: function(isSelected) {
            var response = true;
            var startDay = this.getView().byId("pickerDatdebID").getDateValue();
            var endDay = this.getView().byId("pickerDateEndID").getDateValue();
            if (isSelected === false) {
                this.getView().byId("stopTimeInput").setValue("");
                if (startDay) {
                    this.getView().byId("ProfilPanneStep").setValidated(true);
                }
                response = false;
            } else {

                if (!startDay || !endDay) {
                    sap.m.MessageBox.error(
                        this.getView().getModel("i18n").getResourceBundle().getText("emptyDates")
                    );
                    this.getView().byId("ProfilPanneStep").setValidated(false);
                    response = false;
                    return response;
                }

                if (startDay > endDay) {
                    sap.m.MessageBox.error(
                        this.getView().getModel("i18n").getResourceBundle().getText("dateInconsistency")
                    );
                    this.getView().byId("ProfilPanneStep").setValidated(false);
                    response = false;
                    return response;
                }

            }
            return response;
        },

        genProfilPanneStepValidation: function() {
            var validation = true;

            if (this.getView().byId("pickerDatdebID").getValue()) {
                this.getView().byId("pickerDatdebID").setValueState("None");
            } else {
                this.getView().byId("pickerDatdebID").setValueState("Error");
                validation = false;

            }

            if (validation === true) {
                this.getView().byId("ProfilPanneStep").setValidated(true);

            } else {
                this.getView().byId("ProfilPanneStep").setValidated(false);
            }

            this.RecalculateDifference();

        },

        //calculate difference
        RecalculateDifference: function() {

            var isSelected, returnResponse;

            isSelected = this.getView().byId("stopInput").getSelected();

            returnResponse = this._performDatesCheck(isSelected);

            if (returnResponse === false) {
                this.getView().byId("stopTimeInput").setValue("");
                return returnResponse;
            }

            this.getView().byId("stopTimeInput").setValue(this._calculateDatesdifference());
            this.getView().byId("ProfilPanneStep").setValidated(true);
        },

        //////////////////////////////////////////////////// Failure value help methods //////////////////////////////////////////

        //open failure value help dialog 
        failureValueHelp: function() {
            this._failureValueHelp = new DefaillanceSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("orderCreationModel"),
                    function(oObject) {

                        var failureCode = oObject.CODE,
                            failureCodeGroup = oObject.CODEGRUPPE,
                            failurelabel = oObject.KURZTEXT;
                        //assign failure code label and code group 
                        this.getView().getModel("orderCreationModel").setProperty("/FEGRP", failureCodeGroup);
                        this.getView().getModel("orderCreationModel").setProperty("/CodeFailure", failureCode);
                        this.getView().getModel("orderCreationModel").setProperty("/LabelFailure", failurelabel);

                        // 	// initialise cause label/code
                        this.getView().getModel("orderCreationModel").setProperty("/URGRP", "");
                        this.getView().getModel("orderCreationModel").setProperty("/CodeCause", "");
                        this.getView().getModel("orderCreationModel").setProperty("/LabelCause", "");

                    }.bind(this)
                ),
                this.getView().getModel("orderCreationModel").getProperty("/TPLNR"),
                this.getView().getModel("orderCreationModel").getProperty("/EQUNR")
            );

            this._failureValueHelp.open();


        },
        onFailureLabelChange: function(oEvent) {
            if (oEvent.getParameter("value").length === 0) {
                this.getView().getModel("orderCreationModel").setProperty("/FEGRP", "");
                this.getView().getModel("orderCreationModel").setProperty("/CodeFailure", "");
                this.getView().getModel("orderCreationModel").setProperty("/LabelFailure", "");
                this.getView().getModel("orderCreationModel").setProperty("/URGRP", "");
                this.getView().getModel("orderCreationModel").setProperty("/CodeCause", "");
                this.getView().getModel("orderCreationModel").setProperty("/LabelCause", "");
            }

        },



        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////// Cause value help methods /////////////////////////////////////////////

        //open cause value help dialog 
        causeValueHelp: function() {
            var LabelFailure = this.getView().getModel("orderCreationModel").getProperty("/LabelFailure");
            if (!LabelFailure) {
                sap.m.MessageBox.error(
                    this.getView().getModel("i18n").getResourceBundle().getText("noFailureSelected")

                );
                return;
            }


            this._causeValueHelp = new CauseSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("orderCreationModel"),
                    function(oObject) {
                        this.getView().getModel("orderCreationModel").setProperty("/URGRP", oObject.CODEGRUPPE);
                        this.getView().getModel("orderCreationModel").setProperty("/CodeCause", oObject.CODE);
                        this.getView().getModel("orderCreationModel").setProperty("/LabelCause", oObject.KURZTEXT);
                    }.bind(this)
                ),
                this.getView().getModel("orderCreationModel").getProperty("/FEGRP"),
                this.getView().getModel("orderCreationModel").getProperty("/CodeFailure")
            );
            this._causeValueHelp.subscribe(this);

            this._causeValueHelp.open();

        },



        onCauseLabelChange: function(oEvent) {
            if (oEvent.getParameter("value").length === 0) {

                this.getView().getModel("orderCreationModel").setProperty("/URGRP", "");
                this.getView().getModel("orderCreationModel").setProperty("/CodeCause", "");
                this.getView().getModel("orderCreationModel").setProperty("/LabelCause", "");
            }
        },

    });
});
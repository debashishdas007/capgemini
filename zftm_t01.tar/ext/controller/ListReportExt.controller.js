sap.ui.controller("com.ftm.zftmt01.ext.controller.ListReportExt",
    {
        onCreate: function (oEvent) { 
            let sHash = sap.ushell.Container.getService('CrossApplicationNavigation').hrefForExternal({
                target: {
                    semanticObject: 'ZGestionInvestIMA11',
                    action: 'manage'
                },
                params: {
                    "appReq": "",
                    "DYNP_OKCODE": "AKTYP_CREATE"
                }

            });
            sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
        },
        onListNavigationExtension: function (oEvent) {
            let appReq = oEvent.getSource().getBindingContext().getObject().Appr_Request_Number;
            let sHash = sap.ushell.Container.getService('CrossApplicationNavigation').hrefForExternal({
                target: {
                    semanticObject: 'ZGestionInvestIMA11',
                    action: 'manage'
                },
                params: {
                    "appReq": appReq
                    
                }

            });
            sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
            return true;
        },
    });

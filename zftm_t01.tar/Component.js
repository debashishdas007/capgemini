sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function(AppComponent) {
    return AppComponent.extend("com.ftm.zftmt01.Component", {
        metadata: {
            manifest: "json"
        }
    });
});

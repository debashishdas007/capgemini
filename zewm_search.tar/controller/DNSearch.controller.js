sap.ui.define([
    //"sap/ui/core/mvc/Controller"
    "com/grtgz/ewm/search/zewmsearch/controller/BaseController"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController) {
        "use strict";
        //var zip = new JSZip();
        return BaseController.extend("com.grtgz.ewm.search.zewmsearch.controller.DNSearch", {
            onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("Home").attachPatternMatched(this._onObjectMatched, this);
            },
            _onObjectMatched: function (oEvent) {
                // This part is done to display only DN Search Tab. FSD EWM_T01_P08
                if (typeof oEvent.getParameter("arguments").deliveryNo !== "undefined") {
                    this.getView().byId("deliveryNo").setValue(oEvent.getParameter("arguments").deliveryNo);
                }

            },

            onDownload: function (oEvent, sVal) {
                //console.log(sVal);

                var oModel = this.getOwnerComponent().getModel();
                this._deliveryNo = this.getView().byId("deliveryNo").getValue();
                this._type = sVal
                if (this._deliveryNo !== "") {
                    var filters = [];
                    filters.push(this.setFilters("deliveryNo", "EQ", this._deliveryNo, ""));
                    filters.push(this.setFilters("type", "EQ", this._type, ""));
                    oModel.read("/DNSearchSet", {
                        filters: filters,
                        success: function (oData, oResponse) {
                            sap.ui.core.BusyIndicator.hide();
                            this.downloadFile(oData.results);
                        }.bind(this),
                        error: function (oError) {
                            // Error message
                            sap.ui.core.BusyIndicator.hide();
                            this.getOwnerComponent()._oErrorHandler._showBackendError(JSON.parse(oError.responseText).error.message.value,
                                JSON.parse(oError.responseText).error.innererror.errordetails);
                        }.bind(this)
                    });
                    oModel.attachRequestSent(function (oEvent) {
                        sap.ui.core.BusyIndicator.show();
                    });
                } else {
                    // Error message
                    sap.ui.core.BusyIndicator.hide();
                    this.getOwnerComponent()._oErrorHandler._showBackendError("Provide Delivery Number");
                }
            },

            downloadFile: function (files) {
                var zip = new JSZip();
                if (this._type == "DN") {
                    try {
                        for (var i = 0; i < files.length; i++) {
                            var a = document.createElement("a");
                            a.href = "data:application/pdf;base64," + files[i].file;
                            a.download = files[i].fileName; //File name Here
                            a.click();
                            a.remove();
                        }
                    } catch (error) {
                        this.getOwnerComponent()._oErrorHandler._showBackendError('Error occured in downloading files', '');
                    }
                } else {
                    // Code for downloading indivisual files
                    // try {
                    //     for (var i = 0; i < files.length; i++) {
                    //         if (files[i].fileName != '') {
                    //             var a = document.createElement("a");
                    //             a.href = "data:application/pdf;base64," + files[i].file;
                    //             a.download = files[i].fileName; //File name Here
                    //             a.click();
                    //             a.remove();
                    //         }
                    //     }
                    // } catch (error) {
                    //     this.getOwnerComponent()._oErrorHandler._showBackendError('Error occured in downloading files', '');
                    // }

                    // Code for downloading files as a zip
                    try {
                        for (var i = 0; i < files.length; i++) {
                            if (files[i].fileName != '') {
                                zip.file(files[i].fileName, files[i].file, { base64: true });
                            }
                        }
                        if (Object.keys(zip.files).length > 0) {
                            zip.generateAsync({ type: "blob" })
                                .then(function (content) {
                                    saveAs(content, "PVdocs.zip");
                                });
                        }

                    } catch (error) {
                        this.getOwnerComponent()._oErrorHandler._showBackendError(error.message, error);
                    }
                }
            }

        });
    });
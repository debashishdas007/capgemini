sap.ui.define([
    //"sap/ui/core/mvc/Controller"
    "com/grtgz/ewm/search/zewmsearch/controller/BaseController"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController) {
        "use strict";

        return BaseController.extend("com.grtgz.ewm.search.zewmsearch.controller.Home", {
            onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("Home").attachPatternMatched(this._onObjectMatched, this);
            },
            _onObjectMatched: function (oEvent) {
                // This part is done to display only DN Search Tab. FSD EWM_T01_P08
                if( typeof oEvent.getParameter("arguments").deliveryNo !=="undefined" ){
                    var oPanelMenu1 = this.byId("idIconTabBarMulti");
                    oPanelMenu1.getItems()[0].destroy();
                    // oPanelMenu1.setSelectedKey("DNSearch");
                }
                
            }
        });
    });

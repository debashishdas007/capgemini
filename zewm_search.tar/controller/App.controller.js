sap.ui.define([
    //"sap/ui/core/mvc/Controller"
    "com/grtgz/ewm/search/zewmsearch/controller/BaseController"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController) {
        "use strict";

        return BaseController.extend("com.grtgz.ewm.search.zewmsearch.controller.App", {
            onInit: function () {

            }
        });
    });

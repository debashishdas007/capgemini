sap.ui.define([
    //"sap/ui/core/mvc/Controller"
    "sap/ui/comp/library",
    "com/grtgz/ewm/search/zewmsearch/controller/BaseController",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/ui/core/Fragment",
    "sap/m/Token",
    "sap/ui/model/type/String"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (compLibrary, BaseController, FilterOperator, MessageToast, Fragment, Token, TypeString) {
        "use strict";
        var zip = new JSZip();
        return BaseController.extend("com.grtgz.ewm.search.zewmsearch.controller.PVSearch", {
            onInit: function () {

            },

            onInputSubmit: function (oEvent, id) {
                let oMultiInput = this.getView().byId(id);
                const tokenValue = oEvent.getSource().getValue();
                oMultiInput.addToken(new Token({
                    key: "",
                    text: "=" + tokenValue
                }).data("range", {
                    "exclude": false,
                    "operation": "EQ",
                    "keyField": id,
                    "value1": tokenValue,
                    "value2": ""
                }));
                oEvent.getSource().setValue();
            },

            onValueHelpRequested: function (oEvent) {
                let id = oEvent.getSource().getId();
                id = id.split("--")[1];
                this._oMultiInput = this.getView().byId(id);
                let fragmentTxt = oEvent.getSource().getParent().getAggregation("content")[0].getProperty("text");
                Fragment.load({
                    name: "com.grtgz.ewm.search.zewmsearch.view.fragments.ValueHelpDialogConditionsTabOnly",
                    controller: this
                }).then(function name(oFragment) {
                    this._oValueHelpDialog = oFragment;
                    this.getView().addDependent(this._oValueHelpDialog);
                    this._oValueHelpDialog.setTitle(fragmentTxt);
                    this._oValueHelpDialog.setKey(id);
                    this._oValueHelpDialog.setRangeKeyFields([{
                        key: id
                    }]);
                    this._oValueHelpDialog.setTokens(this._oMultiInput.getTokens());
                    this._oValueHelpDialog.open();
                    this._oValueHelpDialog.setIncludeRangeOperations([
                        sap.ui.comp.valuehelpdialog.ValueHelpRangeOperation.EQ,
                        sap.ui.comp.valuehelpdialog.ValueHelpRangeOperation.BT,
                        sap.ui.comp.valuehelpdialog.ValueHelpRangeOperation.Contains,
                        sap.ui.comp.valuehelpdialog.ValueHelpRangeOperation.GE,
                        sap.ui.comp.valuehelpdialog.ValueHelpRangeOperation.GT,
                        sap.ui.comp.valuehelpdialog.ValueHelpRangeOperation.LE,
                        sap.ui.comp.valuehelpdialog.ValueHelpRangeOperation.LT,
                    ])
                }.bind(this));


            },

            onSearch: function () {
                let filters = [];
                let filterItems = this.getView().byId("filters").getFilterGroupItems();
                filterItems.forEach(function (item) {
                    let id = item.getControl().getId();
                    id = id.split("--")[1];
                    let tokens = this.getView().byId(id).getTokens();
                    for (let i = 0; i < tokens.length; i++) {
                        let range = tokens[i].data("range");
                        filters.push(this.setFilters(id,
                            range.operation,
                            (range.value1 !== null ? (range.value1).trim() : ""),
                            (range.value2 !== null ? (range.value2).trim() : "")
                        )
                        );
                    }

                }.bind(this));

                filters = filters.filter(function (e) { return e; });
                let oTable = this.getView().byId("pvRecords");
                oTable.bindRows({
                    path: '/PVSearchSet',
                    filters: filters
                });
                
                oTable.getBinding().attachDataReceived(function(oEvent){
                    oTable.setNoData(null); //Use default again ("No Data" in case no data is available)
                });                

            },
            onDownload: function (oEvent) {
                let file = oEvent.getSource().getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/file");
                let fileName = oEvent.getSource().getModel().getProperty(oEvent.getSource().getBindingContext().getPath() + "/fileName");
                if (file !== "") {
                    var a = document.createElement("a");
                    a.href = "data:application/pdf;base64," + file;
                    a.download = fileName; //File name Here
                    a.click();
                    a.remove();
                }
            },
            onValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this._oMultiInput.setTokens(aTokens);
                this._oValueHelpDialog.close();
            },
            onValueHelpCancelPress: function () {
                this._oValueHelpDialog.close();
            },
            onValueHelpAfterClose: function () {
                this._oValueHelpDialog.destroy();
            },

            onZipDownload: function (oEvent) {
                var oTable = this.getView().byId("pvRecords");
                var selectedItems = oTable.getSelectedIndices();
                if (selectedItems.length === 0) {
                    MessageToast.show("Please select atleast one record");
                    return false;
                }

                var files = selectedItems.map(function (item) {
                    var sBindingPath = oTable.getContextByIndex(item);
                    var records = []
                    records = {
                        fileName: oTable.getModel().getProperty(sBindingPath + '/fileName'),
                        file: oTable.getModel().getProperty(sBindingPath + '/file')
                    }
                    return records;
                });
                // console.log(files);

                // Code for downloading indivisual files
                // for (var i = 0; i < files.length; i++) {
                //     if (files[i].fileName != '') {
                //         var a = document.createElement("a");
                //         a.href = "data:application/pdf;base64," + files[i].file;
                //         a.download = files[i].fileName; //File name Here
                //         a.click();
                //         a.remove();
                //     }
                // }

                // Code for downloading files as a zip
                try {
                    for (var i = 0; i < files.length; i++) {
                        if (files[i].fileName != '') {
                            zip.file(files[i].fileName, files[i].file, { base64: true });
                        }
                    }

                    if (Object.keys(zip.files).length > 0) {
                        zip.generateAsync({ type: "blob" })
                            .then(function (content) {
                                saveAs(content, "PVdocs.zip");
                            });
                    }
                } catch (error) {
                    this.getOwnerComponent()._oErrorHandler._showBackendError(error.message, error);
                }
            }
        });
    });
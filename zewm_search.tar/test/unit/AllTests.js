sap.ui.define([
	"comgrtgzewmsearch/zewm_search/test/unit/controller/App.controller"
], function () {
	"use strict";
});

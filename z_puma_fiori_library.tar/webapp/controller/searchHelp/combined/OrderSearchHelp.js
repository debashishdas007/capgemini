sap.ui.define([
	"./CombinedSearchHelp",
	"../unitary/OrderTypeSearchHelp",
	"../selectionMode/SimpleSelectionMode",
	"../unitary/WorkCenterSearchHelp",
	"../unitary/WorkTypeSearchHelp",
	"./FunctionalLocationSearchHelp",
	"./EquipmentSearchHelp",
	"../unitary/MaintenancePlantSearchHelp",
    "../unitary/PlannerGroupSearchHelp",
    "../unitary/PlantSectionSearchHelp",
	"../../../model/models"
], function(CombinedSearchHelp, OrderTypeSearchHelp, SimpleSelectionMode, WorkCenterSearchHelp, WorkTypeSearchHelp, 
FunctionalLocationSearchHelp, EquipmentSearchHelp, MaintenancePlantSearchHelp, PlannerGroupSearchHelp, PlantSectionSearchHelp, Models) {
	"use strict";
    
    /**
     * Aide à la recherche de l'ordre
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.OrderSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.CombinedSearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-274
     * Par : Alexandre PISSOTTE (APY)
     * Date : 06/08/2021
     * Motif : Rajouter la désignation d'installation dans le résultat de 
     * recherche d'équipement, du poste technique, de l'ordre et de l'avis
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
	return CombinedSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.OrderSearchHelp", {
		constructor: function(oController, oSelectionMode) {
			CombinedSearchHelp.call(this,
				oController,
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.combined.OrderSearchHelp",
				oSelectionMode
			);
			this._aSystemStatusFilters = [];
		},
		
		_getFragmentClassName: function() {
			return ;
		},
		
		getKey: function() {
			return "AUFNR";
		},
		
		getI18nKey: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("orderNumber");
		},
		
		getDescription: function() {
			return "KTEXT";
		},
		
		getI18nDescription: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("orderDescription");
		},
		
		_getODataEntitySet: function() {
			return "/OrderSet";
        },
        
        addColumns: function() {
			return [				
                "ZPLTXT" // GMAO-274
			];
		},
		
		addI18nColumns: function(oi18nModel) {
			return [				
                oi18nModel.getResourceBundle().getText("designationSite"), // GMAO-274
			];
		},
		
		_addModels: function() {
			this._oFragment.setModel(Models.createOrderSearchHelpModel(), "frgModel");
			this._oFragment.setModel(new sap.ui.model.json.JSONModel({
				selected: ["I0002"],
				items: [{
						STAT: "I0002",
						TXT30: this._oFragment.getModel("i18n").getResourceBundle().getText("LANC")
					}, {
						STAT: "I0001",
						TXT30: this._oFragment.getModel("i18n").getResourceBundle().getText("OUV.")
					}, {
						STAT: "I0045",
						TXT30: this._oFragment.getModel("i18n").getResourceBundle().getText("TCLO")
					}, {
						STAT: "I0046",
						TXT30: this._oFragment.getModel("i18n").getResourceBundle().getText("CLOT")
					}
				]
			}), "systemStatus");
		},
		
		_prepareFilters: function(oEvent) {
			CombinedSearchHelp.prototype._prepareFilters.call(this, oEvent);
			
			if (this._oFragment.getModel("frgModel").getProperty("/ARBPL") !== "") {
				this._aFilters.push(new sap.ui.model.Filter({
					path: "WAWRK",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._oFragment.getModel("frgModel").getProperty("/WAWRK")
				}));
			}
			
			if (this._aSystemStatusFilters.length > 0) {
				this._aFilters.push(new sap.ui.model.Filter(this._aSystemStatusFilters, false));
			}
		},
		
		onSystemStatusSelectionChange: function(oEvent) {
			this._aSystemStatusFilters = [];
			
			oEvent.getSource().getSelectedKeys().forEach(function(key) {
				this._aSystemStatusFilters.push(new sap.ui.model.Filter({
					path: oEvent.getSource().getName(),
					operator: sap.ui.model.FilterOperator.EQ,
					value1: key
				}));
			}.bind(this));
		},
		
		onOrderTypeValueHelpRequest: function() {
			if (!this._orderTypeSearchHelp) {
				this._orderTypeSearchHelp = new OrderTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/AUART"));
			}
			this._orderTypeSearchHelp.open();
		},
		
		onWorkCenterValueHelpRequest: function() {
			if (!this._workCenterSearchHelp) {
				this._workCenterSearchHelp = new WorkCenterSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/ARBPL", "/WAWRK"));
			}
			this._workCenterSearchHelp.open();
		},
		
		onWorkTypeValueHelpRequest: function() {
			if (!this._workTypeSearchHelp) {
				this._workTypeSearchHelp = new WorkTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/ILART"));
			}
			this._workTypeSearchHelp.open();
		},
		
		onFunctionalLocationValueHelpRequest: function() {
			if (!this._functionalLocationSearchHelp) {
				this._functionalLocationSearchHelp = new FunctionalLocationSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/TPLNR"));
			}
			this._functionalLocationSearchHelp.open();
		},
		
		onEquipmentValueHelpRequest: function() {
			if (!this._equipmentSearchHelp) {
				this._equipmentSearchHelp = new EquipmentSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/EQUNR"));
			}
			this._equipmentSearchHelp.open();
		},
		
		onMaintenancePlantValueHelpRequest: function() {
			if (!this._maintenancePlantSearchHelp) {
				this._maintenancePlantSearchHelp = new MaintenancePlantSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/SWERK"));
			}
			this._maintenancePlantSearchHelp.open();
		},
		
		onPlannerGroupValueHelpRequest: function() {
			if (!this._plannerGroupSearchHelp) {
				this._plannerGroupSearchHelp = new PlannerGroupSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/INGRP"));
			}
			this._plannerGroupSearchHelp.open();
        },
        
        /**
         * Ouvre l'aide à la recherche du secteur d'exploitation.
         * 
         * @public
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-467
         * Par : Alexandre PISSOTTE (APY)
         * Date : 05/11/2021
         * Motif : Ajout des champs Désignation site (ZPLTXT) et secteur 
         * d'exploitation (BEBER) comme filtre dans la recherche des ordres.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onPlantSectionValueHelpRequest: function() {
			if (!this._plantSectionSearchHelp) {
				this._plantSectionSearchHelp = new PlantSectionSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/BEBER"));
			}
			this._plantSectionSearchHelp.open();
		}
	});
});
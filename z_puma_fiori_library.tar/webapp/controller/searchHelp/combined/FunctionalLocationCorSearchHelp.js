sap.ui.define([
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp"
], function(FunctionalLocationSearchHelp) {
    "use strict";

    /**
     * Aide à la recherche hiérarchique du poste technique avec option correctif ZCO1
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationCorSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     * @param {string} sFunctionalLocationNumber Numéro de poste fonctionnel
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-529
     * Par : Alexandre PISSOTTE (APY)
     * Date : 08/12/2021
     * Motif : Permettre la recherche hiérarchique des postes techniques
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
    return FunctionalLocationSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationCorSearchHelp", {
        _prepareFilters: function(oEvent) {
            FunctionalLocationSearchHelp.prototype._prepareFilters.call(this, oEvent);

            this._aFilters.push(new sap.ui.model.Filter({
                path: "ZZ_OT_ZCO1",
                operator: sap.ui.model.FilterOperator.EQ,
                value1: "X"
            }));
        }
    });
});
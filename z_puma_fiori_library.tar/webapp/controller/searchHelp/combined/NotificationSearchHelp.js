sap.ui.define([
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/CombinedSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/NotificationTypeSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/MaintenancePlantSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/OrderSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkCenterSearchHelp"
], function(CombinedSearchHelp, SimpleSelectionMode,
	FunctionalLocationSearchHelp, EquipmentSearchHelp, NotificationTypeSearchHelp, MaintenancePlantSearchHelp, OrderSearchHelp, WorkCenterSearchHelp) {
	"use strict";

    /**
     * Aide à la recherche de l'avis
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.NotificationSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.CombinedSearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-274
     * Par : Alexandre PISSOTTE (APY)
     * Date : 06/08/2021
     * Motif : Rajouter la désignation d'installation dans le résultat de 
     * recherche d'équipement, du poste technique, de l'ordre et de l'avis
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
	return CombinedSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.NotificationSearchHelp", {
		constructor: function(oController, oSelectionMode) {
			CombinedSearchHelp.call(this,
				oController,
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.combined.NotificationSearchHelp",
				oSelectionMode
			);
		},

		getKey: function() {
			return "QMNUM";
		},

		getI18nKey: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("notificationNumber");
		},

		getDescription: function() {
			return "QMTXT";
		},

		getI18nDescription: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("notificationDescription");
		},

		_getODataEntitySet: function() {
			return "/PMNotificationSet";
        },
        
        addColumns: function() {
			return [				
                "ZPLTXT" // GMAO-274
			];
		},
		
		addI18nColumns: function(oi18nModel) {
			return [				
                oi18nModel.getResourceBundle().getText("designationSite"), // GMAO-274
			];
		},

		_addModels: function() {
			this._oFragment.setModel(new sap.ui.model.json.JSONModel({
				"INGRP": "",
				"CLASS": "",
				"KLART": "",
				"SWERK": "",
				"STORT": "",
				"BEBER": "",
				"VAPLZ": "",
				"WAWRK": ""
			}), "frgModel");
		}, 
		
		_prepareFilters: function(oEvent) {
			CombinedSearchHelp.prototype._prepareFilters.call(this, oEvent);
			
			if (this._oFragment.getModel("frgModel").getProperty("/VAPLZ") !== "") {
				this._aFilters.push(new sap.ui.model.Filter({
					path: "WAWRK",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this._oFragment.getModel("frgModel").getProperty("/WAWRK")
				}));
			}
		},
		
		onFunctionalLocationValueHelpRequest: function() {
			if (!this._functionalLocationSearchHelp) {
				this._functionalLocationSearchHelp = new FunctionalLocationSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/TPLNR"));
			}
			this._functionalLocationSearchHelp.open();
		},
		
		onEquipmentValueHelpRequest: function() {
			if (!this._equipmentSearchHelp) {
				this._equipmentSearchHelp = new EquipmentSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/EQUNR"));
			}
			this._equipmentSearchHelp.open();
		},
		
		onNotificationTypeValueHelpRequest: function() {
			if (!this._notificationTypeSearchHelp) {
				this._notificationTypeSearchHelp = new NotificationTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/QMART"));
			}
			this._notificationTypeSearchHelp.open();
		},
		
		onMaintenancePlantValueHelpRequest: function() {
			if (!this._maintenancePlantSearchHelp) {
				this._maintenancePlantSearchHelp = new MaintenancePlantSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/SWERK"));
			}
			this._maintenancePlantSearchHelp.open();
		},
		
		onWorkCenterValueHelpRequest: function() {
			if (!this._workCenterSearchHelp) {
				this._workCenterSearchHelp = new WorkCenterSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/VAPLZ", "/WAWRK"));
			}
			this._workCenterSearchHelp.open();
		},
		
		onOrderValueHelpRequest: function() {
			if (!this._orderSearchHelp) {
				this._orderSearchHelp = new OrderSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/AUFNR"));
			}
			this._orderSearchHelp.open();
		}
	});
});
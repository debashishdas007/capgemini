sap.ui.define([
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentSearchHelp"
], function(EquipmentSearchHelp) {
	"use strict";

	return EquipmentSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.EquipmentCreateSearchHelp", {
		_prepareFilters: function(oEvent) {
			EquipmentSearchHelp.prototype._prepareFilters.call(this, oEvent);
			
			this._aFilters.push(new sap.ui.model.Filter({
				path: "ZZ_CREATE",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "X"
			}));
		}
	});
});
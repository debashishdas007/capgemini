sap.ui.define([
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/CombinedSearchHelp"
], function(CombinedSearchHelp) {
	"use strict";

	return CombinedSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.EntryListSearchHelp", {
		constructor: function(oController, oSelectionMode) {
			CombinedSearchHelp.call(this,
				oController,
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.combined.EntryListSearchHelp",
				oSelectionMode
			);
		},

		getKey: function() {
			return "MELNR";
		},

		getI18nKey: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("entryListNumber");
		},

		getDescription: function() {
			return "NAMEL";
		},

		getI18nDescription: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("entryListDescription");
		},

		_getODataEntitySet: function() {
			return "/EntryListSet";
		},

		_addModels: function() {
			this._oFragment.setModel(new sap.ui.model.json.JSONModel({}), "frgModel");
		}
	});
});
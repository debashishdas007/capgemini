sap.ui.define([
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/CombinedSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/ClassSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/MaterialSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/StorageLocationSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/EquipmentCategorySearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/ObjectTypeSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/PlannerGroupSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkCenterSearchHelp",
	"../../../model/models"
], function(CombinedSearchHelp, SimpleSelectionMode,
	FunctionalLocationSearchHelp, ClassSearchHelp, MaterialSearchHelp, StorageLocationSearchHelp, EquipmentCategorySearchHelp, ObjectTypeSearchHelp, PlannerGroupSearchHelp, WorkCenterSearchHelp, Models) {
	"use strict";

    /**
     * Aide à la recherche de l'équipement
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.CombinedSearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     * @param {string} sFunctionalLocationNumber Numéro de poste fonctionnel
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-274
     * Par : Alexandre PISSOTTE (APY)
     * Date : 06/08/2021
     * Motif : Rajouter la désignation d'installation dans le résultat de 
     * recherche d'équipement, du poste technique, de l'ordre et de l'avis
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
	return CombinedSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp", {
		constructor: function(oController, oSelectionMode, sFunctionalLocationNumber) {
			CombinedSearchHelp.call(this,
				oController,
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.combined.EquipmentSearchHelp",
				oSelectionMode
			);
			this._sFunctionalLocationNumber = sFunctionalLocationNumber;
		},

		getKey: function() {
			return "EQUNR";
		},

		getI18nKey: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("equipmentNumber");
		},

		getDescription: function() {
			return "EQKTX";
		},

		getI18nDescription: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("equipmentDescription");
		},

		_getODataEntitySet: function() {
			return "/EquipmentSet";
		},
		
		addColumns: function() {
			return [                
				"EQART",
				"SERGE",
                "ARBPL",
                "ZPLTXT", // GMAO-274
			];
		},
		
		addI18nColumns: function(oi18nModel) {
			return [                
				oi18nModel.getResourceBundle().getText("objectType"),
				oi18nModel.getResourceBundle().getText("serialNumber"),
                oi18nModel.getResourceBundle().getText("workCenter"),
                oi18nModel.getResourceBundle().getText("designationSite"), // GMAO-274
			];
		},

		_addModels: function() {
			this._oFragment.setModel(new sap.ui.model.json.JSONModel({
				"CLASS": "", // Numéro de la classe
				"MATNR": "", // Numéro de l'article
				"LGORT": "",  // Magasin
				"TPLNR": this._sFunctionalLocationNumber
			}), "frgModel");
		},
		
		_prepareFilters: function(oEvent) {
			CombinedSearchHelp.prototype._prepareFilters.call(this, oEvent);
			
			if (this._oFragment.getModel("frgModel").getProperty("/CLASS") !== "") {
				this._aFilters.push(new sap.ui.model.Filter({
					path: "KLART",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "002"
				}));
			}
		},
		
		onEquipmentCategoryValueHelpRequest: function() {
			if (!this._equipmentCategorySearchHelp) {
				this._equipmentCategorySearchHelp = new EquipmentCategorySearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/EQTYP"));
			}
			this._equipmentCategorySearchHelp.open();
		},
		
		onObjectTypeValueHelpRequest: function() {
			if (!this._objectTypeSearchHelp) {
				this._objectTypeSearchHelp = new ObjectTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/EQART"));
			}
			this._objectTypeSearchHelp.open();
		},
		
		onPlannerGroupValueHelpRequest: function() {
			if (!this._plannerGroupSearchHelp) {
				this._plannerGroupSearchHelp = new PlannerGroupSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/INGRP"));
			}
			this._plannerGroupSearchHelp.open();
		},
		
		onWorkCenterValueHelpRequest: function() {
			if (!this._workCenterSearchHelp) {
				this._workCenterSearchHelp = new WorkCenterSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/ARBPL", "/WAWRK"));
			}
			this._workCenterSearchHelp.open();
		},
		
		onFunctionalLocationValueHelpRequest: function() {
			if (!this._functionalLocationSearchHelp) {
				this._functionalLocationSearchHelp = new FunctionalLocationSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/TPLNR"));
			}
			this._functionalLocationSearchHelp.open();
		},
		
		onClassValueHelpRequest: function() {
			if (!this._classSearchHelp) {
				this._classSearchHelp = new ClassSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/CLASS", "/KLART"), "002");
			}
			this._classSearchHelp.open();
		},
		
		onMaterialValueHelpRequest: function() {
			if (!this._materialSearchHelp) {
				this._materialSearchHelp = new MaterialSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/MATNR"));
			}
			this._materialSearchHelp.open();
		},
		
		onStorageLocationValueHelpRequest: function() {
			if (!this._storageLocationSearchHelp) {
				this._storageLocationSearchHelp = new StorageLocationSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/LGORT"));
			}
			this._storageLocationSearchHelp.open();
		}
	});
});
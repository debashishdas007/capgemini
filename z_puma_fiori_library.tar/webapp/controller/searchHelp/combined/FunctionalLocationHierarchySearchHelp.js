sap.ui.define([
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/CombinedSearchHelp"
], function(CombinedSearchHelp) {
    "use strict";

    /**
     * Aide à la recherche hiérarchique du poste technique
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationHierarchySearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.CombinedSearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     * @param {string} sFunctionalLocationNumber Numéro de poste fonctionnel
     * @param {string} sPlantSection Plant
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-529
     * Par : Alexandre PISSOTTE (APY)
     * Date : 08/12/2021
     * Motif : Permettre la recherche hiérarchique des postes techniques
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
    return CombinedSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationHierarchySearchHelp", {

        constructor: function(oController, oSelectionMode, sFunctionalLocationNumber, sPlantSection) {
            CombinedSearchHelp.call(this,
                oController,
                "com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.combined.FunctionalLocationHierarchySearchHelp",
                oSelectionMode
            );
            this._sFunctionalLocationNumber = sFunctionalLocationNumber;
            this._sPlantSection = sPlantSection;
        },

        defineTable: function() {
            var oTable = this._oFragment.getTable();

            // Définition du type de table
            switch (oTable.getMetadata().getName()) {
                case "sap.ui.table.Table":
                    oTable = new sap.ui.table.TreeTable({
                        enableColumnReordering: false,
                        expandFirstLevel: true,
                        selectionBehavior: sap.ui.table.SelectionBehavior.Row,
                        selectionMode: sap.ui.table.SelectionMode.Single
                    });
                    oTable.setRowSettingsTemplate(new sap.ui.table.RowSettings({
                        highlight: "{treeModel>ZF_COLOR}"
                    }))
                    break;
                case "sap.m.Table":
                    oTable = new sap.m.Table();
                    break;
            }

            // Ajout du modèle JSON contenant les postes techniques
            oTable.setModel(this._oFragment.getModel("treeModel"), "treeModel");

            // Ajout des colonnes obligatoires
            switch (oTable.getMetadata().getName()) {
                case "sap.ui.table.TreeTable":
                    oTable.addColumn(new sap.ui.table.Column({
                        label: new sap.m.Label({
                            text: this.getI18nKey(this._oFragment.getModel("i18n"))
                        }),
                        template: new sap.m.Text({ wrapping: false }).bindProperty("text", "treeModel>" + this.getKey()),
                        width: "30%"
                    }));
                    oTable.addColumn(new sap.ui.table.Column({
                        label: new sap.m.Label({
                            text: this.getI18nDescription(this._oFragment.getModel("i18n"))
                        }),
                        template: new sap.m.Text().bindProperty("text", "treeModel>" + this.getDescription())
                    }));
                    break;
                case "sap.m.Table":
                    oTable.addColumn(new sap.m.Column({
                        header: new sap.m.Label({
                            text: this.getI18nKey(this._oFragment.getModel("i18n"))
                        })
                    }));
                    oTable.addColumn(new sap.m.Column({
                        header: new sap.m.Label({
                            text: this.getI18nDescription(this._oFragment.getModel("i18n"))
                        })
                    }));
                    break;
            }

            // Récupération des textes pour le nom des colonnes
            var aPropertyColumns = this.addColumns(this._oFragment.getModel("i18n"));

            // Récupération des propriétés de l'entité
            var aI18nColumns = this.addI18nColumns(this._oFragment.getModel("i18n"));

            // Ajout des colonnes additionnelles
            if (aI18nColumns && aPropertyColumns && aI18nColumns.length === aPropertyColumns.length) {
                switch (oTable.getMetadata().getName()) {
                    case "sap.ui.table.TreeTable":
                        aPropertyColumns.forEach(function(value, index) {
                            oTable.addColumn(new sap.ui.table.Column({
                                label: new sap.m.Label({
                                    text: aI18nColumns[index]
                                }),
                                template: new sap.m.Text().bindProperty("text", "treeModel>" + value)
                            }));
                        });
                        break;
                    case "sap.m.Table":
                        aPropertyColumns.forEach(function(value, index) {
                            oTable.addColumn(new sap.m.Column({
                                header: new sap.m.Label({
                                    text: aI18nColumns[index]
                                })
                            }));
                        });
                        break;
                }
            }

            this._oFragment.setTable(oTable);
        },

        getKey: function() {
            return "TPLNR";
        },

        getI18nKey: function(oi18nModel) {
            return oi18nModel.getResourceBundle().getText("functionalLocationNumber");
        },

        getDescription: function() {
            return "PLTXT";
        },

        getI18nDescription: function(oi18nModel) {
            return oi18nModel.getResourceBundle().getText("functionalLocationDescription");
        },

        _getODataEntitySet: function() {
            return "/FunctionalLocationSet";
        },

        /**
         * Définit les colonnes complémentaires pour l'aide à la recherche
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-511
         * Par : Alexandre PISSOTTE (APY)
         * Date : 17/12/2021
         * Motif : Afficher le repère site dans le résultat des recherches
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        addColumns: function() {
            return [
                "EQFNR",
                "EQART",
                "FLTYP",
                "ARBPL",
                "ZPLTXT" // GMAO-274                
            ];
        },

        /**
         * Définit les textes des colonnes complémentaires pour l'aide à la 
         * recherche
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-511
         * Par : Alexandre PISSOTTE (APY)
         * Date : 17/12/2021
         * Motif : Afficher le repère site dans le résultat des recherches
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        addI18nColumns: function(oi18nModel) {
            return [
                oi18nModel.getResourceBundle().getText("repereSite"),
                oi18nModel.getResourceBundle().getText("objectType"),
                oi18nModel.getResourceBundle().getText("functionalLocationType"),
                oi18nModel.getResourceBundle().getText("workCenter"),
                oi18nModel.getResourceBundle().getText("designationSite"), // GMAO-274                
            ];
        },

        _addModels: function() {
            var sValueState = sap.ui.core.ValueState.Error;

            if (this._sFunctionalLocationNumber && !this._sFunctionalLocationNumber.endsWith("*")) {
                this._sFunctionalLocationNumber = this._sFunctionalLocationNumber + "*";
                sValueState = sap.ui.core.ValueState.None;
            }

            this._oFragment.setModel(new sap.ui.model.json.JSONModel({
                "INGRP": "",
                "CLASS": "",
                "KLART": "",
                "SWERK": "",
                "STORT": "",
                "BEBER": this._sPlantSection,
                "FLTYP": "",
                "ZValueState": sValueState,
                "TPLNR": this._sFunctionalLocationNumber
            }), "frgModel");

            this._oFragment.setModel(new sap.ui.model.json.JSONModel(), "treeModel");
        },

        _prepareFilters: function(oEvent) {
            CombinedSearchHelp.prototype._prepareFilters.call(this, oEvent);

            if (this._oFragment.getModel("frgModel").getProperty("/CLASS") !== "") {
                this._aFilters.push(new sap.ui.model.Filter({
                    path: "KLART",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: "003"
                }));
            }

            // Indique à l'oData qu'il s'agit d'une recherche hiérarchique
            this._aFilters.push(new sap.ui.model.Filter({
                path: "ZZ_HIERARCHY",
                operator: sap.ui.model.FilterOperator.EQ,
                value1: true
            }));
        },

        _filterTable: function(oFilter, fragmentInstance, entityset, firstCellBinding, secondCellBinding) {
            var oValueHelpDialog = fragmentInstance;
            var oTable = oValueHelpDialog.getTable();

            oValueHelpDialog.setBusy(true);

            // Recherche hiérarchique des postes techniques
            this._getFragment().getModel().read(entityset, {
                filters: [oFilter],
                success: function(odata) {
                    // Transformation de la table (flat) en table deep
                    // Utilisation des références croisées
                    odata.results.forEach((value, index, array) => {
                        delete value.__metadata;
                        switch (value.FLTYP) {
                            case "E":
                                value.ZF_COLOR = sap.ui.core.IndicationColor.Indication05
                                break;
                            case "M":
                                value.ZF_COLOR = sap.ui.core.IndicationColor.Indication08
                                break;
                            case "S":
                                value.ZF_COLOR = sap.ui.core.IndicationColor.Indication03
                                break;
                            case "T":
                                value.ZF_COLOR = sap.ui.core.IndicationColor.Indication04
                                break;
                        }
                        value.children = array.filter(x => x.TPLMA === value.TPLNR);
                    });

                    // Conservation de la première ligne
                    this._oFragment.getModel("treeModel").setData({ children: odata.results[0] });

                    oValueHelpDialog.setBusy(false)
                }.bind(this),
                error: function() {
                    oValueHelpDialog.setBusy(false);
                    this._oFragment.getModel("treeModel").setData();
                }.bind(this)
            });

            // Cas d'un sap.ui.table.TreeTable
            if (oTable.bindRows) {
                oTable.bindRows({
                    model: "treeModel",
                    path: "/",
                    parameters: {
                        arrayNames: ['children']
                    }
                });
            }

            // Cas d'un sap.m.table
            if (oTable.bindItems) {
                oTable.bindAggregation("items", {
                    model: "treeModel",
                    path: entityset,
                    filters: oFilter,
                    factory: function() {
                        return new sap.m.ColumnListItem({
                            type: "Active",
                            cells: [
                                new sap.m.Text({
                                    text: firstCellBinding
                                }),
                                new sap.m.Text({
                                    text: secondCellBinding
                                })
                            ]
                        });
                    }
                });
            }

            oValueHelpDialog.update();
        },

        onSearch: function(oEvent) {
            if (this._sFunctionalLocationNumber && this._sFunctionalLocationNumber !== "") {
                CombinedSearchHelp.prototype.onSearch.call(this, oEvent);
            } else {
                if (this._oFragment.getModel("frgModel").getProperty("/INGRP") !== "" || this._oFragment.getModel("frgModel").getProperty("/BEBER") !== "") {
                    CombinedSearchHelp.prototype.onSearch.call(this, oEvent);
                } else {
                    sap.m.MessageBox.error(this._oFragment.getModel("i18n").getResourceBundle().getText("plannerGroupOrPlantSectionMandatory"));
                }
            }
        },

        /**
         * Vérifie la présence d'un groupe gestionnaire OU d'un secteur d'exploitation
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-458
         * Par : Alexandre PISSOTTE (APY)
         * Date : 28/10/2021
         * Motif : Ajouter les variantes sur les filtres de l'aide à la recherche
         * de l'équipement et du poste technique. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onLiveChange: function(oEvent) {
            let bIsValid = false;

            // On arrive depuis la sélection de l'aide à la recherche => comparaison sur les modèles
            if (!oEvent) {
                if (this._oFragment.getModel("frgModel").getProperty("/INGRP") || this._oFragment.getModel("frgModel").getProperty("/BEBER")) {
                    bIsValid = true;
                }

                // On arrive depuis le live update d'un input => comparaison de la valeur champ mis à jour contre le modèle de l'autre input
            } else {
                if (oEvent.getSource().getName() == "INGRP") {
                    if (oEvent.getSource().getValue() || this._oFragment.getModel("frgModel").getProperty("/BEBER")) {
                        bIsValid = true;
                    }
                } else {
                    if (oEvent.getSource().getValue() || this._oFragment.getModel("frgModel").getProperty("/INGRP")) {
                        bIsValid = true;
                    }
                }
            }

            if (bIsValid) {
                this._oFragment.getModel("frgModel").setProperty("/ZValueState", sap.ui.core.ValueState.None);
            } else {
                this._oFragment.getModel("frgModel").setProperty("/ZValueState", sap.ui.core.ValueState.Error);
            }
        },

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-225 (3) Alexandre PISSOTTE (APY)
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        onFunctionalLocationTypeValueHelpRequest: function() {
            if (!this._functionalLocationTypeSearchHelp) {
                this._functionalLocationTypeSearchHelp = new FunctionalLocationTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/FLTYP"));
            }
            this._functionalLocationTypeSearchHelp.open();
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-255 (3) Alexandre PISSOTTE (APY)
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        onObjectTypeValueHelpRequest: function() {
            if (!this._objectTypeSearchHelp) {
                this._objectTypeSearchHelp = new ObjectTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/EQART"));
            }
            this._objectTypeSearchHelp.open();
        },

        onPlannerGroupValueHelpRequest: function() {
            if (!this._plannerGroupSearchHelp) {
                this._plannerGroupSearchHelp = new PlannerGroupSearchHelp(this._oController, new ObjectSimpleSelectionMode(this._oFragment.getModel("frgModel"), function(oObject) {
                    this._oFragment.getModel("frgModel").setProperty("/INGRP", oObject.INGRP);
                    this.onLiveChange();
                }.bind(this)));
            }
            this._plannerGroupSearchHelp.open();
        },

        onClassValueHelpRequest: function() {
            if (!this._classSearchHelp) {
                this._classSearchHelp = new ClassSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/CLASS", "/KLART"), "003");
            }
            this._classSearchHelp.open();
        },

        onMaintenancePlantValueHelpRequest: function() {
            if (!this._maintenancePlantSearchHelp) {
                this._maintenancePlantSearchHelp = new MaintenancePlantSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/SWERK"));
            }
            this._maintenancePlantSearchHelp.open();
        },

        onLocationValueHelpRequest: function() {
            if (!this._locationSearchHelp) {
                this._locationSearchHelp = new LocationSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/STORT"));
            }
            this._locationSearchHelp.open();
        },

        onPlantSectionValueHelpRequest: function() {
            if (!this._plantSectionSearchHelp) {
                this._plantSectionSearchHelp = new PlantSectionSearchHelp(this._oController, new ObjectSimpleSelectionMode(this._oFragment.getModel("frgModel"), function(oObject) {
                    this._oFragment.getModel("frgModel").setProperty("/BEBER", oObject.BEBER);
                    this.onLiveChange();
                }.bind(this)));
            }
            this._plantSectionSearchHelp.open();
        }

    });
});
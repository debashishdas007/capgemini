sap.ui.define([
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/CombinedSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/PlannerGroupSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/ClassSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/MaintenancePlantSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/LocationSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/PlantSectionSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/FunctionalLocationTypeSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/ObjectTypeSearchHelp"
], function(CombinedSearchHelp, SimpleSelectionMode, ObjectSimpleSelectionMode,
    PlannerGroupSearchHelp, ClassSearchHelp, MaintenancePlantSearchHelp, LocationSearchHelp, PlantSectionSearchHelp, FunctionalLocationTypeSearchHelp, ObjectTypeSearchHelp) {
    "use strict";

    /**
     * Aide à la recherche du poste technique
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.CombinedSearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     * @param {string} sFunctionalLocationNumber Numéro de poste fonctionnel
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-274
     * Par : Alexandre PISSOTTE (APY)
     * Date : 06/08/2021
     * Motif : Rajouter la désignation d'installation dans le résultat de 
     * recherche d'équipement, du poste technique, de l'ordre et de l'avis
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
    return CombinedSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp", {
        /**
         * Constructeur de l'aide à la recherche des postes techniques
         * 
         * @public
         * 
         * @param {sap.ui.core.mvc.Controller} oController 
         * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode 
         * @param {string} sFunctionalLocationNumber 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-436
         * Par : Alexandre PISSOTTE (APY)
         * Date : 10/11/2021
         * Motif : Faire passer à l'aide à la recherche du poste technique, le 
         * secteur d'exploitation et le poste technique suffixé d'une étoile
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        constructor: function(oController, oSelectionMode, sFunctionalLocationNumber, sPlantSection) {
            CombinedSearchHelp.call(this,
                oController,
                "com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.combined.FunctionalLocationSearchHelp",
                oSelectionMode
            );
            this._sFunctionalLocationNumber = sFunctionalLocationNumber;
            this._sPlantSection = sPlantSection;
        },

        defineTable: function() {
            var oTable = this._oFragment.getTable();
            console.log(oTable)

            // Détermination du type de table
            var sClassNameSelected = this._oFragment.getModel("searchTypeModel").getProperty("/types")
                .find(value => value.key === this._oFragment.getModel("searchTypeModel").getProperty("/selectedKey"))?.className;

            if (!sClassNameSelected) {
                sClassNameSelected = oTable.getMetadata().getName();
            }

            // sClassNameSelected = "sap.ui.table.TreeTable";
            console.log(sClassNameSelected);

            // Nécessite une reconstruction
            if (this._oFragment.getTable().getMetadata().getName() !== sClassNameSelected) {
                switch (sClassNameSelected) {
                    case "sap.ui.table.Table":
                        oTable = new sap.ui.table.Table(oTable.getId() - "table", {
                            selectionBehavior: sap.ui.table.SelectionBehavior.Row,
                            selectionMode: sap.ui.table.SelectionMode.Single
                        });
                        break;

                    case "sap.ui.table.TreeTable":
                        oTable = new sap.ui.table.TreeTable(oTable.getId() - "table", {
                            enableColumnReordering: false,
                            expandFirstLevel: true,
                            selectionBehavior: sap.ui.table.SelectionBehavior.Row,
                            selectionMode: sap.ui.table.SelectionMode.Single
                        });

                        oTable.addStyleClass("sapUiTableEmpty")

                        // Coloration des lignes en fonction du type de poste technique
                        oTable.setRowSettingsTemplate(new sap.ui.table.RowSettings({
                            highlight: "{treeModel>ZF_COLOR}"
                        }))

                        // Ajout du modèle JSON contenant les postes techniques
                        oTable.setModel(this._oFragment.getModel("treeModel"), "treeModel");
                        break;

                    case "sap.m.Table":
                        oTable = new sap.m.Table(oTable.getId() - "table");
                        break;
                }

                // La table devient occupée
                oTable.setEnableBusyIndicator(true);
            }

            // Première construction ou reconstruction
            if (oTable.getColumns().length === 0) {
                // Ajout des colonnes obligatoires
                switch (oTable.getMetadata().getName()) {
                    case "sap.ui.table.Table":
                        oTable.addColumn(new sap.ui.table.Column({
                            label: new sap.m.Label({
                                text: this.getI18nKey(this._oFragment.getModel("i18n"))
                            }),
                            template: new sap.m.Text().bindProperty("text", this.getKey())
                        }));
                        oTable.addColumn(new sap.ui.table.Column({
                            label: new sap.m.Label({
                                text: this.getI18nDescription(this._oFragment.getModel("i18n"))
                            }),
                            template: new sap.m.Text().bindProperty("text", this.getDescription())
                        }));
                        break;

                    case "sap.ui.table.TreeTable":
                        oTable.addColumn(new sap.ui.table.Column({
                            label: new sap.m.Label({
                                text: this.getI18nKey(this._oFragment.getModel("i18n"))
                            }),
                            template: new sap.m.Text({ wrapping: false }).bindProperty("text", "treeModel>" + this.getKey()),
                            width: "30%"
                        }));
                        oTable.addColumn(new sap.ui.table.Column({
                            label: new sap.m.Label({
                                text: this.getI18nDescription(this._oFragment.getModel("i18n"))
                            }),
                            template: new sap.m.Text().bindProperty("text", "treeModel>" + this.getDescription())
                        }));
                        break;

                    case "sap.m.Table":
                        oTable.addColumn(new sap.m.Column({
                            header: new sap.m.Label({
                                text: this.getI18nKey(this._oFragment.getModel("i18n"))
                            }),
                            template: new sap.m.Text().bindProperty("text", this.getKey())
                        }));
                        oTable.addColumn(new sap.m.Column({
                            header: new sap.m.Label({
                                text: this.getI18nDescription(this._oFragment.getModel("i18n"))
                            }),
                            template: new sap.m.Text().bindProperty("text", this.getDescription())
                        }));
                        break;
                }

                // Récupération des textes pour le nom des colonnes
                var aPropertyColumns = this.addColumns(this._oFragment.getModel("i18n"));

                // Récupération des propriétés de l'entité
                var aI18nColumns = this.addI18nColumns(this._oFragment.getModel("i18n"));

                // Ajout des colonnes addtionnelles
                if (aI18nColumns && aPropertyColumns && aI18nColumns.length === aPropertyColumns.length) {
                    aPropertyColumns.forEach(function(value, index) {
                        // Ajout des colonnes à la table // Add the table columns' properties and binding 
                        switch (oTable.getMetadata().getName()) {
                            case "sap.ui.table.Table":
                                oTable.addColumn(new sap.ui.table.Column({
                                    label: new sap.m.Label({
                                        text: aI18nColumns[index]
                                    }),
                                    template: new sap.m.Text().bindProperty("text", value)
                                }));
                                break;

                            case "sap.ui.table.TreeTable":
                                oTable.addColumn(new sap.ui.table.Column({
                                    label: new sap.m.Label({
                                        text: aI18nColumns[index]
                                    }),
                                    template: new sap.m.Text().bindProperty("text", "treeModel>" + value)
                                }));
                                break;

                            case "sap.m.Table":
                                oTable.addColumn(new sap.m.Column({
                                    header: new sap.m.Label({
                                        text: aI18nColumns[index]
                                    }),
                                    template: new sap.m.Text().bindProperty("text", value)
                                }));
                                break;
                        }
                    });
                }

                if (this._oFragment.getTable().getMetadata().getName() !== sClassNameSelected) {
                    this._oFragment.setTable(oTable, true);
                }
            }
        },

        getKey: function() {
            return "TPLNR";
        },

        getI18nKey: function(oi18nModel) {
            return oi18nModel.getResourceBundle().getText("functionalLocationNumber");
        },

        getDescription: function() {
            return "PLTXT";
        },

        getI18nDescription: function(oi18nModel) {
            return oi18nModel.getResourceBundle().getText("functionalLocationDescription");
        },

        _getODataEntitySet: function() {
            return "/FunctionalLocationSet";
        },

        /**
         * Définit les colonnes complémentaires pour l'aide à la recherche
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-511
         * Par : Alexandre PISSOTTE (APY)
         * Date : 17/12/2021
         * Motif : Afficher le repère site dans le résultat des recherches
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        addColumns: function() {
            return [
                "EQFNR",
                "EQART",
                "FLTYP",
                "ARBPL",
                "ZPLTXT" // GMAO-274                
            ];
        },

        /**
         * Définit les textes des colonnes complémentaires pour l'aide à la 
         * recherche
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-511
         * Par : Alexandre PISSOTTE (APY)
         * Date : 17/12/2021
         * Motif : Afficher le repère site dans le résultat des recherches
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        addI18nColumns: function(oi18nModel) {
            return [
                oi18nModel.getResourceBundle().getText("repereSite"),
                oi18nModel.getResourceBundle().getText("objectType"),
                oi18nModel.getResourceBundle().getText("functionalLocationType"),
                oi18nModel.getResourceBundle().getText("workCenter"),
                oi18nModel.getResourceBundle().getText("designationSite"), // GMAO-274                
            ];
        },

        /**
         * Ajoute du modèle spécifique pour l'aide à la recherche
         * 
         * @private
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-436
         * Par : Alexandre PISSOTTE (APY)
         * Date : 10/11/2021
         * Motif : Faire passer à l'aide à la recherche du poste technique, le 
         * secteur d'exploitation et le poste technique suffixé d'une étoile
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-552
         * Par : Alexandre PISSOTTE (APY)
         * Date : 06/01/2022
         * Motif : Combiner la recherche classique et la recherche hiérarchique
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _addModels: function() {
            var sValueState = sap.ui.core.ValueState.Error;

            if (this._sFunctionalLocationNumber && !this._sFunctionalLocationNumber.endsWith("*")) {
                this._sFunctionalLocationNumber = this._sFunctionalLocationNumber + "*";
                sValueState = sap.ui.core.ValueState.None;
            }

            this._oFragment.setModel(new sap.ui.model.json.JSONModel({
                "INGRP": "",
                "CLASS": "",
                "KLART": "",
                "SWERK": "",
                "STORT": "",
                "BEBER": this._sPlantSection,
                "FLTYP": "",
                "ZValueState": sValueState,
                "TPLNR": this._sFunctionalLocationNumber
            }), "frgModel");

            // Modèle dédié au type de recherche
            this._oFragment.setModel(new sap.ui.model.json.JSONModel({
                types: [
                    { key: "TABLE", text: "Liste", className: "sap.ui.table.Table" },
                    { key: "TREE_TABLE", text: "Hiérarchique", className: "sap.ui.table.TreeTable" }
                ],
                selectedKey: "TABLE"
            }), "searchTypeModel");

            // Modèle dédié à la gestion du résultat de l'arbre
            this._oFragment.setModel(new sap.ui.model.json.JSONModel(), "treeModel");
        },

        _prepareFilters: function(oEvent) {
            CombinedSearchHelp.prototype._prepareFilters.call(this, oEvent);

            this._aFilters = this._aFilters.filter(value => value.getPath() !== "SEARCH_TYPE");
            console.log(this._aFilters)

            if (this._oFragment.getModel("frgModel").getProperty("/CLASS") !== "") {
                this._aFilters.push(new sap.ui.model.Filter({
                    path: "KLART",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: "003"
                }));
            }

            if (this._oFragment.getModel("searchTypeModel").getProperty("/selectedKey") === "TREE_TABLE") {
                // Indique à l'oData qu'il s'agit d'une recherche hiérarchique
                this._aFilters.push(new sap.ui.model.Filter({
                    path: "ZZ_HIERARCHY",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: true
                }));
            }
        },

        _filterTable: function(oFilter, fragmentInstance, entityset, firstCellBinding, secondCellBinding) {
            if (this._oFragment.getModel("searchTypeModel").getProperty("/selectedKey") === "TABLE") {
                CombinedSearchHelp.prototype._filterTable.call(this, oFilter, fragmentInstance, entityset, firstCellBinding, secondCellBinding);

            } else {
                var oValueHelpDialog = fragmentInstance;
                var oTable = oValueHelpDialog.getTable();

                oValueHelpDialog.setBusy(true);

                // Recherche hiérarchique des postes techniques
                this._getFragment().getModel().read(entityset, {
                    filters: [oFilter],
                    success: function(odata) {
                        // Transformation de la table (flat) en table deep
                        // Utilisation des références croisées
                        odata.results.forEach((value, index, array) => {
                            delete value.__metadata;
                            switch (value.FLTYP) {
                                case "E":
                                    value.ZF_COLOR = sap.ui.core.IndicationColor.Indication05
                                    break;
                                case "M":
                                    value.ZF_COLOR = sap.ui.core.IndicationColor.Indication08
                                    break;
                                case "S":
                                    value.ZF_COLOR = sap.ui.core.IndicationColor.Indication03
                                    break;
                                case "T":
                                    value.ZF_COLOR = sap.ui.core.IndicationColor.Indication04
                                    break;
                            }
                            value.children = array.filter(x => x.TPLMA === value.TPLNR);
                        });

                        // Conservation de la première ligne
                        this._oFragment.getModel("treeModel").setData({ children: odata.results[0] });

                        oValueHelpDialog.setBusy(false)
                    }.bind(this),
                    error: function() {
                        oValueHelpDialog.setBusy(false);
                        this._oFragment.getModel("treeModel").setData();
                    }.bind(this)
                });

                // Cas d'un sap.ui.table.TreeTable
                if (oTable.bindRows) {
                    oTable.bindRows({
                        model: "treeModel",
                        path: "/",
                        parameters: {
                            arrayNames: ['children']
                        }
                    });
                }

                // Cas d'un sap.m.table
                if (oTable.bindItems) {
                    oTable.bindAggregation("items", {
                        model: "treeModel",
                        path: entityset,
                        filters: oFilter,
                        factory: function() {
                            return new sap.m.ColumnListItem({
                                type: "Active",
                                cells: [
                                    new sap.m.Text({
                                        text: firstCellBinding
                                    }),
                                    new sap.m.Text({
                                        text: secondCellBinding
                                    })
                                ]
                            });
                        }
                    });
                }

                oValueHelpDialog.update();
            }
        },

        onSearch: function(oEvent) {
            // Reconstruit la table en fonction du type de recherche
            this.defineTable();

            if (this._sFunctionalLocationNumber && this._sFunctionalLocationNumber !== "") {
                CombinedSearchHelp.prototype.onSearch.call(this, oEvent);
            } else {
                if (this._oFragment.getModel("frgModel").getProperty("/INGRP") !== "" || this._oFragment.getModel("frgModel").getProperty("/BEBER") !== "") {
                    CombinedSearchHelp.prototype.onSearch.call(this, oEvent);
                } else {
                    sap.m.MessageBox.error(this._oFragment.getModel("i18n").getResourceBundle().getText("plannerGroupOrPlantSectionMandatory"));
                }
            }
        },

        /**
         * Vérifie la présence d'un groupe gestionnaire OU d'un secteur d'exploitation
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-458
         * Par : Alexandre PISSOTTE (APY)
         * Date : 28/10/2021
         * Motif : Ajouter les variantes sur les filtres de l'aide à la recherche
         * de l'équipement et du poste technique. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onLiveChange: function(oEvent) {
            let bIsValid = false;

            // On arrive depuis la sélection de l'aide à la recherche => comparaison sur les modèles
            if (!oEvent) {
                if (this._oFragment.getModel("frgModel").getProperty("/INGRP") || this._oFragment.getModel("frgModel").getProperty("/BEBER")) {
                    bIsValid = true;
                }

                // On arrive depuis le live update d'un input => comparaison de la valeur champ mis à jour contre le modèle de l'autre input
            } else {
                if (oEvent.getSource().getName() == "INGRP") {
                    if (oEvent.getSource().getValue() || this._oFragment.getModel("frgModel").getProperty("/BEBER")) {
                        bIsValid = true;
                    }
                } else {
                    if (oEvent.getSource().getValue() || this._oFragment.getModel("frgModel").getProperty("/INGRP")) {
                        bIsValid = true;
                    }
                }
            }

            if (bIsValid) {
                this._oFragment.getModel("frgModel").setProperty("/ZValueState", sap.ui.core.ValueState.None);
            } else {
                this._oFragment.getModel("frgModel").setProperty("/ZValueState", sap.ui.core.ValueState.Error);
            }
        },

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-225 (3) Alexandre PISSOTTE (APY)
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        onFunctionalLocationTypeValueHelpRequest: function() {
            if (!this._functionalLocationTypeSearchHelp) {
                this._functionalLocationTypeSearchHelp = new FunctionalLocationTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/FLTYP"));
            }
            this._functionalLocationTypeSearchHelp.open();
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-255 (3) Alexandre PISSOTTE (APY)
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        onObjectTypeValueHelpRequest: function() {
            if (!this._objectTypeSearchHelp) {
                this._objectTypeSearchHelp = new ObjectTypeSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/EQART"));
            }
            this._objectTypeSearchHelp.open();
        },

        onPlannerGroupValueHelpRequest: function() {
            if (!this._plannerGroupSearchHelp) {
                this._plannerGroupSearchHelp = new PlannerGroupSearchHelp(this._oController, new ObjectSimpleSelectionMode(this._oFragment.getModel("frgModel"), function(oObject) {
                    this._oFragment.getModel("frgModel").setProperty("/INGRP", oObject.INGRP);
                    this.onLiveChange();
                }.bind(this)));
            }
            this._plannerGroupSearchHelp.open();
        },

        onClassValueHelpRequest: function() {
            if (!this._classSearchHelp) {
                this._classSearchHelp = new ClassSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/CLASS", "/KLART"), "003");
            }
            this._classSearchHelp.open();
        },

        onMaintenancePlantValueHelpRequest: function() {
            if (!this._maintenancePlantSearchHelp) {
                this._maintenancePlantSearchHelp = new MaintenancePlantSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/SWERK"));
            }
            this._maintenancePlantSearchHelp.open();
        },

        onLocationValueHelpRequest: function() {
            if (!this._locationSearchHelp) {
                this._locationSearchHelp = new LocationSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/STORT"));
            }
            this._locationSearchHelp.open();
        },

        onPlantSectionValueHelpRequest: function() {
            if (!this._plantSectionSearchHelp) {
                this._plantSectionSearchHelp = new PlantSectionSearchHelp(this._oController, new ObjectSimpleSelectionMode(this._oFragment.getModel("frgModel"), function(oObject) {
                    this._oFragment.getModel("frgModel").setProperty("/BEBER", oObject.BEBER);
                    this.onLiveChange();
                }.bind(this)));
            }
            this._plantSectionSearchHelp.open();
        },

        /**
         * Récupère les champs custom du filterbar
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         *
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-560
         * Par : Alexandre PISSOTTE (APY)
         * Date : 21/01/2021
         * Motif : Choix du type de recherche pas pris en compte par les variantes.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onBeforeVariantSave: function(oEvent) {
            var oFilterCriteriaValues = { _CUSTOM: {} };

            oEvent.getSource().getControlConfiguration()
                .map((oControlConfiguration) => oControlConfiguration.getKey())
                .forEach((sKey) => {
                    if (oEvent.getSource().getControlByKey(sKey)?.getValue()) {
                        if (sKey === "SEARCH_TYPE") {
                            oFilterCriteriaValues._CUSTOM[sKey] = oEvent.getSource().getControlByKey("SEARCH_TYPE").getSelectedKey();
                        } else {
                            oFilterCriteriaValues._CUSTOM[sKey] = oEvent.getSource().getControlByKey(sKey).getValue();
                        }
                    }
                });

            oEvent.getSource().setFilterData(oFilterCriteriaValues, true);
        },

        /**
         * Alimente les filtres de la filterbar
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-560
         * Par : Alexandre PISSOTTE (APY)
         * Date : 21/01/2021
         * Motif : Choix du type de recherche pas pris en compte par les variantes.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onAfterVariantLoad: function(oEvent) {
            CombinedSearchHelp.prototype.onAfterVariantLoad.call(this, oEvent);

            if (oEvent.getSource().getControlByKey("SEARCH_TYPE")) {
                var oVariantData = JSON.parse(oEvent.getSource().fetchVariant().filterBarVariant)["_CUSTOM"];
                oEvent.getSource().getControlByKey("SEARCH_TYPE").setSelectedKey(oVariantData["SEARCH_TYPE"]);
            }
        }

    });
});
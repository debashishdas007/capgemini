sap.ui.define([
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/CombinedSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/ClassSearchHelp",
	"com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/MaintenancePlantSearchHelp",
	"../../../model/models"
], function(CombinedSearchHelp, SimpleSelectionMode, ClassSearchHelp, MaintenancePlantSearchHelp, Models) {
	"use strict";

	return CombinedSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.MaterialSearchHelp", {
		constructor: function(oController, oSelectionMode) {
			CombinedSearchHelp.call(this,
				oController,
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.combined.MaterialSearchHelp",
				oSelectionMode
			);
		},

		getKey: function() {
			return "MATNR";
		},

		getI18nKey: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("materialNumber");
		},

		getDescription: function() {
			return "MAKTX";
		},

		getI18nDescription: function(oi18nModel) {
			return oi18nModel.getResourceBundle().getText("materialDescription");
		},

		_getODataEntitySet: function() {
			return "/MaterialSet";
		},

		_addModels: function() {
			this._oFragment.setModel(new sap.ui.model.json.JSONModel({
			}), "frgModel");
		},
		
		_prepareFilters: function(oEvent) {
			CombinedSearchHelp.prototype._prepareFilters.call(this, oEvent);
			
			if (this._oFragment.getModel("frgModel").getProperty("/CLASS") !== "") {
				this._aFilters.push(new sap.ui.model.Filter({
					path: "KLART",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "001"
				}));
			}
		},
		
		onClassValueHelpRequest: function() {
			if (!this._classSearchHelp) {
				this._classSearchHelp = new ClassSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/CLASS", "/KLART"), "001");
			}
			this._classSearchHelp.open();
		},
		
		onMaintenancePlantValueHelpRequest: function() {
			if (!this._maintenancePlantSearchHelp) {
				this._maintenancePlantSearchHelp = new MaintenancePlantSearchHelp(this._oController, new SimpleSelectionMode(this._oFragment.getModel("frgModel"), "/WERKS"));
			}
			this._maintenancePlantSearchHelp.open();
		}
		
	});
});
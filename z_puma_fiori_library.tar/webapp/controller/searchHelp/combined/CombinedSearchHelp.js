sap.ui.define([
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/SearchHelpAction"
], function(SearchHelpAction) {
    "use strict";

    return SearchHelpAction.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.combined.CombinedSearchHelp", {
        metadata: {
            abstract: true,
            interfaces: ["com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/table/ITableSearchHelp"]
        },

        constructor: function(oController, sFragmentName, oSelectionMode) {
            SearchHelpAction.call(this,
                oController,
                sFragmentName,
                oSelectionMode
            );
        },

        _getFragment: function() {
            if (!this._oFragment) {
                // Instancie le fragment et assigne les modèles
                this._instantiateFragment();

                // Ajoute les modèles des sous classes
                this._addModels();

                // Définit la table
                this.defineTable();

                // Met ou non le fragment en sélection multiple
                this._oSelectionMode.setMultiSelect(this._oFragment);
            }
            return this._oFragment;
        },

        _getODataEntitySet: function() {
            throw Error("Cannot access abstract method CombinedSearchHelp::_getODataEntitySet");
        },

        /**
         * Ajoute les filtres de l'utilisateur à la requête OData.
         * 
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-538
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/02/2022
         * Motif : Permettre la recherche des ordres à partir des PT inclus dans 
         *         la liste des objets de l'ordre    
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _prepareFilters: function(oEvent) {
            this._aFilters = [];

            var aSelectionSet = oEvent.getParameter("selectionSet") == undefined ? oEvent.getParameters()[0]["selectionSet"] : oEvent.getParameter("selectionSet");
            aSelectionSet.forEach(function(oControl) {
                if (oControl.getMetadata().getName() === "sap.m.CheckBox") {
                    this._aFilters.push(new sap.ui.model.Filter({
                        path: oControl.getName(),
                        operator: sap.ui.model.FilterOperator.EQ,
                        value1: oControl.getSelected() ? 'X' : ''
                    }));
                } else {
                    if (oControl.getValue()) {
                        this._aFilters.push(new sap.ui.model.Filter({
                            path: oControl.getName(),
                            operator: sap.ui.model.FilterOperator.EQ,
                            value1: oControl.getValue().toUpperCase()
                        }));
                    }
                }
            }.bind(this));
        },

        _filterTable: function(oFilter, fragmentInstance, entityset, firstCellBinding, secondCellBinding) {
            var oValueHelpDialog, oTable;

            // get the  table of the value dialog help   
            oValueHelpDialog = fragmentInstance;
            oTable = oValueHelpDialog.getTable();

            // case the value help dialog table  is  a sap.ui.table 
            if (oTable.bindRows) {
                oTable.bindRows({
                    path: entityset,
                    filters: oFilter
                });
            }

            //case the value help dialog table  is  a sap.m.table
            if (oTable.bindItems) {
                oTable.bindAggregation("items", {
                    path: entityset,
                    factory: function() {
                        return new sap.m.ColumnListItem({
                            type: "Active",
                            cells: [
                                new sap.m.Text({
                                    text: firstCellBinding
                                }),
                                new sap.m.Text({
                                    text: secondCellBinding
                                })
                            ]
                        });
                    },
                    filters: oFilter
                });
            }
            oValueHelpDialog.update();
        },


        // - - SECTION PUBLIQUE
        getKey: function() {
            throw Error("Cannot access abstract method CombinedSearchHelp::getKey");
        },

        getDescription: function() {
            throw Error("Cannot access abstract method CombinedSearchHelp::getDescription");
        },

        getI18nKey: function() {
            throw Error("Cannot access abstract method CombinedSearchHelp::getI18nKey");
        },

        getI18nDescription: function() {
            throw Error("Cannot access abstract method CombinedSearchHelp::getI18nDescription");
        },

        addColumns: function() { },

        addI18nColumns: function() { },

        defineTable: function() {
            // Récupération de la table du fragment
            var oTable = this._oFragment.getTable();

            // La table devient occupée
            oTable.setEnableBusyIndicator(true);

            // Ajout des colonnes obligatoires
            switch (oTable.getMetadata().getName()) {
                case "sap.ui.table.Table":
                    oTable.addColumn(new sap.ui.table.Column({
                        label: new sap.m.Label({
                            text: this.getI18nKey(this._oFragment.getModel("i18n"))
                        }),
                        template: new sap.m.Text().bindProperty("text", this.getKey())
                    }));
                    oTable.addColumn(new sap.ui.table.Column({
                        label: new sap.m.Label({
                            text: this.getI18nDescription(this._oFragment.getModel("i18n"))
                        }),
                        template: new sap.m.Text().bindProperty("text", this.getDescription())
                    }));
                    break;
                case "sap.m.Table":
                    oTable.addColumn(new sap.m.Column({
                        header: new sap.m.Label({
                            text: this.getI18nKey(this._oFragment.getModel("i18n"))
                        }),
                        template: new sap.m.Text().bindProperty("text", this.getKey())
                    }));
                    oTable.addColumn(new sap.m.Column({
                        header: new sap.m.Label({
                            text: this.getI18nDescription(this._oFragment.getModel("i18n"))
                        }),
                        template: new sap.m.Text().bindProperty("text", this.getDescription())
                    }));
                    break;
            }

            // Récupération des textes pour le nom des colonnes
            var aPropertyColumns = this.addColumns(this._oFragment.getModel("i18n"));

            // Récupération des propriétés de l'entité
            var aI18nColumns = this.addI18nColumns(this._oFragment.getModel("i18n"));

            // Ajout des colonnes addtionnelles
            if (aI18nColumns && aPropertyColumns && aI18nColumns.length === aPropertyColumns.length) {
                aPropertyColumns.forEach(function(value, index) {
                    // Ajout des colonnes à la table // Add the table columns' properties and binding 
                    switch (oTable.getMetadata().getName()) {
                        case "sap.ui.table.Table":
                            oTable.addColumn(new sap.ui.table.Column({
                                label: new sap.m.Label({
                                    text: aI18nColumns[index]
                                }),
                                template: new sap.m.Text().bindProperty("text", value)
                            }));
                            break;
                        case "sap.m.Table":
                            oTable.addColumn(new sap.m.Column({
                                header: new sap.m.Label({
                                    text: aI18nColumns[index]
                                }),
                                template: new sap.m.Text().bindProperty("text", value)
                            }));
                            break;
                    }
                });
            }
        },

        onSearch: function(oEvent) {
            this._prepareFilters(oEvent);
            this._filterTable(new sap.ui.model.Filter({
                filters: this._aFilters,
                and: true
            }), this._oFragment, this._getODataEntitySet(), "{" + this.getKey() + "}", "{" + this.getDescription() + "}");
        },

        onOk: function(oEvent) {
            this._oSelectionMode.updateOutputModel(this._oFragment, oEvent);
            this.notifySubscribers();
            this._oFragment.close();
        },

        onCancel: function() {
            this._oFragment.close();
        },

        /**
         * Récupère les champs custom du filterbar
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-458
         * Par : Alexandre PISSOTTE (APY)
         * Date : 28/10/2021
         * Motif : Ajouter les variantes sur les filtres de l'aide à la recherche
         * de l'équipement et du poste technique. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onBeforeVariantSave: function(oEvent) {
            var oFilterCriteriaValues = { _CUSTOM: {} };

            oEvent.getSource().getControlConfiguration()
                .map((oControlConfiguration) => oControlConfiguration.getKey())
                .forEach((sKey) => {
                    if (oEvent.getSource().getControlByKey(sKey)?.getValue()) {
                        oFilterCriteriaValues._CUSTOM[sKey] = oEvent.getSource().getControlByKey(sKey).getValue();
                    }
                })
                ;

            oEvent.getSource().setFilterData(oFilterCriteriaValues, true);
        },

        /**
         * Alimente les filtres de la filterbar
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-458
         * Par : Alexandre PISSOTTE (APY)
         * Date : 28/10/2021
         * Motif : Ajouter les variantes sur les filtres de l'aide à la recherche
         * de l'équipement et du poste technique. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onAfterVariantLoad: function(oEvent) {
            var oVariantData = JSON.parse(oEvent.getSource().fetchVariant().filterBarVariant)["_CUSTOM"];

            oEvent.getSource().getControlConfiguration()
                .map((oControlConfiguration) => oControlConfiguration.getKey())
                .forEach(function(sKey) {
                    if (oEvent.getSource().getControlByKey(sKey)) {
                        oEvent.getSource().getControlByKey(sKey).setValue(oVariantData[sKey] !== undefined ? oVariantData[sKey] : "");
                        this._oFragment.getModel("frgModel").setProperty("/" + sKey, oVariantData[sKey] !== undefined ? oVariantData[sKey] : "");
                    }
                }.bind(this))
                ;
        }

    });
});
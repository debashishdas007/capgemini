sap.ui.define([
	"./SearchHelp"
], function(SearchHelp) {
	return SearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.SearchHelpAction", {
		metadata: {
			abstract: true
		},
		
		// - - SECTION PROTEGEE
		constructor: function(oController, sFragmentName, oSelectionMode) {
			SearchHelp.call(this, 
				oController, 
				sFragmentName, 
				oSelectionMode
			);
		},
		
		_prepareFilters: function(oEvent) {
			throw Error("Cannot acces abstract method SearchHelpAction::_prepareFilters");
		},
		
		// - - SECTION PUBLIQUE
		onSearch: function(oEvent) {
			throw Error("Cannot acces abstract method SearchHelpAction::_prepareFilters");
		}
	});
});
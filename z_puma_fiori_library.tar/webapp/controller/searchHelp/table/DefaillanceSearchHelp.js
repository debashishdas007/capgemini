sap.ui.define([
	"./TableSearchHelp"
], function(TableSearchHelp) {
	"use strict";
	
	return TableSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.table.DefaillanceSearchHelp", {
		constructor: function(oController, oSelectionMode, sFunctionalLocationNumber, sEquipmentNumber) {
			TableSearchHelp.call(this, 
				oController, 
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.table.DefaillanceSearchHelp",
				oSelectionMode, 
				"CODE"
			);
			this._sFunctionalLocationNumber = sFunctionalLocationNumber;
			this._sEquipmentNumber = sEquipmentNumber;
		},
		
		_prepareFilters: function(oEvent) {
			this._aFilters = [];
			
			if (oEvent) {
				this._aFilters.push(new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase()));
			}
			
			if (this._sFunctionalLocationNumber) {
				this._aFilters.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, this._sFunctionalLocationNumber));
			}
			
			if (this._sEquipmentNumber) {
				this._aFilters.push(new sap.ui.model.Filter("EQUNR", sap.ui.model.FilterOperator.EQ, this._sEquipmentNumber));
			}
		},
		
		open: function() {
			this._prepareFilters();
			
			this._getFragment().bindAggregation("items", {
				path: "/DefaillanceSet",
				filters: this._aFilters,
				sorter: new sap.ui.model.Sorter({
					path: "CODEGRUPPE",
					group: true
				}),
				factory: function() {
					return new sap.m.ColumnListItem({
						type: "Active",
						cells: [
							new sap.m.ObjectIdentifier({
								text: "{CODE}"
							}),
							new sap.m.Text({
								text: "{KURZTEXT}"
							})
						]
					});
				}
			});
			
			this._getFragment().open();
		}
	});
});
sap.ui.define([
	"./TableSearchHelp"
], function(TableSearchHelp) {
	"use strict";
	
	return TableSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.table.CauseSearchHelp", {
		constructor: function(oController, oSelectionMode, sDefaillanceCodegruppe, sDefaillanceCode) {
			TableSearchHelp.call(this, 
				oController, 
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.table.CauseSearchHelp",
				oSelectionMode, 
				"CODE"
			);
			this._sDefaillanceCodegruppe = sDefaillanceCodegruppe;
			this._sDefaillanceCode = sDefaillanceCode;
		},
		
		_prepareFilters: function(oEvent) {
			this._aFilters = [];
			
			if (oEvent) {
				this._aFilters.push(new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase()));
			}
			
			if (this._sDefaillanceCodegruppe && this._sDefaillanceCode) {
				var sCauseCodegruppe = this._sDefaillanceCodegruppe.split("-")[0] + "-" + this._sDefaillanceCode;
				this._aFilters.push(new sap.ui.model.Filter("CODEGRUPPE", sap.ui.model.FilterOperator.EQ, sCauseCodegruppe));
			}
		},
		
		open: function() {
			this._prepareFilters();
			
			this._getFragment().bindAggregation("items", {
				path: "/CauseSet",
				filters: this._aFilters,
				sorter: new sap.ui.model.Sorter({
					path: "CODEGRUPPE",
					group: true
				}),
				factory: function() {
					return new sap.m.ColumnListItem({
						type: "Active",
						cells: [
							new sap.m.ObjectIdentifier({
								text: "{CODE}"
							}),
							new sap.m.Text({
								text: "{KURZTEXT}"
							})
						]
					});
				}
			});
			
			this._getFragment().open();
		}
	});
});
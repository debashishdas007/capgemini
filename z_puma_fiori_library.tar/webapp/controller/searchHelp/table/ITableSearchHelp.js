sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/base/Interface"
], function(Object, Interface) {
	"use strict";
	
	return Object.extend(
		"com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.table.ITableSearchHelp", {
		metadata: {
			interfaces: [],
			abstract: true
		},
		
		constructor: function() {
			return new Interface(this, this.getMetadata().getAllPublicMethods());
		},
		
		getKey: function() {},
		
		getDescription: function() {},
		
		getI18nKey: function() {},
		
		getI18nDescription: function() {},
		
		addColumns: function() {},
		
		addI18nColumns: function() {}
	});
});
sap.ui.define([
	"../unitary/UnitarySearchHelp"
], function(UnitarySearchHelp) {
	"use strict";
	
	return UnitarySearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.table.TableSearchHelp", {
		metadata: {
			abstract: true,
			interfaces: ["com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/table/ITableSearchHelp"]
		},
		
		// - - SECTION PROTEGEE
		constructor: function(oController, sFragmentName, oSelectionMode, sSearchProperty) {
			UnitarySearchHelp.call(this, 
				oController, 
				sFragmentName,
				oSelectionMode, 
				sSearchProperty)
			;
		},
		
		_getFragment: function() {
			if (!this._oFragment) {
				// Instancie le fragment et assigne les modèles
				this._instantiateFragment();
				
				// Ajoute les modèles des sous classes
				this._addModels();
				
				// Définit la table
				this.defineTable();
				
				// Met ou non le fragment en sélection multiple
				this._oSelectionMode.setMultiSelect(this._oFragment);
			}
			return this._oFragment;
		},
		
		// - - SECTION PUBLIQUE
		getKey: function() {
			throw Error("Cannot acces abstract method TableSearchHelp::getKey");
		},
		
		getDescription: function() {
			throw Error("Cannot acces abstract method TableSearchHelp::getDescription");
		},
		
		getI18nKey: function() {
			throw Error("Cannot acces abstract method TableSearchHelp::getI18nKey");
		},
		
		getI18nDescription: function() {
			throw Error("Cannot acces abstract method TableSearchHelp::getI18nDescription");
		},
		
		addColumns: function(oi18nModel) {},
		
		addI18nColumns: function(oi18nModel) {},
		
		defineTable: function() {
			// Récupération de la table du fragment
			var oTable = this._oFragment.getMetadata().getElementName() === "sap.m.TableSelectDialog" ? this._oFragment : this._oFragment.getTable();
			
			// La table devient occupée
			// oTable.setEnableBusyIndicator(true);
			
			// Ajout des colonnes obligatoires
			switch (oTable.getMetadata().getName()) {
				case "sap.ui.table.Table":
					oTable.addColumn(new sap.ui.table.Column({
						label: new sap.m.Label({
							text: this.getI18nKey(this._oFragment.getModel("i18n"))
						}),
						template: new sap.m.Text().bindProperty("text", this.getKey())
					}));
					oTable.addColumn(new sap.ui.table.Column({
						label: new sap.m.Label({
							text: this.getI18nDescription(this._oFragment.getModel("i18n"))
						}),
						template: new sap.m.Text().bindProperty("text", this.getDescription())
					}));
					break;
				case "sap.m.Table":
					oTable.addColumn(new sap.m.Column({
						header: new sap.m.Label({
							text: this.getI18nKey(this._oFragment.getModel("i18n"))
						}),
						template: new sap.m.Text().bindProperty("text", this.getKey())
					}));
					oTable.addColumn(new sap.m.Column({
						header: new sap.m.Label({
							text: this.getI18nDescription(this._oFragment.getModel("i18n"))
						}),
						template: new sap.m.Text().bindProperty("text", this.getDescription())
					}));
					break;
			}
			
			// Récupération des textes pour le nom des colonnes
			var aI18nColumns = this.addI18nColumns(this._oFragment.getModel("i18n"));
			
			// Récupération des propriétés de l'entité
			var aPropertyColumns = this.addColumns(this._oFragment.getModel("i18n"));
			
			// Ajout des colonnes addtionnelles
			if (aI18nColumns && aPropertyColumns && aI18nColumns.length === aPropertyColumns.length) {
				aPropertyColumns.forEach(function(value, index) {
					// Ajout des colonnes à la table // Add the table columns' properties and binding 
					switch (oTable.getMetadata().getName()) {
						case "sap.ui.table.Table":
							oTable.addColumn(new sap.ui.table.Column({
								label: new sap.m.Label({
									text: aI18nColumns[index]
								}),
								template: new sap.m.Text().bindProperty("text", value)
							}));
							break;
						case "sap.m.Table":
							oTable.addColumn(new sap.m.Column({
								header: new sap.m.Label({
									text: aI18nColumns[index]
								}),
								template: new sap.m.Text().bindProperty("text", value)
							}));
							break;
					}
				});
			}
		}
	});
});
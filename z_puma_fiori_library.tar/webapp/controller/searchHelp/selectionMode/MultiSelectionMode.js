sap.ui.define([
	"./SelectionMode",
	"../../utility"
], function(SelectionMode, Utility) {
	"use strict";
	
	return SelectionMode.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.MultiSelectionMode", {
		constructor: function(oOuputModel, fCallback) {
			SelectionMode.call(this, oOuputModel);
			this._fCallback = fCallback;
		},
		
		updateOutputModel: function(oFragment, oEvent) {
			var aTokens = [];
			
			switch (oFragment.getMetadata().getElementName()) {
				case "sap.ui.comp.valuehelpdialog.ValueHelpDialog":
					aTokens = oEvent.getParameter("tokens");
					break;
				case "sap.m.SelectDialog":
					oEvent.getParameter("selectedItems").forEach(function(oResult) {
						aTokens.push(new sap.m.Token({
							key: oResult.getDescription(),
							text: oResult.getTitle()
						}));
					});
			}
			
			// Appel de la callback
			if (this._fCallback) {
				this._fCallback(aTokens);
			}
		},
		
		setMultiSelect: function(oFragment) {
			switch (oFragment.getMetadata().getElementName()) {
				case "sap.ui.comp.valuehelpdialog.ValueHelpDialog":
					oFragment.setSupportMultiselect(true);
					break;
				case "sap.m.SelectDialog":
				case "sap.m.TableSelectDialog":
					oFragment.setMultiSelect(true);
			}
		}
	});
});
sap.ui.define([
	"./SelectionMode",
	"./../../utility"
], function(SelectionMode, Utility) {
	"use strict";

	return SelectionMode.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SimpleSelectionMode", {
		constructor: function(oOuputModel, sTitleProperty, sDescriptionProperty, sInfoProperty) {
			SelectionMode.call(this, oOuputModel);
			this._sTitleProperty = sTitleProperty;
			this._sDescriptionProperty = sDescriptionProperty;
			this._sInfoProperty = sInfoProperty;
		},

		updateOutputModel: function(oFragment, oEvent) {
			switch (oFragment.getMetadata().getElementName()) {
				case "sap.ui.comp.valuehelpdialog.ValueHelpDialog":
					var oBindingContext = Utility._getBindingContext(oEvent);
					if (oBindingContext) {
						if (this._sTitleProperty) {
							this._oOutputModel.setProperty(this._sTitleProperty, oBindingContext.getProperty(oFragment.getKey()));
						}
						if (this._sDescriptionProperty) {
							this._oOutputModel.setProperty(this._sDescriptionProperty, oBindingContext.getProperty(oFragment.getDescriptionKey()));
						}
					}
					break;
				case "sap.m.SelectDialog":
					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
					/*
						TICKET JIRA GMAO-293
						La création de l'avis ZV ne prend pas en compte le type d'inspection qui est pourtant
						obligatoire. En effet, la bibliothèque ne passe pas le paramètre info de l'aide à la
						recherche à l'application appelante.
						
						Fait le  : 16/03/2021
						Fait par : Alexandre PISSOTTE (APY)
					*/
					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
					// DEBUT MODIFICATION GMAO-293
					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
					if (this._sTitleProperty) {
						this._oOutputModel.setProperty(this._sTitleProperty, oEvent.getParameter("selectedItem").getTitle());
					}
					if (this._sDescriptionProperty) {
						this._oOutputModel.setProperty(this._sDescriptionProperty, oEvent.getParameter("selectedItem").getDescription());
					}
					if (this._sInfoProperty) {
						this._oOutputModel.setProperty(this._sInfoProperty, oEvent.getParameter("selectedItem").getInfo());
					}
					break;
					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
					// FIN MODIFICATION GMAO-293
					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
				case "sap.m.TableSelectDialog":
					if (this._sTitleProperty) {
						this._oOutputModel.setProperty(this._sTitleProperty, oEvent.getParameter("selectedItem").getBindingContext().getProperty("CODE"));
					}
					if (this._sDescriptionProperty) {
						this._oOutputModel.setProperty(this._sDescriptionProperty, oEvent.getParameter("selectedItem").getBindingContext().getProperty("KURZTEXT"));
					}
					if (this._sInfoProperty) {
						this._oOutputModel.setProperty(this._sInfoProperty, oEvent.getParameter("selectedItem").getBindingContext().getProperty("CODEGRUPPE"));
					}
					if (this._fCallbackObject) {
						this._fCallbackObject(oEvent.getParameter("selectedItem").getBindingContext().getObject());
					}
					break;
			}
		},

		setMultiSelect: function(oFragment) {
			switch (oFragment.getMetadata().getElementName()) {
				case "sap.ui.comp.valuehelpdialog.ValueHelpDialog":
					oFragment.setSupportMultiselect(false);
					break;
				case "sap.m.SelectDialog":
				case "sap.m.TableSelectDialog":
					oFragment.setMultiSelect(false);
			}
		}
	});
});
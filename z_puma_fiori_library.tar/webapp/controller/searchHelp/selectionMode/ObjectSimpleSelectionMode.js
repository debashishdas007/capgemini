sap.ui.define([
	"./SelectionMode",
	"./../../utility"
], function(SelectionMode, Utility) {
	"use strict";
	
	return SelectionMode.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode", {
		constructor: function(oOuputModel, fCallbackObject) {
			SelectionMode.call(this, oOuputModel);
			this._fCallbackObject = fCallbackObject;
		},
		
		updateOutputModel: function(oFragment, oEvent) {
			switch (oFragment.getMetadata().getElementName()) {
				case "sap.ui.comp.valuehelpdialog.ValueHelpDialog":
					if (this._fCallbackObject) {
						this._fCallbackObject(Utility._getBindingContext(oEvent).getObject());
					}
					break;
				case "sap.m.SelectDialog":
					if (this._fCallbackObject) {
                        if (oEvent.getParameter("selectedItem").getBindingContext()) {
                            this._fCallbackObject(oEvent.getParameter("selectedItem").getBindingContext().getObject());
                        } else {
                            this._fCallbackObject(oEvent.getParameter("selectedItem").getBindingContext("frgModel").getObject()); // GMAO-322
                        }
						
					}
					break;
				case "sap.m.TableSelectDialog":
					if (this._sTitleProperty) {
							// oEvent.getParameter("selectedItem").getCells().find(function(oCell) { return oCell.getMetadata().getElementName() === "sap.m.ObjectIdentifier" }).getProperty("text")
							this._oOutputModel.setProperty(this._sTitleProperty, oEvent.getParameter("selectedItem").getBindingContext().getProperty("CODE"));
						}
					if (this._sDescriptionProperty) {
						this._oOutputModel.setProperty(this._sDescriptionProperty, oEvent.getParameter("selectedItem").getBindingContext().getProperty("KURZTEXT"));
					}
					if (this._sInfoProperty) {
						this._oOutputModel.setProperty(this._sInfoProperty, oEvent.getParameter("selectedItem").getBindingContext().getProperty("CODEGRUPPE"));
					}
					if (this._fCallbackObject) {
						this._fCallbackObject(oEvent.getParameter("selectedItem").getBindingContext().getObject());
					}
					break;
			}
		},
		
		setMultiSelect: function(oFragment) {
			switch (oFragment.getMetadata().getElementName()) {
				case "sap.ui.comp.valuehelpdialog.ValueHelpDialog":
					oFragment.setSupportMultiselect(false);
					break;
				case "sap.m.SelectDialog":
				case "sap.m.TableSelectDialog":
					oFragment.setMultiSelect(false);
			}
		}
	});
});
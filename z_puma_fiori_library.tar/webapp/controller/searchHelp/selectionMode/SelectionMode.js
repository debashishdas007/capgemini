sap.ui.define([
	"sap/ui/base/Object"
], function(Object) {
	"use strict";
	
	return Object.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode", {
		constructor: function(oOutputModel) {
			this._oOutputModel = oOutputModel;
		},
		
		updateOutputModel: function(oFragment, oEvent) {
			throw Error("Cannot acces abstract method SelectionMode::updateOutputModel");
		},
		
		setMultiSelect: function(oFragment) {
			throw Error("Cannot acces abstract method SelectionMode::setMultiSelect");
		}
	});
});
sap.ui.define([
	"./UnitarySearchHelp"
], function(UnitarySearchHelp) {
	"use strict";
		
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
	/*
		TICKET JIRA GMAO-225
		Le champ Désignation site ZPLTXT doit être rajouté dans toutes les fenêtres de recherche de PT.
		Le champ Type du poste technique FLTYP doit être rajouté dans toutes les fenêtres de recherche de PT
		
		Fait le  : 23/02/2021
		Fait par : Alexandre PISSOTTE (APY)
	*/
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
	// DEBUT MODIFICATION GMAO-255
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
	return UnitarySearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.FunctionalLocationTypeSearchHelp", {
		constructor: function(oController, oSelectionMode) {
			UnitarySearchHelp.call(this, 
				oController, 
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.unitary.FunctionalLocationTypeSearchHelp",
				oSelectionMode, 
				"FLTYP"
			);
		},
		
		_prepareFilters: function(oEvent) {
			this._aFilters = [];
			
			if (oEvent) {
				this._aFilters.push(new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, oEvent.getParameter("value").toUpperCase()));
			}
		}
	});
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
	// FIN MODIFICATION GMAO-225
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
});
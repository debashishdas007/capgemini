sap.ui.define([
	"./StorageLocationSearchHelp"
], function(StorageLocationSearchHelp) {
	"use strict";
    
    /**
     * Aide à la recherche du magasin avec filtre sur la division
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.StorageLocationFilterOnMaintenancePlantSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.StorageLocationSearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     * @param {string} sMaintenancePlant Division
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-263
     * Par : Alexandre PISSOTTE (APY)
     * Date : 03/08/2021
     * Motif : La recherche doit se faire en même temps sur code et désignation.
     * Attention, la condition logique utilisée entre le code et la désignation
     * est le ET/AND et non le OU/OR. Ainsi, les filtres sont remontées par l'
     * oData dans le paramètre IT_FILTER_SELECT_OPTIONS.
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
	return StorageLocationSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.StorageLocationFilterOnMaintenancePlantSearchHelp", {
		constructor: function(oController, oSelectionMode, fCallback) {
			StorageLocationSearchHelp.call(this, 
				oController, 
				oSelectionMode
            );
            this._fCallback = fCallback;
        },
        
        // GMAO-263 (APY) 26/07/2021
        _prepareFilters: function(oEvent) {
            StorageLocationSearchHelp.prototype._prepareFilters.call(this, oEvent);

            if (this._fCallback) {
                this._aFilters.push(new sap.ui.model.Filter("WERKS", sap.ui.model.FilterOperator.EQ, this._fCallback()));
            }
        },

        open: function() {
            this._getFragment().setBusy(true);
            this._prepareFilters();
            this._getFragment().open();
            this._getFragment().getBinding("items").filter(this._aFilters);
            this._getFragment().setBusy(false);
        }
	});
});
sap.ui.define([
	"../SearchHelpAction"
], function(SearchHelpAction) {
	"use strict";
	
	return SearchHelpAction.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.UnitarySearchHelp", {
		// - - SECTION PROTEGEE
		constructor: function(oController, sFragmentName, oSelectionMode, sSearchProperty) {
			SearchHelpAction.call(this, 
				oController, 
				sFragmentName, 
				oSelectionMode
			);
			this._sSearchProperty = sSearchProperty;
		},
		
		_prepareFilters: function(oEvent) {
			this._aFilters = [];
			this._aFilters.push(new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase()));
		},
		
		// - - SECTION PUBLIQUE
		onSearch: function(oEvent) {
			if (this._sSearchProperty) {
				this._prepareFilters(oEvent);
				
				var oBinding = oEvent.getSource().getBinding("items");
				oBinding.filter(this._aFilters);
			} else {
				throw Error("Cannot search throught values because no search property was define");
			}
		},
		
		onConfirm: function(oEvent) {
			if (this._oSelectionMode) {
				this._oSelectionMode.updateOutputModel(this._oFragment, oEvent);
				this.notifySubscribers();
			} else {
				throw Error("Cannot update model because no SelectionMode was set");
			}
		}
	});
});
sap.ui.define([
	"./UnitarySearchHelp"
], function(UnitarySearchHelp) {
	"use strict";
    
    /**
     * Aide à la recherche du groupe gestionnaire
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.PlannerGroupSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.UnitarySearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     *
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-263
     * Par : Alexandre PISSOTTE (APY)
     * Date : 03/08/2021
     * Motif : La recherche doit se faire en même temps sur code et désignation.
     * Attention, la condition logique utilisée entre le code et la désignation
     * est le ET/AND et non le OU/OR. Ainsi, les filtres sont remontées par l'
     * oData dans le paramètre IT_FILTER_SELECT_OPTIONS.
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
	return UnitarySearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.PlannerGroupSearchHelp", {
		constructor: function(oController, oSelectionMode) {
			UnitarySearchHelp.call(this, 
				oController, 
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.unitary.PlannerGroupSearchHelp",
				oSelectionMode, 
				"INGRP"
			);
        },
        
        // GMAO-263 (APY) 26/07/2021
        _prepareFilters: function(oEvent) {
            var sValue = oEvent.getParameter("value");
 
            if (sValue !== undefined || sValue !== "") {
                this._aFilters = [
                    new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase()),
                            new sap.ui.model.Filter("INNAM", sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase())
                        ],
                        and: true // Ne pas changer la condition logique (cf : GMAO-263)
                    })
                ];
            }
        }
	});
});
sap.ui.define([
	"./UnitarySearchHelp"
], function(UnitarySearchHelp) {
	"use strict";
	
	return UnitarySearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.NotificationTypeSearchHelp", {
		constructor: function(oController, oSelectionMode) {
			UnitarySearchHelp.call(this, 
				oController, 
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.unitary.NotificationTypeSearchHelp",
				oSelectionMode, 
				"QMART"
			);
		}
	});
});
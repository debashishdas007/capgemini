sap.ui.define([
	"./UnitarySearchHelp"
], function(UnitarySearchHelp) {
	"use strict";
    
    /**
     * Aide à la recherche de la classe
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.ClassSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.UnitarySearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     * @param {string} sClassCategory Catégorie de classes
     * 
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-263
     * Par : Alexandre PISSOTTE (APY)
     * Date : 03/08/2021
     * Motif : La recherche doit se faire en même temps sur code et désignation.
     * Attention, la condition logique utilisée entre le code et la désignation
     * est le ET/AND et non le OU/OR. Ainsi, les filtres sont remontées par l'
     * oData dans le paramètre IT_FILTER_SELECT_OPTIONS.
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
	return UnitarySearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.ClassSearchHelp", {
		// - - SECTION PROTEGEE
		constructor: function(oController, oSelectionMode, sClassCategory) {
			UnitarySearchHelp.call(this, 
				oController, 
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.unitary.ClassSearchHelp",
				oSelectionMode, 
				"CLASS"
			);
			this._sClassCategory = sClassCategory;
		},
		
		_addModels: function() {
			this._oFragment.setModel(new sap.ui.model.json.JSONModel(), "frgModel");
		},
		
		_prepareFilters: function(oEvent) {
			this._aFilters = [
				new sap.ui.model.Filter("KLART", sap.ui.model.FilterOperator.EQ, this._sClassCategory)
			];
			
			if (oEvent) {
                // GMAO-263 (APY) 26/07/2021
                this._aFilters.push(new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase()),
                        new sap.ui.model.Filter("KSCHG", sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase())
					],
					and: true // Ne pas changer la condition logique (cf : GMAO-263)
				}));
                
                // this._aFilters.push(new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase())); // (-) GMAO-263 (APY) 26/07/2021
			}
			
		},
		
		// - - SECTION PUBLIQUE
		open: function() {
			this._prepareFilters();
			
			this._getFragment().getModel().read("/ClassSet", {
				filters: this._aFilters,
				success: function(odata, response) {
					var aData = this._oFragment.getModel("frgModel").getData();
					aData.ClassSet = odata.results;
					this._oFragment.getModel("frgModel").setData(aData);
				}.bind(this)
			});
			
			this._getFragment().open();
		},
		
		onSearch: function(oEvent) {
			if (this._sClassCategory) {
				this._prepareFilters(oEvent);
				
				this._getFragment().getModel().read("/ClassSet", {
					filters: this._aFilters,
					success: function(odata, response) {
						var aData = this._oFragment.getModel("frgModel").getData();
						aData.ClassSet = odata.results;
						this._oFragment.getModel("frgModel").setData(aData);
					}.bind(this)
				});
			} else {
				throw Error("Cannot search classes because no class cateogry has been set");
			}
		}
	});
});
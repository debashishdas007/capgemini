sap.ui.define([
	"./WorkTypeSearchHelp"
], function(WorkTypeSearchHelp) {
	"use strict";
	
	return WorkTypeSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.WorkTypeFilterSearchHelp", {
		// TODO Faire filter avec saisie utilisateur
		_prepareFilters: function(oEvent) {
			this._aFilters = [
				new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, "COR"),
                        new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, "REN"),
                        new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, "PRE"),
                        new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, "RAJ")   // GMAO-342
					],
					and: false
				})
			];
		},
		
		open: function() {
			this._prepareFilters();
			
			this._getFragment().getBinding("items").filter(this._aFilters);
			
			this._getFragment().open();
		},
		
		onSearch: function(oEvent) {
			this._prepareFilters(oEvent);
			this._getFragment().getBinding("items").filter(this._aFilters);
		}
	});
});
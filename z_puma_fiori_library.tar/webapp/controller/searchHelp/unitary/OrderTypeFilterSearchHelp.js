sap.ui.define([
	"./OrderTypeSearchHelp"
], function(OrderTypeSearchHelp) {
	"use strict";

	return OrderTypeSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.OrderTypeFilterSearchHelp", {
		// TODO Faire filter avec saisie utilisateur
		_prepareFilters: function(oEvent) {
			this._aFilters = [
				new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, "ZCO1"),
                        new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, "ZADP"),
                        new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.EQ, "ZPR1")
					],
					and: false
				})
			];
		},
		
		open: function() {
			this._prepareFilters();
			
			this._getFragment().getBinding("items").filter(this._aFilters);
			
			this._getFragment().open();
		},
		
		onSearch: function(oEvent) {
			this._prepareFilters(oEvent);
			this._getFragment().getBinding("items").filter(this._aFilters);
		}
	});
});
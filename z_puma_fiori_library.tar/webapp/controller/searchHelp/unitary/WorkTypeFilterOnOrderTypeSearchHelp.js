sap.ui.define([
	"./WorkTypeFilterSearchHelp"
], function(WorkTypeFilterSearchHelp) {
	"use strict";
	
	return WorkTypeFilterSearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.WorkTypeFilterOnOrderTypeSearchHelp", {
        constructor: function(oController, oSelectionMode, fCallback) {
			WorkTypeFilterSearchHelp.call(this, 
				oController, 
				oSelectionMode
            );
            
            this._fCallback = fCallback;
        },
        
		// TODO Faire filter avec saisie utilisateur
		_prepareFilters: function(oEvent) {
            WorkTypeFilterSearchHelp.prototype._prepareFilters.call(this);
            
            if (this._fCallback !== undefined) {
                var sOrderType = this._fCallback();
            
                if (sOrderType !== undefined) {
                    this._aFilters.push(
                        new sap.ui.model.Filter({
                            filters: [
                                new sap.ui.model.Filter("AUART", sap.ui.model.FilterOperator.EQ, sOrderType)
                            ]
                        })
                    );
                }
            }
		}
	});
});
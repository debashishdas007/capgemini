sap.ui.define([
	"./UnitarySearchHelp"
], function(UnitarySearchHelp) {
	"use strict";
    
    /**
     * Aide à la recherche de l'intervenant GRT
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.IntervenantGRTSearchHelp
     * @extends com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.UnitarySearchHelp
     * 
     * @param {sap.ui.core.mvc.Controller} oController Contrôleur appelant l'aide à la recherche
     * @param {com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.selectionMode.SelectionMode} oSelectionMode Mode de sélection des valeurs de l'aide à la recherche
     * @param {string} sPlant Division
     * @param {string} sWorkCenter Poste responsable
     * 
     * @author Alexandre PISSOTTE (APY)
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-322
     * Par : Alexandre PISSOTTE (APY)
     * Date : 04/08/2021
     * Motif : La recherche doit se faire en même temps sur code et désignation.
     * Attention, la condition logique utilisée entre le code et la désignation
     * est le ET/AND et non le OU/OR. Ainsi, les filtres sont remontées par l'
     * oData dans le paramètre IT_FILTER_SELECT_OPTIONS.
     * Le résultat de la recherche doit être pré-filtré sur la division et le
     * poste de travail.
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
	return UnitarySearchHelp.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.unitary.IntervenantGRTSearchHelp", {
        // GMAO-322
        constructor: function(oController, oSelectionMode, sPlant, sWorkCenter) {
			UnitarySearchHelp.call(this, 
				oController, 
				"com.grtgaz.puma.fiori.zpumafiorilibrary.view.fragment.unitary.IntervenantGRTSearchHelp",
				oSelectionMode, 
				"PERNR"
            );
            
            this._sPlant = sPlant;
            this._sWorkCenter = sWorkCenter;
        },

        // GMAO-322
        _addModels: function() {
			this._oFragment.setModel(new sap.ui.model.json.JSONModel(), "frgModel");
		},
        
        // GMAO-263 (APY) 26/07/2021
        // GMAO-322
        _prepareFilters: function(oEvent) {
            this._aFilters = [];

            if (oEvent) {
                var sValue = oEvent.getParameter("value");
                
                if (sValue !== undefined || sValue !== "") {
                    this._aFilters.push(
                        new sap.ui.model.Filter({
                            filters: [
                                new sap.ui.model.Filter(this._sSearchProperty, sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase()),
                                new sap.ui.model.Filter("STEXT", sap.ui.model.FilterOperator.Contains, oEvent.getParameter("value").toUpperCase())
                            ],
                            and: true // Ne pas changer la condition logique (cf : GMAO-322)
                        })
                    );
                }
            }

            if (this._sPlant) {
                this._aFilters.push(new sap.ui.model.Filter("ARBPL", sap.ui.model.FilterOperator.EQ, this._sPlant));
            }

            if (this._sWorkCenter) {
                this._aFilters.push(new sap.ui.model.Filter("WERKS", sap.ui.model.FilterOperator.EQ, this._sWorkCenter));
            }
        },

        // GMAO-322
        open: function() {
			this._prepareFilters();
			
			this._getFragment().getModel().read("/IntervenantGRTSet", {
				filters: this._aFilters,
				success: function(odata, response) {
					var aData = this._oFragment.getModel("frgModel").getData();
					aData.IntervenantGRTSet = odata.results;
					this._oFragment.getModel("frgModel").setData(aData);
				}.bind(this)
			});
			
			this._getFragment().open();
        },
        
        // GMAO-322
        onSearch: function(oEvent) {
			this._prepareFilters(oEvent);
				
            this._getFragment().getModel().read("/IntervenantGRTSet", {
                filters: this._aFilters,
                success: function(odata, response) {
                    var aData = this._oFragment.getModel("frgModel").getData();
                    aData.IntervenantGRTSet = odata.results;
                    this._oFragment.getModel("frgModel").setData(aData);
                }.bind(this)
            });
		}
	});
});
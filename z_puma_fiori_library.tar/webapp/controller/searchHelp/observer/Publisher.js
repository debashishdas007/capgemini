sap.ui.define([
	"sap/ui/base/Object"
], function(Object) {
	"use strict";
	
	return Object.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.observer.Publisher", {
		constructor: function() {
			this._aSubscribers = [];
		},
		
		subscribe: function(oSubscriber) {
			this._aSubscribers.push(oSubscriber);
		},
		
		unsubscribe: function(oSubscriber) {
			this._aSubscribers = this._aSubscribers.filter(function(oItem) {
			    return oItem !== oSubscriber;
			});
		},
		
		unsubscribeAll: function() {
			this._aSubscribers = [];
		},
		
		notifySubscribers: function() {
			this._aSubscribers.forEach(function (oItem) {
				oItem.update();
			});
		}
	});
});
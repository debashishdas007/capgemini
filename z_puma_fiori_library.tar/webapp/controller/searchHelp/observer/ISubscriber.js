sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/base/Interface"
], function(Object, Interface) {
	"use strict";
	
	return Object.extend(
		"com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.observer.ISubscriber", {
		metadata: {
			interfaces: [],
			abstract: true
		},
		
		constructor: function() {
			return new Interface(this, this.getMetadata().getAllPublicMethods());
		},
		
		update: function() {}
	});
});
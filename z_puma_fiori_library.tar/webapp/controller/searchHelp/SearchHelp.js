sap.ui.define([
    // "sap/ui/base/Object"
    "./observer/Publisher"
], function (Publisher) {
    return Publisher.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.searchHelp.SearchHelp", {
        metadata: {
            abstract: true
        },
        // - - SECTION PROTEGEE
        constructor: function (oController, sFragmentName, oSelectionMode) {
            Publisher.call(this);
            this._oController = oController;
            this._sFragmentName = sFragmentName;
            this._oFragment = undefined;
            this._oSelectionMode = oSelectionMode;
            this._aFilters = [];
            this._sBackend = undefined;

            // // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // /*
            // 	TICKET JIRA GMAO-272
            // 	Résolution destination pour multi-backend en récupérant le paramètre sap-system depuis le target
            // 	mapping de l'application.

            // 	Fait le  : 16/03/2021
            // 	Fait par : Alexandre PISSOTTE (APY)
            // */
            // // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // // DEBUT MODIFICATION GMAO-272
            // // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // // Détermination du backend
            // try {
            // 	this._sBackend = oController.getOwnerComponent().getComponentData().startupParameters["sap-system"][0];
            // } catch(e) {
            // 	this._sBackend = undefined;
            // }
            // // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // // FIN MODIFICATION GMAO-272
            // // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        },

        _instantiateFragment: function () {
            // Instanciation du fragment
            this._oFragment = new sap.ui.xmlfragment(this._sFragmentName, this);

            // Ajout du modèle de textes
            var i18nModel = new sap.ui.model.resource.ResourceModel({
                bundleName: "com.grtgaz.puma.fiori.zpumafiorilibrary.i18n.i18n"
            });
            this._oFragment.setModel(i18nModel, "i18n");

            // Ajout du modèle par défaut                
            var oDataModel = this._oController.getOwnerComponent().getModel("libModel");       
            this._oFragment.setModel(oDataModel);

            // Ajout du fragment à la vue principale
            this._oController.getView().addDependent(this._oFragment);
        },

        _getFragment: function () {
            if (!this._oFragment) {
                // Instanciation du fragment et ajout des modèles
                this._instantiateFragment();

                // Met le fragment en sélection multi ou non
                this._oSelectionMode.setMultiSelect(this._oFragment);

                // Ajout des modèles des sous-classes
                this._addModels();
            }
            return this._oFragment;
        },

        _addModels: function () { },


        // - - SECTION PUBLIQUE
        open: function () {
            this._getFragment().open();
        },

        destroy: function () {
            this._oController.getView().removeDependent(this._oFragment);
            this._getFragment().destroy();            
        }

    });
});
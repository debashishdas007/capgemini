sap.ui.define([], function() {
    "use strict";

    return {

        //instantiate xml fragment and add dependency to the view
        _instantiateFragment: function(FragmentName, oController, oView) {
            var FragmentInstance;
            FragmentInstance = new sap.ui.xmlfragment(FragmentName, oController);
            oView.addDependent(FragmentInstance);
            FragmentInstance.setModel(oView.getModel("i18n"), "i18n");
            FragmentInstance.setModel(oView.getModel());
            return FragmentInstance;
        },

        //Define value help table 
        defineTable: function(fragmentInstance, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
            var oValueHelpDialog, oTable, sTableType;

            // get the  table of the value dialog help   
            oValueHelpDialog = fragmentInstance;
            oTable = oValueHelpDialog.getTable();
            oTable.setEnableBusyIndicator(true);

            // Add the table columns' properties and binding 
            sTableType = this._returnControlName(oTable);

            if (sTableType === "sap.ui.table.Table") {
                this._addUiTableColumns(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding);
            }

            if (sTableType === "sap.m.Table") {
                this._addRespTableColumns(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding);
            }
        },

        //Apply filtre on value help table 
        filterTable: function(oFilter, fragmentInstance, entitySet, firstCellBinding, secondCellBinding) {
            // Get the  table of the value dialog help   
            var oValueHelpDialog = fragmentInstance;
            var oTable = oValueHelpDialog.getTable();

            // Case the value help dialog table is a sap.ui.table
            if (oTable.bindRows) {
                oTable.bindRows({
                    path: entitySet,
                    filters: oFilter
                });
            }

            // Case the value help dialog table is a sap.m.table
            if (oTable.bindItems) {
                oTable.bindAggregation("items", {
                    path: entitySet,
                    factory: function() {
                        return new sap.m.ColumnListItem({
                            type: "Active",
                            cells: [
                                new sap.m.Text({
                                    text: firstCellBinding
                                }),
                                new sap.m.Text({
                                    text: secondCellBinding
                                })
                            ]
                        });
                    },
                    filters: oFilter
                });
            }

            // Update the fragment
            oValueHelpDialog.update();
        },

        //return control name
        _returnControlName: function(oControl) {
            return oControl.getMetadata().getName();
        },

        //add sap.ui.ui.table column
        _addUiTableColumns: function(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
            var oColumn;
            oColumn = new sap.ui.table.Column({
                label: new sap.m.Label({
                    text: firsColumnName
                }),
                template: new sap.m.Text().bindProperty("text", firstColumnBinding)
                // sortProperty: firstColumnBinding, PISSOTTE Alexandre : Désactiviation du filter et du trie par backend ne le fait pas
                // filterProperty: firstColumnBinding
            });
            oTable.addColumn(oColumn);

            oColumn = new sap.ui.table.Column({
                label: new sap.m.Label({
                    text: secondColumnName
                }),
                template: new sap.m.Text().bindProperty("text", SecondColumnBinding)
                // sortProperty: SecondColumnBinding, PISSOTTE Alexandre : Désactiviation du filter et du trie par backend ne le fait pas
                // filterProperty: SecondColumnBinding
            });
            oTable.addColumn(oColumn);
        },

        //add sap.m.table column
        _addRespTableColumns: function(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
            var oColumn;
            oColumn = new sap.m.Column({
                header: new sap.m.Label({
                    text: firsColumnName
                }),
                template: new sap.m.Text().bindProperty("text", firstColumnBinding)
            });
            oTable.addColumn(oColumn);

            oColumn = new sap.m.Column({
                header: new sap.m.Label({
                    text: secondColumnName
                }),
                template: new sap.m.Text().bindProperty("text", SecondColumnBinding)
            });
            oTable.addColumn(oColumn);
        },

        //research element from select dialog 
        searchElementFromSelectDialogList: function(oEvent, FilterName) {
            var sValue, oFilter, oBinding;
            sValue = oEvent.getParameter("value").toUpperCase();
            oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
            oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },

		/**
		 * retruns the selected item's title  
		 * @param {event} oEvent : event triggered once item selected 
		 * @return {string } item's title 
		 * @private
		 */
        _getSelectedItemTitle: function(oEvent) {
            return oEvent.getParameter("selectedItem").getTitle();
        },

		/**
		 * retruns the selected item's description  
		 * @param {event} oEvent : event triggered once item selected 
		 * @return {string } item's description 
		 * @private
		 */
        _getSelectedItemDescription: function(oEvent) {
            return oEvent.getParameter("selectedItem").getDescription();
        },

        /**
         * Return binding context depending on the table type
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-529
         * Par : Alexandre PISSOTTE (APY)
         * Date : 08/12/2021
         * Motif : Permettre la recherche hiérarchique des postes techniques
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _getBindingContext: function(oEvent) {
            var oTable = oEvent.getSource().getTable(),
                sTableType = this._returnControlName(oTable),
                oBindingContext;

            switch (sTableType) {
                case "sap.ui.table.Table":
                case "sap.ui.table.TreeTable":
                    oBindingContext = oTable.getContextByIndex(oTable.getSelectedIndex());
                    break;
                case "sap.m.Table":
                    oBindingContext = oTable.getSelectedItem().getBindingContext();
                    break;
            }

            return oBindingContext;
        },

        //reset input parameters
        _resetInputDescriptionValue: function(oEvent, oModel, aProperties) {
            var sParameter = oEvent.getParameter("newValue");
            if (!sParameter) {
                aProperties.forEach(function(sProperty) {
                    oModel.setProperty(sProperty, "");
                });
            }
        },
        handleDependent: function(oFragmentController) {
            // Connexion du fragment à la vue (models et cycle de vie)
            oFragmentController._oView.addDependent(oFragmentController._oFragment);
            // Deconnexion du  fragment à la vue
            oFragmentController._oView.attachBeforeExit(function() {
                if (oFragmentController._oView) {
                    oFragmentController._oView.removeDependent(oFragmentController._oFragment);
                }
            }.bind(oFragmentController._oView));
        }

    };

});
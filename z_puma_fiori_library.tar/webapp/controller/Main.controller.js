sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/models",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationHierarchySearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/OrderSearchHelp"
], function(Controller, Models, SimpleSelectionMode, FunctionalLocationHierarchySearchHelp, FunctionalLocationSearchHelp, OrderSearchHelp) {
    "use strict";

    return Controller.extend("com.grtgaz.puma.fiori.zpumafiorilibrary.controller.Main", {
        metadata: {
            interfaces: ["com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/observer/ISubscriber"]
        },

        update: function() {
            alert("une aide à la recheche a été validée");
        },

        onInit: function() {
            this.getView().setModel(Models.createResultModel(), "rsl");
        },

        /**
         * TreeTable is set by the user after hitting the search button
         */
        onFunctionalLocationHierarchySValueHelpRequest: function() {
            new FunctionalLocationHierarchySearchHelp(this, new SimpleSelectionMode(this.getView().getModel("rsl"), "/TPLNR"), this.getView().getModel("rsl").getProperty("/TPLNR")).open();
        },

        /**
         * TreeTable is set before first opening
         */
        onFunctionalLocationSValueHelpRequest: function() {
            new FunctionalLocationSearchHelp(this, new SimpleSelectionMode(this.getView().getModel("rsl"), "/TPLNR"), this.getView().getModel("rsl").getProperty("/TPLNR")).open();
        },

        onOrderValueHelpRequest: function() {
            new OrderSearchHelp(this, new SimpleSelectionMode(this.getView().getModel("rsl"), "/AUFNR"), this.getView().getModel("rsl").getProperty("/AUFNR")).open()
        }

    });
});
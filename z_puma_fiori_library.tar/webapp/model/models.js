sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/base/util/ObjectPath"
], function (JSONModel, Device, ObjectPath) {
	"use strict";

	return {

			createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
        },
        
        createResultModel: function() {
			var data = {
				"AUART": "" // Type d'ordre
			};
			var oModel = new JSONModel(data);
			oModel.setDefaultBindingMode("TwoWay");
			return oModel;
		},
		
		createOrderSearchHelpModel: function() {
			var data = {
				"AUFNR": "",	// Numéro d'ordre
				"AUART": "",	// Type d'ordre
				"KTEXT": "", 	// Désignation d'ordre,
				"DEFCODE": "",
				"CAUSECODE": "",
				"DEFCODEGRUPPE": ""
			};
			var oModel = new JSONModel(data);
			oModel.setDefaultBindingMode("TwoWay");
			return oModel;
		}
	};
});
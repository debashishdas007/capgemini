## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Fri Oct 22 2021 10:33:34 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>@sap/generator-fiori|
|**App Generator Version**<br>1.3.7|
|**Generation Platform**<br>SAP Business Application Studio|
|**Floorplan Used**<br>simple|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://vpce-0b6044784749c09f5-id8llpzd.vpce-svc-0b1300bed60c69f3d.eu-west-1.vpce.amazonaws.com:44301/sap/opu/odata/sap/ZFIORI_LIBRARY_SRV
|**Module Name**<br>z_puma_fiori_library|
|**Application Title**<br>App Title|
|**Namespace**<br>com.grtgaz.puma.fiori|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>Latest|
|**Enable Code Assist Libraries**<br>False|
|**Add Eslint configuration**<br>False|
|**Enable Telemetry**<br>False|

## z_puma_fiori_library

Fiori library for PUMA Fiori apps

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)



jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.OrderTypeSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.WorkTypeSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.WorkCenterSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.MaintenancePlantSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.PlannerGroupSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.PlantSectionSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.SimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.MultiSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode");

sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/MultiSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/OrderTypeSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkTypeSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkCenterSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/MaintenancePlantSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/PlannerGroupSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/PlantSectionSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, SimpleSelectionMode, MultiSelectionMode, ObjectSimpleSelectionMode,
    OrderTypeSearchHelp, WorkTypeSearchHelp,
    WorkCenterSearchHelp, MaintenancePlantSearchHelp, PlannerGroupSearchHelp, PlantSectionSearchHelp, EquipmentSearchHelp, FunctionalLocationSearchHelp) {
    "use strict";

    return BaseController.extend("grtgaz.puma.ImputationDesTemps.controller.Worklist", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function() {
            var oViewModel,
                iOriginalBusyDelay,
                oOrderModel,
                oTable = this.byId("table");

            this.getRouter().getRoute("worklist").attachPatternMatched(this._onWorkListMatched, this);

            // Put down worklist table's original value for busy indicator delay,
            // so it can be restored later on. Busy handling on the table is
            // taken care of by the table itself.
            iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
            // keeps the search state
            this._oTableSearchState = [];

            // Model used to manipulate control states
            oViewModel = new JSONModel({
                worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
                saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
                shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
                shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
                shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
                tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
                tableBusyDelay: 0,
                tplnrOnEquip: "",
                maintPlanWorklist: ""

            });
            this.setModel(oViewModel, "worklistView");

            // set order model 
            oOrderModel = new JSONModel({
                WAWRK: ""
            });
            this.setModel(oOrderModel, "Order");
            // Make sure, busy indication is showing immediately so there is no
            // break after the busy indication for loading the view's meta data is
            // ended (see promise 'oWhenMetadataIsLoaded' in AppController)

            oTable.attachEventOnce("updateFinished", function() {
                // Restore original busy indicator delay for worklist's table
                oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
            });

            var oFilter = this.getView().byId("smartFilterBar"),
                that = this;
            oFilter.addEventDelegate({
                "onAfterRendering": function(oEvent) {
                    var oResourceBundle = that.getOwnerComponent().getModel("i18n").getResourceBundle();
                    var oButton = oEvent.srcControl._oSearchButton;
                    oButton.setText(oResourceBundle.getText("search"));
                }
            });

            //Variant management handler
            oFilter.attachBeforeVariantSave(this._onBeforeVariantSave, this);
            oFilter.attachAfterVariantLoad(this._onAfterVariantLoad, this);

            var startupParams = this.getOwnerComponent().getComponentData()?.startupParameters;
            if (startupParams?.AUFNR) {
                var oGlobalBusyDialog = new sap.m.BusyDialog();
                oGlobalBusyDialog.open();
                var sObjectPath = "/OrderSet(" + "'" + startupParams.AUFNR[0] + "')";
                this._getinfo(sObjectPath, oGlobalBusyDialog);
            }

            //manage batch request( sent /completed )
            this.getOwnerComponent().getModel().attachBatchRequestSent(this._onBatchRequestSent, this);
            this.getOwnerComponent().getModel().attachBatchRequestCompleted(this._onBatchRequestCompleted, this);
            this.getOwnerComponent().getModel("researchModel").attachBatchRequestCompleted(this._onBatchRequestCompleted, this);
            this.getOwnerComponent().getModel("researchModel").attachBatchRequestSent(this._onBatchRequestSent, this);
        },

        // event handler for batch request sent 
        _onBatchRequestSent: function() {
            if (!this._oGlobalBusyIndicator) {
                this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            }
            this._oGlobalBusyIndicator.open();
        },

        // event handler for batch request completed 
        _onBatchRequestCompleted: function() {
            this._oGlobalBusyIndicator.close();
        },

        _onBeforeVariantSave: function(oEvent) {
            var oFilterCriteriaValues = {},
                oFilter;

            // get the smartfilter
            oFilter = oEvent.getSource();

            //get filter criteria values 
            oFilterCriteriaValues._CUSTOM = this._prepareDefaultValue(oFilter);

            oEvent.getSource().setFilterData(oFilterCriteriaValues, true);
        },

        /**
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-538
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/02/2022
         * Motif : Permettre la recherche des ordres à partir des PT inclus dans 
         *         la liste des objets de l'ordre    
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-578
         * Par : Alexandre PISSOTTE (APY)
         * Date : 23/03/2022
         * Motif : Champs "Secteur d'exploitation" pas pris en compte pour la
         *         variante
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _prepareDefaultValue: function(oFilter) {

            var aFiltersSingleParameters = ["AUFNR", "KTEXT", "VAPLZ", "WAWRK", "SWERK", "EQFNR", "INGRP", "BEBER"],
                _custom = {},
                sProperty, sValue, aNotifTypes = [],
                aStatus = [],
                aWorkTypes = [],
                aFuncLocations = [],
                aEquipements = [];

            // save single value filter criteria 	
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                sValue = this.getView().getModel("Order").getProperty(sProperty);
                if (sValue) {
                    _custom[aFiltersSingleParameters[i]] = sValue;
                }
            }

            var startDate = this.getView().byId("pickerDateDebutID").getValue();
            if (startDate) {
                _custom["GSTRP"] = startDate;
                /* AAA (+){ GMAO29 */
            } else {
                _custom["GSTRP"] = null;
                /* AAA }(+) GMAO29 */
            }

            var endDate = this.getView().byId("pickerDateFinID").getValue();
            if (endDate) {
                _custom["GLTRP"] = endDate;
                /* AAA (+){ GMAO29 */
            } else {
                _custom["GLTRP"] = null;
                /* AAA }(+) GMAO29 */
            }

            // save Multiple value filter criteria 
            aNotifTypes = this._getOrderTypes();
            if (aNotifTypes.length !== 0) {
                _custom["AUART"] = aNotifTypes;
            }

            aStatus = this._getSystemStatus();
            if (aStatus.length !== 0) {
                _custom["STATUS"] = aStatus;
            }

            aWorkTypes = this._getWorkTypes();
            if (aStatus.length !== 0) {
                _custom["ILART"] = aWorkTypes;
            }

            aFuncLocations = this._getFuncLocations();
            if (aFuncLocations.length !== 0) {
                _custom["TPLNR"] = aFuncLocations;
            }

            aEquipements = this._getEquipements();
            if (aEquipements.length !== 0) {
                _custom["EQUNR"] = aEquipements;
            }

            _custom["FLAG_OBJECT_LIST"] = this.getView().byId("FLAG_OBJECT_LIST").getSelected();

            return _custom;
        },

        _getFuncLocations: function() {
            //get functional Location values  
            var aFuncLocTokens = this.getView().byId("PosteTechnique").getTokens(),
                aFuncLocations = [];

            for (var i = 0; i < aFuncLocTokens.length; i++) {
                aFuncLocations.push(aFuncLocTokens[i].getKey());
            }
            return aFuncLocations;
        },

        _getEquipements: function() {
            //get equipements values  
            var aEquipementTokens = this.getView().byId("equipement").getTokens(),
                aEquipements = [];

            for (var i = 0; i < aEquipementTokens.length; i++) {
                aEquipements.push(aEquipementTokens[i].getKey());
            }
            return aEquipements;
        },

        _getWorkTypes: function() {
            //get order type filter values   
            var aTypes = this.getView().byId("workTypeInput").getTokens(),
                aWorkTypes = [],
                sWorkType;

            for (var ii = 0; ii < aTypes.length; ii++) {
                sWorkType = aTypes[ii].getText();
                aWorkTypes.push(sWorkType);
            }
            return aWorkTypes;
        },

        _getOrderTypes: function() {
            //get order type filter values   
            var aTypesOrder = this.getView().byId("typeOrderInput").getTokens(),
                aOrderTypes = [],
                sTypeOrder;

            for (var ii = 0; ii < aTypesOrder.length; ii++) {
                sTypeOrder = aTypesOrder[ii].getText();
                aOrderTypes.push(sTypeOrder);
            }
            return aOrderTypes;
        },

        _getSystemStatus: function() {
            // get system Status value
            var sStatusInput = this.getView().byId("statusComboBox"),
                aSelectedKeys = sStatusInput.getSelectedKeys(),
                aStatus = [];
            for (var i = 0; i < aSelectedKeys.length; i++) {
                aStatus.push(aSelectedKeys[i]);
            }

            return aStatus;
        },

        _onAfterVariantLoad: function(oEvent) {
            var oVariantData = JSON.parse(oEvent.getSource().fetchVariant().filterBarVariant)["_CUSTOM"];
            if (oVariantData) {
                this._setFilterCriteriaData(oVariantData);
            } else {
                this._initializeFilterCriteria();
            }
            var filterBar = this.getView().byId("smartFilterBar");
            if (this.getView().byId("smartFilterBar").getVariantManagement().oSelectedItem.getExecuteOnSelection()) {
                filterBar.fireSearch();
            }
        },

        /**
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-538
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/02/2022
         * Motif : Permettre la recherche des ordres à partir des PT inclus dans 
         *         la liste des objets de l'ordre    
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-578
         * Par : Alexandre PISSOTTE (APY)
         * Date : 23/03/2022
         * Motif : Champs "Secteur d'exploitation" pas pris en compte pour la
         *         variante
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _initializeFilterCriteria: function() {
            var aFiltersSingleParameters = ["AUFNR", "KTEXT", "VAPLZ", "WAWRK", "SWERK", "EQFNR", "INGRP", "BEBER"],
                sProperty;
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                this.getView().getModel("Order").setProperty(sProperty, "");
            }
            this.getView().byId("pickerDateDebutID").setValue("");
            this.getView().byId("pickerDateFinID").setValue("");
            this.getView().byId("PosteResponsableInput").setValueState("Error");
            this.getView().byId("equipement").removeAllTokens();
            this.getView().byId("PosteTechnique").removeAllTokens();
            this.getView().byId("statusComboBox").clearSelection();
            this.getView().byId("typeOrderInput").removeAllTokens();
            this.getView().byId("workTypeInput").removeAllTokens();

            this.getView().getModel("Order").setProperty("/FLAG_OBJECT_LIST", false);
            this.getView().byId("FLAG_OBJECT_LIST").setSelected(false);
        },

        /**
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-538
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/02/2022
         * Motif : Permettre la recherche des ordres à partir des PT inclus dans 
         *         la liste des objets de l'ordre    
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-578
         * Par : Alexandre PISSOTTE (APY)
         * Date : 23/03/2022
         * Motif : Champs "Secteur d'exploitation" pas pris en compte pour la
         *         variante
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _setFilterCriteriaData: function(oObject) {
            var aFiltersSingleParameters = ["AUFNR", "KTEXT", "VAPLZ", "WAWRK", "SWERK", "EQFNR", "INGRP", "BEBER"],
                sValue, sProperty;
            // set single value filter criteria 	
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                sValue = oObject[aFiltersSingleParameters[i]];
                if (sValue) {
                    this.getView().getModel("Order").setProperty(sProperty, sValue);
                } else {
                    this.getView().getModel("Order").setProperty(sProperty, "");
                }
            }

            if (!oObject["VAPLZ"] || oObject["VAPLZ"] === "") {
                this.getView().byId("PosteResponsableInput").setValueState("Error");
            } else {
                this.getView().byId("PosteResponsableInput").setValueState("None");
            }

            this.getView().getModel("Order").getProperty("/FLAG_OBJECT_LIST", oObject.FLAG_OBJECT_LIST);
            this.getView().byId("FLAG_OBJECT_LIST").setSelected(oObject.FLAG_OBJECT_LIST);

            this._setOrderType(oObject);

            this._setWorkType(oObject);

            this._setSystemStatus(oObject);

            this._setFunctLocations(oObject);

            this._setEquipements(oObject);

            this._setStartEndDate(oObject);

        },

        _setWorkType: function(oObject) {
            var aWorkTypes = oObject["ILART"],
                oWorkTypeInput = this.getView().byId("workTypeInput");
            oWorkTypeInput.removeAllTokens();
            if (aWorkTypes) {
                for (var i = 0; i < aWorkTypes.length; i++) {

                    var token = new sap.m.Token({
                        key: aWorkTypes[i],
                        text: aWorkTypes[i]
                    });

                    oWorkTypeInput.addToken(token);
                }
            }
        },

        _setOrderType: function(oObject) {
            var aOrderTypes = oObject["AUART"],
                oOrderTypeInput = this.getView().byId("typeOrderInput");
            oOrderTypeInput.removeAllTokens();
            if (aOrderTypes) {
                for (var i = 0; i < aOrderTypes.length; i++) {

                    var token = new sap.m.Token({
                        key: aOrderTypes[i],
                        text: aOrderTypes[i]
                    });

                    oOrderTypeInput.addToken(token);
                }
            }
        },

        _setStartEndDate: function(oObject) {
            var startDate = oObject["GSTRP"];

            if (startDate) {
                this.getView().byId("pickerDateDebutID").setValue(startDate);
            } else {
                // this.getView().byId("pickerDateDebutID").setValue(""); /* AAA (-) GMAO29 */
                this.getView().byId("pickerDateDebutID").setValue(null); /* AAA (+) GMAO29 */
            }

            var endDate = oObject["GLTRP"];
            if (endDate) {
                this.getView().byId("pickerDateFinID").setValue(endDate);
            } else {
                // this.getView().byId("pickerDateFinID").setValue(""); /* AAA (-) GMAO29 */
                this.getView().byId("pickerDateFinID").setValue(null); /* AAA (+) GMAO29 */
            }
        },

        _setSystemStatus: function(oObject) {
            var aSystemStatus = oObject["STATUS"],
                oStatusFilter = this.getView().byId("statusComboBox");
            oStatusFilter.clearSelection();
            if (aSystemStatus) {
                oStatusFilter.setSelectedKeys(aSystemStatus);
            }
        },

        _setFunctLocations: function(oObject) {
            // set functional Locations 
            var aFuncLocations = oObject["TPLNR"],
                oFuncLocMultiInput = this.getView().byId("PosteTechnique");
            oFuncLocMultiInput.removeAllTokens();
            if (aFuncLocations) {
                for (var i = 0; i < aFuncLocations.length; i++) {

                    var token = new sap.m.Token({
                        key: aFuncLocations[i],
                        text: aFuncLocations[i]
                    });

                    oFuncLocMultiInput.addToken(token);
                }
            }
        },

        _setEquipements: function(oObject) {
            // set equipements 
            var aEquipements = oObject["EQUNR"],
                oEquipMultiInput = this.getView().byId("equipement");
            oEquipMultiInput.removeAllTokens();
            if (aEquipements) {
                for (var i = 0; i < aEquipements.length; i++) {

                    var token = new sap.m.Token({
                        key: aEquipements[i],
                        text: aEquipements[i]
                    });

                    oEquipMultiInput.addToken(token);
                }
            }
        },

        _getinfo: function(sobject, oGlobalBusyDialog) {
            this.getOwnerComponent().getModel().read(sobject, {
                success: function(odata, oresp) {
                    var bLauched = odata.OT_OUVERT;
                    var sOrderNumber = odata.AUFNR;
                    oGlobalBusyDialog.close();
                    this._proccedToDetail(bLauched, sOrderNumber);
                }.bind(this),
                error: function(error) {

                }
            });
        },

        onAfterRendering: function() {
            //Initialize Status system  
            this.getView().byId("statusComboBox").setSelectedKeys(this.getModel("statutSysteme").getProperty("/selected"));

        },

        /**
         * Alimente le sap.m.MultiInput du poste technique avec les valeurs
         * retournées de la recherche hiérarchique.
         * 
         * @private
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-436
         * Par : Alexandre PISSOTTE
         * Date : 10/11/2021
         * Motif : Faire passer à l'aide à la recherche le secteur d'exploitation
         * et le poste technique suffixé d'une étoile
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _displayHirarchyList: function() {
            var afunctionLocs = this.getModel("hierarchySearch").getProperty("/funcLocations"),
                oFuncLocationMultiInput = this.getView().byId("PosteTechnique");

            if (afunctionLocs.length !== 0) {
                this.getView().byId("statusComboBox").setSelectedKeys(this.getModel("statutSysteme").getProperty("/selected"));
                this.getView().byId("pickerDateDebutID").setDateValue(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));
                oFuncLocationMultiInput.removeAllTokens();
                for (var i = 0; i < afunctionLocs.length; i++) {
                    var token = new sap.m.Token({
                        key: afunctionLocs[i].TPLNR,
                        text: afunctionLocs[i].TPLNR,
                        // text: afunctionLocs[i].PLTXT, // (-) GMAO-436 (APY)
                        tooltip: afunctionLocs[i].PLTXT
                    });
                    oFuncLocationMultiInput.addToken(token);
                }

                this.getModel("Order").setProperty("/VAPLZ", this.getModel("hierarchySearch").getProperty("/ARBPL"));
                this.getView().byId("PosteResponsableInput").fireChange();
                this.getView().byId("smartFilterBar").fireSearch();
            }
        },

        _onWorkListMatched: function(oEvent) {
            this._displayHirarchyList();
        },

        onExit: function() {
            var aFragments = [this._technicalObjectHelp, this._EquipementValueHelp, this._workTypeHelp, this._workCenterPlantHelp,
            this._workLeadHelp, this._pmPlannerGroupHelp, this._LocalisationPlantHelp, this._LocalisationHelp, this._OperatingSectorHelp,
            this._ClassHelp, this._articleHelp, this._storeHelp, this._equipementClassHelp
            ];
            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }

        },
        _destroyFragmentInstance: function(FragmentInstance) {
            var oFragmentInstance = FragmentInstance;
            oFragmentInstance.destroy();
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
        onUpdateFinished: function(oEvent) {
            // update the worklist's object counter after the table update
            // var sTitle,
            // 	oTable = oEvent.getSource(),
            // 	iTotalItems = oEvent.getParameter("total");
            // // only update the counter if the length is final and
            // // the table is not empty
            // if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
            // 	sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
            // } else {
            // 	sTitle = this.getResourceBundle().getText("worklistTableTitle");
            // }
            // this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
        },

        //instantiate  xml fragment 
        _instantiateFragment: function(FragmentName) {
            var FragmentInstance;
            FragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
            this.getView().addDependent(this.FragmentInstance);
            FragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
            FragmentInstance.setModel(this.getView().getModel("researchModel"));
            return FragmentInstance;
        },

        //search an input value from a list of elements 
        _searchElementFromSelectDialogList: function(oEvent, FilterName) {
            var sValue, oFilter, oBinding;
            sValue = oEvent.getParameter("value").toUpperCase();
            oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
            oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
        onPress: function(oEvent) {
            var listItem, AUFNR, bLAunched;

            listItem = oEvent.getParameter("listItem");
            bLAunched = listItem.getBindingContext().getProperty("OT_OUVERT");
            AUFNR = listItem.getBindingContext().getObject().AUFNR;
            // The source is the list item that got pressed
            this._proccedToDetail(bLAunched, AUFNR);
        },
        _proccedToDetail: function(bLaunched, orderNumber) {
            var Message, buttonText, textModel, popupTitle;
            if (!bLaunched) {
                this._showObject(orderNumber);
            } else {
                textModel = this.getView().getModel("i18n").getResourceBundle();
                Message = textModel.getText("order") + orderNumber + " " + textModel.getText("orderLaunchErrorMessage");
                buttonText = textModel.getText("orderLaunch");
                popupTitle = textModel.getText("Error");
                sap.m.MessageBox.error(Message, {
                    title: popupTitle,
                    actions: [buttonText, sap.m.MessageBox.Action.CLOSE],
                    onClose: function(sAction) {
                        switch (sAction) {
                            case buttonText:
                                this._onLaunchOrder(orderNumber, "X");
                                break;
                            default:

                        }

                    }.bind(this)
                });

            }
        },

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
        onNavBack: function() {
            history.go(-1);
        },

        onSearch: function(oEvent) {
            var oTableSearchState = [];
            var squery = oEvent.getParameter("query");
            if ((squery !== null) && (squery !== undefined) && (squery !== "")) {
                oTableSearchState.push(new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, squery));
            }

            this._applySearch(oTableSearchState);

        },

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
        onRefresh: function() {
            var oTable = this.byId("table").getTable();
            oTable.getBinding("items").refresh();

        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
        _showObject: function(orderNumer) {
            this.getRouter().navTo("object", {
                objectId: orderNumer
            });
        },

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
        _applySearch: function(oTableSearchState) {
            var oTable = this.byId("table"),
                oViewModel = this.getModel("worklistView");
            oTable.getBinding("items").filter(oTableSearchState, "Application");
            // changes the noDataText of the list in case there are no filter results
            if (oTableSearchState.length !== 0) {
                oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
            }
        },

        orderTypeHelp: function() {
            var OrderTypeMultiInput = this.getView().byId("typeOrderInput"),
                oMultiSelectionMode = new MultiSelectionMode(new JSONModel(), function(aTokens) {
                    OrderTypeMultiInput.setTokens(aTokens);

                });
            new OrderTypeSearchHelp(this, oMultiSelectionMode).open();

        },

        workTypeHelp: function() {
            var oWorkTypeMultiInput = this.getView().byId("workTypeInput"),
                oMultiSelectionMode = new MultiSelectionMode(new JSONModel(), function(aTokens) {
                    oWorkTypeMultiInput.setTokens(aTokens);

                });
            new WorkTypeSearchHelp(this, oMultiSelectionMode).open();
        },

        // afficher le "selectdialog" pour rechercher un poste responsable
        PosteResonsableDivision: function() {
            var oPosteResponsable = this.getView().byId("PosteResponsableInput"),
                oOrderObject = this.getView().getModel("Order");

            if (!this._posteResponsableHelp) {

                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
                    oPosteResponsable.setValue(oObject.ARBPL);
                    oOrderObject.setProperty("/WAWRK", oObject.WERKS);
                    oPosteResponsable.setValueState("None");
                });
                this._posteResponsableHelp = new WorkCenterSearchHelp(this, oObjectSelectionMode);

            }
            this._posteResponsableHelp.open();

        },

        /**
         * Afficher l'aide à la recherche du poste technique&nbsp;
         * 
         * @public
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-436
         * Par : Alexandre PISSOTTE
         * Date : 10/11/2021
         * Motif : Faire passer à l'aide à la recherche le secteur d'exploitation
         * et le poste technique suffixé d'une étoile
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        OnTplnrRequest: function() {
            var oFunctionalLocation = this.getView().byId("PosteTechnique");
            if (!this._technicalObjectHelp) {
                var oMultiSelectMode = new MultiSelectionMode(new JSONModel(), function(aTokens) {
                    oFunctionalLocation.setTokens(aTokens);
                });

                // GMAO-436 (APY)
                if (this.getModel("hierarchySearch").getProperty("/funcLocations")) {
                    this._technicalObjectHelp = new FunctionalLocationSearchHelp(this, oMultiSelectMode,
                        this.getModel("hierarchySearch").getProperty("/funcLocation"),
                        this.getModel("hierarchySearch").getProperty("/BEBER")
                    );
                } else {
                    this._technicalObjectHelp = new FunctionalLocationSearchHelp(this, oMultiSelectMode);
                }
            }

            this._technicalObjectHelp.open();
        },

        onMangementGroupHelp: function() {
            var oOrderObject = this.getView().getModel("Order");
            if (!this._pmPlannerGroupHelp) {
                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {

                    oOrderObject.setProperty("/INGRP", oObject.INGRP);

                });
                this._pmPlannerGroupHelp = new PlannerGroupSearchHelp(this, oObjectSelectionMode);
            }
            this._pmPlannerGroupHelp.open();

        },

        /**
         * Ouvre l'aide à la recherche du secteur d'exploitation
         * @public
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-467
         * Par : Alexandre PISSOTTE (APY)
         * Date : 05/11/2021
         * Motif : Ajout des champs Désignation site (ZPLTXT) et secteur 
         * d'exploitation (BEBER) comme filtre dans la recherche des ordres.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onPlantSectionValueHelpRequest: function() {
            if (!this._plantSectionSearchHelp) {
                this._plantSectionSearchHelp = new PlantSectionSearchHelp(this, new SimpleSelectionMode(this.getView().getModel("Order"), "/BEBER"));
            }
            this._plantSectionSearchHelp.open();
        },

        ////////////////////////////////////////Equipement value Help Dialog Methods//////////////////////////////////////////

        //Display equipement dialog help&nbsp;
        OnEqunrRequest: function() {
            var oEquipement = this.getView().byId("equipement"),
                sFunctionalLocation = this.getView().byId("PosteTechnique").getValue();
            if (!this._EquipementValueHelp) {
                var oMultiSelectMode = new MultiSelectionMode(new JSONModel(), function(aTokens) {
                    oEquipement.setTokens(aTokens);
                });
                this._EquipementValueHelp = new EquipmentSearchHelp(this, oMultiSelectMode, sFunctionalLocation);

            }
            this._EquipementValueHelp.open();

        },

        onWorkCenterChange: function(oEvent) {
            var sWorkCenter = this.getView().getModel("Order").getProperty("/VAPLZ");
            if (!sWorkCenter || sWorkCenter === "") {
                this.getView().byId("PosteResponsableInput").setValueState("Error");
            } else {
                this.getView().byId("PosteResponsableInput").setValueState("None");
            }

        },

        onDivLocHelp: function() {
            var oComponentSearchModel = this.getView().getModel("componentSearchModel");
            var oOrderModel = this.getView().getModel("Order");

            if (!this._LocalisationPlantHelp) {
                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
                    oComponentSearchModel.setProperty("/SWERK", oObject.WERKS);
                    oOrderModel.setProperty("/SWERK", oObject.WERKS);
                });
                this._LocalisationPlantHelp = new MaintenancePlantSearchHelp(this, oObjectSelectionMode);
            }
            this._LocalisationPlantHelp.open();

        },

        onPosteResponsableRefresh: function() {
            this.getView().byId("PosteResponsableInput").setValue("");
            this.getView().getModel("Order").setProperty("/WAWRK", "");
            this.getView().byId("PosteResponsableInput").setValueState("Error");
        },

        onEquipementRefresh: function() {
            this.getView().byId("equipement").setValue("");
        },
        onPosteTechniqueRefresh: function() {
            this.getView().byId("PosteTechnique").setValue("");
            this.getModel("equipementSearchModel").setProperty("/TPLNR", "");
        },
        onMaintenancePlantRefresh: function() {
            this.getView().byId("divLocaInput").setValue("");
        },

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////

        /**
         * Construit les filtres pour la recherche des ordres.
         * 
         * @public
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-467
         * Par : Alexandre PISSOTTE (APY)
         * Date : 05/11/2021
         * Motif : Ajout des champs Désignation site (ZPLTXT) et secteur 
         * d'exploitation (BEBER) comme filtre dans la recherche des ordres.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-538
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/02/2022
         * Motif : Permettre la recherche des ordres à partir des PT inclus dans 
         *         la liste des objets de l'ordre    
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _filterConstructor: function(oEvent) {
            var aFilters = [],
                AfiltersParameters = [],
                sProperty, sValue,

                FilterOrderNumber, FilterTypeOder, FilterWorkType, typeOrder, workType, TechnicalObject, equipement;

            // prepare filters for order single selection filter criteria
            AfiltersParameters = ["AUFNR", "KTEXT", "VAPLZ", "WAWRK", "SWERK", "EQFNR", "INGRP", "ZPLTXT", "BEBER", "FLAG_OBJECT_LIST"]; // GMAO-467 (APY) // GMAO-538
            for (var i = 0; i < AfiltersParameters.length; i++) {
                sProperty = "/" + AfiltersParameters[i];
                sValue = this.getView().getModel("Order").getProperty(sProperty);
                if (sValue) {
                    // GMAO-467 (APY)
                    if (AfiltersParameters[i] === "ZPLTXT") {
                        sValue = sValue.toUpperCase();
                    }

                    if (AfiltersParameters[i] === "FLAG_OBJECT_LIST") {
                        sValue = sValue ? 'X' : '';
                    }

                    aFilters.push(new sap.ui.model.Filter(AfiltersParameters[i], sap.ui.model.FilterOperator.EQ, sValue));
                }
            }

            // gèrer le filtre type d'ordre&nbsp;
            var typeOrderInput = this.getView().byId("typeOrderInput");
            // gÃ©rer les valeurs selectionÃ©es du "select dialog"&nbsp;
            var typeOrders = typeOrderInput.getTokens();
            for (var j = 0; j < typeOrders.length; j++) {
                typeOrder = typeOrders[j].getText();
                FilterTypeOder = new sap.ui.model.Filter("AUART", sap.ui.model.FilterOperator.EQ, typeOrder);
                aFilters.push(FilterTypeOder);
            }

            // gÃ©rer les dates dÃ©but et fin&nbsp;
            var dateformatter = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "dd.MM.yyyy"
            });

            var startDate = dateformatter.format(this.getView().byId("pickerDateDebutID").getProperty("dateValue"));
            var endDate = dateformatter.format(this.getView().byId("pickerDateFinID").getProperty("dateValue"));

            if ((startDate !== null) && (startDate !== undefined) && (startDate !== "")) {
                var filterStartDate = new sap.ui.model.Filter("GSTRP", sap.ui.model.FilterOperator.EQ, startDate);
                aFilters.push(filterStartDate);
            }
            if ((endDate !== null) && (endDate !== undefined) && (endDate !== "")) {
                var filterEndDate = new sap.ui.model.Filter("GLTRP", sap.ui.model.FilterOperator.EQ, endDate);
                aFilters.push(filterEndDate);
            }

            //gÃ©rer les types de travail&nbsp;
            var workTypeInput = this.getView().byId("workTypeInput");
            // gÃ©rer les valeurs selectionÃ©es du "select dialog"&nbsp;
            var workTypes = workTypeInput.getTokens();
            for (var ii = 0; ii < workTypes.length; ii++) {
                workType = workTypes[ii].getText();
                FilterWorkType = new sap.ui.model.Filter("ILART", sap.ui.model.FilterOperator.EQ, workType);
                aFilters.push(FilterWorkType);
            }

            // gÃ©rer le filtre statut systÃ©me
            var statutInput = this.getView().byId("statusComboBox");
            var selectedKeys = statutInput.getSelectedKeys();
            for (var jj = 0; jj < selectedKeys.length; jj++) {
                var x = selectedKeys[jj];
                aFilters.push(new sap.ui.model.Filter("STATUS", sap.ui.model.FilterOperator.EQ, x));
            }

            // gÃ©rer le filtre poste technique
            var TechnicalObjectInput = this.getView().byId("PosteTechnique");
            var aTechnicalObjects = TechnicalObjectInput.getTokens();
            for (var z = 0; z < aTechnicalObjects.length; z++) {
                TechnicalObject = aTechnicalObjects[z].getKey();
                aFilters.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, TechnicalObject));
            }

            // gÃ©rer le filtre equipement
            var equipementInput = this.getView().byId("equipement");
            var aEquipements = equipementInput.getTokens();
            for (var y = 0; y < aEquipements.length; y++) {
                equipement = aEquipements[y].getKey();
                aFilters.push(new sap.ui.model.Filter("EQUNR", sap.ui.model.FilterOperator.EQ, equipement));
            }

            return aFilters;
        },

        onfilter: function(oEvent) {
            this.filters = [];
            var PosteResponsable = this.getView().byId("PosteResponsableInput").getValue();
            if (!PosteResponsable || PosteResponsable === "") {
                sap.m.MessageBox.warning("Attention le Poste responsable est obligatoire", {
                    title: "Avertissement" // default
                });

            } else {
                var filters = this._filterConstructor(oEvent);
                this.filters = filters;
                if (!this.oSorter) {
                    this.oSorter = new sap.ui.model.Sorter("AUFNR", true);
                }
                this._bindOrderTable(filters, this.oSorter);
            }

        },

        _bindOrderTable: function(aFilter, oSorter) {
            var tab = this.getView().byId("table").getTable(),
                template = this.getView().byId("table").getTable().getBindingInfo("items").template;

            tab.bindAggregation("items", {
                path: "/OrderSet",
                filters: aFilter,
                sorter: oSorter,
                template: template,
                events: {
                    dataReceived: function() {
                        tab.setBusy(false);
                    }
                }
            });
        },

        handleSearch: function(oEvent) {
            var sValue = oEvent.getParameter("value").toUpperCase();
            var oFilter = new sap.ui.model.Filter("AUART", sap.ui.model.FilterOperator.Contains, sValue);
            var oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);

        },
        handleWorkTypeSearch: function(oEvent) {
            var sValue = oEvent.getParameter("value").toUpperCase();
            var oFilter = new sap.ui.model.Filter("ILART", sap.ui.model.FilterOperator.Contains, sValue);
            var oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },
        handlePosteResSearch: function(oEvent) {
            var sValue = oEvent.getParameter("value").toUpperCase();
            var oFilter = new sap.ui.model.Filter("ARBPL", sap.ui.model.FilterOperator.Contains, sValue);
            var oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },
        onBeforeRebindTable: function(oEvent) {
            var params = oEvent.getParameters();
            if (this.filters) {
                oEvent.getParameter("bindingParams").filters = this.filters;
            }

            if (this.oSorter && params.bindingParams.sorter == undefined) { //GMAO-511 : if there's a sorter selected by the user then leave it
                oEvent.getParameter("bindingParams").sorter = this.oSorter;
            }

        },
        // toggle buttons visibility
        onTableSelection: function(oEvent) {
            var selectedItem = this._getSelectedItem();
            var launchStatus = selectedItem.getBindingContext().getObject().OT_OUVERT;
            if (selectedItem && launchStatus === true) {
                this._toggleToolBarButtonsLaunch(true);

            } else {
                this._toggleToolBarButtonsLaunch(false);
            }
        },

        //get table selected items&nbsp;
        _getSelectedItem: function() {
            return this.getView().byId("table").getTable().getSelectedItem();
        },

        //set tool bar buttons enabled/disabled
        _toggleToolBarButtonsLaunch: function(status) {
            this.getView().byId("launchButton").setEnabled(status);
        },

        onLaunchOrders: function(oEvent) {

            //	var selectedItem = this.getView().byId("table").getTable().getSelectedItem();
            var selectedItems = this.getView().byId("table").getTable().getItems();
            for (var i = 0; i < selectedItems.length; i++) {
                if (selectedItems[i].getSelected()) {
                    this._onLaunchOrder(selectedItems[i].getBindingContext().getObject().AUFNR, "");
                    // ndourPl
                    //	oGlobalBusyDialog.showBusyIndicator(4000,0);
                }
            }
        },

        _onLaunchOrder: function(orderNumber, Navigation) {

            var orderId = orderNumber,
                bError = false,
                sMessage,
                tMessage = [],
                oParameters = {
                    "AUFNR": orderId
                    //
                    //
                };
            // ndour Pap
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();
            this.getView().getModel().callFunction("/ReleaseOrder", // function import name
                {
                    method: "GET", // http method
                    urlParameters: oParameters, // function import parameters
                    context: null,

                    success: function(oData, response) { // callback function for success
                        // check if on message return is an error mrssage&nbsp;
                        for (var i = 0; i < oData.results.length; i++) {
                            if (oData.results[i].Type === "E") {
                                bError = true;
                                if (oData.results[i].Id !== "IWO_BAPI2") {
                                    tMessage.push(oData.results[i].Message);
                                }
                            }
                        }

                        //ndourPl
                        oGlobalBusyDialog.close();
                        if (bError === false) {
                            sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("succes"));

                            if (Navigation === "X") {
                                this._showObject(orderNumber);
                            } else {
                                this.getView().getModel().refresh();
                            }
                        } else {
                            for (i = 0; i < tMessage.length; i++) {
                                sap.m.MessageToast.show(tMessage[i]);
                            }
                            if (tMessage.length === 0) {
                                sap.m.MessageToast.show("Erreur de Lancement");
                            }
                        }

                    }.bind(this),
                    error: function(oError) { // callback function for error
                        oGlobalBusyDialog.close();
                        sap.m.MessageToast.show("Erreur de lancement");
                    }
                });
        },
        onAddOrder: function() {
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
            var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: "ZCreation_OT",
                    action: "display"
                }

            })) || ""; // generate the Hash to display the order creation app&nbsp;
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order creation app&nbsp;

        },
        onSortOrderPress: function() {

            if (!this._orderSortFragment) {
                this._orderSortFragment = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.orderSort");

            }

            this._orderSortFragment.open();
        },
        onOrderSortConfirmation: function(oEvent) {
            var oTable = this.getView().byId("table").getTable(),
                mParams = oEvent.getParameters(),
                oBinding = oTable.getBinding("items"),
                sPath,
                bDescending,
                oSorter;

            sPath = mParams.sortItem.getKey();
            bDescending = mParams.sortDescending;
            oSorter = new sap.ui.model.Sorter(sPath, bDescending);
            this.oSorter = oSorter;
            oBinding.sort(oSorter);
        },
        onMandFilterCriteriaChange: function(oEvent) {
            var sValueState = "None",
                sValueMessage = "",
                oTechObjModel = this.getModel("TechnicalObjectSearchModel"),
                sInputName = oEvent.getSource().getId(),
                sValue = oTechObjModel.getProperty("/BEBER");

            if (sInputName === "technivalObjectOperatingSector") {
                sValue = oTechObjModel.getProperty("/INGRP");
            }

            if (!oEvent.getParameter("newValue") && !sValue) {
                sValueState = "Error";
                sValueMessage = this.getModel("i18n").getResourceBundle().getText("FilterCriteriaValueMessage");
            }
            oTechObjModel.setProperty("/FilterCriteriaStatueValue", sValueState);
            oTechObjModel.setProperty("/FilterCriteriaValueMessage", sValueMessage);
        }

    });
});
jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.SimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.MaintenancePlantSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.StorageLocationFilterOnMaintenancePlantSearchHelp");

sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentDispoSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/MaintenancePlantSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/StorageLocationFilterOnMaintenancePlantSearchHelp",
    "../model/formatter",
    "sap/ui/model/Filter"
], function (
    BaseController,
    JSONModel,
    History,
    EquipmentDispoSearchHelp,
    SimpleSelectionMode,
    ObjectSimpleSelectionMode,
    MaintenancePlantSearchHelp,
    StorageLocationFilterOnMaintenancePlantSearchHelp,
    formatter,
    Filter
) {
    "use strict";

    return BaseController.extend("grtgaz.puma.ImputationDesTemps.controller.Object", {

        formatter: formatter,

        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
        /*                                        LIFECYCLE METHODS                                          */
        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function () {
            /***********************************************GMAO340 */
            this.getOwnerComponent().getService("ShellUIService").then(function (oShellService) {
                oShellService.setBackNavigation(function () {
                    this.onNavBack();
                }.bind(this));
            }.bind(this));
            /***********************************************END GMAO 340 */

            // Model used to manipulate control states. The chosen values make sure,
            // detail page is busy indication immediately so there is no break in
            // between the busy indication for loading the view's meta data
            var iOriginalBusyDelay,
                oViewModel = new JSONModel({
                    busy: true,
                    delay: 0,
                    isValid: true,
                    DefaultDateValue: new Date(2018, 8, 22, 0, 0, 0)
                });

            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

            // Store original busy indicator delay, so it can be restored later on
            iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
            this.setModel(oViewModel, "objectView");
            this.getOwnerComponent().getModel().metadataLoaded().then(function () {
                // Restore original busy indicator delay for the object view
                oViewModel.setProperty("/delay", iOriginalBusyDelay);
            });

            var inputModel = new JSONModel({
                InputId: ""
            });
            this.setModel(inputModel, "inputModel");
            var oCommentModel = new JSONModel();
            this.setModel(oCommentModel, "CommentModel");

            var oNotifCommentModel = new JSONModel();
            this.setModel(oNotifCommentModel, "NotifCommentModel");
            this.getOwnerComponent().getModel().setDeferredGroups(["UpdateGroup"]);
            this.getOwnerComponent().getModel().attachBatchRequestSent(this._onBatchRequestSent, this);
            this.getOwnerComponent().getModel().attachBatchRequestCompleted(this._onBatchRequestCompleted, this);

        },

        // event handler for batch request sent 
        _onBatchRequestSent: function () {
            if (!this._oGlobalBusyIndicator) {
                this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            }
            this._oGlobalBusyIndicator.open();
        },

        // event handler for batch request completed 
        _onBatchRequestCompleted: function () {
            this._oGlobalBusyIndicator.close();
        },

        onExit: function () {
            var aFragments = [
                this._displayAddCompFrag,
                this._componentStoreHelp,
                this._quantityComponent,
                this._SubOrderTypeSelection,
                this._onDeposeButtPress,
                this._equipementHelpPoseRecherche,
                this._equipementClassHelpPose,
                this._articleHelpPose,
                this._storeHelpPose,
                this._LocalisationPlantHelp,
                this._clotOrder,
                this._sortFragment1,
                this._sortFragment2,
                this._statusFragment,
                this._oTimesUpdateDialog,
                this._oTimeUpdateDialog,
                this._commentList,
                this._addCommentFragment
            ];

            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }

        },

        _destroyFragmentInstance: function (FragmentInstance) {
            var oFragmentInstance = FragmentInstance;
            oFragmentInstance.destroy();
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
        onNavBack: function () {
            if (this.bUnsaved) {
                this._checkUnsavedData("NAVBACK");
                return;
            }
            var sPreviousHash = History.getInstance().getPreviousHash();

            if (sPreviousHash !== undefined) {
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);

            }
        },

        onSupOrderPress: function (oEvent) {
            var sSupOrder = oEvent.getSource().getText();
            this.getRouter().navTo("object", {
                objectId: sSupOrder
            });
        },

        // sub operation binding methods///////////////////////////////////////////////////////////////		
        onBeforeSubOpRebindTable: function (oEvent) {
            var aFilters = [],
                sSelect = oEvent.getParameter("bindingParams").parameters.select,
                oSorter = new sap.ui.model.Sorter("TPLNR", true, this.fngroup.bind(this));

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
			/*
				TICKET JIRA GMAO-171
				Lorsque les opérations dépassent 100 lignes, seules les 100 premières sont affichées. Cela est
				dû à la limitation du modèle.
				
				Liste des modifications :
				- Augmenter la taille limite du modèle attaché à la table (sap.m) des sous-opérations
				- Augmenter la taille limite du modèle attaché à la table (sap.m) des imputations
				
				Fait le  : 27/01/2021
				Fait par : Alexandre PISSOTTE (APY)
			*/
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-171 (1)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            oEvent.getSource().getTable().getModel().setSizeLimit(99999);
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-171 (1)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

            aFilters = this._PrepareFilterForSearch(true);
            aFilters.push(new sap.ui.model.Filter("MODIF_STAT", sap.ui.model.FilterOperator.EQ, true));

            sSelect = sSelect + ",QMNUM,ESTAT,SORTL,KTSCH,STSMA,PLTXT,EQTXT,USR00,QMTXT,QMART,TXT30";
            oEvent.getParameter("bindingParams").parameters.select = sSelect;
            oEvent.getParameter("bindingParams").filters = aFilters;

            if (this._subOperSorter) {
                oEvent.getParameter("bindingParams").sorter = this._subOperSorter;
            } else {
                oEvent.getParameter("bindingParams").sorter = oSorter;
            }

        },
        onSubOpSearch: function (oEvent) {
            var oTable = this.getView().byId("sub-op-table").getTable(),
                oBinding = oTable.getBinding("items"),
                sSearchValue = oEvent.getParameter("query"),
                aFilters = [];

            aFilters = this._PrepareFilterForSearch(false);
            if (sSearchValue) {
                aFilters.push(new sap.ui.model.Filter("LTXA2", sap.ui.model.FilterOperator.Contains, sSearchValue));
            }

            oBinding.filter(aFilters);

        },
        onSortGroupElement: function () {
            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR;

            if (!this._sortFragment1) {
                this._sortFragment1 = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.sortGroup");

            }
            if (!this._aufnr2 || sOrderNumber !== this._aufnr2) {
                this._aufnr2 = sOrderNumber;
                this._bindtechPoste(sOrderNumber, "", "func-loc-filter");
            }

            this._sortFragment1.open();

        },

        _bindtechPoste: function (sOrderNumber, bIsOp, sTableName) {
            var aFilters = [];
            aFilters.push(new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, sOrderNumber));
            aFilters.push(new sap.ui.model.Filter("ISOP", sap.ui.model.FilterOperator.EQ, bIsOp));
            sap.ui.getCore().byId(sTableName).bindItems({
                path: "/FunctionalLocationSet",
                filters: aFilters,
                factory: function () {
                    return new sap.m.ViewSettingsItem({
                        key: "{TPLNR}",
                        text: "{PLTXT}"
                    });
                }
            });
        },
        handleSortGroupConfirmation: function (oEvent) {
            var oTable = this.getView().byId("sub-op-table").getTable(),
                mParams = oEvent.getParameters(),
                afilters = oEvent.getParameters().filterItems,
                afilterTplnr = [],
                oBinding = oTable.getBinding("items"),
                sPath,
                bDescending,
                oSorter;

            afilters.forEach(function (el) {
                afilterTplnr.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, el.getKey()));
            }.bind(this));

            oBinding.filter(afilterTplnr);

            sPath = mParams.sortItem.getKey();
            bDescending = mParams.sortDescending;
            if (sPath === "TPLNR") {
                oSorter = new sap.ui.model.Sorter(sPath, bDescending, this.fngroup.bind(this));
            } else {
                oSorter = new sap.ui.model.Sorter(sPath, bDescending, true);
            }

            // apply the selected sort and group settings
            oBinding.sort(oSorter);
            this._subOpfilter = afilterTplnr;
            this._subOperSorter = oSorter;
        },
        _PrepareFilterForSearch: function (bSearch) {
            var aFilters = [];
            if (this._subOpfilter) {
                this._subOpfilter.forEach(function (element) {
                    aFilters.push(element);
                }.bind(this));

            }
            if (bSearch) {
                aFilters.push(new sap.ui.model.Filter("MODIF_STAT", sap.ui.model.FilterOperator.EQ, true));
            }

            return aFilters;
        },

        //operations binding methods///////////////////////////////////////	
        onBeforeOpRebindTable: function (oEvent) {
            var aFilters = [],
                sSelect = oEvent.getParameter("bindingParams").parameters.select,
                oSorter = new sap.ui.model.Sorter("LTXA2", false);

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-171 (2)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            oEvent.getSource().getTable().getModel().setSizeLimit(99999);
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-171 (2)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

            if (this._Opfilter) {
                this._Opfilter.forEach(function (element) {
                    aFilters.push(element);
                }.bind(this));
            }

            aFilters.push(new sap.ui.model.Filter("SAISIE_TPS", sap.ui.model.FilterOperator.EQ, true));

            sSelect = sSelect + ",QMNUM,ESTAT,SORTL,KTSCH,STSMA,PLTXT,EQTXT,USR00,RUECK,VORNR,AUFNR";
            oEvent.getParameter("bindingParams").parameters.select = sSelect;
            oEvent.getParameter("bindingParams").filters = aFilters;

            if (this._OperSorter) {
                oEvent.getParameter("bindingParams").sorter = this._OperSorter;
            } else {
                oEvent.getParameter("bindingParams").sorter = oSorter;
                this._OperSorter = oSorter;
            }
        },
        operationFactory: function (sId, oContext) {
            return new sap.ui.core.ListItem({
                key: "{ESTAT}",
                text: "{TXT30}"
                // additionalText: "{ESTAT}"
            });
        },
        fngroup: function (oCOntexet) {
            var text,
                key = oCOntexet.getObject().TPLNR;
            if (oCOntexet.getObject().PLTXT && oCOntexet.getObject().TPLNR) {
                text = oCOntexet.getObject().PLTXT + "-(" + oCOntexet.getObject().TPLNR + ")";
            } else {
                text = this.getView().getModel("i18n").getResourceBundle().getText("NoFunctionalLocation");
            }

            return {
                key: key,
                text: text
            };
        },
        onOpSearch: function (oEvent) {
            var oTable = this.getView().byId("op-table").getTable(),
                oBinding = oTable.getBinding("items"),
                sSearchValue = oEvent.getParameter("query"),
                aFilters = [];

            if (this._Opfilter) {
                this._Opfilter.forEach(function (element) {
                    aFilters.push(element);
                }.bind(this));
            }
            //aFilters.push(new sap.ui.model.Filter("SAISIE_TPS", sap.ui.model.FilterOperator.EQ, true));
            if (sSearchValue) {
                aFilters.push(new sap.ui.model.Filter("LTXA2", sap.ui.model.FilterOperator.Contains, sSearchValue));
            }

            oBinding.filter(aFilters);
        },
        onSortGroupElement1: function () {
            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR;

            if (!this._sortFragment2) {
                this._sortFragment2 = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.sortGroup1");
            }

            if (!this._aufnr4 || sOrderNumber !== this._aufnr4) {
                this._aufnr4 = sOrderNumber;
                this._bindtechPoste(sOrderNumber, "X", "func-loc-filter-op");
            }

            this._sortFragment2.open();
        },

        handleSortConfirmation: function (oEvent) {
            var oTable = this.getView().byId("op-table").getTable(),
                mParams = oEvent.getParameters(),
                afilters = oEvent.getParameters().filterItems,
                afilterTplnr = [],
                oBinding = oTable.getBinding("items"),
                sPath,
                bDescending,
                oSorter;

            afilters.forEach(function (el) {
                afilterTplnr.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, el.getKey()));
            }.bind(this));
            oBinding.filter(afilterTplnr);

            sPath = mParams.sortItem.getKey();
            bDescending = mParams.sortDescending;
            if (sPath === "TPLNR") {
                oSorter = new sap.ui.model.Sorter(sPath, bDescending, this.fngroup.bind(this));
            } else {
                oSorter = new sap.ui.model.Sorter(sPath, bDescending);
            }
            oBinding.sort(oSorter);
            this._OperSorter = oSorter;
            this._Opfilter = afilterTplnr;
        },

        onStatusSave: function () {
            var oTable = this.getView().byId("sub-op-table").getTable(),
                aSelectedElements = oTable.getSelectedItems(),
                sSeletecdLength = aSelectedElements.length;
            this.bUnsaved = false;
            if (sSeletecdLength === 0) {
                this._modifyTableStatus(oTable);
            } else {
                this._modifyMultipleStatus(aSelectedElements, sSeletecdLength);
            }

        },

        _modifyMultipleStatus: function (aSelectedItems) {
            if (aSelectedItems.length === 1) {
                sap.m.MessageBox.information(this.getView().getModel("i18n").getResourceBundle().getText("multiLinesSelection"));
                return;
                /*} else if (sLength > 1 && !this._checkStatusSchema(aElements)) {
                    sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("schemaStatusError"));
                    return;*/
            } else {
                this._displayMultipleStatusUpdateFragment(aSelectedItems);
            }
        },

        /**
         * Instancie et ouvre le fragment permettant de changer en masse le statut des actes sélectionnés en proposant
         * une liste déroulante (sap.m.Select) en fonction du schéma de statuts.
         * 
         * @private
         * @param {sap.m.ListItemBase[]} aSelectedItems 
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-110
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Saisie pour les actes des statuts réalisation et conformité en 
         * même temps.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _displayMultipleStatusUpdateFragment: function (aSelectedItems) {
            if (!this._statusFragment) {
                this._statusFragment = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.statusSelection");
            }

            var oModel = new sap.ui.model.json.JSONModel();

            // Vérifie la présence des types d'actes
            oModel.setProperty('/HAS_PUMA_OP', aSelectedItems.some(e => e.getBindingContext().getProperty("STSMA") === 'PUMA-OP'));
            oModel.setProperty('/HAS_CONFORM', aSelectedItems.some(e => e.getBindingContext().getProperty("STSMA") === 'CONFORM'));

            // Vide la précédente sélection pour chaque schéma de statuts
            /*oModel.setProperty('/ESTAT_PUMA_OP', null);
            oModel.setProperty('/ESTAT_CONFORM', null);*/

            sap.ui.getCore().byId("selectmenuone").setSelectedItem(null);
            sap.ui.getCore().byId("selectmenuone_st2").setSelectedItem(null);

            this._statusFragment.setModel(oModel, 'frgModel');

            this._statusFragment.open();
        },

        /**
         * @deprecated GMAO-110, remplacé par {@link #_displayMultipleStatusUpdateFragment}
         * @private
         * @param {sap.m.ListItemBase[]} aElements 
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-110
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Saisie pour les actes des statuts réalisation et conformité en 
         * même temps.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _bindSelectElement: function (aElements) {
            /*
            var sPath = aElements[0].getBindingContext().getPath();
            sap.ui.getCore().byId("selectmenuone").bindElement({
                path: sPath
            });

            var sKey = aElements[0].getBindingContext().getObject().STSMA;
                //aElements_status_list.push(aElements[0]);

            for (var i = 1; i < aElements.length; i++) {
                if (aElements[i].getBindingContext().getObject().STSMA !== sKey) {
                      var sPath2 = aElements[i].getBindingContext().getPath();
                      sap.ui.getCore().byId("selectmenuone_st2").bindElement({
                          path: sPath2
                      });
                      sap.ui.getCore().byId("selectmenuone_st2").setVisible(true);
                    break;
                }

            }
            */
        },

        /**
         * Procéde à la mise à jour en masse des statuts des actes
         */
        onFragmentSave: function () {
            this.bUnsaved = false;
            var oTable = this.getView().byId("sub-op-table").getTable(),
                aSelectedElements = oTable.getSelectedItems();
            this._processStatusModifiction(aSelectedElements, true);
            this._statusFragment.close();
        },

        /**
         * Ferme le fragement de mise à jour en masse des statuts des actes
         */
        onSaveCancel: function () {
            this._statusFragment.close();
        },

        _checkStatusSchema: function (aElements) {
            var bResult = true,
                sKey = aElements[0].getBindingContext().getObject().STSMA;

            for (var i = 1; i < aElements.length; i++) {
                if (aElements[i].getBindingContext().getObject().STSMA !== sKey) {
                    bResult = false;
                    break;
                }

            }
            return bResult;

        },

        /**
         * 
         * @private
         * @param {any[]} aElements 
         * @param {boolean} bMulti 
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-110
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Saisie pour les actes des statuts réalisation et conformité en 
         * même temps.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _processStatusModifiction: function (aElements, bMulti) {
            this.messages = [];
            var oModel = this.getView().getModel();
            for (var i = 0; i < aElements.length; i++) {
                var oOperationDetails = null,
                    sStatut = "",
                    sStatutText = "",
                    oInputCell,
                    oSelectControl,
                    aStatTable = [],
                    oContext = aElements[i].getBindingContext(),
                    sPath = oContext.getPath(),
                    sLineType = aElements[i].getMetadata().getName();

                // skip grouping line 	
                if (sLineType === "sap.m.GroupHeaderListItem") {
                    continue;
                }

                //get the line binding object 
                oOperationDetails = oContext.getObject();
                delete oOperationDetails.__metadata;
                delete oOperationDetails.operationDescriptifText;
                //update the status if updated 

                if (bMulti) {
                    // GMAO-110
                    switch (oContext.getProperty("STSMA")) {
                        case 'PUMA-OP':
                            oSelectControl = sap.ui.getCore().byId("selectmenuone");
                            break;
                        case 'CONFORM':
                            oSelectControl = sap.ui.getCore().byId("selectmenuone_st2");
                            break;
                    }

                    sStatut = oSelectControl.getSelectedKey();
                    sStatutText = oSelectControl.getSelectedItem().getText();

                } else {
                    oInputCell = this._getSpecificCell(aElements[i].getCells(), "sap.m.Input");
                    sStatut = oInputCell.getName();
                    sStatutText = oInputCell.getValue();

                }

                if ((sStatut && sStatut === oOperationDetails.ESTAT) || (sStatutText && sStatutText === oOperationDetails.TXT30)) {
                    continue;
                }

                oOperationDetails.ESTAT = sStatut;
                this.VONR = oOperationDetails.VONR;
                oModel.update(sPath, oOperationDetails, {
                    changeSetId: "changeSetStatus",
                    groupId: "UpdateGroup",
                    success: this._handleCallSuccess.bind(this),
                    error: this._handleCallError.bind(this)
                });

            }

            oModel.submitChanges({
                groupId: "UpdateGroup",
                success: this._handleSubmitChangeSuccess.bind(this),
                error: this._handleSubmitChangeError.bind(this)
            });
        },

        _getSpecificCell: function (aCells, sName) {
            var oControl;
            for (var el in aCells) {

                if (aCells[el].getName && aCells[el].getMetadata().getName() === sName) {
                    oControl = aCells[el];
                }

            }
            return oControl;
        },

        _modifyTableStatus: function (oTable) {
            var items = oTable.getAggregation("items");
            this._processStatusModifiction(items, false);

        },

        _getSelectComponentStatus: function (oItem) {
            var aCells = oItem.getCells(),
                aStatTable = [];
            for (var el in aCells) {
                if (aCells[el].getMetadata().getName() !== "sap.m.Input") {
                    continue;
                }
                aStatTable[0] = aCells[el].getProperty("selectedKey");
                aStatTable[1] = aCells[el].getValue();
                break;
            }
            return aStatTable;

        },

        _handleCallSuccess: function (oData, oResponse) {
            var oMessage;
            if (oResponse.headers["sap-message"]) {
                oMessage = $.parseJSON(oResponse.headers["sap-message"]);
                if (oMessage.severity === "error") {
                    oMessage.VONR = this.VONR;
                    this.messages.push(oMessage);
                } else {
                    this._bindHeader(); // GMAO-50
                }

            }

        },
        _handleCallError: function (oError) {

        },
        _handleSubmitChangeSuccess: function (oData, oResponse) {
            if (this.messages && this.messages.length !== 0) {
                this._constructErrorDialog();
            } else {
                sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("modificationStatusSuccess"));
            }
        },
        _handleSubmitChangeError: function (oError) {

        },

        _constructErrorDialog: function () {
            var dialog = new sap.m.Dialog({
                title: this.getView().getModel("i18n").getResourceBundle().getText("erreurSauvgarde"),
                type: 'Message',
                beginButton: new sap.m.Button({
                    text: 'OK',
                    press: function () {
                        dialog.close();
                    }
                }),
                afterClose: function () {
                    dialog.destroy();
                }
            });
            var verticallayout = new sap.ui.layout.VerticalLayout();
            verticallayout.addContent(new sap.m.Text({
                text: this.getView().getModel("i18n").getResourceBundle().getText("messageErreur") + ":"
            }));

            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
            for (var i = 0; i < this.messages.length; i++) {
                var msg = "\u2022" + "Op\u00e9ration:" + this.messages[i].vonr + "  " + "Message :" + this.messages[i].message + "\n";
                var x = new sap.m.Text({
                    text: msg
                });
                verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                verticallayout.addContent(x);
                verticallayout.addContent(new sap.ui.layout.VerticalLayout());
            }
            dialog.addContent(verticallayout);
            dialog.open();
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
        _onObjectMatched: function (oEvent) {
            var sObjectId = oEvent.getParameter("arguments").objectId;
            this.getModel().metadataLoaded().then(function () {
                var sObjectPath = this.getModel().createKey("OrderSet", {
                    AUFNR: sObjectId
                });
                this._bindView("/" + sObjectPath);
            }.bind(this));
            this.AUFNR = sObjectId;
        },
        onClotureOrderButton: function () {
            if (this.bUnsaved) {
                this._checkUnsavedData("CLOSEORDER");
                return;
            }

            if (!this._clotOrder) {
                this._clotOrder = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.Cloture");

            }
            this._clotOrder.open();
            sap.ui.getCore().byId("pickerDatdebID").setDateValue(new Date());

        },
        OnCancelCloseOrder: function () {
            this._clotOrder.close();
        },

        onDateChange: function (oEvent) {
            var sValid = oEvent.getParameter("valid");
            this.getView().getModel("objectView").setProperty("/isValid", sValid);
        },
        onCLoseOrder: function () {

            if (this.getView().getModel("objectView").getProperty("/isValid") === false) {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("wrongDateFormat"));
                return;
            }

            var dDate = sap.ui.getCore().byId("pickerDatdebID").getDateValue();
            var pickerDatdebID = sap.ui.core.format.DateFormat.getDateTimeInstance({
                pattern: "dd.MM.yyyy HH:mm"
            }).format(dDate).split(" "),
                sDate, sTime;

            if (pickerDatdebID.length === 2) {
                sDate = pickerDatdebID[0];
                sTime = pickerDatdebID[1] + ":00";
            } else {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("EmptyDate"));
                return;
            }

            var diff = Math.abs(new Date() - dDate);
            var diffD = Math.ceil(diff / (1000 * 60 * 60 * 24));

            if (diffD > 30) {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("overRangeDate"));
                return;
            }

            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR,
                Order = {
                    "AUFNR": sOrderNumber,
                    "DATE_REF": sDate,
                    "HEURE_REF": sTime
                };

            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();
            this.getView().getModel().callFunction("/ClotureOrder", // function import name
                {
                    method: "GET", // http method
                    urlParameters: Order, // function import parameters
                    context: null,
                    success: function (oData, response) { // callback function for success
                        this.OnCancelCloseOrder();
                        this._oGlobalBusyIndicator.close();
                        if (response.headers["sap-message"]) {
                            var oResponse = $.parseJSON(response.headers["sap-message"]);
                            if (oResponse.severity === "success") {
                                //Début Modif GMAO-382
                                var text;
                                if (oResponse.details) {
                                    for (var i = 0; i < oResponse.details.length; i++) {
                                        if (oResponse.details[i].code === "IW/189") {
                                            text = this.getView().getModel("i18n").getResourceBundle().getText("ClotureSuccessWarning");
                                        }
                                    }
                                }
                                if (!text) {
                                    text = this.getView().getModel("i18n").getResourceBundle().getText("ClotureSuccess");
                                }
                                sap.m.MessageBox.success(text, {
                                    //Fin Modif GMAO-382
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("success"),
                                    onClose: function () {
                                        this.getView().getElementBinding().refresh();
                                        this.getView().byId("end-button").setEnabled(false);
                                        this.getView().byId("clot-button").setEnabled(false);
                                    }.bind(this)

                                });
                            } else {
                                sap.m.MessageBox.error(oResponse.message, {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default

                                });
                            }
                        }
                    }.bind(this),
                    error: function (oError) { // callback function for error
                        this._oGlobalBusyIndicator.close();
                        this.OnCancelCloseOrder();
                    }.bind(this)
                });
        },

        onPressPauseOrder: function () {
            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR;
            var oOrder = {
                "AUFNR": sOrderNumber
            };

            // Met l'application en busy
            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();

            // Appel du function import PauseOrder
            this.getView().getModel().callFunction("/PauseOrder", {
                method: "GET", // http method
                urlParameters: oOrder, // function import parameters
                context: null,
                success: function (oData, response) { // callback function for success
                    // Enlève le busy
                    this._oGlobalBusyIndicator.close();

                    // Vérification des messages
                    if (response.headers["sap-message"]) {
                        var oResponse = $.parseJSON(response.headers["sap-message"]);

                        // Si on a un message de succés
                        if (oResponse.severity === "success") {
                            sap.m.MessageBox.success(oResponse.message, {
                                title: this.getView().getModel("i18n").getResourceBundle().getText("success"),
                                onClose: function () {
                                    this.getView().getElementBinding().refresh();
                                    this.getView().byId("end-button").setEnabled(false);
                                }.bind(this)
                            });
                        } else {
                            sap.m.MessageBox.error(oResponse.message, {
                                title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default
                            });
                        }
                    }
                }.bind(this),
                error: function () { // callback function for error
                    this._oGlobalBusyIndicator.close();
                }.bind(this)
            });
        },

        onPressReactivateOrder: function () {
            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR;
            var oOrder = {
                "AUFNR": sOrderNumber
            };

            // Met l'application en busy
            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();

            // Appel du function import PauseOrder
            this.getView().getModel().callFunction("/ReactivateOrder", {
                method: "GET", // http method
                urlParameters: oOrder, // function import parameters
                context: null,
                success: function (oData, response) { // callback function for success
                    // Enlève le busy
                    this._oGlobalBusyIndicator.close();

                    // Vérification des messages
                    if (response.headers["sap-message"]) {
                        var oResponse = $.parseJSON(response.headers["sap-message"]);

                        if (oResponse.severity === "success") {
                            sap.m.MessageBox.success(oResponse.message, {
                                title: this.getView().getModel("i18n").getResourceBundle().getText("success"),
                                onClose: function () {
                                    this.getView().getElementBinding().refresh();
                                    this.getView().byId("end-button").setEnabled(false);
                                }.bind(this)
                            });
                        } else {
                            sap.m.MessageBox.error(oResponse.message, {
                                title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default
                            });
                        }
                    }
                }.bind(this),
                error: function () { // callback function for error
                    this._oGlobalBusyIndicator.close();
                }.bind(this)
            });
        },

        onEndOrderButton: function () {
            if (this.bUnsaved) {
                this._checkUnsavedData("ENDORDER");
                return;
            }

            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR,
                Order = {
                    "AUFNR": sOrderNumber
                };

            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();
            this.getView().getModel().callFunction("/TerminateOrder", // function import name
                {
                    method: "GET", // http method
                    urlParameters: Order, // function import parameters
                    context: null,
                    success: function (oData, response) { // callback function for success
                        this._oGlobalBusyIndicator.close();
                        if (response.headers["sap-message"]) {
                            var oResponse = $.parseJSON(response.headers["sap-message"]);
                            if (oResponse.severity === "success") {
                                sap.m.MessageBox.success(this.getView().getModel("i18n").getResourceBundle().getText("TerminateSuccess"), {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("success"),
                                    onClose: function () {
                                        this.getView().getElementBinding().refresh();
                                        this.getView().byId("end-button").setEnabled(false);

                                    }.bind(this)

                                });
                            } else {
                                sap.m.MessageBox.error(oResponse.message, {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default

                                });
                            }
                        }
                    }.bind(this),
                    error: function (oError) { // callback function for error
                        this._oGlobalBusyIndicator.close();
                    }
                });

        },

        onTimeSave: function () {
            var oTable = this.getView().byId("op-table").getTable(),
                sSelecItemsNumber = oTable.getSelectedItems().length,
                bIsNew = this._CheckNewOrderDisplay();

            if (sSelecItemsNumber !== 0) {
                this._displayMultipleTimeUpdate(bIsNew);
            } else {
                this._displaySingleTimeUpdate(bIsNew);
            }
        },

        _CheckNewOrderDisplay: function () {
            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR,
                bIsNew = false;
            if ((this._aufnr3 && sOrderNumber !== this._aufnr3) || !this._aufnr3) {
                bIsNew = true;
            }
            if (!this._aufnr3 || sOrderNumber !== this._aufnr3) {
                this._aufnr3 = sOrderNumber;

            }
            return bIsNew;
        },

        _displaySingleTimeUpdate: function (bIsNew) {
            if (!this._oTimesUpdateDialog) {
                this._oTimesUpdateDialog = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.multiTimesUpdate");
                sap.ui.getCore().byId("realisation-dates").setDateValue(new Date());
                this._oTimesUpdateDialog.setModel(this.getView().getModel("objectView"), "objectView");
            }
            this._bindMultiInputOperations();
            if (bIsNew) {
                this._initialiseTImeInputFragements(true, this._checkDialogInstance(this._oTimeUpdateDialog));
            }

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
			/*
				TICKET JIRA GMAO-185
				Lorsque l'utilisateur filtre les imputations à partir d'un ou de plusieurs postes techniques,
				le fragment pour saisir le temps doit reprendre uniquement les opérations résultantes du filtre
				sur les postes techniques.
				
				Liste des modifications :
				- Ajout d'un filtre en ré-utilisant les propriétés privées de la méthode handleSortConfirmation.
				
				Fait le  : 26/01/2021
				Fait par : Alexandre PISSOTTE (APY)
			*/
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-185
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // Récupération du path pour accéder aux opérations à partir de l'entité d'Ordre
            var sPath = this.getView().getBindingContext().getPath() + "/ToOperations";

            if (this._Opfilter && this._OperSorter) {
                // Uniquement les opérations imputables
                this._Opfilter.push(new sap.ui.model.Filter("SAISIE_TPS", sap.ui.model.FilterOperator.EQ, true));
                var oSorter = new sap.ui.model.Sorter("KTSCH", false, this.fn1group);
                sap.ui.getCore().byId("operationsList").bindItems({
                    path: sPath,
                    factory: function () {
                        var oInput = new sap.m.InputListItem({
                            label: "{PLTXT}"
                        });
                        var oTimePicker = new sap.m.TimePicker({
                            valueFormat: "HH:mm",
                            displayFormat: "HH:mm",
                            dateValue: new Date(2018, 8, 22, 0, 0, 0),
                            change: this.onRecordedTimeChange.bind(this),
                            placeholder: this.getView().getModel("i18n").getResourceBundle().getText("recTimePlaceHolder")
                        });
                        oInput.addContent(oTimePicker);
                        return oInput;
                    }.bind(this),
                    filters: this._Opfilter,
                    sorter: oSorter
                });
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-185
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

            this._oTimesUpdateDialog.open();
        },

        _checkDialogInstance: function (oFragementInstance) {
            var oFragment = oFragementInstance,
                bInstance = false;
            if (oFragment) {
                bInstance = true;
            }
            return bInstance;
        },

        _initialiseTImeInputFragements: function (bSingleInput, bMultiInput) {
            if (bSingleInput) {
                sap.ui.getCore().byId("agents-multi-input").removeAllTokens();
                sap.ui.getCore().byId("realisation-dates").setDateValue(new Date());
                // this._bindMultiInputOperations();
            }
            if (bMultiInput) {
                sap.ui.getCore().byId("agent-multi-input").removeAllTokens();
                sap.ui.getCore().byId("realisation-date").setDateValue(new Date());
                sap.ui.getCore().byId("recorded-time").setValue("");
            }

        },

        _initialiseFuncLocationVH: function () {
            var oFunctionalLocation = sap.ui.getCore().byId("post-technique"),
                aFuncLocList = this.getModel("objectView").getProperty("/postetechnique"),
                aFuncLocFilter = [];

            oFunctionalLocation.removeAllTokens();
            aFuncLocList.forEach(function (element) {
                var oToken = new sap.m.Token({
                    key: element.TPLNR, // string
                    text: element.PLTXT // string

                });
                aFuncLocFilter.push(element.TPLNR);
                oFunctionalLocation.addToken(oToken);
            });

            return aFuncLocFilter;
        },

        _displayMultipleTimeUpdate: function (bIsNew) {
            if (!this._oTimeUpdateDialog) {
                this._oTimeUpdateDialog = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.multiTimeUpdate");
                sap.ui.getCore().byId("realisation-date").setDateValue(new Date());
            }
            if (bIsNew) {
                this._initialiseTImeInputFragements(this._checkDialogInstance(this._oTimesUpdateDialog), true);
            }
            sap.ui.getCore().byId("recorded-time").setDateValue(new Date(2018, 8, 22, 0, 0, 0));
            this._oTimeUpdateDialog.open();
        },

        onRecordedTimeChange: function (oEvent) {
            var oInput = oEvent.getSource(),
                oValue = oInput.getDateValue(),
                sWorkTime = this._ParseTimerValue(oValue),
                srecordTimeMessage = this.getModel("i18n").getResourceBundle().getText("valueStateMessage");
            if (!sWorkTime || sWorkTime < 0.25) {
                oInput.setValueState("Error");
                oInput.setValueStateText(srecordTimeMessage);
            } else {
                oInput.setValueState("None");
                oInput.setValueStateText("");
            }
        },

        _ParseTimerValue: function (oValue) {
            var nHours, nMinutes, sValue;
            if (oValue) {
                nHours = oValue.getHours();
                nMinutes = oValue.getMinutes();
                sValue = nHours + parseFloat((nMinutes / 60).toFixed(2));

            }
            return sValue;

        },

        HandleAgentValueRequest: function () {

            if (!this._agentHelp) {
                this._agentHelp = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.agentValueHelp");
                this._agentHelp.setModel(this.getView().getModel("objectView"), "objectView");
            }
            this._prepareAgentList();
            this._agentHelp.open();
            this.getView().getModel("objectView").setProperty("/Agent", "");
        },
        HandleAgentValueRequestx: function () {
            if (!this._agentHelp) {
                this._agentHelp = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.agentValueHelp");
                this._agentHelp.setModel(this.getView().getModel("objectView"), "objectView");
            }
            this._prepareAgentList();
            this._agentHelp.open();
            this.getView().getModel("objectView").setProperty("/Agent", "x");
        },

        _prepareAgentList: function () {
            var aItems = this.getView().byId("op-table").getTable().getAggregation("items"),
                sPath;
            if (aItems.length === 0) {
                return;
            }
            if (aItems[0].getMetadata().getName() === "sap.m.GroupHeaderListItem") {
                sPath = aItems[1].getBindingContext().getPath() + "/ToMatriculeOperations";
            } else {
                sPath = aItems[0].getBindingContext().getPath() + "/ToMatriculeOperations";
            }

            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();

            this.getModel().read(sPath, {
                success: function (odata, response) {
                    this._oGlobalBusyIndicator.close();
                    var data = this.getView().getModel("objectView").getData();
                    data.agentsData = odata.results;
                    this.getView().getModel("objectView").setData(data);
                }.bind(this),
                error: function () {

                }
            });
        },
        HandleAgentSearch: function (oEvent) {
            var Value = oEvent.getParameter("value").toUpperCase();
            var oFilter = new sap.ui.model.Filter({
                filters: [

                    // filter for value 1
                    new sap.ui.model.Filter("STEXT", sap.ui.model.FilterOperator.Contains, Value),

                    // filter for value 2
                    new sap.ui.model.Filter("PERNR", sap.ui.model.FilterOperator.Contains, Value)

                ],

                // set the OR or AND condition between the filters
                // true for AND, and false for OR
                // false by default
                and: false
            });

            var oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },
        onAgentsConfirm: function (oEvent) {
            var aSelectedItems = oEvent.getParameter("selectedItems"),
                oAgentsInput;

            if (this.getView().getModel("objectView").getProperty("/Agent") === "") {
                oAgentsInput = sap.ui.getCore().byId("agent-multi-input");
            } else {
                oAgentsInput = sap.ui.getCore().byId("agents-multi-input");
            }

            oAgentsInput.removeAllTokens();
            for (var i = 0; i < aSelectedItems.length; i++) {
                var s = aSelectedItems[i].getDescription(),
                    r = aSelectedItems[i].getTitle(),
                    token = new sap.m.Token({
                        key: s,
                        text: r
                    });

                oAgentsInput.addToken(token);
            }
        },
        onPosteTechniqueRequest: function () {
            if (!this._oPosteTechniqueDialog) {
                this._oPosteTechniqueDialog = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.postTechValueHelp");
                this._oPosteTechniqueDialog.setModel(this.getView().getModel("objectView"), "objectView");
            }
            this._oPosteTechniqueDialog.open();
            this._SelectDefaultFuncLocation();
        },

        _SelectDefaultFuncLocation: function () {
            var aSelectlistItems = this._oPosteTechniqueDialog.getAggregation("_dialog").getContent()[1].getItems(),
                aTokens = sap.ui.getCore().byId("post-technique").getTokens();
            if (aTokens.length !== 0) {
                aSelectlistItems.forEach(function (Element) {
                    var sId = Element.getBindingContext("objectView").getObject().TPLNR;
                    for (var i = 0; i < aTokens.length; i++) {
                        var sFuncLocation = aTokens[i].getKey();
                        if (sId === sFuncLocation) {
                            Element.setSelected(true);
                            break;
                        }
                    }

                });
            }

        },

        _bindFunctionalLocationVH: function () {
            var aFilters = [],
                sOrderNumber = this.getView().getBindingContext().getObject().AUFNR;

            aFilters.push(new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, sOrderNumber));
            aFilters.push(new sap.ui.model.Filter("ISOP", sap.ui.model.FilterOperator.EQ, "X"));

            this.getModel().read("/FunctionalLocationSet", {
                filters: aFilters,
                success: function (odata, response) {
                    var data = this.getView().getModel("objectView").getData();
                    data.postetechnique = odata.results;
                    this.getView().getModel("objectView").setData(data);
                }.bind(this),
                error: function () {

                }
            });
        },

        handlePosteSearch: function (oEvent) {
            var Value = oEvent.getParameter("value").toUpperCase();
            var oFilter = new sap.ui.model.Filter({
                filters: [

                    // filter for value 1
                    new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.Contains, Value),

                    // filter for value 2
                    new sap.ui.model.Filter("PLTXT", sap.ui.model.FilterOperator.Contains, Value)

                ],

                // set the OR or AND condition between the filters
                // true for AND, and false for OR
                // false by default
                and: false
            });

            var oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },
        handlePosteSelection: function (oEvent) {

            var oPT = sap.ui.getCore().byId("post-technique"),
                aSelectedItems = [],
                aFunctTable = [];
            sap.ui.getCore().byId("post-technique").removeAllTokens();
            aSelectedItems = oEvent.getParameter("selectedItems");
            aSelectedItems.forEach(function (Element) {
                var TPLNR = Element.getDescription(),
                    PLTXT = Element.getTitle(),
                    token = new sap.m.Token({
                        key: TPLNR,
                        text: PLTXT
                    });
                aFunctTable.push(TPLNR);
                oPT.addToken(token);
            });

            if (aFunctTable.length !== 0) {
                this._bindMultiInputOperations(aFunctTable);
            } else {
                sap.ui.getCore().byId("operationsList").unbindItems();
            }

        },

        _bindMultiInputOperations: function () {

            var template = sap.ui.xmlfragment("grtgaz.puma.ImputationDesTemps.view.fragments.listtemplate", this),
                oSorter = new sap.ui.model.Sorter("KTSCH", false, this.fn1group),
                sPath = this.getView().getBindingContext().getPath() + "/ToOperations",
                aFilters = [];

            aFilters.push(new sap.ui.model.Filter("SAISIE_TPS", sap.ui.model.FilterOperator.EQ, true));
            sap.ui.getCore().byId("operationsList").bindItems({
                path: sPath,
                factory: function () {
                    var oInput = new sap.m.InputListItem({
                        label: '{PLTXT}'
                    });

                    var oTimePicker = new sap.m.TimePicker({
                        valueFormat: 'HH:mm',
                        displayFormat: 'HH:mm',
                        dateValue: new Date(2018, 8, 22, 0, 0, 0),
                        change: this.onRecordedTimeChange.bind(this),
                        placeholder: this.getView().getModel("i18n").getResourceBundle().getText("recTimePlaceHolder")
                    });
                    oInput.addContent(oTimePicker);
                    return oInput;
                }.bind(this),
                filters: aFilters,
                sorter: oSorter

            });
        },

        fn1group: function (oCOntexet) {
            var key = oCOntexet.getObject().KTSCH;
            var text = oCOntexet.getObject().LTXA2;
            return {
                key: key,
                text: text
            };
        },

        onCancelmultiTimeUpdate: function () {
            this._oTimeUpdateDialog.close();
        },
        onCancelMultiTimesUpdate: function () {
            this._oTimesUpdateDialog.close();
        },

        onMultiTimesSave: function () {
            var aItems = sap.ui.getCore().byId("operationsList").getItems(),
                aMatricules = sap.ui.getCore().byId("agents-multi-input").getTokens(),
                sDate = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy"
                }).format(sap.ui.getCore().byId("realisation-dates").getDateValue()),
                oModel = this.getView().getModel();

            this.messages = [];

            if (aItems.length === 0 || aMatricules.length === 0 || !sDate) {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("imputationErreur"));
                return;
            }

            for (var i = 0; i < aItems.length; i++) {
                var oOperationDetails = null,
                    operations = [],
                    sStatut = "",
                    sLineType = aItems[i].getMetadata().getName();

                // skip grouping line 	
                if (sLineType === "sap.m.GroupHeaderListItem") {
                    continue;
                }
                var oContext = aItems[i].getBindingContext(),
                    sPath = oContext.getPath(),
                    sRecordedValue = this._ParseTimerValue(aItems[i].getContent()[0].getDateValue());

                if (!sRecordedValue || sRecordedValue < 0.25) {
                    continue;
                }

                //get the line binding object 
                oOperationDetails = oContext.getObject();
                delete oOperationDetails.__metadata;
                delete oOperationDetails.operationDescriptifText;

                oOperationDetails.CATSHOURS = sRecordedValue.toString();
                oOperationDetails.WORKDATE = sDate;
                for (var ii = 0; ii < aMatricules.length; ii++) {

                    operations.push(Object.assign({}, oOperationDetails, {
                        PERNR: aMatricules[ii].getKey()
                    }));
                }
                for (var j = 0; j < operations.length; j++) {
                    this._modifierLigneTable(operations[j], oContext, "changeSetStatus");
                }

            }
            this.getModel().submitChanges({
                groupId: "UpdateGroup",
                success: function (data, resp) {
                    this._oTimesUpdateDialog.close();

                    if (this.messages && this.messages.length !== 0) {

                        var dialog = new sap.m.Dialog({
                            title: this.getView().getModel("i18n").getResourceBundle().getText("erreurSauvgarde"),
                            type: 'Message',
                            beginButton: new sap.m.Button({
                                text: 'OK',
                                press: function () {
                                    dialog.close();
                                }
                            }),
                            afterClose: function () {
                                dialog.destroy();
                            }
                        });
                        var verticallayout = new sap.ui.layout.VerticalLayout();
                        verticallayout.addContent(new sap.m.Text({
                            text: this.getView().getModel("i18n").getResourceBundle().getText("messageErreur") + ":"
                        }));

                        verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        for (var i = 0; i < this.messages.length; i++) {
                            var msg = "\u2022" + "Op\u00e9ration:" + this.messages[i].vonr + "  " + "Message :" + this.messages[i].message + "\n";
                            var x = new sap.m.Text({
                                text: msg
                            });
                            verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                            verticallayout.addContent(x);
                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        }
                        dialog.addContent(verticallayout);
                        dialog.open();

                    } else {
                        sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("succesTime"));
                    }

                    // this.getView().byId("HistoryTable").getTable().getBinding("items").refresh(); // (-) GMAO-409 (APY)
                    this._bindHeader(); // GMAO-50

                }.bind(this),
                error: function (data, resp) {
                    this._oTimeUpdateDialog.close();
                    this._oGlobalBusyIndicators.close();

                }
            });

        },

        onMultiTimeSave: function () {
            var aItems = this.getView().byId("op-table").getTable().getSelectedItems(),
                aMatricules = sap.ui.getCore().byId("agent-multi-input").getTokens(),
                sRecordedTime = this._ParseTimerValue(sap.ui.getCore().byId("recorded-time").getDateValue()),
                sDate = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy"
                }).format(sap.ui.getCore().byId("realisation-date").getDateValue()),
                oModel = this.getView().getModel();

            this.messages = [];

            if (aItems.length === 0 || aMatricules.length === 0 || !sDate) {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("imputationErreur"));
                return;
            }

            if (sRecordedTime < 0.25) {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("valueStateMessage"));
                return;
            }

            for (var i = 0; i < aItems.length; i++) {
                var oOperationDetails = null,
                    operations = [],
                    sStatut = "",
                    oContext = aItems[i].getBindingContext(),
                    sPath = oContext.getPath(),
                    sLineType = aItems[i].getMetadata().getName();

                // skip grouping line 	
                if (sLineType === "sap.m.GroupHeaderListItem") {
                    continue;
                }

                //get the line binding object 
                oOperationDetails = oContext.getObject();
                delete oOperationDetails.__metadata;
                delete oOperationDetails.operationDescriptifText;

                oOperationDetails.CATSHOURS = sRecordedTime.toString();
                oOperationDetails.WORKDATE = sDate;
                for (var ii = 0; ii < aMatricules.length; ii++) {

                    operations.push(Object.assign({}, oOperationDetails, {
                        PERNR: aMatricules[ii].getKey()
                    }));
                }
                for (var j = 0; j < operations.length; j++) {
                    this._modifierLigneTable(operations[j], oContext, "changeSetStatus");
                }

            }
            this.getModel().submitChanges({
                groupId: "UpdateGroup",
                success: function (data, resp) {
                    this._oTimeUpdateDialog.close();

                    if (this.messages && this.messages.length !== 0) {

                        var dialog = new sap.m.Dialog({
                            title: this.getView().getModel("i18n").getResourceBundle().getText("erreurSauvgarde"),
                            type: 'Message',
                            beginButton: new sap.m.Button({
                                text: 'OK',
                                press: function () {
                                    dialog.close();
                                }
                            }),
                            afterClose: function () {
                                dialog.destroy();
                            }
                        });
                        var verticallayout = new sap.ui.layout.VerticalLayout();
                        verticallayout.addContent(new sap.m.Text({
                            text: this.getView().getModel("i18n").getResourceBundle().getText("messageErreur") + ":"
                        }));

                        verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        for (var i = 0; i < this.messages.length; i++) {
                            var msg = "\u2022" + "Op\u00e9ration:" + this.messages[i].vonr + "  " + "Message :" + this.messages[i].message + "\n";
                            var x = new sap.m.Text({
                                text: msg
                            });
                            verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                            verticallayout.addContent(x);
                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        }
                        dialog.addContent(verticallayout);
                        dialog.open();

                    } else {
                        sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("succesTime"));

                    }

                    // this.getView().byId("HistoryTable").getTable().getBinding("items").refresh(); // (-) GMAO-409 (APY)

                    this._bindHeader(); // GMAO-50
                }.bind(this),
                error: function (data, resp) {
                    this._oTimeUpdateDialog.close();
                    this._oGlobalBusyIndicators.close();

                }
            });

        },
        //modification unitaire d'operation 
        _modifierLigneTable: function (changedObject, Context, changeSetId) {

            var oModel = this.getModel(),
                sPath = Context.getPath();

            this.vonr = Context.getObject().VORNR;
            oModel.update(sPath, changedObject, {
                changeSetId: changeSetId,
                groupId: "UpdateGroup",
                success: function (data, resp) {
                    if (resp.headers["sap-message"]) {
                        var x = $.parseJSON(resp.headers["sap-message"]);
                        x.vonr = this.vonr;
                        this.messages.push(x);
                    }

                }.bind(this),
                error: function (data, resp) {

                }
            });

        },

        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
        /*                                           LAZY LOADING                                            */
        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

        /**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
        _bindView: function (sObjectPath) {
            // DEBUT MODIFICATION GMAO-362
            // this.getView().byId("page").setSelectedSection(this.getView().byId("iconTabBarFilter1")); // (-) GMAO-50 (APY)
            this.getView().byId("page").setSelectedSection(this.getView().byId("generalInformation"));
            // FIN MODIFICATION GMAO-362

            var oViewModel = this.getModel("objectView"),
                oDataModel = this.getModel();

            this.getView().bindElement({
                path: sObjectPath,
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oDataModel.metadataLoaded().then(function () {
                            // Busy indicator on view should only be set if metadata is loaded,
                            // otherwise there may be two busy indications next to each other on the
                            // screen. This happens because route matched handler already calls '_bindView'
                            // while metadata is loaded.
                            oViewModel.setProperty("/busy", true);
                        });
                    },
                    dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
                    }.bind(this)
                }
            });

        },

        _onBindingChange: function () {
            var oView = this.getView(),
                oViewModel = this.getModel("objectView"),
                oElementBinding = oView.getElementBinding();

            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("objectNotFound");
                return;
            }

            var Order = oView.getBindingContext().getObject(),
                orderType = Order.AUART,
                Equipement = Order.EQUNR;

            if ((orderType === "ZCO1" || orderType === "ZCO2" || orderType === "ZPR1" || orderType === "ZPR2" || orderType === "ZADP") && (!
                Order.OT_CLO)) {
                this.getView().byId("addSubOrderButton").setEnabled(true);
            } else {
                this.getView().byId("addSubOrderButton").setEnabled(false);
            }

            if (Equipement) {
                this.getView().byId("depose-button").setVisible(true);
                this.getView().byId("pose-button").setVisible(true);
            } else {
                this.getView().byId("depose-button").setVisible(false);
                this.getView().byId("pose-button").setVisible(true);
            }
            if (Order.OT_CLO) {
                this.getView().byId("depose-button").setEnabled(false);
                this.getView().byId("pose-button").setEnabled(false);
                this.getView().byId("status-save").setEnabled(false);
                this.getView().byId("addButton").setEnabled(false);

            } else {
                this.getView().byId("depose-button").setEnabled(true);
                this.getView().byId("pose-button").setEnabled(true);
                this.getView().byId("status-save").setEnabled(true);
                this.getView().byId("addButton").setEnabled(true);
            }

            if (Order.OT_CLO || Order.OT_TCLO) {
                this.getView().byId("end-button").setEnabled(false);
                this.getView().byId("clot-button").setEnabled(false);
            } else {
                this.getView().byId("clot-button").setEnabled(true);
                if (Order.USERSTATUS.includes("TERM")) {
                    this.getView().byId("end-button").setEnabled(false);
                } else {
                    this.getView().byId("end-button").setEnabled(true);
                }
            }

            // Gestion des status ATTE En attente de réalisation et ACTI Actif
            if (orderType === "ZCO1" || orderType === "ZCO2") {
                // L'ordre possède le statut En attente de réalisation
                if (Order.USERSTATUS.includes("ATTE")) {
                    this.getView().byId("reactivate-button").setVisible(true);
                    this.getView().byId("pause-button").setVisible(false);

                    // Désactivation des boutons dans l'en-tête
                    this.getView().byId("addSubOrderButton").setEnabled(false);
                    this.getView().byId("depose-button").setEnabled(false);
                    this.getView().byId("pose-button").setEnabled(false);
                    this.getView().byId("end-button").setEnabled(false);
                    this.getView().byId("clot-button").setEnabled(false);

                    // Désactivation des boutons dans les sections
                    this.getView().byId("status-save").setEnabled(false);
                    this.getView().byId("save-time").setEnabled(false);
                    this.getView().byId("addButton").setEnabled(false);

                } else if (Order.USERSTATUS.includes("ACTI")) { // L'odre possède le statut Actif
                    this.getView().byId("reactivate-button").setVisible(false);
                    this.getView().byId("pause-button").setVisible(true);

                    // Activiation des boutons dans l'en-tête
                    this.getView().byId("addSubOrderButton").setEnabled(true);
                    this.getView().byId("depose-button").setEnabled(true);
                    this.getView().byId("pose-button").setEnabled(true);
                    this.getView().byId("end-button").setEnabled(true);
                    this.getView().byId("clot-button").setEnabled(true);

                    // Activation des boutons dans les sections
                    this.getView().byId("status-save").setEnabled(true);
                    this.getView().byId("save-time").setEnabled(true);
                    this.getView().byId("addButton").setEnabled(true);

                } else {
                    this.getView().byId("reactivate-button").setVisible(false);
                    this.getView().byId("pause-button").setVisible(false);
                }
            } else {
                this.getView().byId("reactivate-button").setVisible(false);
                this.getView().byId("pause-button").setVisible(false);
            }

            this._bindHeader(); // GMAO-50
            this._bindFunctionalLocationVH();

            // DEBUT MODIFICATION GMAO-362
            // this._bindActesTables(); // GMAO-50
            // Fin MODIFICATION GMAO-362
            // Everything went fine.

            oViewModel.setProperty("/busy", false);
        },

        /**
         * [FR] Permet le lazy loading de l'en-tête de l'ObjectPage de l'ordre en effectuant
         * un appel oData GETENTITY de l'ordre consulté.
         * 
         * [EN] Perform lazy loading for ObjectPage header by sending an GETENTITY oData call
         * for the current order.
         * 
         * @private
         * @author Alexandre PISSOTTE (APY)
         */
        _bindHeader: function () {
            //var aFilters = [],
            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR;

            this.getModel().read("/OrderSet(AUFNR='" + sOrderNumber + "')", {
                success: function (odata, response) {
                    var data = this.getView().getModel("objectView").getData();
                    data.header = odata.results;
                    this.getView().getModel("objectView").setData(data);

                    this.getView().byId("op-conf-harvey").destroyTooltip();
                    this.getView().byId("op-conf-harvey-item").destroyTooltip();

                    this.getView().byId("op-rea-harvey").destroyTooltip();
                    this.getView().byId("op-rea-harvey-item").destroyTooltip();

                    this.getView().byId("op-imp-harvey").destroyTooltip();
                    this.getView().byId("op-imp-harvey-item").destroyTooltip();

                    this.getView().byId("op-mop-harvey").destroyTooltip();
                    this.getView().byId("op-mop-harvey-item").destroyTooltip();
                }.bind(this)
            });
        },

        // DEBUT MODIFICATION GMAO-362
        /**
         * Recharge la table des actes lors du changement d'un onglet vers l'onglet des actes.
         * Puisque l'onglet des actes contient un sap.m.IconTabBar, il fait sélectionner le tab "All"
         * pour que l'icon bar soit aligné avec la table.
         * 
         * @private
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-362
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-110
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Saisie pour les actes des statuts réalisation et conformité en 
         * même temps.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _bindActesTables: function () {
            var oTable = this.getView().byId("sub-op-table").getTable();
            if (oTable.isBound("items")) {
                var oTemplate = oTable.getBindingInfo("items").template,
                    aFilters = [new sap.ui.model.Filter("MODIF_STAT", sap.ui.model.FilterOperator.EQ, true)],
                    oSorter = oTable.getBindingInfo("items").sorter,
                    sPath = this.getView().getBindingContext().getPath() + "/ToOperations";
                this.getView().byId("sub-op-table").getTable().unbindItems();

                this.getView().byId("sub-op-table").getTable().bindAggregation("items", {
                    path: sPath,
                    parameters: {
                        expand: "operationDescriptifText"
                    },

                    filters: aFilters,
                    template: oTemplate,
                    sorter: oSorter
                });
                this.getView().byId("sub-op-table").getTable().setBusy(false);
                this.getView().byId("search-subop-field").setValue("");
                this.getView().byId("search-op-field").setValue("");
            }

            // GMAO-110
            this.getView().byId("idIconTabBar").setSelectedKey("All");
        },

        _bindImputationTables: function () {
            var oTable1 = this.getView().byId("op-table").getTable();
            
            if (oTable1.isBound("items")) {
                var oTemplate1 = oTable1.getBindingInfo("items").template,
                    aFilters1 = [new sap.ui.model.Filter("SAISIE_TPS", sap.ui.model.FilterOperator.EQ, true)],
                    oSorter1 = oTable1.getBindingInfo("items").sorter,
                    sPath1 = this.getView().getBindingContext().getPath() + "/ToOperations";
                oTable1.unbindItems();
                oTable1.bindAggregation("items", {
                    path: sPath1,
                    parameters: {
                        expand: "operationDescriptifText"
                    },
                    filters: aFilters1,
                    template: oTemplate1,
                    sorter: oSorter1
                });
                oTable1.setBusy(false);
                this.getView().byId("search-op-field").setValue("");
            }

        },
        // FIN MODIFICATION GMAO-362

        bindHistory: function () {
            var aFilters = [];
            var aufnrFilter = new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, this.AUFNR);
            aFilters.push(aufnrFilter);
            this.filters = aFilters;
            var tab = this.getView().byId("HistoryTable").getTable();
            var oTemplate = "grtgaz.puma.ImputationDesTemps.view.templates.HistoryTableTemplate";
            var template = sap.ui.xmlfragment(oTemplate, this);
            tab.bindAggregation("items", {
                path: "/Cat2HistorySet",
                filters: aFilters,
                template: template

            });
        },

        _bindComments: function () {
            // DEBUT MODIFICATION GMAO-362
            var sPath = this.getView().getBindingContext().getPath() + "/ToComments";
            // FIN MODIFICATION GMAO-362
            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();
            var that = this;

            this.getModel().read(sPath, {
                success: function (odata, response) {
                    that._oGlobalBusyIndicator.close();
                    that._construtComments(odata.results);
                }.bind(this),
                error: function () {

                }
            });
        },



        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
        /*                                      NOTES & COMMENTAIRES                                         */
        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

        _construtComments: function (aComments) {
            var oModelData = this.getModel().oData,
                oCommentModel = this.getModel("CommentModel"),
                oComment = {},
                aCommentList = new Array(),
                oCommentsModel,
                oData = {};

            if (aComments.length !== 0) {
                // DEBUT MODIFICATION GMAO-362
                oCommentsModel = aComments[0];
                // FIN MODIFICATION GMAO-362
                oComment.TDFDATE = oCommentsModel.TDFDATE;
                oComment.TDFTIME = oCommentsModel.TDFTIME;
                oComment.TDFUSER = oCommentsModel.TDFUSER;
                oComment.TDFUSERFULL = oCommentsModel.TDFUSERFULL;
                oComment.TDLINE = oCommentsModel.TDLINE;
                oComment.QMNUM = oCommentsModel.QMNUM;
                oComment.QMTXT = oCommentsModel.QMTXT;
                oComment.MANUM = oCommentsModel.MANUM;

                for (var i = 1; i < aComments.length; i++) {
                    // DEBUT MODIFICATION GMAO-362
                    oCommentsModel = aComments[i];
                    // FIN MODIFICATION GMAO-362
                    if (oComment.QMNUM === oCommentsModel.QMNUM && oComment.MANUM === oCommentsModel.MANUM && oComment.TDFDATE === oCommentsModel.TDFDATE &&
                        oComment.TDFTIME === oCommentsModel.TDFTIME && oComment.TDFUSERFULL === oCommentsModel.TDFUSERFULL) {
                        oComment.TDLINE = oComment.TDLINE + oCommentsModel.TDLINE;
                    } else {
                        aCommentList.push(oComment);
                        oComment = {};
                        oComment.TDFDATE = oCommentsModel.TDFDATE;
                        oComment.TDFTIME = oCommentsModel.TDFTIME;
                        oComment.TDFUSER = oCommentsModel.TDFUSER;
                        oComment.TDFUSERFULL = oCommentsModel.TDFUSERFULL;
                        oComment.TDLINE = oCommentsModel.TDLINE;
                        oComment.QMNUM = oCommentsModel.QMNUM;
                        oComment.QMTXT = oCommentsModel.QMTXT;
                        oComment.MANUM = oCommentsModel.MANUM;
                    }

                }

                aCommentList.push(oComment);

            }
            oData.commentSet = aCommentList;
            oCommentModel.setData(oData);
            var oSorter = [
                new sap.ui.model.Sorter('CommentModel>QMNUM', true, this._CommentGroup),
                new sap.ui.model.Sorter('CommentModel>MANUM', true),
                new sap.ui.model.Sorter('CommentModel>TDFDATE', true),
                new sap.ui.model.Sorter('CommentModel>TDFTIME', true)
            ];

            this.getView().byId("commentList").bindItems({
                path: "CommentModel>/commentSet",
                sorter: oSorter,
                groupHeaderFactory: function (oGroup) {
                    return new sap.m.GroupHeaderListItem({
                        title: oGroup.text,
                        count: oGroup.key,
                        type: "Active",
                        press: function (oEvent) {
                            var oModel = new JSONModel({
                                QMNUM: oEvent.getSource().getProperty("count")
                            });

                            if (!this._addCommentFragment) {
                                this._addCommentFragment = this._instantiateFragment("project.view.fragments.addComment");
                            }
                            this._addCommentFragment.setModel(oModel, "addCommentModel");
                            sap.ui.getCore().byId("comment").setValue("");
                            this._addCommentFragment.open();
                        }.bind(this)
                    });

                }.bind(this),
                factory: function () {
                    return new sap.m.FeedListItem({
                        text: "{CommentModel>TDLINE}",
                        showIcon: false,
                        sender: "{CommentModel>TDFUSERFULL}",
                        timestamp: "{parts:[{path: 'CommentModel>TDFDATE'},{path: 'CommentModel>TDFTIME'}]}"

                    });
                }
            });
        },
        _CommentGroup: function (oContext) {
            var oObject = oContext.getObject(),
                key = oObject.QMNUM,
                text = oObject.QMTXT;
            return {
                key: key,
                text: text
            };
        },
        onCommentCancelAdd: function () {
            this._addCommentFragment.close();
        },

        onCreateNoteButPress: function (oEvent) {
            var sNotif = this._addCommentFragment.getModel("addCommentModel").getProperty("/QMNUM"),
                sComment = sap.ui.getCore().byId("comment").getValue(),
                aCommentLines = [],
                oObject = {},
                oModel,
                aCommentTable = this._constructCommentLines(aCommentLines, sComment);

            oObject.QMNUM = sNotif;
            oObject.lineSet = aCommentTable;
            this.oNoteComment = oObject;
            oModel = this.getView().getModel();
            this.oNoteGlobalBusyDialog = new sap.m.BusyDialog();
            this.oNoteGlobalBusyDialog.open();
            oModel.create("/commentSet", oObject, {
                success: function (data, resp) {

                    if (resp.headers["sap-message"]) {
                        var messageHeader = $.parseJSON(resp.headers["sap-message"]);
                        var message = messageHeader.message;
                        var severity = messageHeader.severity;
                        if (severity === "error") {
                            sap.m.MessageBox.error(message);
                        } else {
                            sap.m.MessageToast.show(message);
                        }
                    }

                    if (data.QMNUM) {
                        this.getView().getElementBinding().refresh();
                        // this._bindComments(); // (-) GMAO-409 (APY)
                    }
                    this.oNoteGlobalBusyDialog.close();
                    this.onCommentCancelAdd();

                }.bind(this),
                error: function (oError) {
                    this.oNoteGlobalBusyDialog.close();
                }.bind(this)
            });

        },

        //instantiate  xml fragment 
        _instantiateFragment: function (FragmentName) {
            var FragmentInstance;
            FragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
            this.getView().addDependent(this.FragmentInstance);
            FragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
            FragmentInstance.setModel(this.getView().getModel());
            return FragmentInstance;
        },

        onNotificationPress: function (oEvent) {
            this._onLinkPress(oEvent);
        },

        _onLinkPress: function (oEvent) {
            var sNotification = oEvent.getSource().getText(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "Zgestion_AVIS",
                        action: "display"
                    },
                    params: {
                        "QMNUM": sNotification
                    }

                })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	
        },

        // retourner le bindingcontext de la table   
        _getTableContext: function (oTable) {

            var aContexts = oTable.getItems().map(function (oItem) {
                return oItem.getBindingContext().getObject(); // binding path
            });
            return aContexts;
        },

        DisplayMatrDetails: function (oEvent) {
            if (!this.Displaychef) {
                this.Displaychef = new sap.ui.xmlfragment("grtgaz.puma.ImputationDesTemps.view.fragments.AffichageDetailsChefTrav", this);
                this.getView().addDependent(this._Displaychef);
                this.Displaychef.setModel(this.getModel());
                this.Displaychef.setModel(this.getModel("i18n"), "i18n");
            }
            this.Displaychef.openBy(oEvent.getSource());

            var path = oEvent.getSource().getBindingContext();
            var spath = path + "/ToMatricule";
            sap.ui.getCore().byId("detailsCheftrav").bindElement({
                path: spath
            });
        },

        handleCloseMatrDetails: function (oEvent) {
            if (this.Displaychef) {
                this.Displaychef.close();
            }
        },



        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // ONGLET PIECES DETACHEES
        // AJOUT DE PIECES DETACHEES OU AJOUT DE COMPOSANTS
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        /**
         * Instancie dynamiquement et ouvre le fragment pour ajouter des pièces détachées.
         * Il est important de construire les colonnes en vérifiant le type de la table (sap.ui.table.Table ou
         * sap.m.Table). Dans le cas d'un écran de téléphone, le ValueHelpDialog utilisera le sap.m.Table,
         * sinon, le sap.ui.table.Table sera utilisé.
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onPressAddComponent: function (oEvent) {
            if (!this._displayAddCompFrag) {
                sap.ui.core.Fragment.load({
                    name: "grtgaz.puma.ImputationDesTemps.view.fragments.AjoutComposant",
                    controller: this
                }).then(function (oFragment) {
                    this._displayAddCompFrag = oFragment;
                    this.getView().addDependent(oFragment);

                    // Colonnes de la table
                    var aColumns = [
                        {
                            "label": this.getView().getModel("i18n").getResourceBundle().getText("componentCode"),
                            "template": "MATNR",
                        },
                        {
                            "label": this.getView().getModel("i18n").getResourceBundle().getText("designation"),
                            "template": "MAKTX"
                        },
                        {
                            "label": this.getView().getModel("i18n").getResourceBundle().getText("Magasin"),
                            "template": "LGORT"
                        },
                        {
                            "label": this.getView().getModel("i18n").getResourceBundle().getText("Lot"),
                            "template": "CHARG"
                        },
                        {
                            "label": this.getView().getModel("i18n").getResourceBundle().getText("Unity"),
                            "template": "MEINS"
                        },
                        {
                            "label": this.getView().getModel("i18n").getResourceBundle().getText("quantity"),
                            "template": "LABST"
                        }
                    ];

                    // Ajout des colonnes à la table
                    oFragment.getTableAsync().then(function (oTable) {
                        aColumns.forEach(function (oColumn) {
                            switch (oTable.getMetadata().getName()) {
                                case "sap.ui.table.Table":
                                    oTable.addColumn(new sap.ui.table.Column({
                                        label: new sap.m.Label({
                                            text: oColumn.label
                                        }),
                                        template: new sap.m.Text().bindProperty("text", oColumn.template)
                                    }));
                                    break;
                                case "sap.m.Table":
                                    oTable.addColumn(new sap.m.Column({
                                        header: new sap.m.Label({
                                            text: oColumn.label
                                        }),
                                        template: new sap.m.Text().bindProperty("text", oColumn.template)
                                    }));
                                    break;
                            }
                        });
                    }.bind(this));

                    oFragment.open();

                    // Pré-alimentation de la division en fonction de la division de l'ordre
                    this.getModel("componentSearchModel").setProperty("/WERKS", this.getView().getBindingContext().getObject().WAWRK);
                }.bind(this));

            } else {
                this._displayAddCompFrag.open();

                // Pré-alimentation de la division en fonction de la division de l'ordre
                this.getModel("componentSearchModel").setProperty("/WERKS", this.getView().getBindingContext().getObject().WAWRK);
            }
        },

        /**
         * Récupère les champs custom du filterbar
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onBeforeVariantSaveAjoutComposant: function (oEvent) {
            var oFilterCriteriaValues = {};
            // Get the smartfilter
            var oFilter = oEvent.getSource();
            // Get filter criteria values 
            oFilterCriteriaValues._CUSTOM = this._prepareDefaultValue(oFilter);
            oEvent.getSource().setFilterData(oFilterCriteriaValues, true);
        },

        /**
         * Alimente les filtres de la filterbar
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onAfterVariantLoadAjoutComposant: function (oEvent) {
            var oVariantData = JSON.parse(oEvent.getSource().fetchVariant().filterBarVariant)["_CUSTOM"];
            if (oVariantData) {
                this._setFilterCriteriaData(oEvent.getSource(), oVariantData);
            }
        },

        /**
         * Détruit le fragment après chaque fermeture. Cela permet de recharge les variantes.
         *  
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onAfterCloseAjoutComposant: function () {
            this._displayAddCompFrag.destroy();
            this._displayAddCompFrag = undefined;
        },

        /**
         * Extract filterbar value and form a data object
         * 
         * @public
         * @param {sap.ui.comp.smartfilterbar.SmartFilterBar} oSmartFilterBar 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _prepareDefaultValue: function (oSmartFilterBar) {
            var _custom = {};

            // Save unitary (Input, DatePickert) filter criteria
            var aKeyUnitaryFilters = [
                "MATNR",
                "MAKTX",
                "CHARG",
                "WERKS",
                "LGORT"
            ];

            aKeyUnitaryFilters.forEach(function (sKey) {
                var sValue = oSmartFilterBar.getControlByKey(sKey).getValue();
                if (sValue) {
                    _custom[sKey] = sValue;
                }
            }.bind(this));

            return _custom;
        },

        /**
         * Récupère les valeurs et alimente les filtres
         * 
         * @public
         * 
         * @param {sap.ui.comp.smartfilterbar.SmartFilterBar} oSmartFilterBar 
         * @param {object} oObject 
         * 
         * @author Alexandre PISSOTTE (APY)
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _setFilterCriteriaData: function (oSmartFilterBar, oObject) {
            var aKeyUnitaryFilters = [
                "MATNR",
                "MAKTX",
                "CHARG",
                "WERKS",
                "LGORT"
            ];

            aKeyUnitaryFilters.forEach(function (sKey) {
                var sValue = oObject[sKey];
                var oView = oSmartFilterBar.getControlByKey(sKey);
                oView.setValue("");

                if (sValue) {
                    this.getView().getModel("componentSearchModel").setProperty("/" + sKey, sValue);
                    oView.setValue(sValue);
                }
            }.bind(this));
        },

        /**
         * Récupère la pièce détachée sélectionnée par l'utilisateur et ouvre le fragment pour sélectionner la quantité à ajouter.
         * Il est important de vérifier le type de la table (sap.ui.table.Table ou sap.m.Table) car la récupération du path de la 
         * pièce détachée sélectionnée sera différente. 
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent Evénement
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onOkAjoutComposant: function (oEvent) {
            var sObjectPath = undefined;

            // Récupération du path de la pièce détachée sélectionnée
            switch (oEvent.getSource().getTable().getMetadata().getName()) {
                case "sap.ui.table.Table":
                    sObjectPath = oEvent.getSource().getTable().getContextByIndex(oEvent.getSource().getTable().getSelectedIndex()).getPath();
                    break;
                case "sap.m.Table":
                    sObjectPath = oEvent.getSource().getTable().getSelectedItem().getBindingContext().getPath();
                    break;
            }

            // Instanciation et ouverture du fragment pour choisir la quantité à ajouter
            if (!this._quantityComponent) {
                this._quantityComponent = new sap.ui.xmlfragment("grtgaz.puma.ImputationDesTemps.view.fragments.quantityComponent", this);
                this.getView().addDependent(this._quantityComponent);
                this._quantityComponent.setModel(this.getModel());
            }
            this._quantityComponent.open();

            // Binding entre la pièce et le fragment
            sap.ui.getCore().byId("quantityComponentDialog").bindElement({
                path: sObjectPath
            });
        },

        /**
         * Ferme le fragment d'ajout de composant
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onCancelAjoutComposant: function () {
            this._displayAddCompFrag.close();
        },

        /**
         * Cherche les composants en fonction des filtres de l'utilisateur.
         * Il n'est pas possible de récupérer le paramètre selectionSet depuis oEvent.
         * Par conséquence, les filtres sont récupérés à partir de leur clé.
         * Il est important de vérifier le type de la table (sap.ui.table.Table ou sap.m.Table)
         * car l'aggregation à appeler pour filtrer la table n'est pas la même.
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onSearchAjoutComposant: function () {
            var aFilters = [];
            var aKeys = ["MATNR", "MAKTX", "CHARG", "WERKS", "LGORT"];
            var oGlobalBusyDialog = new sap.m.BusyDialog();

            // oGlobalBusyDialog.open();

            // Récupération des filtres
            aKeys.forEach(function (sKey) {
                var sValue = this.getView().getModel("componentSearchModel").getProperty("/" + sKey);
                if (sValue) {
                    aFilters.push(new sap.ui.model.Filter({
                        path: sKey,
                        operator: sap.ui.model.FilterOperator.EQ,
                        value1: sValue.toUpperCase()
                    }));
                }
            }.bind(this));

            // Détermination de l'aggregation
            var sAggregation = this._displayAddCompFrag.getTable().getMetadata().getName() == "sap.m.Table" ? "items" : "rows"

            this._displayAddCompFrag.getTable().bindAggregation(sAggregation, {
                path: "/ComposantSet",
                filters: aFilters,
                factory: function () {
                    return new sap.m.ColumnListItem({
                        type: "Active",
                        cells: [
                            new sap.m.Text({
                                text: "{MATNR}"
                            }),
                            new sap.m.Text({
                                text: "{MAKTX}"
                            }),
                            new sap.m.Text({
                                text: "{LGORT}"
                            }),
                            new sap.m.Text({
                                text: "{CHARG}"
                            }),
                            // DEBUT MODIFICATION GMAO-412 Done By Hajer Cheikhrouhou on 10/08/2021
                            new sap.m.Text({
                                text: "{MEINS}"
                            }),
                            // FIN MODIFICATION GMAO-412
                            new sap.m.Text({
                                text: "{LABST}"
                            })
                        ]
                    });
                }
            });
        },

        /**
         * Instancie dynamiquement l'aide à la recherche de la division de localisation 
         * pour le fragment d'ajout de pièces détachée et l'ouvre
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 31/08/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onMaintenancePlantValueHelpRequestAjoutComposant: function () {
            if (!this._maintenancePlantAddComposantSearchHelp) {
                this._maintenancePlantAddComposantSearchHelp = new MaintenancePlantSearchHelp(
                    this,
                    new SimpleSelectionMode(this.getView().getModel("componentSearchModel"), "/WERKS")
                );
            }
            this._maintenancePlantAddComposantSearchHelp.open();
        },

        /**
         * Instancie dynamiquement l'aide à la recherche du magasin pour le fragment 
         * d'ajout de pièces détachée et l'ouvre
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-432
         * Par : Alexandre PISSOTTE (APY)
         * Date : 31/08/2021
         * Motif : Ajouter les variantes sur les filtres du fragment d'ajout des
         * pièces détachées. 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onStorageLocationValueHelpRequestAjoutComposant: function () {
            if (!this._storageLocationAddComposantSearchHelp) {
                this._storageLocationAddComposantSearchHelp = new StorageLocationFilterOnMaintenancePlantSearchHelp(
                    this,
                    new SimpleSelectionMode(this.getView().getModel("componentSearchModel"), "/LGORT", "/LGOBE"),
                    function () {
                        return this.getModel("componentSearchModel").getProperty("/WERKS");
                    }.bind(this)
                );
            }
            this._storageLocationAddComposantSearchHelp.open();
        },

        // A QUOI CA SERT ?
        onStorageLocationChangeAjoutComposant: function (oEvent) {
            var sValue = oEvent.getParameter("value");
            this.getModel("componentSearchModel").setProperty("/LGOBE", sValue);
            if (sValue === "") {
                this.getModel("componentSearchModel").setProperty("/LGORT", "");
            }
        },

        /**
         * @deprecated
         * GMAO-432
         * @param {event} oEvent 
         */
        CancelAddCompFrag: function (oEvent) {
            this._displayAddCompFrag.close();
        },

        /**
         * @deprecated
         * GMAO-432
         */
        componentStoreHelp: function () {
            var componentPlant, aFilters = [];
            if (!this._componentStoreHelp) {
                this._componentStoreHelp = new sap.ui.xmlfragment("grtgaz.puma.ImputationDesTemps.view.fragments.componentStoreHelp", this);
                this.getView().addDependent(this._componentStoreHelp);
                this._componentStoreHelp.setModel(this.getModel());
            }
            this._componentStoreHelp.open();

            componentPlant = sap.ui.getCore().byId("componentPlant").getValue();
            if (componentPlant) {
                aFilters.push(new sap.ui.model.Filter("WERKS", sap.ui.model.FilterOperator.EQ, componentPlant));
            }

            sap.ui.getCore().byId("componentStoreList").bindAggregation("items", {
                path: "/DivisionMagasinSet",
                factory: function () {
                    return new sap.m.StandardListItem({
                        selected: false,
                        title: "{LGORT}",
                        description: "{LGOBE}",
                        type: "Active"
                    });
                },
                filters: aFilters
            });

        },

        /**
         * @deprecated
         * @param {*} oEvent 
         * 
         * NB : supprimer le fragment associé
         */
        ConfirmComponentStoreSelection: function (oEvent) {
            var selectedStoreID = oEvent.getParameter("selectedItem").getTitle();
            var selectedStoreDesc = oEvent.getParameter("selectedItem").getDescription();
            this.getModel("componentSearchModel").setProperty("/LGORT", selectedStoreID);
            this.getModel("componentSearchModel").setProperty("/LGOBE", selectedStoreDesc);
        },

        /**
         * @deprecated
         * @param {*} oEvent 
         * 
         * NB : supprimer le fragment associé
         */
        handleComponentStoreSearch: function (oEvent) {
            var sValue, oFilter, oBinding;
            sValue = oEvent.getParameter("value").toUpperCase();
            oFilter = new sap.ui.model.Filter("LGORT", sap.ui.model.FilterOperator.Contains, sValue);
            oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },

        /**
         * @deprecated
         * @since GMAO-432
         */
        searchComponent: function () {
            var aFilters = [];
            //sap.ui.getCore().byId("ajoutCompID").setVisible(false);
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();
            var componentCode = sap.ui.getCore().byId("componentCode").getValue();
            if (componentCode) {

                aFilters.push(new sap.ui.model.Filter("MATNR", sap.ui.model.FilterOperator.Contains, componentCode));
            }

            var componentDescription = sap.ui.getCore().byId("componentDescription").getValue();
            if (componentDescription) {

                componentDescription = componentDescription.toUpperCase();
                aFilters.push(new sap.ui.model.Filter("MAKTX", sap.ui.model.FilterOperator.EQ, componentDescription));

            }

            var componentPlant = sap.ui.getCore().byId("componentPlant").getValue();
            if (componentPlant) {

                aFilters.push(new sap.ui.model.Filter("WERKS", sap.ui.model.FilterOperator.EQ, componentPlant));
            }

            var componentStoreDesc = this.getModel("componentSearchModel").getProperty("/LGORT");
            if (componentStoreDesc) {
                componentStoreDesc = componentStoreDesc.toUpperCase();
                aFilters.push(new sap.ui.model.Filter("LGORT", sap.ui.model.FilterOperator.EQ, componentStoreDesc));
            }

            var componentLot = this.getModel("componentSearchModel").getProperty("/CHARG");
            if (componentLot) {

                aFilters.push(new sap.ui.model.Filter("CHARG", sap.ui.model.FilterOperator.EQ, componentLot));
            }

            sap.ui.getCore().byId("ComponentTable").bindAggregation("items", {
                path: "/ComposantSet",
                factory: function () {

                    sap.ui.getCore().byId("ajoutCompID").setVisible(true);
                    return new sap.m.ColumnListItem({
                        type: "Active",
                        cells: [

                            new sap.m.Text({
                                text: "{MATNR}"
                            }),
                            new sap.m.Text({
                                text: "{MAKTX}"
                            }),
                            new sap.m.Text({
                                text: "{LGORT}"
                            }),
                            new sap.m.Text({
                                text: "{CHARG}"
                            }),
                            // DEBUT MODIFICATION GMAO-412 Done By Hajer Cheikhrouhou on 10/08/2021
                            new sap.m.Text({
                                text: "{MEINS}"
                            }),
                            // FIN MODIFICATION GMAO-412
                            new sap.m.Text({
                                text: "{LABST}"
                            })

                        ]
                    });
                },

                events: {
                    dataReceived: function () {
                        oGlobalBusyDialog.close();
                    }.bind(this)
                },

                filters: aFilters
            });

        },

        /**
         * @deprecated
         * @param {} oEvent 
         * GMAO-432
         */
        onComponantSelection: function (oEvent) {
            var sObjectPath = oEvent.getParameter("listItem").getBindingContext().getPath();

            if (!this._quantityComponent) {
                this._quantityComponent = new sap.ui.xmlfragment("grtgaz.puma.ImputationDesTemps.view.fragments.quantityComponent", this);
                this.getView().addDependent(this._quantityComponent);
                this._quantityComponent.setModel(this.getModel());
            }
            this._quantityComponent.open();
            sap.ui.getCore().byId("quantityComponentDialog").bindElement({
                path: sObjectPath
            });
        },

        /**
         * Ajoute la pièce détachée et sa quantité à l'ordre
         */
        handleAddComponent: function () {
            var compParameters = sap.ui.getCore().byId("quantityComponentDialog").getBindingContext().getObject();
            // var numOperation = sap.ui.getCore().byId("operations").getSelectedKey();
            var Quantity = sap.ui.getCore().byId("quantity").getValue();
            // if (!numOperation) {
            // 	sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("missingOpNumber"), {
            // 		title: "Erreur" // default

            // 	});
            // 	return;
            // }
            if (!Quantity) {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("missingQuantity"), {
                    title: "Erreur" // default

                });
                return;
            }
            var Component = {
                "AUFNR": this.getView().getBindingContext().getObject().AUFNR,
                "CHARG": compParameters.CHARG,
                "MATNR": compParameters.MATNR,
                "WERKS": compParameters.WERKS,
                "LGORT": compParameters.LGORT,
                "MENGE": Quantity,
                "VORNR": "0010"
            };
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();
            this.getView().getModel().callFunction("/CreateComponent", // function import name
                {
                    method: "GET", // http method
                    urlParameters: Component, // function import parameters
                    context: null,
                    success: function (oData, response) { // callback function for success
                        oGlobalBusyDialog.close();
                        this._displayAddCompFrag.close();
                        this._quantityComponent.close();
                        this.getView().byId("tableComposants").getBinding("items").refresh();

                        var errorList, MessageJson;
                        MessageJson = $.parseJSON(response.headers["sap-message"]);
                        errorList = MessageJson.details;
                        if (MessageJson && MessageJson.severity !== "success") {

                            var dialog = new sap.m.Dialog({
                                title: this.getView().getModel("i18n").getResourceBundle().getText("AddCompError"),
                                type: "Message",
                                state: 'Error',
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        dialog.close();
                                    }
                                }),
                                afterClose: function () {
                                    dialog.destroy();
                                }
                            });
                            var verticallayout = new sap.ui.layout.VerticalLayout();
                            verticallayout.addContent(new sap.m.Text({
                                text: this.getView().getModel("i18n").getResourceBundle().getText("AddCompErrors") + ":"
                            }));

                            var msg1 = "\u2022" + MessageJson.message + "\n";
                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            verticallayout.addContent(new sap.m.Text({
                                text: msg1
                            }));

                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            for (var i = 0; i < errorList.length; i++) {
                                var msg = "\u2022" + errorList[i].message + "\n";
                                var x = new sap.m.Text({
                                    text: msg
                                });
                                verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                                verticallayout.addContent(x);
                                verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            }
                            dialog.addContent(verticallayout);
                            dialog.open();
                        }

                    }.bind(this),
                    error: function (oError) { // callback function for error
                        oGlobalBusyDialog.close();
                    }
                }
            );
        },

        /**
         * Ferme le fragment pour choisir la quantité de pièce détachée à ajouter
         */
        handleCloseQuantCompFrag: function () {
            this._quantityComponent.close();
            sap.ui.getCore().byId("quantity").setValue("");
        },



        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // AUTRE PARTIE NON IDENTIFIEE
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        onSubOrderTypeSelection: function () {
            if (this.bUnsaved) {
                this._checkUnsavedData("CREATESUBORDER");
                return;
            }
            var filters = [],
                template;
            if (!this._SubOrderTypeSelection) {
                this._SubOrderTypeSelection = new sap.ui.xmlfragment("grtgaz.puma.ImputationDesTemps.view.fragments.subOrderType", this);
                this.getView().addDependent(this._SubOrderTypeSelection);
                this._SubOrderTypeSelection.setModel(this.getModel());
            }
            this._SubOrderTypeSelection.open();
            filters.push(new sap.ui.model.Filter("PAUART", sap.ui.model.FilterOperator.EQ, this.getView().getBindingContext().getObject().AUART));
            sap.ui.getCore().byId("selectSubOrderType").bindItems({
                path: "/SubOrderTypeSet",
                filters: filters,
                factory: function () {
                    return new sap.ui.core.Item({
                        key: "{AUART}",
                        text: "{AUART}"

                    });
                }
            });
        },

        onCreateSubOrder: function () {
            var subOrderType = sap.ui.getCore().byId("selectSubOrderType").getSelectedItem().getKey();
            var Order = this.getView().getBindingContext().getObject();
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
            var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: "ZCreation_OT",
                    action: "display"
                },
                params: {
                    "AUART": subOrderType,
                    "AUFNR": Order.AUFNR,
                    "TPLNR": Order.TPLNR,
                    "VAPLZ": Order.VAPLZ,
                    "EQUNR": Order.EQUNR,
                    "WAWRK": Order.WAWRK,
                    "PLTXT": Order.PLTXT,
                    "EQKTK": Order.EQKTK,
                    "NOTE_OT_SUP": Order.NOTE_OT_SUP
                }

            })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order creation app 

        },

        onCancelSubOrder: function () {
            this._SubOrderTypeSelection.close();
        },

        onBeforeRebindTable: function (oEvent) {
            if ((this.filters !== null) && (this.filters !== undefined) && (this.filters !== "")) {
                oEvent.getParameter("bindingParams").filters = this.filters;
            }
        },

        //******************************** DEPOSE EQUIPEMENT****************************//
        ///****************************************************************************//
        // ******************* PoUp Voir si le statut de l'Ã©quipement.

        onDeposeButtPress: function (oEvent) {
            if (this.bUnsaved) {
                this._checkUnsavedData("DEPOSE");
                return;
            }
            if (!this._onDeposeButtPress) {
                this._onDeposeButtPress = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.popUpPanne");
                this._onDeposeButtPress.setModel(this.getView().getModel("ModelPanne"), "ModelPanne");
            }
            this._onDeposeButtPress.open();

        },

        onCancelPopUP: function (oEvent) {
            this._onDeposeButtPress.close();
        },

        onDeposeButtPressLancer: function (oEvent) {

            var equipement, posteTech, flag, panne, statsysValPanne, OrdreDepot;
            equipement = this.getView().getBindingContext().getObject().EQUNR;
            posteTech = this.getView().getBindingContext().getObject().TPLNR;
            OrdreDepot = this.getView().getBindingContext().getObject().AUFNR;
            statsysValPanne = sap.ui.getCore().byId("panneComboBox").getSelectedItem().getKey();
            if (statsysValPanne === "Y") {
                panne = "X";
            } else {
                panne = "";
            }

            flag = "X";
            var titre1 = this.getView().getModel("i18n").getResourceBundle().getText("deposerEquip");
            var titre2 = this.getView().getModel("i18n").getResourceBundle().getText("messPourDeposer") + ":";
            //	var mesSucces = this.getView().getModel("i18n").getResourceBundle().getText("succesDepose");

            var oGlobalBusyDialog = new sap.m.BusyDialog();
            this._onDeposeButtPress.close();
            oGlobalBusyDialog.open();
            this.getView().getModel().callFunction("/deposeEquipement", // function import name
                {
                    method: "GET", // http method
                    urlParameters: {
                        EQUNR: equipement,
                        TPLNR: posteTech,
                        ZFLAG: flag,
                        EQUI_P: panne,
                        AUFNR: OrdreDepot
                    }, // function import parameters
                    context: null,
                    success: function (oData, response) { // callback function for success
                        oGlobalBusyDialog.close();
                        // preparer les messages d'errors. 
                        var errorList, MessageJson, successList;
                        MessageJson = $.parseJSON(response.headers["sap-message"]);
                        errorList = MessageJson.details;
                        successList = MessageJson.details;
                        if (MessageJson && MessageJson.severity !== "success") {

                            var dialog = new sap.m.Dialog({
                                title: titre1,
                                type: "Message",
                                state: "Error",
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        dialog.close();
                                    }
                                }),
                                afterClose: function () {
                                    dialog.destroy();
                                }
                            });

                            ///

                            var verticallayout = new sap.ui.layout.VerticalLayout();
                            verticallayout.addContent(new sap.m.Text({
                                text: titre2
                            }));
                            ///

                            var msg1 = "\u2022" + MessageJson.message + "\n";
                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            verticallayout.addContent(new sap.m.Text({
                                text: msg1
                            }));

                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            for (var i = 0; i < errorList.length; i++) {
                                var msg = "\u2022" + errorList[i].message + "\n";
                                var x = new sap.m.Text({
                                    text: msg
                                });
                                verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                                verticallayout.addContent(x);
                                verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            }
                            dialog.addContent(verticallayout);
                            dialog.open();

                        } else {

                            /////////////////////
                            var oDialog = new sap.m.Dialog({
                                title: titre1,
                                type: "Message",
                                state: "Success",
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        oDialog.close();
                                    }
                                }),
                                afterClose: function () {
                                    oDialog.destroy();
                                }
                            });

                            ///

                            var oVerticallayout = new sap.ui.layout.VerticalLayout();
                            oVerticallayout.addContent(new sap.m.Text({
                                text: titre1
                            }));
                            ///

                            var msgSucess = "\u2022" + MessageJson.message + "\n";
                            oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            oVerticallayout.addContent(new sap.m.Text({
                                text: msgSucess
                            }));

                            oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            for (var k = 0; k < successList.length; k++) {
                                var msg3 = "\u2022" + successList[i].message + "\n";
                                var y = new sap.m.Text({
                                    text: msg3
                                });
                                oVerticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                                oVerticallayout.addContent(y);
                                oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            }
                            oDialog.addContent(oVerticallayout);
                            oDialog.open();

                            /////////////////

                        }
                    },
                    error: function (oError) { // callback function for error
                        oGlobalBusyDialog.close();
                    }
                });
        },

        //******************************** POSE EQUIPEMENT*******************************//
        //******************************************************************************//

        //************************************************ Recherche de l'equipement**************************//
        //***************************************************************************************************//

        onposeButtPress: function (oEvent) {
            var oBindingObject = this.getView().getBindingContext().getObject(),
                oRessourceBundle = this.getView().getModel("i18n").getResourceBundle(),
                oOdataModel = this.getView().getModel();
            if (!this._equipementHelpPoseRecherche) {
                var ObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function (oObject) {
                    var valEquipPose, posteTechPose, flagPose, pannePose, ordrePose;
                    valEquipPose = oObject.EQUNR;
                    posteTechPose = oBindingObject.TPLNR;
                    ordrePose = oBindingObject.AUFNR;
                    flagPose = "";
                    pannePose = "";
                    var titre31 = oRessourceBundle.getText("poserEquip");
                    var titre21 = oRessourceBundle.getText("messPourDeposer") + ":";
                    var oGlobalBusyDialog = new sap.m.BusyDialog();
                    oGlobalBusyDialog.open();
                    oOdataModel.callFunction("/deposeEquipement", // function import name
                        {
                            method: "GET", // http method
                            urlParameters: {
                                EQUNR: valEquipPose,
                                TPLNR: posteTechPose,
                                EQUI_P: pannePose,
                                ZFLAG: flagPose,
                                AUFNR: ordrePose
                            }, // function import parameters
                            context: null,
                            success: function (oData, response) { // callback function for success
                                oGlobalBusyDialog.close();
                                // preparer les messages d'errors.&nbsp;
                                var errorList, MessageJson, successList;
                                MessageJson = $.parseJSON(response.headers["sap-message"]);
                                errorList = MessageJson.details;
                                successList = MessageJson.details;
                                if (MessageJson && MessageJson.severity !== "success") {

                                    var dialog = new sap.m.Dialog({
                                        title: titre31,
                                        type: "Message",
                                        state: "Error",
                                        beginButton: new sap.m.Button({
                                            text: 'OK',
                                            press: function () {
                                                dialog.close();
                                            }
                                        }),
                                        afterClose: function () {
                                            dialog.destroy();
                                        }
                                    });

                                    ///

                                    var verticallayout = new sap.ui.layout.VerticalLayout();
                                    verticallayout.addContent(new sap.m.Text({
                                        text: titre21
                                    }));
                                    ///

                                    var msg1 = "\u2022" + MessageJson.message + "\n";
                                    verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                                    verticallayout.addContent(new sap.m.Text({
                                        text: msg1
                                    }));

                                    verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                                    for (var i = 0; i < errorList.length; i++) {
                                        var msg = "\u2022" + errorList[i].message + "\n";
                                        var x = new sap.m.Text({
                                            text: msg
                                        });
                                        verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                                        verticallayout.addContent(x);
                                        verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                                    }
                                    dialog.addContent(verticallayout);
                                    dialog.open();

                                } ///
                                else {
                                    /////////////////////
                                    var oDialog = new sap.m.Dialog({
                                        title: titre31,
                                        type: "Message",
                                        state: "Success",
                                        beginButton: new sap.m.Button({
                                            text: 'OK',
                                            press: function () {
                                                oDialog.close();
                                            }
                                        }),
                                        afterClose: function () {
                                            oDialog.destroy();
                                        }
                                    });

                                    ///

                                    var oVerticallayout = new sap.ui.layout.VerticalLayout();
                                    oVerticallayout.addContent(new sap.m.Text({
                                        text: titre21
                                    }));
                                    ///

                                    var msgSucess = "\u2022" + MessageJson.message + "\n";
                                    oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                                    oVerticallayout.addContent(new sap.m.Text({
                                        text: msgSucess
                                    }));

                                    oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                                    for (var k = 0; k < successList.length; k++) {
                                        var msg3 = "\u2022" + successList[i].message + "\n";
                                        var y = new sap.m.Text({
                                            text: msg3
                                        });
                                        oVerticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                                        oVerticallayout.addContent(y);
                                        oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                                    }
                                    oDialog.addContent(oVerticallayout);
                                    oDialog.open();

                                }

                            },
                            error: function (oError) { // callback function for error
                                oGlobalBusyDialog.close();
                            }
                        });
                });
                this._EquipementValueHelp = new EquipmentDispoSearchHelp(this, ObjectSelectionMode);

            }
            this._EquipementValueHelp.open();

        },

        // ***************************************** Buton Rechercher **************************************************//
        //**************************************************************************************************************//

        // ***************************************************** Lancer la Pose***************************&nbsp;
        // ***********************************************************************************************

        onEquipementSelectionPoseReche: function (oEvent) {

            var valEquipPose, posteTechPose, flagPose, pannePose, ordrePose;
            valEquipPose = oEvent.getParameter("listItem").getBindingContext().getObject().EQUNR;
            posteTechPose = this.getView().getBindingContext().getObject().TPLNR;
            ordrePose = this.getView().getBindingContext().getObject().AUFNR;
            flagPose = "";
            pannePose = "";
            var titre31 = this.getView().getModel("i18n").getResourceBundle().getText("poserEquip");
            var titre21 = this.getView().getModel("i18n").getResourceBundle().getText("messPourDeposer") + ":";
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();
            this.getView().getModel().callFunction("/deposeEquipement", // function import name
                {
                    method: "GET", // http method
                    urlParameters: {
                        EQUNR: valEquipPose,
                        TPLNR: posteTechPose,
                        EQUI_P: pannePose,
                        ZFLAG: flagPose,
                        AUFNR: ordrePose
                    }, // function import parameters
                    context: null,
                    success: function (oData, response) { // callback function for success
                        oGlobalBusyDialog.close();
                        // preparer les messages d'errors.&nbsp;
                        var errorList, MessageJson, successList;
                        MessageJson = $.parseJSON(response.headers["sap-message"]);
                        errorList = MessageJson.details;
                        successList = MessageJson.details;
                        if (MessageJson && MessageJson.severity !== "success") {

                            var dialog = new sap.m.Dialog({
                                title: titre31,
                                type: "Message",
                                state: "Error",
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        dialog.close();
                                    }
                                }),
                                afterClose: function () {
                                    dialog.destroy();
                                }
                            });

                            ///

                            var verticallayout = new sap.ui.layout.VerticalLayout();
                            verticallayout.addContent(new sap.m.Text({
                                text: titre21
                            }));
                            ///

                            var msg1 = "\u2022" + MessageJson.message + "\n";
                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            verticallayout.addContent(new sap.m.Text({
                                text: msg1
                            }));

                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            for (var i = 0; i < errorList.length; i++) {
                                var msg = "\u2022" + errorList[i].message + "\n";
                                var x = new sap.m.Text({
                                    text: msg
                                });
                                verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                                verticallayout.addContent(x);
                                verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            }
                            dialog.addContent(verticallayout);
                            dialog.open();

                        } ///
                        else {
                            /////////////////////
                            var oDialog = new sap.m.Dialog({
                                title: titre31,
                                type: "Message",
                                state: "Success",
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        oDialog.close();
                                    }
                                }),
                                afterClose: function () {
                                    oDialog.destroy();
                                }
                            });

                            ///

                            var oVerticallayout = new sap.ui.layout.VerticalLayout();
                            oVerticallayout.addContent(new sap.m.Text({
                                text: titre21
                            }));
                            ///

                            var msgSucess = "\u2022" + MessageJson.message + "\n";
                            oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            oVerticallayout.addContent(new sap.m.Text({
                                text: msgSucess
                            }));

                            oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            for (var k = 0; k < successList.length; k++) {
                                var msg3 = "\u2022" + successList[i].message + "\n";
                                var y = new sap.m.Text({
                                    text: msg3
                                });
                                oVerticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                                oVerticallayout.addContent(y);
                                oVerticallayout.addContent(new sap.ui.layout.VerticalLayout());
                            }
                            oDialog.addContent(oVerticallayout);
                            oDialog.open();

                        }

                    },
                    error: function (oError) { // callback function for error
                        oGlobalBusyDialog.close();
                    }
                });

            this._equipementHelpPoseRecherche.close();
            //***********************************

        },

        // ***************************************** Button Annuler ************************************************//
        //**************************************************************************************************************//

        handleCloseEquipementHelpPoseReche: function (OEvent) {
            sap.ui.getCore().byId("equiPoseID").setVisible(true);
            this._equipementHelpPoseRecherche.close();
        },

        //*******************************CLASSE****************************************//
        //*****************************************************************************
        onequipementClassHelpPose: function (oEvent) {

            if (!this._equipementClassHelpPose) {
                this._equipementClassHelpPose = this._instantiateFragment("project.view.fragments.equipementClassHelpPose");
                this._equipementClassHelpPose.setModel(this.getView().getModel("researchModel"), "researchModel");
            }
            this._equipementClassHelpPose.open();

        },

        //confirm equipement class in dialog help
        handleEquipementClassSelectionPose: function (oEvent) {
            var EquipementClass = oEvent.getParameter("selectedItem").getTitle();
            var EquipementClasssCategory = oEvent.getParameter("selectedItem").getDescription();
            this.getView().getModel("equipementSearchModel").setProperty("/CLASS", EquipementClass);
            this.getView().getModel("equipementSearchModel").setProperty("/KLART", EquipementClasssCategory);
        },

        // ***************************************** Article /////////////////////////////////////////////////////////////
        //**************************************************************************************************************//
        articlePose: function () {

            if (!this._articleHelpPose) {
                this._articleHelpPose = this._instantiateFragment("project.view.fragments.articlePose");
                this._articleHelpPose.setModel(this.getView().getModel("researchModel"), "researchModel");
            }
            this._articleHelpPose.open();

        },

        handleCloseArticleHelpPose: function () {
            this._articleHelpPose.close();
            sap.ui.getCore().byId("artCatID").setValue("");
            sap.ui.getCore().byId("artclaID").setValue("");
            sap.ui.getCore().byId("artPlaID").setValue("");
            sap.ui.getCore().byId("articlesTablePoseID").unbindAggregation("items");
        },

        // Recherche Article&nbsp;
        onArticleSelectionPose: function () {

        },
        searchArticlePose: function () {
            var categoryPose, articleClassPose, plantPose, aPoseFilters = [];

            categoryPose = sap.ui.getCore().byId("artCatID").getValue();
            articleClassPose = sap.ui.getCore().byId("artclaID").getValue();
            plantPose = sap.ui.getCore().byId("artPlaID").getValue();

            if (!categoryPose && !articleClassPose && !plantPose) {
                sap.m.MessageBox.error(
                    this.getView().getModel("i18n").getResourceBundle().getText("noFilterValueArticle")

                );

            } else {
                var oGlobalBusyDialog = new sap.m.BusyDialog();
                oGlobalBusyDialog.open();

                if (articleClassPose) {
                    aPoseFilters.push(new sap.ui.model.Filter("CLASS", sap.ui.model.FilterOperator.EQ, articleClassPose));
                }
                if (plantPose) {
                    aPoseFilters.push(new sap.ui.model.Filter("WERKS", sap.ui.model.FilterOperator.EQ, plantPose));
                }
                if (categoryPose) {
                    aPoseFilters.push(new sap.ui.model.Filter("KLART", sap.ui.model.FilterOperator.EQ, categoryPose));
                }

                sap.ui.getCore().byId("articlesTablePoseID").bindAggregation("items", {
                    path: "/MaterialSet",
                    factory: function () {
                        return new sap.m.ColumnListItem({
                            type: "Active",
                            cells: [

                                new sap.m.Text({
                                    text: "{MATNR}"
                                }),
                                new sap.m.Text({
                                    text: "{MAKTX}"
                                })
                            ]
                        });
                    },
                    events: {
                        dataReceived: function () {
                            oGlobalBusyDialog.close();
                        }.bind(this)
                    },

                    filters: aPoseFilters
                });

            }
        },

        // ***************************************** Magasin ***********************************************************//
        //**************************************************************************************************************//

        storeHelpPose: function (oEvent) {

            if (!this._storeHelpPose) {
				/*	this._storeHelpPose = this._instantiateFragment("project.view.fragments.storeHelpPose");
					this._storeHelpPose.setModel(this.getView().getModel("researchModel"), "researchModel");*/

                this._storeHelpPose = new sap.ui.xmlfragment("project.view.fragments.storeHelpPose", this);
                this.getView().addDependent(this._storeHelpPose);
                this._storeHelpPose.setModel(this.getModel());

            }
            this._storeHelpPose.open();

        },

        //confirm localisation plan selection in dialog help
        handleStoreSelectionPose: function (oEvent) {
            var StorePose = oEvent.getParameter("selectedItem").getTitle();
            this.getView().getModel("equipementSearchModel").setProperty("/LGORT", StorePose);

        },

        handleCloseEquipementHelpPose: function (OEvent) {
            this._equipementPoseHelp.close();
        },

        onDivPlantRequest: function () {
            var oComponentPlant = sap.ui.getCore().byId("componentPlant");
            if (!this._LocalisationPlantHelp) {
                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function (oObject) {
                    oComponentPlant.setValue(oObject.WERKS);
                });
                this._LocalisationPlantHelp = new MaintenancePlantSearchHelp(this, oObjectSelectionMode);
            }
            this._LocalisationPlantHelp.open();

        },


        //search an input value from a list of elements&nbsp;
        _searchElementFromSelectDialogList: function (oEvent, FilterName) {
            var sValue, oFilter, oBinding;
            sValue = oEvent.getParameter("value").toUpperCase();
            oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
            oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },
        OnMeasureButPress: function (oEvent) {
            if (this.bUnsaved) {
                this.oObject = oEvent.getSource().getBindingContext().getObject();
                this._checkUnsavedData("MEASUREBUTPRESS");
                return;
            }
            var oObject = oEvent.getSource().getBindingContext().getObject(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZPTS_DE_MESURE",
                        action: "display"
                    },
                    params: {
                        "QMNUM": oObject.QMNUM,
                        "QMTXT": oObject.QMTXT,
                        "QMART": oObject.QMART
                    }

                })) || ""; // generate the Hash to display the order creation app&nbsp;
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            });

        },

        onDocumentPress: function (oEvent) {
            var oNotifCommentModel = this.getView().getModel("NotifCommentModel"),
                sNotif = oEvent.getSource().getParent().getBindingContext().getObject().QMNUM;

            if (!this._commentList) {
                this._commentList = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.CommentList");
                this._commentList.setModel(oNotifCommentModel, "NotifCommentModel");
            }
            this._commentList.open();
            sap.ui.getCore().byId("commentNotifList").unbindElement("NotifCommentModel");
            this._bindNotifCommentList(sNotif);
        },
        _bindNotifCommentList: function (sNotif) {
            var oNotifCommentModel = this.getView().getModel("NotifCommentModel"),
                sPath = this.getModel().sServiceUrl + "/commentSet?$filter=QMNUM eq '" + sNotif + "'",
                aResults = [],
                oComment = {},
                oData = {},
                aComments = new Array(),
                model = new JSONModel();

            model.loadData(sPath, null, false);
            aResults = model.getData().d.results;
            if (aResults.length !== 0) {
                oComment.TDFDATE = aResults[0].TDFDATE;
                oComment.TDFTIME = aResults[0].TDFTIME;
                oComment.TDFUSER = aResults[0].TDFUSER;
                oComment.TDFUSERFULL = aResults[0].TDFUSERFULL;
                oComment.TDLINE = aResults[0].TDLINE;
                oComment.MANUM = aResults[0].MANUM;

                for (var i = 1; i < aResults.length; i++) {
                    if (oComment.MANUM === aResults[i].MANUM && oComment.TDFDATE === aResults[i].TDFDATE && oComment.TDFTIME === aResults[i].TDFTIME &&
                        oComment.TDFUSERFULL === aResults[i].TDFUSERFULL) {
                        oComment.TDLINE = oComment.TDLINE + aResults[i].TDLINE;
                    } else {
                        aComments.push(oComment);
                        oComment = {};
                        oComment.TDFDATE = aResults[i].TDFDATE;
                        oComment.TDFTIME = aResults[i].TDFTIME;
                        oComment.TDFUSER = aResults[i].TDFUSER;
                        oComment.TDFUSERFULL = aResults[i].TDFUSERFULL;
                        oComment.TDLINE = aResults[i].TDLINE;
                        oComment.MANUM = aResults[0].MANUM;
                    }

                }

                aComments.push(oComment);

            }
            oData.QMNUM = sNotif;
            oData.commentSet = aComments;
            oNotifCommentModel.setData(oData);

            var oSorter = [
                new sap.ui.model.Sorter('CommentModel>MANUM', true),
                new sap.ui.model.Sorter('CommentModel>TDFDATE', true),
                new sap.ui.model.Sorter('CommentModel>TDFTIME', true)
            ];

            sap.ui.getCore().byId("commentNotifList").bindItems({
                path: "NotifCommentModel>/commentSet",
                sorter: oSorter,
                factory: function () {
                    return new sap.m.FeedListItem({
                        text: "{NotifCommentModel>TDLINE}",
                        showIcon: false,
                        sender: "{NotifCommentModel>TDFUSERFULL}",
                        timestamp: "{parts:[{path: 'NotifCommentModel>TDFDATE'},{path: 'NotifCommentModel>TDFTIME'}]}"

                    });
                }
            });

        },
        onBackPress: function () {
            this._commentList.close();
        },
        onCommentAddPress: function (oEvent) {
            var sComment = oEvent.getParameter("value"),
                aCommentLines = [],
                nListItems = sap.ui.getCore().byId("commentNotifList").getItems().length,
                aCommentTable = this._constructCommentLines(aCommentLines, sComment);

            if (nListItems === 0) {
                this._createNote(aCommentTable);
            } else {
                this._addNoteToNotif(aCommentTable);
            }
        },

        _constructCommentLines: function (aCommentLines, sComment) {
            var aLines = aCommentLines;

            if (sComment.length <= 132) {
                aLines.push(this._createObjectTable(sComment));
            } else {
                aLines.push(this._createObjectTable(sComment.slice(0, 131)));
                aLines = this._constructCommentLines(aLines, sComment.slice(132, sComment.length));
            }
            return aLines;
        },

        _createObjectTable: function (sString) {
            var oObject = {};
            if (sString) {
                oObject.TDLINE = sString;
            }
            return oObject;

        },

        _createNote: function (aList) {
            var oObject = {},
                oModel;

            oObject.QMNUM = this.getView().getModel("NotifCommentModel").getProperty('/QMNUM');
            oObject.MATXT = "Note";
            oObject.lineSet = aList;
            this.oNoteComment = oObject;
            oModel = this.getView().getModel();
            this.oNoteGlobalBusyDialog = new sap.m.BusyDialog();
            this.oNoteGlobalBusyDialog.open();
            oModel.create("/noteSet", oObject, {
                success: this._ProcessNoteCreationSuccess.bind(this),
                error: function (oError) {
                    this.oNoteGlobalBusyDialog.close();
                }
            });

        },
        _addNoteToNotif: function (aList) {
            var oObject = {},
                oModel;
            oObject.QMNUM = this.getView().getModel("NotifCommentModel").getProperty('/QMNUM');
            oObject.lineSet = aList;
            this.oNoteComment = oObject;
            oModel = this.getView().getModel();
            this.oNoteGlobalBusyDialog = new sap.m.BusyDialog();
            this.oNoteGlobalBusyDialog.open();
            oModel.create("/commentSet", oObject, {
                success: this._ProcessNoteCreationSuccess.bind(this),
                error: function (oError) {
                    this.oNoteGlobalBusyDialog.close();
                }
            });
        },

        _ProcessNoteCreationSuccess: function (data, resp) {
            this.oNoteGlobalBusyDialog.close();
            if (resp.headers["sap-message"]) {
                var messageHeader = $.parseJSON(resp.headers["sap-message"]);
                var message = messageHeader.message;
                var severity = messageHeader.severity;
                if (severity === "error") {
                    sap.m.MessageBox.error(message);
                } else {
                    sap.m.MessageToast.show(message);
                }
            }

            if (data.QMNUM) {
                this._bindNotifCommentList(data.QMNUM);
                this.getView().getElementBinding().refresh();
                // this._bindComments(); // (-) GMAO-409 (APY)
            }
        },

        /**
         * Lance la recherche des ordres par la recherche hiérarchique des postes
         * techniques. La recherche hiérarchique prend le poste technique de l'ordre
         * courant et suffixe une * à ce dernier. La navigation se lance pour la page
         * Worklist.
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-436
         * Par : Alexandre PISSOTTE
         * Date : 10/11/2021
         * Motif : Faire passer à l'aide à la recherche le secteur d'exploitation
         * et le poste technique suffixé d'une étoile
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onHierarchySearch: function () {
            /*var sFunctionalLocation = this.getView().getBindingContext().getObject().TPLNR + "*",
                // oResearchModel = this.getModel("researchModel"), // GMAO-436
                oResearchModel = this.getModel("libModel")
                sPath = "/FunctionalLocationSet",
                aFilters = [new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, sFunctionalLocation)];

            // GMAO-436 (APY)
            this.getModel("hierarchySearch").setProperty("/funcLocations", sFunctionalLocation);
            this.getModel("hierarchySearch").setProperty("/fromARBPL", this.getView().getBindingContext().getObject().ARBPL);

            oResearchModel.read(sPath, {
                filters: aFilters,
                success: this._processHierarchySearchSuccess.bind(this),
                error: this._processHierarchySearchError.bind(this)
            });*/

            var oBusyDialog = new sap.m.BusyDialog();
            oBusyDialog.open();

            var sTPLNR = this.getView().getBindingContext().getObject().TPLNR;

            this.getModel("libModel").read("/FunctionalLocationSet", {
                filters: [
                    new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, sTPLNR + "*")
                ],
                success: function (odata, response) {
                    var aFuncLocations = odata.results;

                    // Récupération du secteur d'exploitation du poste technique de l'ordre
                    var sBEBER = odata.results.find((sFunctionalLocation) => sFunctionalLocation.TPLNR === sTPLNR)?.BEBER

                    this.getModel("hierarchySearch").setProperty("/funcLocation", sTPLNR);
                    this.getModel("hierarchySearch").setProperty("/funcLocations", aFuncLocations);
                    this.getModel("hierarchySearch").setProperty("/BEBER", sBEBER);
                    this.getModel("hierarchySearch").setProperty("/ARBPL", this.getView().getBindingContext().getObject().ARBPL);

                    this.getModel("statutSysteme").setProperty("/selected", ["I0002", "I0001", "I0045", "I0046"]);

                    oBusyDialog.close();

                    this.getRouter().navTo("worklist");
                }.bind(this),
                error: function () {
                    oBusyDialog.close();
                }
            });
        },

        onTokenChange: function (oEvent) {
            var aTokens = oEvent.getSource().getTokens(),
                aFilters = [];
            if (aTokens.length === 0) {
                sap.ui.getCore().byId("operationsList").unbindItems();
                return;
            }
            aTokens.forEach(function (Element) {
                aFilters.push(Element.getKey());
            });
            this._bindMultiInputOperations(aFilters);
        },

        /**
         * @private
         * @deprecated GMAO-436, remplacé par {@link #onHierarchySearch}
         * @param {any} d 
         * @param {any} r 
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-436
         * Par : Alexandre PISSOTTE
         * Date : 10/11/2021
         * Motif : Faire passer à l'aide à la recherche le secteur d'exploitation
         * et le poste technique suffixé d'une étoile
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _processHierarchySearchSuccess: function (d, r) {
            /*var aFuncLocations = d.results,
                SARBPL = this.getView().getBindingContext().getObject().ARBPL;

            // if (aFuncLocations.length < 1) {
            // 	this.getModel("hierarchySearch").setProperty("/funcLocations", []);
            // 	sap.m.MessageBox.information(this.getModel("i18n").getResourceBundle().getText("NoHirarchyMessage"));
            // } else {
            this.getModel("hierarchySearch").setProperty("/funcLocations", aFuncLocations);
            this.getModel("hierarchySearch").setProperty("/ARBPL", SARBPL);
            this.getModel("statutSysteme").setProperty("/selected", ["I0002", "I0001", "I0045", "I0046"]);
            this.getRouter().navTo("worklist");
            // }*/
        },

        /**
         * @private
         * @deprecated GMAO-436, remplacé par {@link #onHierarchySearch}
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-436
         * Par : Alexandre PISSOTTE
         * Date : 10/11/2021
         * Motif : Faire passer à l'aide à la recherche le secteur d'exploitation
         * et le poste technique suffixé d'une étoile
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _processHierarchySearchError: function (oError) {
        },

        /*	searchEquipementPose: function(OEvent) {

                var vaOrdreSelected = this.getView().getBindingContext().getObject().EQUNR;
                sap.ui.Core().getView().getModel("createEquipementSearchModel").getProperty("/EQUNR", vaOrdreSelected);

        	
            }*/

		/*
		 * (+) AAA GMAO-204
		 */
        onStatusHelp: function (oEvent) {

            var oSelectedItemGlobal = oEvent.getSource(),
                aFilters = [new sap.ui.model.Filter('STSMA', sap.ui.model.FilterOperator.EQ, oSelectedItemGlobal.getBindingContext().getObject()
                    .STSMA)],
                sUpdateStatusText = this.getModel("i18n").getResourceBundle().getText("statusUpdate");


            // @ts-ignore
            this._valueHelpSelectDialog = new sap.m.SelectDialog({
                title: sUpdateStatusText,
                items: {
                    path: "/OperationStatusSet",
                    filters: aFilters,
                    // @ts-ignore
                    template: new sap.m.StandardListItem({
                        title: "{TXT30}",
                        description: "{ESTAT}",
                        active: true
                    })
                },
                confirm: function onConfirm(oEv) {
                    oEv.getSource().getParent().getController().bUnsaved = true;
                    var oSelectedItem = oEv.getParameter("selectedItem");
                    if (oSelectedItem) {
                        oSelectedItemGlobal.setName(oSelectedItem.getDescription());
                        oSelectedItemGlobal.setValue(oSelectedItem.getTitle());
                    }

                },
                search: function (oEvent) {
                    var sValue, aFilter, oBinding;
                    sValue = oEvent.getParameter("value").toUpperCase();
                    aFilter = [new sap.ui.model.Filter("ESTAT", sap.ui.model.FilterOperator.Contains, sValue),
                    new sap.ui.model.Filter("STSMA", sap.ui.model.FilterOperator.Contains, oSelectedItemGlobal.getBindingContext().getObject()
                        .STSMA)];
                    oBinding = oEvent.getSource().getBinding("items");
                    oBinding.filter(aFilter);
                }
            });

            this.getView().addDependent(this._valueHelpSelectDialog);
            this._valueHelpSelectDialog.open();

        },

        // _transcoStatus: function(sVal) {
        // 	var sStatus;

        // 	switch (sVal) {
        // 		case "Sans statut":
        // 			sStatus = "E0001";
        // 			break;
        // 		case "Non Réalisé":
        // 			sStatus = "E0002";
        // 			break;
        // 		case "Non Réalisable":
        // 			sStatus = "E0003";
        // 			break;
        // 		case "Réalisé":
        // 			sStatus = "E0004";
        // 			break;
        // 		default:
        // 			sStatus = "";
        // 	}

        // 	return sStatus;

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
		/*
			TICKET JIRA GMAO-226
			Afficher la liste des points de mesure d'un ordre à partir de tous les avis associés à l'ordre
			
			Fait le  : 02/03/2021
			Fait par : Alexandre PISSOTTE (APY)
		*/
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-226
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        onMeasurementPointsPress: function () {
            if (this.bUnsaved) {
                this._checkUnsavedData("MEASUREMENTPOINTS");
                return;
            }
            var oObject = this.getView().getBindingContext().getObject();
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
            var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: "ZPTS_DE_MESURE",
                    action: "display"
                },
                params: {
                    "AUFNR": oObject.AUFNR,
                    "KTEXT": oObject.KTEXT
                }
            })) || ""; // generate the Hash to display the order creation app&nbsp;
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-226
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-362
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        /**
         * 
         * @param {*} oEvent 
         * 
         * Liste des modifications
         * GMAO-326 (Ticket créateur)
         * GMAO-50
         * GMAO-407
         */
        onTabNavigatePress: function (oEvent) {

            var a = oEvent.getParameters().section.getId();
            var ids = a.split("-");
            var id = ids[ids.length - 1];
            // var table = ""; // GMAO-454
            var oTemplate = "";
            // var path = ""; // GMAO-454

            this._bindHeader();
            /********GMAO-454    **********/
            if (this.bUnsaved) {
                this.id = id;
                this._checkUnsavedData("TabNavigPress");
                this.getView().byId("page").setSelectedSection(this.getView().byId("iconTabBarFilter1"));
                return;
            }
            else {
                this.tabNavigate(id);
            }

            /*  switch (id) { // GMAO-454
                  case "iconTabBarFilter1":
                      table = this.getView().byId("sub-op-table");
                      path = "OperationSet";
                      table.setEntitySet(path);
                      this._bindActesTables();                    
                      break;
                  case "iconTabBarFilter2":
                      table = this.getView().byId("op-table");
                      path = "OperationSet";
                      table.setEntitySet(path);
                      this._bindImputationTables();
                      break;
                  case "iconTabBarFilter3":
                      table = this.getView().byId("HistoryTable");
                      path = "Cat2HistorySet";
                      table.setEntitySet(path);
                      this.bindHistory();
                      break;
                  case "iconTabBarFilter4":
                      table = this.getView().byId("tableComposants");
                      path = "ToComponents";
                      oTemplate = "grtgaz.puma.ImputationDesTemps.view.templates.PieceTableTemplate";
                      var template = sap.ui.xmlfragment(oTemplate, this);
                      table.bindItems({
                          path: path,
                          template: template
                      });
                      break;
                  case "iconTabBarFilter5":
                      table = this.getView().byId("sous-ordres-smart-table");
                      path = "OrderSet";
                      table.setEntitySet(path);
                      this._bindComments();
                      break;
                  // DEBUT MODIF GMAO-407 
                  case "iconTabBarFilter6":
                      this._bindSubOrders();
                      break;
                  case "iconTabBarFilter7":
                      this._bindNotifications();
                      break;
                  // FIN MODIF GMAO-407
                  default:
                      return;
              }*/
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-362
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        /** 
         * Permet de paramètrer le call oData afin de filtrer la table sur les sous ordres de l'OT en cours.
         * Il est impératif d'ajouter au select le champ AUFNR car la colonne est redéfinie dans le XML.
         * @param {event} oEvent 
         * 
         * Liste de modifications
         * GMAO-407
         */
        onBeforeRebindSubOrdersTable: function (oEvent) {
            var aFilters = [
                new sap.ui.model.Filter("MAUFNR", sap.ui.model.FilterOperator.EQ, this.AUFNR)
            ];
            var sSelect = oEvent.getParameter("bindingParams").parameters.select;

            sSelect = sSelect + ",AUFNR,OT_LANCE,OT_OUVERT,OT_TCLO,OT_CLO";

            oEvent.getParameter("bindingParams").filters = aFilters;
            oEvent.getParameter("bindingParams").parameters.select = sSelect;
        },

        /**
         * GMAO-407
         */
        _bindSubOrders: function () {
            var oTable = this.getView().byId("sous-ordres-smart-table").getTable();
            var oTemplate = this.getView().byId("sous-ordres-smart-table").getTable().getBindingInfo("items").template;

            oTable.unbindItems();
            oTable.bindAggregation("items", {
                path: '/OrderSet',
                filters: [
                    new sap.ui.model.Filter("MAUFNR", sap.ui.model.FilterOperator.EQ, this.AUFNR)
                ],
                template: oTemplate
            });
        },

        /**
         * GMAO-407 2
         * @param {EVENT} oEvent 
         */
        onBeforeRebindNotificationsTable: function (oEvent) {
            var aFilters = [
                new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, this.AUFNR)
            ];
            var sSelect = oEvent.getParameter("bindingParams").parameters.select;

            sSelect = sSelect + ",QMNUM,USERSTATUS,SYSTEMSTATUS";

            oEvent.getParameter("bindingParams").filters = aFilters;
            oEvent.getParameter("bindingParams").parameters.select = sSelect;
        },

        /**
         * GMAO-407
         */
        _bindNotifications: function () {
            var oTable = this.getView().byId("notifications-smart-table").getTable();
            var oTemplate = this.getView().byId("notifications-smart-table").getTable().getBindingInfo("items").template;

            oTable.unbindItems();
            oTable.bindAggregation("items", {
                path: '/PMNotificationSet',
                filters: [
                    new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, this.AUFNR)
                ],
                template: oTemplate
            });
        },

        /***********************************START GMAO 340 ***********************************/
        /**
         * Prompte un message de confirmation pour la sauvegarde des données.
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Hajer CHEIKHROUHOU
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-340
         * Par : Hajer CHEIKHROUHOU
         * Date : 02/09/2021
         * Motif : Informer l'utilisateur que des données n'ont pas été sauvegardées.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _checkUnsavedData: function (sSource) {
            var oResourceBundle = this.getModel("i18n").getResourceBundle();
            var sTitle = oResourceBundle.getText("UnsavedDataTitle");
            var sPopUpMessage = oResourceBundle.getText("UnsavedData");
            var oIcon = sap.m.MessageBox.Icon.QUESTION;
            this.sSource = sSource;

            sap.m.MessageBox.show(sPopUpMessage, {
                icon: oIcon,
                title: sTitle,
                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                onClose: this._handleMessagesave.bind(this)
            });
        },

        _handleMessagesave: function (oAction) {
            if (oAction === sap.m.MessageBox.Action.CANCEL) {
                this.sSource = "";
                return;
            }
            /*Clear bUnsaved  */
            this.bUnsaved = false;

            /*Proceed Navigation */
            switch (this.sSource) {
                case ("CREATESUBORDER"):
                    this._subOrderTypeSelectionfn();
                    break;
                case ("MEASUREMENTPOINTS"):
                    this._measurementPointsPress();
                    break;
                case ("MEASUREBUTPRESS"):
                    this._measureButPress();
                    break;
                case ("DEPOSE"):
                    this._deposeButtPress();
                    break;
                case ("ENDORDER"):
                    this._endOrderButton();
                    break;
                case ("CLOSEORDER"):
                    this._clotureOrderButton();
                    break;
                case ("NAVBACK"):
                    this._navBack();
                    break;
                case ("NotifPress"):
                    this._notificationPress();
                    break;
                case ("TabNavigPress"):
                    this._tabNavigatePress(this.id);
                    break;
            }


        },
        _subOrderTypeSelectionfn: function () {

            var filters = [],
                template;
            if (!this._SubOrderTypeSelection) {
                this._SubOrderTypeSelection = new sap.ui.xmlfragment("grtgaz.puma.ImputationDesTemps.view.fragments.subOrderType", this);
                this.getView().addDependent(this._SubOrderTypeSelection);
                this._SubOrderTypeSelection.setModel(this.getModel());
            }
            this._SubOrderTypeSelection.open();
            filters.push(new sap.ui.model.Filter("PAUART", sap.ui.model.FilterOperator.EQ, this.getView().getBindingContext().getObject().AUART));
            sap.ui.getCore().byId("selectSubOrderType").bindItems({
                path: "/SubOrderTypeSet",
                filters: filters,
                factory: function () {
                    return new sap.ui.core.Item({
                        key: "{AUART}",
                        text: "{AUART}"

                    });
                }
            });
        },

        _measurementPointsPress: function () {
            var oObject = this.getView().getBindingContext().getObject();
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
            var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: "ZPTS_DE_MESURE",
                    action: "display"
                },
                params: {
                    "AUFNR": oObject.AUFNR,
                    "KTEXT": oObject.KTEXT
                }
            })) || ""; // generate the Hash to display the order creation app&nbsp;
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	
        },

        _deposeButtPress: function (oEvent) {
            if (!this._onDeposeButtPress) {
                this._onDeposeButtPress = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.popUpPanne");
                this._onDeposeButtPress.setModel(this.getView().getModel("ModelPanne"), "ModelPanne");
            }
            this._onDeposeButtPress.open();
        },
        _endOrderButton: function () {

            var sOrderNumber = this.getView().getBindingContext().getObject().AUFNR,
                Order = {
                    "AUFNR": sOrderNumber
                };

            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();
            this.getView().getModel().callFunction("/TerminateOrder", // function import name
                {
                    method: "GET", // http method
                    urlParameters: Order, // function import parameters
                    context: null,
                    success: function (oData, response) { // callback function for success
                        this._oGlobalBusyIndicator.close();
                        if (response.headers["sap-message"]) {
                            var oResponse = $.parseJSON(response.headers["sap-message"]);
                            if (oResponse.severity === "success") {
                                sap.m.MessageBox.success(this.getView().getModel("i18n").getResourceBundle().getText("TerminateSuccess"), {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("success"),
                                    onClose: function () {
                                        this.getView().getElementBinding().refresh();
                                        this.getView().byId("end-button").setEnabled(false);

                                    }.bind(this)

                                });
                            } else {
                                sap.m.MessageBox.error(oResponse.message, {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default

                                });
                            }
                        }
                    }.bind(this),
                    error: function (oError) { // callback function for error
                        this._oGlobalBusyIndicator.close();
                    }
                });

        },

        _clotureOrderButton: function () {

            if (!this._clotOrder) {
                this._clotOrder = this._instantiateFragment("grtgaz.puma.ImputationDesTemps.view.fragments.Cloture");

            }
            this._clotOrder.open();
            sap.ui.getCore().byId("pickerDatdebID").setDateValue(new Date());

        },
        _navBack: function () {

            var sPreviousHash = History.getInstance().getPreviousHash();

            if (sPreviousHash !== undefined) {
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);

            }
        },

        /***********************************END GMAO 340 ***********************************/



        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // ONGLET DES ACTES
        // TODO : Regrouper les méthodes pour une meilleure lisibilité
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        /**
         * Filtre la table des actes en fonction du schéma de statuts sélectionné à partir du
         * sap.m.IconBarTab.
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-110
         * Par : Alexandre PISSOTTE (APY)
         * Date : 02/09/2021
         * Motif : Saisie pour les actes des statuts réalisation et conformité en 
         * même temps.
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onSelectIconTabBar: function (oEvent) {
            var oBinding = this.byId("sub-op-table").getTable().getBinding("items");
            var sKey = oEvent.getParameter("key");
            var aFilters = [];

            switch (sKey) {
                case "NoStat":
                    aFilters.push(new Filter("ESTAT", "EQ", "E0001"));
                    break;
                case "Conf":
                    aFilters.push(new Filter("STSMA", "EQ", "CONFORM"));
                    break;
                case "Real":
                    aFilters.push(new Filter("STSMA", "EQ", "PUMA-OP"));
                    break;
            }

            oBinding.filter(aFilters);
        },


        _measureButPress: function () {
            var oObject = this.oObject,
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZPTS_DE_MESURE",
                        action: "display"
                    },
                    params: {
                        "QMNUM": oObject.QMNUM,
                        "QMTXT": oObject.QMTXT,
                        "QMART": oObject.QMART
                    }

                })) || ""; // generate the Hash to display the order creation app&nbsp;
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            });

        },

        onNotificationPress2: function (oEvent) {
            if (this.bUnsaved) {
                this._checkUnsavedData("NotifPress");
                return;
            }

            this._onLinkPress(oEvent);

            // this._notificationPress();
        },

        _notificationPress: function () {
            var sNotification = this.getView().getBindingContext().getObject().QMNUM,
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "Zgestion_AVIS",
                        action: "display"
                    },
                    params: {
                        "QMNUM": sNotification
                    }

                })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	
        },

        /****************   GMAO-454  *********************/
        _tabNavigatePress: function (id) {

            this.getView().byId("page").setSelectedSection(this.getView().byId("iconTabBarFilter1"));
            this.getView().byId("page").setSelectedSection(this.getView().byId(id));
            this.tabNavigate(id);
        },

        tabNavigate(id) {
            var table = "";
            var path = "";
            var oTemplate = "";
            switch (id) {
                case "iconTabBarFilter1":
                    table = this.getView().byId("sub-op-table");
                    path = "OperationSet";
                    table.setEntitySet(path);
                    this._bindActesTables();
                    break;
                case "iconTabBarFilter2":
                    table = this.getView().byId("op-table");
                    path = "OperationSet";
                    table.setEntitySet(path);
                    this._bindImputationTables();
                    break;
                case "iconTabBarFilter3":
                    table = this.getView().byId("HistoryTable");
                    path = "Cat2HistorySet";
                    table.setEntitySet(path);
                    this.bindHistory();
                    break;
                case "iconTabBarFilter4":
                    table = this.getView().byId("tableComposants");
                    path = "ToComponents";
                    oTemplate = "grtgaz.puma.ImputationDesTemps.view.templates.PieceTableTemplate";
                    var template = sap.ui.xmlfragment(oTemplate, this);
                    table.bindItems({
                        path: path,
                        template: template
                    });
                    break;
                case "iconTabBarFilter5":
                    table = this.getView().byId("sous-ordres-smart-table");
                    path = "OrderSet";
                    table.setEntitySet(path);
                    this._bindComments();
                    break;
                case "iconTabBarFilter6":
                    this._bindSubOrders();
                    break;
                case "iconTabBarFilter7":
                    this._bindNotifications();
                    break;
                default:
                    return;
            }
        }


    });

});
sap.ui.define([], function () {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit : function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
        },
        	formatterConfirmation: function(sValue) {
			var result = false;
			if (sValue === "X") {
				result = true;
			}
			return result;
		},
		formattodate: function(sValue) {
			// var dateformater = sap.ui.core.format.DateFormat.getDateInstance({
			// 	pattern: "YYYYMMdd "
			// });
			// var date = dateformater.parse(sValue);
			// dateformater.format(date);

		},
		formatterStatus: function(sValOuv, sValLanc, sValTclos, sValClos) {
			var status;
			if (sValOuv === true) {
				status = this.getResourceBundle().getText("ouvert");
			}
			if (sValLanc === true) {
				status = this.getResourceBundle().getText("Lance");
			}
			if (sValTclos === true) {
				status = this.getResourceBundle().getText("TCLO");
			}
			if (sValClos === true) {
				status = this.getResourceBundle().getText("CLOT");
            }
			return status;
		},
		EnableNoteButton: function(sQnum) {
			var bEnable = false;
			if (sQnum) {
				bEnable = true;
			}
			return bEnable;
		},

		formatNombreOpConf: function(a, b) {
			var result = 0;
			if (a !== 0) {
				result = (b / a) * 100;
				result = parseFloat(result.toFixed(2));
			}

			return result;
		},
		formatDate: function(sValue) {
			var day, month, year;
			day = sValue.slice(6, 8);
			month = sValue.slice(4, 6);
			year = sValue.slice(0, 4);
			return day + "-" + month + "-" + year;

        },
        
        // GMAO-407
        formatNotificationUserStatut: function(sVAlue, sType) {
			var sText, sStatut;
			sStatut = sVAlue.trim();

			switch (sStatut) {
				case "E0001":
					if (sType === "ZV") {
						sText = this.getModel("i18n").getResourceBundle().getText("E0001ZV");
					} else {
						sText = this.getModel("i18n").getResourceBundle().getText("E0001");
					}

					break;

				case "E0002":
					if (sType === "ZV") {
						sText = this.getModel("i18n").getResourceBundle().getText("E0002ZV");
					} else {
						sText = this.getModel("i18n").getResourceBundle().getText("E0002");
					}

					break;
				case "E0003":
					if (sType === "ZV") {
						sText = this.getModel("i18n").getResourceBundle().getText("E0003ZV");
					} else {
						sText = this.getModel("i18n").getResourceBundle().getText("E0003");
					}

					break;
				default:

			}
			return sText;
        },

        /**
         * GMAO-407
         * @param {} sVAlue 
         * @param {*} sType 
         */
        formatExternalStatusNotif: function(sVAlue, sType) {
            if (sVAlue) {
                var sText, sStatut;
                sStatut = sVAlue.trim();

                switch (sStatut) {
                    case "E0001":
                        if (sType === "ZV") {
                            sText = this.getModel("i18n").getResourceBundle().getText("E0001ZV");
                        } else {
                            sText = this.getModel("i18n").getResourceBundle().getText("E0001");
                        }

                        break;

                    case "E0002":
                        if (sType === "ZV") {
                            sText = this.getModel("i18n").getResourceBundle().getText("E0002ZV");
                        } else {
                            sText = this.getModel("i18n").getResourceBundle().getText("E0002");
                        }

                        break;
                    case "E0003":
                        if (sType === "ZV") {
                            sText = this.getModel("i18n").getResourceBundle().getText("E0003ZV");
                        } else {
                            sText = this.getModel("i18n").getResourceBundle().getText("E0003");
                        }

                        break;
                    default:

                }

                return sText;
            }
        },
        
        /**
         * GMAO-407
         * @param {*} sValue 
         */
        formatInternalStatusNotif: function(sValue) {
			var aStatus = [],
                sReturn = "";
            if (sValue) {
                aStatus = sValue.split(" ");
                for (var i = 0; i < aStatus.length; i++) {

                    switch (aStatus[i]) {
                        case "I0070":
                            if (!sReturn) {
                                sReturn = this.getModel("i18n").getResourceBundle().getText("AENC");
                            } else {
                                sReturn = sReturn + "-" + this.getModel("i18n").getResourceBundle().getText("AENC");
                            }

                            break;

                        case "I0072":
                            if (!sReturn) {
                                sReturn = this.getModel("i18n").getResourceBundle().getText("ACLO");
                            } else {
                                sReturn = sReturn + "-" + this.getModel("i18n").getResourceBundle().getText("ACLO");
                            }

                            break;
                        case "I0068":
                            if (!sReturn) {
                                sReturn = this.getModel("i18n").getResourceBundle().getText("AOUV");
                            } else {
                                sReturn = sReturn + "-" + this.getModel("i18n").getResourceBundle().getText("AOUV");
                            }

                            break;
                        default:

                    }
                }
                return sReturn;
            }
        }
        
	};

});

	
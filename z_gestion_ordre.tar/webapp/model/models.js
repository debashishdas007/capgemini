sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/base/util/ObjectPath"
], function (JSONModel, Device, ObjectPath) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createStatutModel: function(data) {
			var oModel = new JSONModel(data);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		// status Panne
		createModelPanne: function(data) {
			var oModel = new JSONModel(data);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;

		},

		createComponentSearchModel: function() {
			var oModel = new JSONModel();
			return oModel;
		},

		// create the technical object search model
		createTechnicalObjectSearchModel: function() {
			var data = {
				"INGRP": "",
				"SWERK": "",
				"STORT": "",
				"BEBER": "",
				"CLASS": "",
				"KLART": "",
				"PLTXT": "",
				"TPLNR": "",
				"EQFNR": "",
				"ARBPL": ""
			};
			var oModel = new JSONModel(data);
			return oModel;
		},

		//create equipement research model 
		createEquipementSearchModel: function() {
			var data = {
				"CLASS": "",
				"MATNR": "",
				"LGORT": "",
				"KLART": "",
				"TPLNR": "",
				"SERNR": "",
				"EQUNR": "",
				"EQKTX": "",
				"ARBPL": "",
				"INGRP": ""
				
			};
			var oModel = new JSONModel(data);
			return oModel;
		},
		createHirarchyModel:function(){
			var data = {
				"funcLocations" : [],
				"ARBPL" :""
			};
			
			return new JSONModel(data);
		}

	};

});
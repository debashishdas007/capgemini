sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/m/library"
], function (Controller, UIComponent, mobileLibrary) {
	"use strict";

	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;

	return Controller.extend("com.grtgaz.puma.fiori.zcreationavis.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter : function () {
			return UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel : function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel : function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle : function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },
        /*
		 * destroy the fragment instance using the name  
		 * @param {string} FragmentInstance: instance of the fragment
		 * @private
		 */
		_destroyFragmentInstance: function(FragmentInstance) {
			var oFragmentInstance = FragmentInstance;
			oFragmentInstance.destroy();
		},

		/**
		 * instantiate the fragment and return the fragment instance 
		 * @param {string} FragmentName : name of the fragment
		 * @return {xmlfragment} instance of the fragment
		 * @private
		 */

		_instantiateFragment: function(FragmentName) {
			var oFragmentInstance;
			oFragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
			this.getView().addDependent(this.oFragmentInstance, this);
			oFragmentInstance.setModel(this.getModel("i18n"), "i18n");
			oFragmentInstance.setModel(this.getModel("notifManagementServiceModel"), "notifManagementServiceModel");
			oFragmentInstance.setModel(this.getModel("creationServiceModel"), "creationServiceModel");
			oFragmentInstance.setModel(this.getModel(""), "");
			return oFragmentInstance;
		},

		/**
		 * Define the table structure   
		 * @private
		 */
		_defineTable: function(fragmentInstance, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
			var oValueHelpDialog, oTable, sTableType;

			// get the  table of the value dialog help   
			oValueHelpDialog = fragmentInstance;
			oTable = oValueHelpDialog.getTable();
			oTable.setEnableBusyIndicator(true);

			// Add the table columns' properties and binding 
			sTableType = this._returnControlName(oTable);

			if (sTableType === "sap.ui.table.Table") {
				this._addUiTableColumns(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding);

			}

			if (sTableType === "sap.m.Table") {
				this._addRespTableColumns(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding);
			}

		},

		/**
		 * Redefine the structure of the  filterBar   
		 * @private
		 */

		_reDefineFilterBar: function(fragmentInstance) {
			var oValueHelpDialog, oFilterBar;

			// get the filter bar of the value dialog help   
			oValueHelpDialog = fragmentInstance;
			oFilterBar = oValueHelpDialog.getFilterBar();
			if (sap.ui.Device.system.phone) {
				oFilterBar.setShowGoOnFB(false);
			}
			//change the filter bar search button  label from "lancer" to "rechercher"
			this._changeSearchButtonLabel(oFilterBar);

		},
		/**
		 * add functional location filter bar ui table columns   
		 * @param{object} oTable filter bar table 
		 * @private
		 */
		_addUiTableColumns: function(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
			var oColumn;
			oColumn = new sap.ui.table.Column({
				label: new sap.m.Label({
					text: this.getResourceBundle().getText(firsColumnName)
				}),
				template: new sap.m.Text().bindProperty("text", firstColumnBinding),
				sortProperty: firstColumnBinding,
				filterProperty: firstColumnBinding
				
			});
			oTable.addColumn(oColumn);

			oColumn = new sap.ui.table.Column({
				label: new sap.m.Label({
					text: this.getResourceBundle().getText(secondColumnName)
				}),
				template: new sap.m.Text().bindProperty("text", SecondColumnBinding),
				sortProperty: SecondColumnBinding,
				filterProperty: SecondColumnBinding
				
			});
			oTable.addColumn(oColumn);
		},

		/**
		 * add functional location filter bar responsive table columns   
		 * @param{object} oTable filter bar table 
		 * @private
		 */
		_addRespTableColumns: function(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
			var oColumn;
			oColumn = new sap.m.Column({
				header: new sap.m.Label({
					text: this.getResourceBundle().getText(firsColumnName)
				}),
				template: new sap.m.Text().bindProperty("text", firstColumnBinding),
				sortProperty: firstColumnBinding,
				filterProperty: firstColumnBinding,
				width: "100px"
			});
			oTable.addColumn(oColumn);

			oColumn = new sap.m.Column({
				header: new sap.m.Label({
					text: this.getResourceBundle().getText(secondColumnName)
				}),
				template: new sap.m.Text().bindProperty("text", SecondColumnBinding),
				sortProperty: SecondColumnBinding,
				filterProperty: SecondColumnBinding,
				width: "100px"
			});
			oTable.addColumn(oColumn);
		},
		/**
		 * return the control name  
		 * @param{object} oControl the control instance  
		 * @return {string} the control name 
		 * @private
		 */
		_returnControlName: function(oControl) {
			return oControl.getMetadata().getName();
		},
		/**
		 * change the label of the functional location filterBar search button from "lancer" to "rechercher" 
		 * @param {Object } oFilterBar filter bar  
		 * @private
		 */
		_changeSearchButtonLabel: function(oFilterBar) {
			var that = this;
			oFilterBar.addEventDelegate({
				"onAfterRendering": function(oEvent) {
					var oResourceBundle, oButton;
					oResourceBundle = that.getResourceBundle();
					oButton = oEvent.srcControl._oSearchButton;
					oButton.setText(oResourceBundle.getText("search"));
				}
			});
		},
		/**
		 * search the the entered value from the list
		 * @param {event} oEvent   event triggered when searching for a value 
		 * @param {string} FilterName the property name for filtering 
		 * @private
		 */
		_searchElementFromSelectDialogList: function(oEvent, FilterName) {
			var sValue, oFilter, oBinding;
			sValue = oEvent.getParameter("value").toUpperCase();
			oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		_preapareFilterTAble: function(oEvent, sEquipFuncLocVar) {
			var aFilters, aSelectionSet = oEvent.getParameter("selectionSet"),
				sKlart;

			if (sEquipFuncLocVar === "TPLNR") {
				sKlart = "003";
			} else if (sEquipFuncLocVar === "EQUNR") {
				sKlart = "002";
			} else {
				sKlart = undefined;
			}

			aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new sap.ui.model.Filter({
						path: oControl.getName(),
						operator: sap.ui.model.FilterOperator.EQ,
						value1: oControl.getValue().toUpperCase()
					}));
					if (oControl.getName() === "CLASS" && sKlart) {
						aResult.push(new sap.ui.model.Filter({
							path: "KLART",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: sKlart
						}));
					}
				}

				return aResult;
			}, []);
			return aFilters;
		},

		/**
		 * Apply filter and bind the functional location table with results   
		 * @param {string[] } aFilters table of filters 
		 * @private
		 */
		_filterTable: function(oFilter, fragmentInstance, entityset, firstCellBinding, secondCellBinding) {
			var oValueHelpDialog, oTable;

			// get the  table of the value dialog help   
			oValueHelpDialog = fragmentInstance;
			oTable = oValueHelpDialog.getTable();

			// case the value help dialog table  is  a sap.ui.table 

			if (oTable.bindRows) {
				oTable.bindRows({
					path: entityset,
					filters: oFilter
				});

			}

			//case the value help dialog table  is  a sap.m.table
			if (oTable.bindItems) {
				oTable.bindAggregation("items", {
					path: entityset,
					factory: function() {
						return new sap.m.ColumnListItem({
							type: "Active",
							cells: [

								new sap.m.Text({
									text: firstCellBinding
								}),
								new sap.m.Text({
									text: secondCellBinding
								})
							]
						});
					},
					filters: oFilter
				});
			}

			oValueHelpDialog.update();

		},

		/**
		 * value selection from search help  
		 * @param{Event} oEvent triggered when selecting a value 
		 * @private
		 */

		_onsearchHelpOkPress: function(oEvent, fragmentInstance, fragmentModel, propertyName, worklistModel) {
			var sPropertyValue, sProperty, oTable, sTableType, oBindingContext;

			oTable = oEvent.getSource().getTable();
			sTableType = this._returnControlName(oTable);

			if (sTableType === "sap.ui.table.Table") {

				oBindingContext = oTable.getContextByIndex(oTable.getSelectedIndex());
				sPropertyValue = oBindingContext.getProperty(propertyName);
			}

			if (sTableType === "sap.m.Table") {
				oBindingContext = oTable.getSelectedItem().getBindingContext(fragmentModel);
				sPropertyValue = oBindingContext.getProperty(propertyName);

			}
			sProperty = "/" + propertyName;
			this.getView().getModel(worklistModel).setProperty(sProperty, sPropertyValue);

			switch (propertyName) {
				case "TPLNR":
					this.getView().getModel(worklistModel).setProperty("/PLTXT", oBindingContext.getProperty("PLTXT"));
					this.getView().getModel(worklistModel).setProperty("/VAPLZ", oBindingContext.getProperty("ARBPL"));
					this.getView().getModel(worklistModel).setProperty("/WAWRK", oBindingContext.getProperty("WERKS"));
					this.getView().getModel(worklistModel).setProperty("/INGRP", oBindingContext.getProperty("INGRP"));
					this.getView().getModel(worklistModel).setProperty("/EQUNR", "");
					this.getView().getModel(worklistModel).setProperty("/EQKTX", "");
					break;
				case "EQUNR":
					this.getView().getModel(worklistModel).setProperty("/EQKTX", oBindingContext.getProperty("EQKTX"));
					this.getView().getModel(worklistModel).setProperty("/TPLNR", oBindingContext.getProperty("TPLNR"));
					this.getView().getModel(worklistModel).setProperty("/PLTXT", oBindingContext.getProperty("PLTXT"));
					this.getView().getModel(worklistModel).setProperty("/VAPLZ", oBindingContext.getProperty("ARBPL"));
					this.getView().getModel(worklistModel).setProperty("/WAWRK", oBindingContext.getProperty("WERKS"));
					this.getView().getModel(worklistModel).setProperty("/INGRP", oBindingContext.getProperty("INGRP"));
					this.getView().getModel(worklistModel).setProperty("/IWERK", oBindingContext.getProperty("WERKS"));
					break;
				default:
					break;
			}

			this._closeFragmentInstance(fragmentInstance);
		},
		/**
		 * close the fragment instance using the name  
		 * @param {string} FragmentInstance: instance of the fragment
		 * @private
		 */
		_closeFragmentInstance: function(FragmentInstance) {
			var oFragmentInstance = FragmentInstance;
			oFragmentInstance.close();
		},

		_processDateChange: function(sDate) {
			var sDateChange = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd.MM.yyyy HH:mm"
				}).format(sDate).split(" "),
				aDateTime = [];
			// format date 
			if (sDateChange[0]) {
				aDateTime[0] = sDateChange[0];
			} else {
				aDateTime[0] = "00.00.0000";
			}
			// format Time 
			if (sDateChange[1]) {
				aDateTime[1] = sDateChange[1]+ ":00";
			} else {
				aDateTime[1] = "00:00:00";
			}
			return aDateTime;

		},

		

		/**
		* Adds a history entry in the FLP page history
		* @public
		* @param {object} oEntry An entry object to add to the hierachy array as expected from the ShellUIService.setHierarchy method
		* @param {boolean} bReset If true resets the history before the new entry is added
		*/
		addHistoryEntry: (function() {
			var aHistoryEntries = [];

			return function(oEntry, bReset) {
				if (bReset) {
					aHistoryEntries = [];
				}

				var bInHistory = aHistoryEntries.some(function(oHistoryEntry) {
					return oHistoryEntry.intent === oEntry.intent;
				});

				if (!bInHistory) {
					aHistoryEntries.push(oEntry);
					this.getOwnerComponent().getService("ShellUIService").then(function(oService) {
						oService.setHierarchy(aHistoryEntries);
					});
				}
			};
		})()

	});

});
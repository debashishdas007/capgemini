sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter"
], function (BaseController, JSONModel, History, formatter) {
    "use strict";

    return BaseController.extend("com.grtgaz.puma.fiori.zcreationavis.controller.Object", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
     * Called when the worklist controller is instantiated.
     * @public
     */
        onInit: function () {
            var oData = this.getOwnerComponent().getModel("notificationCreationModel").getData();
            if (oData.QMTXT === "") {
                this.getRouter().navTo("worklist");
            }
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
        onNavBack: function () {
            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);
            }
        },
        onCreateNotification: function () {
            //Début modif GMAO-262
            this.getView().getModel("notificationCreationModel").setProperty("/IWERK", this.getView().getModel("notificationCreationModel").getProperty("/WAWRK"));
            //Fin modif GMAO-262
            var oNotificatioCreationModel = this.getView().getModel("notificationCreationModel").getData();
            var QMDAT = this._processDateChange(this.getView().byId("completion-date").getDateValue());

            oNotificatioCreationModel.QMDAT = QMDAT[0];
            oNotificatioCreationModel.MZEIT = QMDAT[1];

            delete oNotificatioCreationModel.isLoaded;


            this.getModel().create("/PMNotificationDetailsSet", oNotificatioCreationModel, {
                success: function (oData, response) {

                    var msg, messagePart1, messagePart2, label1, label2, link1, link2, sMessage;
                    var notification = oData.QMNUM;

                    if (notification) {
                        msg = this.getView().getModel("i18n").getResourceBundle().getText("Number");
                        messagePart1 = msg + " " + "l'avis est  : ";
                        label1 = new sap.m.Label({
                            text: messagePart1
                        });
                        link1 = new sap.m.Link({
                            text: notification,
                            press: function (oEvent) {
                                var sNotification = oEvent.getSource().getText(),
                                    oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                                    hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                        target: {
                                            semanticObject: "Zgestion_AVIS",
                                            action: "display"
                                        },
                                        params: {
                                            "QMNUM": sNotification
                                        }

                                    })) || ""; // generate the Hash to display the order creation app
                                oCrossAppNavigator.toExternal({
                                    target: {
                                        shellHash: hash
                                    }
                                }); // navigate to order app
                            }
                        });
                        var dialog = new sap.m.Dialog({
                            title: this.getView().getModel("i18n").getResourceBundle().getText("notificationCreationsuccess"),
                            type: 'Message',
                            state: 'Success',
                            beginButton: new sap.m.Button({
                                text: 'OK',
                                press: function () {
                                    var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
                                    var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                        target: {
                                            semanticObject: "Shell",
                                            action: "home"
                                        }

                                    })) || ""; // generate the Hash to display the order creation app 
                                    oCrossAppNavigator.toExternal({
                                        target: {
                                            shellHash: hash
                                        }
                                    }); // navigate to order creation app 
                                    dialog.clos();
                                }
                            }),
                            afterClose: function () {
                                dialog.destroy();
                            }

                        });
                        var horizontalLayout = new sap.ui.layout.HorizontalLayout();
                        if (link1) {
                            horizontalLayout.addContent(label1);
                            horizontalLayout.addContent(link1);
                        }
                        dialog.addContent(horizontalLayout);
                        dialog.open();
                    } else {
                        if (response.headers["sap-message"]) {

                            sMessage = $.parseJSON(response.headers["sap-message"]).message;
                        } else {
                            sMessage = this.getView().getModel("i18n").getResourceBundle().getText("ErrorCreationNoMessage");
                        }
                        sap.m.MessageBox.show(sMessage, {
                            icon: sap.m.MessageBox.Icon.ERROR,
                            title: this.getView().getModel("i18n").getResourceBundle().getText("error")

                        });
                    }

                }.bind(this),
                error: function (oError) {

                }
            });

        }

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

    });

});
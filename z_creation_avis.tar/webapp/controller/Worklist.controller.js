jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.MultiSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.SimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.observer.ISubscriber");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.OrderSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentCreateSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.WorkCenterSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.VerificateurSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.IntervenantGRTSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.TypeInspectionSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.ActivitySearchHelp");

sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/MultiSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/observer/ISubscriber",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/OrderSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentCreateSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkCenterSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/VerificateurSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/IntervenantGRTSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/TypeInspectionSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/ActivitySearchHelp"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MultiSelectionMode, SimpleSelectionMode,
    ObjectSimpleSelectionMode, ISubscriber, OrderSearchHelp, FunctionalLocationSearchHelp, EquipmentCreateSearchHelp, WorkCenterSearchHelp,
    VerificateurSearchHelp, IntervenantGRTSearchHelp, TypeInspectionSearchHelp, ActivitySearchHelp) {
    "use strict";

    /**
     * Contrôleur de la vue WorkList
     *
     * @public
     * @class
     * @name com.grtgaz.puma.fiori.zcreationavis.controller.Worklist
     * @extends BaseController
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-322
     * Par : Alexandre PISSOTTE (APY)
     * Date : 04/08/2021
     * Motif : La recherche doit se faire en même temps sur code et désignation.
     * Attention, la condition logique utilisée entre le code et la désignation
     * est le ET/AND et non le OU/OR. Ainsi, les filtres sont remontées par l'
     * oData dans le paramètre IT_FILTER_SELECT_OPTIONS.
     * Le résultat de la recherche doit être pré-filtré sur la division et le
     * poste de travail.
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
    return BaseController.extend("com.grtgaz.puma.fiori.zcreationavis.controller.Worklist", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function() {
            var oViewModel, orderModel, articleModel, oFunctionalLocationModel, EquipementModel;

            // Model used to manipulate control states
            oViewModel = new JSONModel({
                orderDefinition: "",
                functionalLocationDefinition: "",
                functLocationClassSearch: "",
                equipementDefinition: "",
                ArticleDefinition: ""
            });
            this.setModel(oViewModel, "worklistView");

            var odate = new JSONModel();
            odate.setProperty("/maxDate", new Date());
            this.setModel(odate, "dateModel");
            // model used for order research
            orderModel = new JSONModel();
            this.setModel(orderModel, "orderModel");

            // model used for functional location research
            oFunctionalLocationModel = new JSONModel();
            this.setModel(oFunctionalLocationModel, "FunctionalLocation");

            // model used for equipement research
            EquipementModel = new JSONModel();
            this.setModel(EquipementModel, "Equipement");

            // model used for article research
            articleModel = new JSONModel();
            this.setModel(articleModel, "articleModel");
            this.getView().byId("grt-contributor").setEnabled(false);

            this.getView().byId("completion-Date-time").setValueState("Error");

        },

        onExit: function() {
            var aFragments = [this._oOrderValueHelp, this._oOrderTypeValueHelp, this._oFunctLocationValueHelp, this._oPlanGroupValueHelp,
            this._oClassValueHelp, this._oMaintPlantValueHelp, this._oLocalisationValueHelp,
            this._oPlantSectionValueHelp, this._oEquipementValueHelp, this._oArticleValueHelp,
            this._oStoreValueHelp, this._inspectorValueHelp, this._grtContributorValueHelp,
            this._inspectionTypeValueHelp, this._oConformityValueHelp
            ];
            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }

        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
        onNavBack: function() {
            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: "#Shell-home"
                    }
                });
            }
        },
        /**&nbsp;
         * Ecoute la sélection des aides à la recherche souscrites
         */
        update: function() {
            this.genInfoStepValidation();
            this._enableDisableGrtContributor();

            // Mise à jour Intervenant GRT
            var sZIntervenantGRT = this.getView().getModel("notificationCreationModel").getProperty("/NACHN");
            if (sZIntervenantGRT && sZIntervenantGRT !== "") {
                var aName = sZIntervenantGRT.split(" ");
                this.getView().getModel("notificationCreationModel").setProperty("/NACHN", aName[0] + " ");
                this.getView().getModel("notificationCreationModel").setProperty("/VORNA", aName[1]);
            }

            this.verificationStepValidation();
        },


        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // ETAPE 1 - INFORMATIONS GENERALES
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        /**&nbsp;
         * Ouvre l'aide à la recherche des ordres
         */
        /*================================ order value help methods=============================================*/
        onOrderNumberRequest: function() {
            if (!this._oOrderValueHelp) {

                this._oOrderValueHelp = new OrderSearchHelp(
                    this,
                    new SimpleSelectionMode(
                        this.getView().getModel("notificationCreationModel"),
                        "/AUFNR"
                    )
                );
                this._oOrderValueHelp.subscribe(this);

            }
            this._oOrderValueHelp.open();
        },




        /*=================================================== functional location value help============================= */
        onFunctionalLocationRequest: function() {
            if (!this._oFunctLocationValueHelp) {
                this._oFunctLocationValueHelp = new FunctionalLocationSearchHelp(
                    this,
                    new ObjectSimpleSelectionMode(
                        this.getView().getModel("notificationCreationModel"),
                        function(oObject) {
                            this.getView().getModel("notificationCreationModel").setProperty("/TPLNR", oObject.TPLNR);
                            this.getView().getModel("notificationCreationModel").setProperty("/PLTXT", oObject.PLTXT);
                            this.getView().getModel("notificationCreationModel").setProperty("/VAPLZ", oObject.ARBPL);
                            this.getView().getModel("notificationCreationModel").setProperty("/WAWRK", oObject.WERKS);
                            this.getView().getModel("notificationCreationModel").setProperty("/INGRP", oObject.INGRP);
                            this.getView().getModel("notificationCreationModel").setProperty("/IWERK", oObject.WERKS);
                        }.bind(this)
                    )
                )
                this._oFunctLocationValueHelp.subscribe(this);
            }
            this._oFunctLocationValueHelp.open();

        },


        /*=========================== equipement value help============================================================ */

		/**
		 * Event handler for opening the value help dialog of the equipement.
		 * On Phone the framgment stretchs to adapt the view
		 * @public
		 */
        onEquipementRequest: function() {

            if (this._oEquipementValueHelp) {
                this._oEquipementValueHelp.destroy();
            }

            this._oEquipementValueHelp = new EquipmentCreateSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("notificationCreationModel"),
                    function(oObject) {
                        this.getView().getModel("notificationCreationModel").setProperty("/EQUNR", oObject.EQUNR);
                        this.getView().getModel("notificationCreationModel").setProperty("/EQKTX", oObject.EQKTX);
                        this.getView().getModel("notificationCreationModel").setProperty("/TPLNR", oObject.TPLNR);
                        this.getView().getModel("notificationCreationModel").setProperty("/PLTXT", oObject.PLTXT);
                        this.getView().getModel("notificationCreationModel").setProperty("/VAPLZ", oObject.ARBPL);
                        this.getView().getModel("notificationCreationModel").setProperty("/WAWRK", oObject.WERKS);
                        this.getView().getModel("notificationCreationModel").setProperty("/INGRP", oObject.INGRP);
                        this.getView().getModel("notificationCreationModel").setProperty("/IWERK", oObject.WERKS);
                    }.bind(this)
                ),
                this.getView().getModel("notificationCreationModel").getProperty("/TPLNR")
            )
            this._oEquipementValueHelp.subscribe(this);
            this._oEquipementValueHelp.open();
        },



        /*============================= work center value help ==========================================*/

        onWorkCenterPlantRequest: function() {

            if (!this._oWorkCenterResponsableValueHelp) {
                this._oWorkCenterResponsableValueHelp = new WorkCenterSearchHelp(
                    this,
                    new SimpleSelectionMode(
                        this.getView().getModel("notificationCreationModel"),
                        "/VAPLZ",
                        "/WAWRK"
                    )
                );
            }
            this._oWorkCenterResponsableValueHelp.subscribe(this);
            this._oWorkCenterResponsableValueHelp.open();
        },


        /*================================ inspector value help==========================================*/
        // open Fragment for inspector value help 

        onInspectorRequest: function() {

            if (!this._inspectorValueHelp) {
                this._inspectorValueHelp = new VerificateurSearchHelp(
                    this,
                    new SimpleSelectionMode(
                        this.getView().getModel("notificationCreationModel"),
                        "/ZENTREPRISE",
                        "/ZLIBELLE"
                    )
                );
            }
            this._inspectorValueHelp.subscribe(this);
            this._inspectorValueHelp.open();
        },



        _enableDisableGrtContributor: function(SInspector) {

            var sValue = this.getView().getModel("notificationCreationModel").getProperty("/ZENTREPRISE"),// SInspector.toUpperCase(),
                sEntreprise = this.getView().getModel("i18n").getResourceBundle().getText("GRT"),
                oContributorInput = this.getView().byId("grt-contributor");
            if (sValue.startsWith(sEntreprise)) {
                oContributorInput.setEnabled(true);
            } else {
                oContributorInput.setEnabled(false);
                oContributorInput.setValue("");
                this.getView().getModel("notificationCreationModel").setProperty("/NACHN", "");
                this.getView().getModel("notificationCreationModel").setProperty("/VORNA", "");
            }
        },
        /*======================================= grtContributor value help==============================*/
        /**
         * GMAO-322 (APY) 04/08/2021
         * Destruction du fragment à chaque appel du fragment afin de s'assurer que le poste responsable et
         * la division passés soient les derniers sélectionnés
         */
        onGrtContributorRequest: function() {
            // GMAO-322
            if (this._grtContributorValueHelp) {
                this._destroyFragmentInstance(this._grtContributorValueHelp)
            }

            this._grtContributorValueHelp = new IntervenantGRTSearchHelp(
                this,
                new SimpleSelectionMode(
                    this.getView().getModel("notificationCreationModel"),
                    "/NACHN",
                    "/PERNR"
                ),
                // GMAO-322
                this.getView().getModel("notificationCreationModel").getProperty("/VAPLZ"),
                this.getView().getModel("notificationCreationModel").getProperty("/WAWRK")
            );

            this._grtContributorValueHelp.subscribe(this);
            this._grtContributorValueHelp.open();
        },


        onInspectionTypeRequest: function() {

            if (!this._inspectionTypeValueHelp) {
                this._inspectionTypeValueHelp = new TypeInspectionSearchHelp(
                    this,
                    new SimpleSelectionMode(
                        this.getView().getModel("notificationCreationModel"),
                        "/MFCOD",
                        "/TXTMFCOD",
                        "/MFGRP"
                    )
                );
                this._inspectionTypeValueHelp.subscribe(this);
            }

            this._inspectionTypeValueHelp.open();
        },


        /*================================ non conformity value help ==============================================*/
        onAddCauseButPress: function() {

            if (!this._oConformityValueHelp) {
                this._oConformityValueHelp = new ActivitySearchHelp(
                    this,
                    new ObjectSimpleSelectionMode(
                        this.getView().getModel("notificationCreationModel"),
                        function(oObject) {
                            var bFound = false;
                            var oConformityCauses = this.getView().getModel("notificationCreationModel").getProperty("/ToNonComplianceCauses");

                            // Evite l'ajout multiple de la même cause de non conformité
                            for (var i = 0; i < oConformityCauses.length; i++) {
                                if (oConformityCauses[i].MFCOD === oObject.CODE) {
                                    bFound = true;
                                    return;
                                }
                            }
                            if (!bFound) {
                                console.log(oObject);
                                oConformityCauses.push({
                                    MFCOD: oObject.CODE,
                                    TXTMFCOD: oObject.KURZTEXT,
                                    MFGRP: oObject.CODEGRUPPE
                                });
                                this.getView().getModel("notificationCreationModel").setProperty("/ToNonComplianceCauses", oConformityCauses);
                            }
                            this.nonConformityCauseStepValidation();
                        }.bind(this)
                    )
                );
            }
            this._oConformityValueHelp.open();
        },



        onDeleteCauseButPress: function() {
            var oTable = this.getView().byId("non-conformity-causes"),
                oIndex = oTable.indexOfItem(oTable.getSelectedItem()),
                oConformityCauses = this.getView().getModel("notificationCreationModel").getProperty("/ToNonComplianceCauses");
            oConformityCauses.splice(oIndex, 1);
            this.getView().getModel("notificationCreationModel").setProperty("/ToNonComplianceCauses", oConformityCauses);
            this.nonConformityCauseStepValidation();
        },

        /*============================ Validation step one ===========================================*/

        genInfoStepValidation: function() {
            var validation = true,
                inputId = ["notification-designation", "notification-Type", "equipement", "work-center-responsable", "plant"];
            for (var i = 0; i < inputId.length; i++) {
                if (this.getView().byId(inputId[i]).getValue()) {
                    this.getView().byId(inputId[i]).setValueState("None");
                } else {
                    this.getView().byId(inputId[i]).setValueState("Error");
                    validation = false;

                }
            }

            if (validation === true) {
                this.getView().byId("genInfoStep").setValidated(true);
                this.getView().byId("nonConformityCauseStep").setValidated(true);
                this.getView().byId("verificationStep").setValidated(true);
            } else {
                this.getView().byId("nonConformityCauseStep").setValidated(false);
                this.getView().byId("verificationStep").setValidated(false);
                this.getView().byId("genInfoStep").setValidated(false);
            }
        },

        onDateCompletionChange: function(oEvent) {
            var bValid = oEvent.getParameter("valid"),
                oModel = this.getModel("notificationCreationModel"),
                aDates = [];
            if (bValid && oEvent.getParameter("value")) {
                this.getView().byId("completion-Date-time").setValueState("None");
                aDates = this._processDateChange(this.getView().byId("completion-Date-time").getDateValue());

                oModel.setProperty("/QMDAT", aDates[0].replace(/\./gi, "/"));
                oModel.setProperty("/MZEIT", aDates[1].slice(0, 5));
            } else {
                this.getView().byId("completion-Date-time").setValueState("Error");

            }
            this.verificationStepValidation();
        },



        verificationStepValidation: function() {
            var validation = true,
                inputId = ["inspection-type", "completion-Date-time"];
            for (var i = 0; i < inputId.length; i++) {
                if (this.getView().byId(inputId[i]).getValue()) {
                    this.getView().byId(inputId[i]).setValueState("None");
                } else {
                    this.getView().byId(inputId[i]).setValueState("Error");
                    validation = false;

                }
            }

            if (validation) {
                this.getView().byId("verificationStep").setValidated(true);
                this.getView().byId("nonConformityCauseStep").setValidated(true);
            } else {

                this.getView().byId("verificationStep").setValidated(false);
                this.getView().byId("nonConformityCauseStep").setValidated(false);
            }

        },

        nonConformityCauseStepValidation: function() {
            var sResultCheck = this.getView().getModel("notificationCreationModel").getProperty("/USERSTATUS"),
                sLength = this.getView().byId("non-conformity-causes").getItems().length;
            if (sResultCheck === "E0003" && sLength === 0) {
                this.getView().byId("nonConformityCauseStep").setValidated(false);
            } else {
                this.getView().byId("nonConformityCauseStep").setValidated(true);
            }

        },

        //Navigate to recap page 
        wizardCompletedHandler: function() {
            this.getRouter().navTo("object");
        },







    });
});
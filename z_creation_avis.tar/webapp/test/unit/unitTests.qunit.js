/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"grtgaz/puma/AvisCreation/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "sap/base/util/ObjectPath"
], function (JSONModel, Device, ObjectPath) {
    "use strict";

    return {

        createDeviceModel: function () {
            var oModel = new JSONModel(Device);
            oModel.setDefaultBindingMode("OneWay");
            return oModel;
        },

        createFLPModel: function () {
            var fnGetUser = ObjectPath.get("sap.ushell.Container.getUser"),
                bIsShareInJamActive = fnGetUser ? fnGetUser().isJamActive() : false,
                oModel = new JSONModel({
                    isShareInJamActive: bIsShareInJamActive
                });
            oModel.setDefaultBindingMode("OneWay");
            return oModel;
        },
      //create the notification creation model 
		createCreationModel: function() {
			var data = {
				"QMTXT": "",
				"QMART": "ZV",
				"AUFNR": "",
				"TPLNR": "",
				"PLTXT": "",
				"EQUNR": "",
				"EQKTX": "",
				"IWERK": "",
				"VAPLZ": "",
				"WAWRK": "",
				"INGRP": "",
				"ZENTREPRISE": "",
				"ZLIBELLE": "",
				"PERNR": "",
				"NACHN": "",
				"VORNA": "",
				"QMDAT":"",
				"MZEIT":"",
				"ZCONSTAT": "",
				"MFCOD": "",
				"TXTMFCOD": "",
				"MFGRP": "",
				"USERSTATUS": "",
				"ToNonComplianceCauses": new Array()

			};
			var oModel = new JSONModel(data);
			return oModel;
		}

    };
});
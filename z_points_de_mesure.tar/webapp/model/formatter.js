sap.ui.define([], function () {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit : function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
//format value
		formatValue: function(sVal1, sVal2) {
			return parseFloat(sVal1).toFixed(2) + " " + sVal2;
		},
		
		
		formatDate:function(sValue){
		return new Date();	
		},
		
		
		formatMeasuredValue:function(sValue){
			if(!sValue){
			return "";	
			}
			
		},
	
		//format state
		formatState: function(sVal1, sVal2, sVal3) {
			var nVal = Number(sVal1),
				nMinVal = Number(sVal2),
				nMaxVal = Number(sVal3),
				sState = "Success";

			if (nVal < nMinVal || nVal > nMaxVal) {
				sState = "Error";
			}
			return sState;

		}

	};

});
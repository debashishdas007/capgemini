sap.ui.define([
	"sap/m/Text"
], function(Text) {
	"use strict";

	return Text.extend("grtgaz.puma.PointsDeMesures.control.TextWithName", {
		metadata: {
			properties: {
				"name": {
					type: "string"
				}
			}
		},
		renderer: function(oRm, oControl) {
			sap.m.TextRenderer.render(oRm, oControl);
		}
	});
});
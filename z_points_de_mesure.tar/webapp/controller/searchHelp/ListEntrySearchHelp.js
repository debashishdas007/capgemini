sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.ListEntrySearchHelp", {

		//display the fragment	
		open: function(aProperties, sModel) {
			this._aproperties = aProperties;
			this._sModel = sModel;
			this._getFragment().open();
		},

		onSearch: function(oEvent) {
			var aFilters = this._prepareFilterTable(oEvent, "MELNR");

			this._filterTable(new sap.ui.model.Filter({
				filters: aFilters,
				and: true
			}), this._oFragment, "/EntryListSet", "{MELNR}", "{NAMEL}");
		},

		onSelectionConfirm: function(oEvent) {
			this._onSearchHelpOkPress(oEvent, "", "MELNR");
			this._onSearchHelpOkPress(oEvent, "", "NAMEL");
			this._initializeFilterCriteria();
			if (this._aproperties) {
				this._oView.byId("hiearchy-options").setEnabled(true);
				this._oView.byId("hiearchy-options").setSelectedKey("RB-1");
				this._oModel.setProperty("/inputState", "None");
				this._oModel.setProperty("/inputStateText", "");
			}

		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.listEntrySearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
				// Table and columns definition according to used device
				Utility.defineTable(
					this._oFragment,
					oRessourceModel.getText("entryListNumber"), "MELNR",
					oRessourceModel.getText("entryListDescription"), "NAMEL"
				);

			}
			return this._oFragment;
		},

	});

});
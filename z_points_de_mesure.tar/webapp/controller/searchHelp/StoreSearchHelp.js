sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.StoreSearchHelp", {

		//display the fragment	
		open: function() {

			this._getFragment().open();
		},

		onStoreSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "LGORT");
		},

		onStoreConfirm: function(oEvent) {
			var sSelectedItem = Utility._getSelectedItemTitle(oEvent);

			this._oModel.setProperty("/LGORT", sSelectedItem);

		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.StoreSearchHelp";

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
			}
			return this._oFragment;
		}

	});

});
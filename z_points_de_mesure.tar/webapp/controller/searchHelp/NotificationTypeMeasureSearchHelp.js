sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.NotificationTypeMeasureSearchHelp", {

		//display the fragment	
		open: function() {

			this._getFragment().open();
		},

		onNotificationTypeSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "ATWRT");
		},

		onNotificationTypeConfirm: function(oEvent) {
			var sSelectedItem = Utility._getSelectedItemTitle(oEvent),
				sSelectedDivision = Utility._getSelectedItemDescription(oEvent);
			this._oModel.setProperty("/ATWRT", sSelectedItem);
			this._oModel.setProperty("/ATWTB", sSelectedDivision);

			// var aSelectedItems = oEvent.getParameter("selectedItems"),
			// 	oNotifType = sap.ui.getCore().byId("notif-type-multi"),
			// 	aItemsArray = [];
			// //remove all notification multiinput tokens 
			// oNotifType.removeAllTokens();
			// // add new values 
			// aSelectedItems.forEach(function(item) {
			// 	aItemsArray.push(item.getTitle());

			// 	oNotifType.addToken(new sap.m.Token({
			// 		key: item.getTitle(),
			// 		text: item.getTitle() // Texte affiché dans le MultiInput
			// 	}));
			// });

			// //prepare selected items for filters	
			// if (aItemsArray) {
			// 	this._oModel.setProperty("/QMART", aItemsArray);
			// }

		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.NotificationTypeMeasureSearchHelp";

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
			}
			return this._oFragment;
		},

	});

});
sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.PlannerGroupSearchHelp", {

		//display the fragment	
		open: function() {

			this._getFragment().open();
		},

		onPlannerGroupSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "INGRP");
		},

		onPlannerGroupConfirm: function(oEvent) {
			var sSelectedItem = Utility._getSelectedItemTitle(oEvent),
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			this._oModel.setProperty("/INGRP", sSelectedItem);
			this._oModel.setProperty("/FilterCriteriaStatueValue", oRessourceModel.getText("none"));
			this._oModel.setProperty("/FilterCriteriaValueMessage", "");

		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.plannerGroupSearchHelp";
				

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
				this._oFragment.setModel(this._oView.getModel("notificationSearchModel"), "notificationSearchModel");
			}
			return this._oFragment;
		}

	});

});
sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.OrderTypeSearchHelp", {

		//display the fragment	
		open: function() {

			this._getFragment().open();
		},

		onOrderTypeSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "AUART");
		},

		onOrderTypeConfirm: function(oEvent) {
			var sSelectedItem = Utility._getSelectedItemTitle(oEvent);
			this._oModel.setProperty("/AUART", sSelectedItem);

		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.orderTypeSearchHelp";

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
			}
			return this._oFragment;
		}

	});

});
sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel",
	"./OrderTypeSearchHelp"
], function(searchHelp, Utility, models, JSONModel, orderTypeSearchHelp) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.OrderSearchHelp", {

		open: function() {
			//display the fragment
			this._getFragment().open();
			//instantiate the notification type fragment
			this._orderTypeFragment = new orderTypeSearchHelp(this._oController, this._oFragment.getModel("order"));
		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.orderSearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);

				// Table and columns definition according to used device
				Utility.defineTable(
					this._oFragment,
					oRessourceModel.getText("orderNumber"), "AUFNR",
					oRessourceModel.getText("orderDesignation"), "KTEXT"
				);
			}
			//initialize the fragment filter bar model 
			this._oFragment.setModel(new JSONModel({}), "order");

			return this._oFragment;
		},
		onSelectionConfirm: function(oEvent) {
			this._onSearchHelpOkPress(oEvent, "", "AUFNR");
		},
		onSearch: function(oEvent) {
			var aFilters = this._prepareFilterTable(oEvent, "AUFNR");
			this._filterTable(new sap.ui.model.Filter({
				filters: aFilters,
				and: true
			}), this._oFragment, "/OrderSet", "{AUFNR}", "{KTEXT}");
		},
		/////////////////////////////////////////// value help fragments open methods ////////////////////////////

		//open notification type fragment
		onOrderTypeHelpRequest: function() {
			this._orderTypeFragment.open();
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////

	});

});
sap.ui.define([
	"./SearchHelp",
	"./ClassSearchHelp",
	"./FunctionalLocationSearchHelp",
	"./StoreSearchHelp",
	"./MaterialSearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, ClassSearchHelp, FunctionalLocationSearchHelp, StoreSearchHelp, MaterialSearchHelp, Utility, models,
	JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.equipementSearchHelp", {

		open: function(aProperties, sModel) {

			this._aproperties = aProperties;
			this._sModel = sModel;
			//display the fragment
			this._getFragment().open();
			//instantiate the class  fragment
			this._classFragment = new ClassSearchHelp(this._oController, this._oFragment.getModel("equipement"));

			//instantiate the  functional location fragment
			this.searchHelpFunctionalLocationFragment = new FunctionalLocationSearchHelp(this._oController, this._oFragment.getModel(
				"equipement"));
			//instantiate the Store fragment
			this.searchHelpStoreFragment = new StoreSearchHelp(this._oController, this._oFragment.getModel(
				"equipement"));
			//instantiate the materialfragment
			this.searchHelpMaterialFragment = new MaterialSearchHelp(this._oController, this._oFragment.getModel(
				"equipement"));

		},

		_getFragment: function() {
			// variable declaration measurementPoint
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.equipementSearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);

				// Table and columns definition according to used device
				Utility.defineTable(
					this._oFragment,
					oRessourceModel.getText("equipmentNumber"), "EQUNR",
					oRessourceModel.getText("equipmentDescription"), "EQKTX"
				);
			}
			//initialize the fragment filter bar model 
			this._oFragment.setModel(new JSONModel({}), "equipement");

			return this._oFragment;
		},
		/**
		 * Event handler for searching a functional location  .
		 * @param {event} oEvent : event triggered once researching a functional location   
		 * @public
		 */
		onSearch: function(oEvent) {
			var aFilters = this._prepareFilterTable(oEvent, "EQUNR");

			this._filterTable(new sap.ui.model.Filter({
				filters: aFilters,
				and: true
			}), this._oFragment, "/EquipmentSet", "{EQUNR}", "{EQKTX}");
		},

		/**
		 * Event handler for selecting the tplnr value  .
		 * @param {event} oEvent : event triggered once researching a functional location   
		 * @public
		 */
		onSelectionConfirm: function(oEvent) {
			this._initializeFilterCriteria();
			this._onSearchHelpOkPress(oEvent, "", "EQUNR");
			this._onSearchHelpOkPress(oEvent, "", "EQKTX");
			if (this._aproperties) {
				this._oView.byId("hiearchy-options").setEnabled(false);
				this._oModel.setProperty("/inputState", "None");
				this._oModel.setProperty("/inputStateText", "");
			}

		},

		/////////////////////////////////////////// value help fragments open methods ////////////////////////////

		//open class fragment
		onClassHelpRequest: function() {
			this._classFragment.open("002");
		},

		//open Functional Location fragment
		onFunctionalLocationRequest: function() {
			var sFunctionalLocation = this._oFragment.getModel(
				"equipement").getProperty("/TPLNR");
			this.searchHelpFunctionalLocationFragment.open(sFunctionalLocation);
		},

		//open store fragment
		onStoreHelpRequest: function() {
			this.searchHelpStoreFragment.open();
		},
		//open Material fragment
		onMaterialHelpRequest: function() {
				this.searchHelpMaterialFragment.open();
			}
			//////////////////////////////////////////////////////////////////////////////////////////////////////////

	});

});
sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.NotificationTypeSearchHelp", {

		//display the fragment	
		open: function() {

			this._getFragment().open();
		},

		onNotificationTypeSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "QMART");
		},

		onNotificationTypeConfirm: function(oEvent) {
			var sSelectedItem = Utility._getSelectedItemTitle(oEvent);
			this._oModel.setProperty("/QMART", sSelectedItem);

			// var aSelectedItems = oEvent.getParameter("selectedItems"),
			// 	oNotifType = sap.ui.getCore().byId("notif-type-multi"),
			// 	aItemsArray = [];
			// //remove all notification multiinput tokens 
			// oNotifType.removeAllTokens();
			// // add new values 
			// aSelectedItems.forEach(function(item) {
			// 	aItemsArray.push(item.getTitle());

			// 	oNotifType.addToken(new sap.m.Token({
			// 		key: item.getTitle(),
			// 		text: item.getTitle() // Texte affiché dans le MultiInput
			// 	}));
			// });

			// //prepare selected items for filters	
			// if (aItemsArray) {
			// 	this._oModel.setProperty("/QMART", aItemsArray);
			// }

		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.NotificationTypeSearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
				this._oFragment.setModel(this._oView.getModel("notificationSearchModel"), "notificationSearchModel");

			}
			return this._oFragment;
		},

	});

});
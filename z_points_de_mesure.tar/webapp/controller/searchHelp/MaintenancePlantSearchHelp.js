sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.MaintenancePlantSearchHelp", {

		//display the fragment	
		open: function(sValue) {
			this._returProperty = sValue;
			this._getFragment().open();
		},

		onMaintenancePlantSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "WERKS");
		},

		onMaintenancePlantconfirm: function(oEvent) {
			var aSelectedItem = Utility._getSelectedItemTitle(oEvent);
			this._oModel.setProperty(this._returProperty, aSelectedItem);

		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.maintenancePlantSearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();
			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
				this._oFragment.setModel(this._oView.getModel("CreationSearchModel"), "CreationSearchModel");
			}
			return this._oFragment;
		},

	});

});
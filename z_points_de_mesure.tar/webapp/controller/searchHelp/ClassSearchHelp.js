sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.ClassSearchHelp", {

		//display the fragment	
		open: function(sClassCategory) {

			this._getFragment(sClassCategory).open();
		},

		onClassSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "CLASS");
		},

		onClassConfirm: function(oEvent) {
			var sSelectedItem = Utility._getSelectedItemTitle(oEvent),
				sSelectedDivision = Utility._getSelectedItemDescription(oEvent);
			this._oModel.setProperty("/CLASS", sSelectedItem);
			this._oModel.setProperty("/KLART", sSelectedDivision);

		},

		_getFragment: function(sClassCategory) {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.classSearchHelp";

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
			}
			//initialize the fragment filter bar model 
			this._oFragment.setModel(new JSONModel({

			}), "class");

			//bind class items depending on class category
			this._readMaterialList(sClassCategory);
			return this._oFragment;

		},

		//prepare class help dialog filter 
		_prepareClassHelpFilter: function(sValue) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("KLART", sap.ui.model.FilterOperator.EQ, sValue));
			return aFilters;
		},
		
		//read data and bind class list
		_readMaterialList: function(sValue) {
			var aFilters = this._prepareClassHelpFilter(sValue);
			this._oView.getModel().read("/ClassSet", {
				filters: aFilters,
				success: function(odata, response) {
					var data = this._oFragment.getModel("class").getData();
					data.ClassSet = odata.results;
					this._oFragment.getModel("class").setData(data);
				}.bind(this),
				error: function() {

				}
			});
		}

	});

});
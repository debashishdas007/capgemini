sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/model/resource/ResourceModel"
], function(JSONModel,Device,ResourceModel) {
	"use strict";
		var i18nModel = new ResourceModel({
		bundleName: "pm-SaisieDesPointsDeMesure.i18n.i18n"
	});

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createFLPModel: function() {
			var fnGetUser = jQuery.sap.getObject("sap.ushell.Container.getUser"),
				bIsShareInJamActive = fnGetUser ? fnGetUser().isJamActive() : false,
				oModel = new JSONModel({
					isShareInJamActive: bIsShareInJamActive
				});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		createMeasurementPointModel: function() {
			var oModel = new JSONModel({
				"TPLNR": "",
				"PLTXT":"",
				"QMNUM":"",
				"QMTXT":"",
				"AUFNR":"",
				"KTEXT":"",
				"inputState":"Error",
				"inputStateText": i18nModel.getResourceBundle().getText("ValueStateErrorText")
			});
			return oModel;
		},
			// DEBUT MODFICATION GMAO-105 07/01/2021 APY
		createMultiInputMeasurementPointModel: function(sQMNUM, sPOINT, sMRNGU, sMRMIN, sMRMAX) {
			var oData = [];
			
			oData.push({
				MDOCM: sQMNUM, // Document de mesure
				POINT: sPOINT, // Numéro du point de mesure
				MRNGU: sMRNGU, // Unité
				IDATE: new Date(), // Date de mesure
				ITIME: new Date(), // Heure de mesure
				RECDC: "", // Valeur de mesure
				MRMIN: sMRMIN, // Valeur minimale
				MRMAX: sMRMAX // Valeur maximale
			});
			
			oData.push({
				MDOCM: sQMNUM, // Document de mesure
				POINT: sPOINT, // Numéro du point de mesure
				MRNGU: sMRNGU, // Unité
				IDATE: new Date(new Date().getTime() - 5 * 60000), // Date de mesure
				ITIME: new Date(new Date().getTime() - 5 * 60000), // Heure de mesure
				RECDC: "", // Valeur de mesure
				MRMIN: sMRMIN, // Valeur minimale
				MRMAX: sMRMAX // Valeur maximale
			});
			
			oData.push({
				MDOCM: sQMNUM, // Document de mesure
				POINT: sPOINT, // Numéro du point de mesure
				MRNGU: sMRNGU, // Unité
				IDATE: new Date(new Date().getTime() - 10 * 60000), // Date de mesure
				ITIME: new Date(new Date().getTime() - 10 * 60000), // Heure de mesure
				RECDC: "", // Valeur de mesure
				MRMIN: sMRMIN, // Valeur minimale
				MRMAX: sMRMAX // Valeur maximale
			});
			
			var oModel = new JSONModel();
			oModel.setData(oData);
			return oModel;
		}
		// FIN MODFICATION GMAO-105 07/01/2021 APY

	};

});
sap.ui.define([
    "./SearchHelp",
    "../Utility",
    "./modelss",
    "sap/ui/model/json/JSONModel",
    "./NotificationTypeSearchHelp",
    "./MaintenancePlantSearchHelp",
    "./WorkCenterSearchHelp",
    "./OrderSearchHelp",
    "./FunctionalLocationSearchHelp",
    "./EquipementSearchHelp",
], function(searchHelp, Utility, models, JSONModel, NotificationTypeSearchHelp, MaintenancePlantSearchHelp, WorkCenterSearchHelp,
    OrderSearchHelp, FunctionalLocationSearchHelp, EquipementSearchHelp) {
    "use strict";

    return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.NotificationSearchHelp", {

        open: function(isOption, aProperties, sModel) {

            this._aproperties = aProperties;
            this._sModel = sModel;

            this._IsOption = isOption;

            //display the fragment
            this._getFragment().open();
            //instantiate the notification type fragment
            this._notificationTypeFragment = new NotificationTypeSearchHelp(this._oController, this._oFragment.getModel("Notification"));
            //instantiate the localisation division fragment
            this._LocalisationDivisionFragment = new MaintenancePlantSearchHelp(this._oController, this._oFragment.getModel("Notification"));
            //instantiate the work center fragment
            this._workCenterFragment = new WorkCenterSearchHelp(this._oController, this._oFragment.getModel("Notification"));
            //instantiate the order fragment
            this._orderFragment = new OrderSearchHelp(this._oController, this._oFragment.getModel("Notification"));
            // functional location search help reference creation
            this._FunctionalLocationFragment = new FunctionalLocationSearchHelp(this._oController, this._oFragment.getModel("Notification"));
            // equipement search help reference creation
            this._EquipementFragment = new EquipementSearchHelp(this._oController, this._oFragment.getModel("Notification"));

        },

        _getFragment: function() {
            // variable declaration
            var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.NotificationSearchHelp",
                oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

            if (!this._oFragment) {
                //fragment instance and model assignement
                this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
                this._oFragment.setModel(this._oView.getModel("notificationSearchModel"), "notificationSearchModel");

                // Table and columns definition according to used device
                Utility.defineTable(
                    this._oFragment,
                    oRessourceModel.getText("notificationNumber"), "notificationSearchModel>QMNUM",
                    oRessourceModel.getText("notificationDescription"), "notificationSearchModel>QMTXT"
                );
            }
            //initialize the fragment filter bar model 
            this._oFragment.setModel(new JSONModel({
                "WAWRK": ""
            }), "Notification");

            return this._oFragment;
        },

		/**
		 * Event handler for searching a functional location  .
		 * @param {event} oEvent : event triggered once researching a functional location   
		 * @public
		 */
        onSearch: function(oEvent) {
            var aFilters = this._prepareFilterTable(oEvent, "QMNUM");

            this._filterTable(new sap.ui.model.Filter({
                filters: aFilters,
                and: true
            }), this._oFragment, "notificationSearchModel>/PMNotificationDetailsSet", "{notificationSearchModel>QMNUM}",
                "{notificationSearchModel>QMTXT}");
        },

		/**
		 * Event handler for selecting the tplnr value  .
		 * @param {event} oEvent : event triggered once researching a functional location   
		 * @public
		 */
        onSelectionConfirm: function(oEvent) {

            this._initializeFilterCriteria();
            this._onSearchHelpOkPress(oEvent, "notificationSearchModel", "QMNUM");
            this._onSearchHelpOkPress(oEvent, "notificationSearchModel", "QMTXT");

            if (this._IsOption === true) {
                this._oView.byId("hiearchy-options").setEnabled(false);
                this._oModel.setProperty("/inputState", "None");
                this._oModel.setProperty("/inputStateText", "");
            }

        },

        /////////////////////////////////////////// value help fragments open methods ////////////////////////////

        //open notification type fragment
        onNotificationTypeHelpRequest: function() {
            this._notificationTypeFragment.open();
        },

        //open maintenance type fragment
        onMaintenancePlantRequest: function() {
            this._LocalisationDivisionFragment.open("/SWERK");
        },

        //open work center fragment
        onPosteResponsableHelpRequest: function() {
            this._workCenterFragment.open();
        },
        //open order fragment
        onOrderHelpRequest: function() {
            this._orderFragment.open();
        },

        //open Equipment fragment
        onEquipmentRequest: function() {
            this._EquipementFragment.open();
        },

        //open functional Location fragment
        onFuncLocationHelpRequest: function() {
            this._FunctionalLocationFragment.open();
        },

        //////////////////////////////////////////////////////////////////////////////////////////////////////////

        onPosteRespRefresh: function(oEvent) {
            Utility._resetInputDescriptionValue(oEvent, this._oFragment.getModel("Notification"), ["/VAPLZ", "/WAWRK"]);

        }

    });

});
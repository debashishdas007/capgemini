sap.ui.define([
	"./SearchHelp",
	"./MaintenancePlantSearchHelp",
	"./ClassSearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, MaintenancePlantSearchHelp, ClassSearchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.MaterialLocationSearchHelp", {

		open: function() {
			//display the fragment
			this._getFragment().open();
			//instantiate the localisation division fragment
			this._LocalisationDivisionFragment = new MaintenancePlantSearchHelp(this._oController, this._oFragment.getModel(
				"material"));
			//instantiate the class  fragment
			this._classFragment = new ClassSearchHelp(this._oController, this._oFragment.getModel("material"));
		},

		_getFragment: function() {
			// variable declaration measurementPoint
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.materialSearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);

				// Table and columns definition according to used device
				Utility.defineTable(
					this._oFragment,
					oRessourceModel.getText("material"), "MATNR",
					oRessourceModel.getText("materialDescription"), "MAKTX"
				);
			}

			//initialize the fragment filter bar model 
			this._oFragment.setModel(new JSONModel({

			}), "material");

			return this._oFragment;
		},
		/**
		 * Event handler for searching a functional location  .
		 * @param {event} oEvent : event triggered once researching a functional location   
		 * @public
		 */
		onSearch: function(oEvent) {
			var aFilters = this._prepareFilterTable(oEvent, "MATNR");
			this._filterTable(new sap.ui.model.Filter({
				filters: aFilters,
				and: true
			}), this._oFragment, "/MaterialSet", "{MATNR}", "{MAKTX}");
		},

		/**
		 * Event handler for selecting the material .
		 * @param {event} oEvent : event triggered once selecting a material  
		 * @public
		 */
		onSelectionConfirm: function(oEvent) {
			this._onSearchHelpOkPress(oEvent, "", "MATNR");
			this._onSearchHelpOkPress(oEvent, "", "MAKTX");
		},

		/////////////////////////////////////////// value help fragments open methods ////////////////////////////
	

		//open maintenance Plant fragment
		onMaintenancePlantHelpRequest: function() {
			this._LocalisationDivisionFragment.open("/WERKS");
		},
		//open class fragment
		onClassHelpRequest: function() {
			var sClassCategory ="001";
			this._classFragment.open(sClassCategory);
		},
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	});

});
sap.ui.define([
			"sap/ui/base/Object",
			"../Utility",
			"./modelss",
			"sap/ui/model/json/JSONModel"
		], function(Object, Utility, models, JSONModel) {
			"use strict";

			return Object.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.SearchHelp", {

					//Search help constructor
					constructor: function(oController, oModel) {

						this._oView = oController.getView();
						this._oController = oController;
						this._oModel = oModel;

					},

					//close the fragment
					onCancel: function() {
						this._oFragment.close();
					},

					//destroy the fragment
					destroy: function() {
						if (this._oFragment) {
							this._oFragment.destroy();
						}
					},
                    
                    //Initialize filter criterias
					_initializeFilterCriteria: function() {
						if (this._aproperties) {
							this._aproperties.forEach(function(oElement) {
								this._oView.getModel(this._sModel).setProperty(oElement, "");
							}.bind(this));
						}
					},

						//prepare filter for table   
						_prepareFilterTable: function(oEvent, sEquipFuncLocVar) {
								var aFilters, aSelectionSet = oEvent.getParameter("selectionSet"),
									sKlart, sWawrk;

								if (sEquipFuncLocVar === "TPLNR") {
									sKlart = "003";
								} else if (sEquipFuncLocVar === "EQUNR") {
									sKlart = "002";
								} else if (sEquipFuncLocVar === "MATNR") {
									sKlart = "001";
								} else if (sEquipFuncLocVar === "QMNUM") {
									sWawrk = this._oFragment.getModel("Notification").getProperty("/WAWRK");
								} else {
									sKlart = undefined;
								}

								aFilters = aSelectionSet.reduce(function(aResult, oControl) {
									if (oControl.getValue()) {
										aResult.push(new sap.ui.model.Filter({
											path: oControl.getName(),
											operator: sap.ui.model.FilterOperator.EQ,
											value1: oControl.getValue().toUpperCase()
										}));
										if (oControl.getName() === "CLASS" && sKlart) {
											aResult.push(new sap.ui.model.Filter({
												path: "KLART",
												operator: sap.ui.model.FilterOperator.EQ,
												value1: sKlart
											}));
										}
										if (oControl.getName() === "VAPLZ" && sWawrk) {
											aResult.push(new sap.ui.model.Filter({
												path: "WAWRK",
												operator: sap.ui.model.FilterOperator.EQ,
												value1: sWawrk
											}));
										}
									}

									return aResult;
								}, []);
								return aFilters;
							},

							/**
							 * Apply filter and bind  table with results   
							 * @param {string[] } aFilters table of filters 
							 * @private
							 */
							_filterTable: function(oFilter, fragmentInstance, entityset, firstCellBinding, secondCellBinding) {
								var oValueHelpDialog, oTable;

								// get the  table of the value dialog help   
								oValueHelpDialog = fragmentInstance;
								oTable = oValueHelpDialog.getTable();

								// case the value help dialog table  is  a sap.ui.table 

								if (oTable.bindRows) {
									oTable.bindRows({
										path: entityset,
										filters: oFilter,
										events: {
											dataReceived: this._DataReceivedEventHandler.bind(this)
										}
									});

								}

								//case the value help dialog table  is  a sap.m.table
								if (oTable.bindItems) {
									oTable.bindAggregation("items", {
										path: entityset,
										factory: function() {
											return new sap.m.ColumnListItem({
												type: "Active",
												cells: [

													new sap.m.Text({
														text: firstCellBinding
													}),
													new sap.m.Text({
														text: secondCellBinding
													})
												]
											});
										},
										filters: oFilter,
										events: {
											dataReceived: this._DataReceivedEventHandler.bind(this)
										}

									});
								}

								oValueHelpDialog.update();

							},

							// handle data reveived event handler for search help table
							_DataReceivedEventHandler: function(oEvent) {
								// var nLength = oEvent.getParameter("data").results.length,
								// 	oRessourceModel = this._oView.getModel("i18n").getResourceBundle();
								// if (nLength === 0) {
								// 	sap.m.MessageBox.information(
								// 		oRessourceModel.getText("emptySearchHelpTable")
								// 	);
								// }
							},

							//selection event handler for serach help
							_onSearchHelpOkPress: function(oEvent, fragmentModel, propertyName) {

								var oBindingContext = Utility._getBindingContext(oEvent, fragmentModel),
									sPropertyValue = oBindingContext.getProperty(propertyName),
									sProperty = "/" + propertyName;

								this._oModel.setProperty(sProperty, sPropertyValue);

								this.onCancel();
							}

					});

			});
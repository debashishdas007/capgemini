sap.ui.define([
	"./SearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.WorkCenterSearchHelp", {

		//display the fragment	
		open: function() {

			this._getFragment().open();
		},

		onWorkCenterSearch: function(oEvent) {
			Utility.searchElementFromSelectDialogList(oEvent, "ARBPL");
		},

		onWorkCenterconfirm: function(oEvent) {
			var sSelectedItem = Utility._getSelectedItemTitle(oEvent),
				sSelectedDivision = Utility._getSelectedItemDescription(oEvent);
			this._oModel.setProperty("/VAPLZ", sSelectedItem);
			this._oModel.setProperty("/WAWRK", sSelectedDivision);
		},

		_getFragment: function() {
			// variable declaration
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.WorkCenterSearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);
				this._oFragment.setModel(this._oView.getModel("notificationSearchModel"), "notificationSearchModel");

			}
			return this._oFragment;
		},

	});

});
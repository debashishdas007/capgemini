sap.ui.define([
	"./SearchHelp",
	"./PlannerGroupSearchHelp",
	"./MaintenancePlantSearchHelp",
	"./LocalisationSearchHelp",
	"./PlantSectionSearchHelp",
	"./ClassSearchHelp",
	"../Utility",
	"./modelss",
	"sap/ui/model/json/JSONModel"
], function(searchHelp, PlannerGroupsearchHelp, MaintenancePlantSearchHelp, LocalisationSearchHelp, PlantSectionSearchHelp,
	ClassSearchHelp, Utility, models, JSONModel) {
	"use strict";

	return searchHelp.extend("grtgaz.puma.PointsDeMesures.controller.searchHelp.FunctionalLocationSearchHelp", {

		open: function(sFunctionalLocationCode, aProperties, sModel) {
			this._aproperties = aProperties;
			this._sModel = sModel;
			//display the fragment
			this._getFragment(sFunctionalLocationCode).open();
			//instantiate theplanner group fragment
			this._plannerGroupFragment = new PlannerGroupsearchHelp(this._oController, this._oFragment.getModel("functionalLocation"));
			//instantiate the localisation division fragment
			this._LocalisationDivisionFragment = new MaintenancePlantSearchHelp(this._oController, this._oFragment.getModel(
				"functionalLocation"));
			//instantiate the localisation  fragment
			this._LocalisationFragment = new LocalisationSearchHelp(this._oController, this._oFragment.getModel("functionalLocation"));
			//instantiate the plant section  fragment
			this._plantSectionFragment = new PlantSectionSearchHelp(this._oController, this._oFragment.getModel("functionalLocation"));
			//instantiate the class  fragment
			this._classFragment = new ClassSearchHelp(this._oController, this._oFragment.getModel("functionalLocation"));
		},

		_getFragment: function(sFunctionalLocationCode) {
			// variable declaration measurementPoint
			var sFragmentName = "grtgaz.puma.PointsDeMesures.view.fragments.FunctionalLocationSearchHelp",
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle(),
				sValueState = oRessourceModel.getText("error"),
				sValueMessage = oRessourceModel.getText("FilterCriteriaValueMessage"),
				bLoaded = false;

			if (!this._oFragment) {
				//fragment instance and model assignement
				this._oFragment = Utility._instantiateFragment(sFragmentName, this, this._oView);

				// Table and columns definition according to used device
				Utility.defineTable(
					this._oFragment,
					oRessourceModel.getText("funcLocationNumber"), "TPLNR",
					oRessourceModel.getText("funcLocationDescription"), "PLTXT"
				);
			}

			if (sFunctionalLocationCode) {
				sValueState = oRessourceModel.getText("none");
				sValueMessage = "";
				bLoaded = true;
				sFunctionalLocationCode = sFunctionalLocationCode + "*";
			}

			//initialize the fragment filter bar model 
			this._oFragment.setModel(new JSONModel({
				"TPLNR": sFunctionalLocationCode,
				"FilterCriteriaValueMessage": sValueMessage,
				"FilterCriteriaStatueValue": sValueState,
				"isLoaded": bLoaded

			}), "functionalLocation");

			return this._oFragment;
		},
		/**
		 * Event handler for searching a functional location  .
		 * @param {event} oEvent : event triggered once researching a functional location   
		 * @public
		 */
		onSearch: function(oEvent) {
			var sFilterCriteriaValueState = this._oFragment.getModel("functionalLocation").getProperty("/FilterCriteriaStatueValue"),
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle();

			if (sFilterCriteriaValueState === "Error") {
				sap.m.MessageBox.error(
					oRessourceModel.getText("FilterCriteriaValueMessage")
				);
				return;
			}

			var aFilters = this._prepareFilterTable(oEvent, "TPLNR");

			this._filterTable(new sap.ui.model.Filter({
				filters: aFilters,
				and: true
			}), this._oFragment, "/FunctionalLocationSet", "{TPLNR}", "{PLTXT}");
		},

		/**
		 * Event handler for selecting the tplnr value  .
		 * @param {event} oEvent : event triggered once researching a functional location   
		 * @public
		 */
		onSelectionConfirm: function(oEvent) {
			this._initializeFilterCriteria();
			this._onSearchHelpOkPress(oEvent, "", "TPLNR");
			this._onSearchHelpOkPress(oEvent, "", "PLTXT");
			if (this._aproperties) {
				this._oView.byId("hiearchy-options").setEnabled(true);
				this._oView.byId("hiearchy-options").setSelectedKey("RB-3");
				this._oModel.setProperty("/inputState", "None");
				this._oModel.setProperty("/inputStateText", "");
			}

		},

		//handle functional location code deletion
		onFuncLocationNumberChange: function(oEvent) {
			var sParameter = oEvent.getParameter("newValue"),
				oFunctionalLocationModel = this._oFragment.getModel("functionalLocation"),
				oRessourceModel = this._oView.getModel("i18n").getResourceBundle(),
				sLoaded = oFunctionalLocationModel.getProperty("/isLoaded"),
				sValueState = "None",
				sValueMessage = "",
				sIGRP = oFunctionalLocationModel.getProperty("/INGRP"),
				sBEBER = oFunctionalLocationModel.getProperty("/BEBER");

			if (!sParameter && sLoaded === true) {
				if (!sIGRP && !sBEBER) {
					sValueState = "Error";
					sValueMessage = oRessourceModel.getText("FilterCriteriaValueMessage");
				}
				oFunctionalLocationModel.setProperty("/FilterCriteriaStatueValue", sValueState);
				oFunctionalLocationModel.setProperty("/FilterCriteriaValueMessage", sValueMessage);
				oFunctionalLocationModel.setProperty("/isLoaded", false);
			}

		},

		/////////////////////////////////////////// value help fragments open methods ////////////////////////////
		//open notification type fragment
		onPlannerGroupRequest: function() {
			this._plannerGroupFragment.open();
		},

		//open maintenance type fragment
		onMaintenancePlantHelpRequest: function() {
			this._LocalisationDivisionFragment.open("/SWERK");
		},
		//open Localisation fragment
		onLocalisationHelpRequest: function() {
			this._LocalisationFragment.open();
		},
		//open plant section fragment
		onPlantSectionHelpRequest: function() {
			this._plantSectionFragment.open();
		},
		//open class fragment
		onClassHelpRequest: function() {
			this._classFragment.open("003");
		},
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		onMandFilterCriteriaChange: function(oEvent) {
			var oRessourceModel = this._oView.getModel("i18n").getResourceBundle(),
				sValueState = oRessourceModel.getText("none"),
				sValueMessage = "",
				oModel = this._oFragment.getModel("functionalLocation"),
				sloaded = oModel.getProperty("/isLoaded"),
				sInputName = oEvent.getSource().getProperty("name"),
				sValue = oModel.getProperty("/BEBER");

			if (sInputName === "BEBER") {
				sValue = oModel.getProperty("/INGRP");
			}

			if (!oEvent.getParameter("newValue") && sloaded === false && !sValue) {
				sValueState = oRessourceModel.getText("error");
				sValueMessage = oRessourceModel.getText("FilterCriteriaValueMessage");
			}
			oModel.setProperty("/FilterCriteriaStatueValue", sValueState);
			oModel.setProperty("/FilterCriteriaValueMessage", sValueMessage);
		}
	});

});
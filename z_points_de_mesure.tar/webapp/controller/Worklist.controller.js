jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.SimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.NotificationSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EntryListSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.NotificationTypeMeasurementPointSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.OrderSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.observer.ISubscriber");

sap.ui.define([
    "./BaseController",
    "./Utility",
    "../model/models",
    "./DialogMultipleInputMeasurementPoint",
    "./DialogSimoneMeasurementPoint",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "../control/TextWithName",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/SimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/NotificationSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EntryListSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/NotificationTypeMeasurementPointSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/OrderSearchHelp"
], function(BaseController, Utility, models, DialogMultipleInputMeasurementPoint, DialogSimoneMeasurementPoint,
    JSONModel,
    History,
    formatter, Filter,
    FilterOperator, TextWithName,
    SimpleSelectionMode, ObjectSimpleSelectionMode, NotificationSearchHelp,
    FunctionalLocationSearchHelp, EquipmentSearchHelp, EntryListSearchHelp, NotificationTypeMeasurementPointSearchHelp, OrderSearchHelp
) {
    "use strict";

    return BaseController.extend("grtgaz.puma.PointsDeMesures.controller.Worklist", {
        metadata: {
            interfaces: ["com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/observer/ISubscriber"]
        },

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function() {
            var oViewModel,
                oSmartFilterModel,
                oFilter,
                iOriginalBusyDelay,
                oTable,
                oDate = new Date(),
                oTime = new Date(2018, 8, 22, 0, 0, 0);

            this.bNavigate = false;
            /***********************************************GMAO340 */
            this.getOwnerComponent().getService("ShellUIService").then(function(oShellService) {
                oShellService.setBackNavigation(function() {
                    this.onNavBack();
                }.bind(this));
            }.bind(this));


            /***********************************************END GMAO 340 */


            // Model used to manipulate control states
            oViewModel = new JSONModel({});
            this.setModel(oViewModel, "worklistView");
            this.getModel("worklistView").setProperty("/DefaultDateValue", oDate);
            this.getModel("worklistView").setProperty("/DefaultTimeValue", oTime);

            // Model used to manipulate smart filter criteria
            oSmartFilterModel = models.createMeasurementPointModel();
            this.setModel(oSmartFilterModel, "measurementPoint");

            // // Make sure, busy indication is showing immediately so there is no
            // // break after the busy indication for loading the view's meta data is
            // // ended (see promise 'oWhenMetadataIsLoaded' in AppController)
            // oTable = this.getView().byId("measure-point-table").getTable();
            // // iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
            // oTable.attachEventOnce("updateFinished", function() {
            // 	// Restore original busy indicator delay for worklist's table
            // 	//oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
            // 	oTable.setBusy(false);
            // });

            // this.getOwnerComponent().getModel().attachEvent("dataReceived", function() {
            // 	this.getView().byId("measure-point-table").getTable().setBusy(false);
            // }.bind(this));

            // Fragment de l'aide à la recherche des avis
            this.searchHelpNotificationFragment = new NotificationSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("measurementPoint"),
                    function(oObject) {
                        console.log(oObject);
                        this.getView().getModel("measurementPoint").setProperty("/QMNUM", oObject.QMNUM);
                        this.getView().getModel("measurementPoint").setProperty("/QMTXT", oObject.QMTXT);

                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // DEBUT MODIFICATION GMAO-226 (1)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        this.getView().getModel("measurementPoint").setProperty("/AUFNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/KTEXT", "");
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // FIN MODIFICATION GMAO-226 (1)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

                        this.getView().getModel("measurementPoint").setProperty("/TPLNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/PLTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/EQUNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/EQKTX", "");

                        this.getView().getModel("measurementPoint").setProperty("/MELNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/NAMEL", "");
                    }.bind(this)
                )
            );
            this.searchHelpNotificationFragment.subscribe(this);

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
			/*
				TICKET JIRA GMAO-226
				
				Fait le  : 03/03/2021
				Fait par : Alexandre PISSOTTE (APY)
			*/
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-226
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // Fragment de l'aide à la recherche des ordres
            this.searchHelpOrderFragment = new OrderSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("measurementPoint"),
                    function(oObject) {
                        this.getView().getModel("measurementPoint").setProperty("/AUFNR", oObject.AUFNR);
                        this.getView().getModel("measurementPoint").setProperty("/KTEXT", oObject.KTEXT);

                        this.getView().getModel("measurementPoint").setProperty("/QMNUM", "");
                        this.getView().getModel("measurementPoint").setProperty("/QMTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/TPLNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/PLTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/EQUNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/EQKTX", "");

                        this.getView().getModel("measurementPoint").setProperty("/MELNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/NAMEL", "");
                    }.bind(this)
                )
            );
            this.searchHelpOrderFragment.subscribe(this);
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-226
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

            // Fragment de l'aide à la recherche des postes techniques
            this.searchHelpFunctionalLocationFragment = new FunctionalLocationSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("measurementPoint"),
                    function(oObject) {
                        this.getView().getModel("measurementPoint").setProperty("/TPLNR", oObject.TPLNR);
                        this.getView().getModel("measurementPoint").setProperty("/PLTXT", oObject.PLTXT);

                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // DEBUT MODIFICATION GMAO-226 (2)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        this.getView().getModel("measurementPoint").setProperty("/AUFNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/KTEXT", "");
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // FIN MODIFICATION GMAO-226 (2)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

                        this.getView().getModel("measurementPoint").setProperty("/QMNUM", "");
                        this.getView().getModel("measurementPoint").setProperty("/QMTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/EQUNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/EQKTX", "");

                        this.getView().getModel("measurementPoint").setProperty("/MELNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/NAMEL", "");
                    }.bind(this)
                )
            );
            this.searchHelpFunctionalLocationFragment.subscribe(this);

            // Fragment de l'aide à la recherche des équipements
            this.searchHelpEquipementFragment = new EquipmentSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("measurementPoint"),
                    function(oObject) {
                        this.getView().getModel("measurementPoint").setProperty("/EQUNR", oObject.EQUNR);
                        this.getView().getModel("measurementPoint").setProperty("/EQKTX", oObject.EQKTX);

                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // DEBUT MODIFICATION GMAO-226 (3)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        this.getView().getModel("measurementPoint").setProperty("/AUFNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/KTEXT", "");
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // FIN MODIFICATION GMAO-226 (3)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

                        this.getView().getModel("measurementPoint").setProperty("/QMNUM", "");
                        this.getView().getModel("measurementPoint").setProperty("/QMTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/TPLNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/PLTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/MELNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/NAMEL", "");
                    }.bind(this)
                )
            );
            this.searchHelpEquipementFragment.subscribe(this);

            // Fragment de l'aide à la recherche des listes de saisie
            this.searchHelpListEntryFragment = new EntryListSearchHelp(
                this,
                new ObjectSimpleSelectionMode(
                    this.getView().getModel("measurementPoint"),
                    function(oObject) {
                        this.getView().getModel("measurementPoint").setProperty("/MELNR", oObject.MELNR);
                        this.getView().getModel("measurementPoint").setProperty("/NAMEL", oObject.NAMEL);

                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // DEBUT MODIFICATION GMAO-226 (4)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        this.getView().getModel("measurementPoint").setProperty("/AUFNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/KTEXT", "");
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
                        // FIN MODIFICATION GMAO-226 (4)
                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

                        this.getView().getModel("measurementPoint").setProperty("/QMNUM", "");
                        this.getView().getModel("measurementPoint").setProperty("/QMTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/TPLNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/PLTXT", "");

                        this.getView().getModel("measurementPoint").setProperty("/EQUNR", "");
                        this.getView().getModel("measurementPoint").setProperty("/EQKTX", "");
                    }.bind(this)
                )
            );
            this.searchHelpListEntryFragment.subscribe(this);

            // Fragment de l'aide à la recherche des types d'avis pour les points de mesure
            this.searchHelpNotificationTypeFragment = new NotificationTypeMeasurementPointSearchHelp(
                this,
                new SimpleSelectionMode(
                    this.getView().getModel("measurementPoint"),
                    "/ATWRT",
                    "/ATWTB"
                )
            );

            // Création d'une référence publique au fragment pour la saisie multiple des points de mesure
            this.dialogMultipleInputMeasurementPointFragment = new DialogMultipleInputMeasurementPoint();

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-58 
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // Création d'une référence publique au fragment pour la saisie  de point de mesure simone
            this.dialogSimoneMeasurementPointFragment = new DialogSimoneMeasurementPoint();

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            //  FIN MODIFICATION GMAO-58
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - // 



            //prefill startup parameters
            this._catchStartupParameters();

            // Variant management handler
            oFilter = this.getView().byId("smartFilterBar");
            oFilter.attachBeforeVariantSave(this._onBeforeVariantSave, this);
            oFilter.attachAfterVariantLoad(this._onAfterVariantLoad, this);
            this.getView().byId("page").scrollToElement(oFilter, 0);

        },

        onExit: function() {
            var aFragments = [this.searchHelpNotificationFragment, this.searchHelpFunctionalLocationFragment,
            this.searchHelpEquipementFragment, this.searchHelpListEntryFragment,
            this.searchHelpNotificationTypeFragment, this.dialogMultipleInputMeasurementPointFragment,
            this.searchHelpOrderFragment,// GMAO-226 Alexandre PISSOTTE (APY)
            this.dialogSimoneMeasurementPointFragment // GMAO-58 Omar Mahmoudi
            ];
            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }
        },

        _destroyFragmentInstance: function(FragmentInstance) {
            var oFragmentInstance = FragmentInstance;
            oFragmentInstance.destroy();
        },

        //////////////// variant handler/////////////////////

        _onBeforeVariantSave: function(oEvent) {
            var oFilterCriteriaValues = {},
                oFilter;

            // get the smartfilter
            oFilter = oEvent.getSource();

            //get filter criteria values&nbsp;
            oFilterCriteriaValues._CUSTOM = this._prepareDefaultValue(oFilter);

            oEvent.getSource().setFilterData(oFilterCriteriaValues);
        },

        _prepareDefaultValue: function(oFilter) {

            var aFiltersSingleParameters = ["QMNUM", "QMTXT", "TPLNR", "PLTXT", "EQUNR", "EQKTX", "MELNR", "NAMEL", "ATWRT", "ATWTB"],
                _custom = {},
                sProperty, sValue;

            // save single value filter criteria 	
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                sValue = this.getView().getModel("measurementPoint").getProperty(sProperty);
                if (sValue) {
                    _custom[aFiltersSingleParameters[i]] = sValue;
                }
            }

            var oListOptionSelected = this.getView().byId("hiearchy-options").getSelectedKey();
            if (oListOptionSelected) {
                _custom["HIERARCHY"] = oListOptionSelected;
            }

            return _custom;
        },

        _onAfterVariantLoad: function(oEvent) {
            var oVariantData = JSON.parse(oEvent.getSource().fetchVariant().filterBarVariant)["_CUSTOM"];
            if (oVariantData) {
                this._setFilterCriteriaData(oVariantData);
            } else {
                this._initializeFilterCriteria();
            }
            var filterBar = this.getView().byId("smartFilterBar");
            if (this.getView().byId("smartFilterBar").getVariantManagement().oSelectedItem.getExecuteOnSelection()) {
                filterBar.fireSearch();
            }

        },

        _initializeFilterCriteria: function() {
            var aFiltersSingleParameters = ["QMNUM", "QMTXT", "TPLNR", "PLTXT", "EQUNR", "EQKTX", "MELNR", "NAMEL", "ATWRT", "ATWTB"],
                sProperty;
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                this.getView().getModel("measurementPoint").setProperty(sProperty, "");
            }

        },
        _setFilterCriteriaData: function(oObject) {
            var aFiltersSingleParameters = ["QMNUM", "QMTXT", "TPLNR", "PLTXT", "EQUNR", "EQKTX", "MELNR", "NAMEL", "ATWRT", "ATWTB"],
                sValue, sProperty;
            // set single value filter criteria 	
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                sValue = oObject[aFiltersSingleParameters[i]];
                if (sValue) {
                    this.getView().getModel("measurementPoint").setProperty(sProperty, sValue);
                } else {
                    this.getView().getModel("measurementPoint").setProperty(sProperty, "");
                }
            }

            this._setOption(oObject);
        },

        _setOption: function(oObject) {
            var sOption = oObject["/HIERARCHY"],
                oOptionFilter = this.getView().byId("hiearchy-options");
            if (sOption) {
                oOptionFilter.setSelectedKey(sOption);
            }
        },

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */
		/**&nbsp;
		 * Valide les inputs lorsque l'utilisateur sélectionne une valeur dans l'une
		 * des aides à la recherche
		 */
        update: function() {
            this._setInputStateToError(true);
        },

		/**&nbsp;
		 * Ouvre l'aide à la recherche des avis
		 */
        onNotificationValueHelpRequest: function() {
            this.searchHelpNotificationFragment.open();
        },

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-226 (5)
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
		/**&nbsp;
		 * Ouvre l'aide à la recherche des avis
		 */
        onOrderValueHelpRequest: function() {
            this.searchHelpOrderFragment.open();
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-226 (5)
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

		/**&nbsp;
		 * Ouvre l'aide à la recherche des poste techniques
		 */
        onFunctionalLocationValueHelpRequest: function() {
            this.searchHelpFunctionalLocationFragment.open();
        },

		/**&nbsp;
		 * Ouvre l'aide à la recherche des équipements
		 */
        onEquipementValueHelpRequest: function() {
            this.searchHelpEquipementFragment.open();
        },

		/**&nbsp;
		 * Ouvre l'aide à la recherche des listes de saisie
		 */
        onEntryListValueHelpRequest: function() {
            this.searchHelpListEntryFragment.open();
        },

		/**&nbsp;
		 * Ouvre l'aide à la recherche des types d'avis pour les points de mesure
		 */
        onNotificationTypeValueHelpRequest: function() {
            this.searchHelpNotificationTypeFragment.open();
        },

        onNotificationChange: function(oEvent) {
            Utility._resetInputDescriptionValue(oEvent, this.getModel("measurementPoint"), ["/QMNUM", "/QMTXT"]);
            this.getView().byId("hiearchy-options").setEnabled(true);
            this._setInputStateToError(false);
        },

        onOrderChange: function(oEvent) {
            Utility._resetInputDescriptionValue(oEvent, this.getModel("measurementPoint"), ["/AUFNR", "/KTEXT"]);
            this._setInputStateToError(false);
        },

        onFuncLocChange: function(oEvent) {
            Utility._resetInputDescriptionValue(oEvent, this.getModel("measurementPoint"), ["/TPLNR", "/PLTXT"]);
            this._setInputStateToError(false);
        },

        onEquipementChange: function(oEvent) {
            Utility._resetInputDescriptionValue(oEvent, this.getModel("measurementPoint"), ["/EQUNR", "/EQKTX"]);
            this._setInputStateToError(false);
        },

        onEntryListChange: function(oEvent) {
            Utility._resetInputDescriptionValue(oEvent, this.getModel("measurementPoint"), ["/MELNR", "/NAMEL"]);
            this._setInputStateToError(false);
        },

        onNotificationTypeChange: function(oEvent) {
            Utility._resetInputDescriptionValue(oEvent, this.getModel("measurementPoint"), ["/ATWRT", "/ATWTB"]);
        },

        onInputValueHelp: function(oEvent) {

            var oBindingContext = oEvent.getSource().getBindingContext(),
                bSimone = oBindingContext.getObject().ZZSIMONE;

            if (bSimone) {
                this.dialogSimoneMeasurementPointFragment.open(
                    this,
                    oBindingContext
                );
            } else {
                this.dialogMultipleInputMeasurementPointFragment.open(
                    this,
                    oBindingContext
                );
            }

        },

        _setInputStateToError: function(bIsSateValid) {
            var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle(),
                sInputState = "Error",
                sInputStateMesssage = oResourceBundle.getText("ValueStateErrorText");
            if (bIsSateValid) {
                sInputState = "None";
                sInputStateMesssage = "";
            }
            this.getModel("measurementPoint").setProperty("/inputState", sInputState);
            this.getModel("measurementPoint").setProperty("/inputStateText", sInputStateMesssage);
        },

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
        onNavBack: function() {
            /************************GMAO 430************************************************************** */
            /***********             If unsaved Data exists, a message Box will be shown to propose save ** */
            /***********             Done By Hajer Cheikhouhou On 24/08/2021   **************************** */
            this.CheckUnsavedData(true, false, false);

            /* var sPreviousHash = History.getInstance().getPreviousHash(),
                 oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
 
             if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                 history.go(-1);
             } else {
                 oCrossAppNavigator.toExternal({
                     target: {
                         shellHash: "#Shell-home"
                     }
                 });
             }*/
        },

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
        onRefresh: function() {
            var oTable = this.byId("table");
            oTable.getBinding("items").refresh();
        },

        /** 
         * Effectue la recherche des points de mesure
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-513
         * Par : Alexandre PISSOTTE (APY)
         * Date : 17/01/2022
         * Motif : Tri de la table des points de mesure
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onSearchMeasurmentPointFilter: function() {
            /*************             GMAO430      ********************** */
            if (this.bSaved === false) {
                this.CheckUnsavedData(false, true, false);
                return;
            }
            this.bSaved = false;
            /*************    End  GMAO430      ********************** */

            var aProperties = ["/QMNUM", "/AUFNR", "/TPLNR", "/EQUNR", "/MELNR", "/ATWRT"], // GMAO-226 Alexandre PISSOTTE (APY)
                aFilters = [],
                oTemplate,
                oModel = this.getView().getModel("measurementPoint"),
                oSmartTable = this.getView().byId("measure-point-table").getTable(),
                sNotificationNumber = oModel.getProperty("/QMNUM"),
                sOrderNumber = oModel.getProperty("/AUFNR"), // GMAO-226 Alexandre PISSOTTE (APY)
                sFuncLocationNumber = oModel.getProperty("/TPLNR"),
                sEquipmentNumber = oModel.getProperty("/EQUNR"),
                sEntryListNumber = oModel.getProperty("/MELNR"),
                sNotificationType = oModel.getProperty("/ATWRT");

            if (this.getView().byId("hiearchy-options").getSelectedItem() != null) {
                var sOption = this.getView().byId("hiearchy-options").getSelectedItem().getKey();
            }

            // Si l'utilisateur n'a rien saisi
            if (!sNotificationNumber && !sFuncLocationNumber && !sEquipmentNumber && !sEntryListNumber && !sOrderNumber) { // GMAO-226 Alexandre PISSOTTE (APY)
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("noFiltersSearch"));
                return;
            }
            if (sNotificationNumber) {
                aFilters.push(new sap.ui.model.Filter("QMNUM", sap.ui.model.FilterOperator.EQ, sNotificationNumber));
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-226 (6)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if (sOrderNumber) {
                aFilters.push(new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, sOrderNumber));
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-226 (6)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if (sFuncLocationNumber) {
                aFilters.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, sFuncLocationNumber));
            }
            if (sEquipmentNumber) {
                aFilters.push(new sap.ui.model.Filter("EQUNR", sap.ui.model.FilterOperator.EQ, sEquipmentNumber));
            }
            if (sEntryListNumber) {
                aFilters.push(new sap.ui.model.Filter("MELNR", sap.ui.model.FilterOperator.EQ, sEntryListNumber));
            }
            if (sNotificationType) {
                aFilters.push(new sap.ui.model.Filter("ATWRT", sap.ui.model.FilterOperator.EQ, sNotificationType));
            }
            if (sFuncLocationNumber || sEntryListNumber) {
                switch (sOption) {
                    case "RB-1": // Liste
                        aFilters.push(new sap.ui.model.Filter("LIST", sap.ui.model.FilterOperator.EQ, "X"));
                        break;
                    case "RB-2": // Hiérarchie descendante
                        aFilters.push(new sap.ui.model.Filter("HIERARCHY", sap.ui.model.FilterOperator.EQ, "X"));
                        break;
                    case "RB-3": // Sans hiérarchie
                        aFilters.push(new sap.ui.model.Filter("HIERARCHY", sap.ui.model.FilterOperator.EQ, ""));
                        break;
                    default:
                }
            }

            this._filters = aFilters;
            if (oSmartTable.getBindingInfo("items") && oSmartTable.getBindingInfo("items").template) {
                oTemplate = oSmartTable.getBindingInfo("items").template;
            } else {
                oTemplate = sap.ui.xmlfragment("grtgaz.puma.PointsDeMesures.view.fragments.tableTemplate", this);
            }

            oSmartTable.bindAggregation("items", {
                path: "/MeasurementPointSet",
                //	template: oSmartTable.getBindingInfo("items").template,
                template: oTemplate,
                filters: aFilters,
                sorter: this.oSorter, // GMAO-513
                events: {
                    dataReceived: function() {
                        oSmartTable.setBusy(false);
                    }.bind(this)
                }
            });
        },

        groupHeaderFactory: function(oSorter) {
            return new sap.m.GroupHeaderListItem({
                title: oSorter.text
            });
        },

        _GroupMeasurePoint: function(oContext) {
            return {
                key: oContext.getProperty("TPLNR"),
                text: oContext.getProperty("PLTXT")
            };
        },

        /**
        * Recupère les filtres et les tris
        * 
        * @param {sap.ui.base.Event} oEvent 
        * 
        * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
        * LISTE DE MODIFICATIONS
        * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
        * Ticket : GMAO-513
        * Par : Alexandre PISSOTTE (APY)
        * Date : 17/01/2022
        * Motif : Tri de la table des points de mesure
        * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
        */
        onBeforeRebindTable: function(oEvent) {
            if (this._filters) {
                oEvent.getParameter("bindingParams").filters = this._filters;
            }

            if (!this.oSorter && oEvent.getParameter("bindingParams").sorter.length == 0) {
                // Sorter par défaut
                this.oSorter = new sap.ui.model.Sorter("TPLNR", null, this._GroupMeasurePoint.bind(this));
            } else {
                // Sorter sélectionné
                this.oSorter = oEvent.getParameter("bindingParams").sorter;
            }
        },

        _handleLiveChange: function(oEvent) {
            var oControl = oEvent.getSource(),
                oObjectContext = oControl.getBindingContext().getObject(),
                nMeasurementValue = oEvent.getParameter("value"),
                aLineCells = oControl.getParent().getAggregation("cells"),
                oGapControl;
            //fetch the gap text control
            for (var el in aLineCells) {
                if (aLineCells[el].getName && aLineCells[el].getName() === "Difference") {
                    oGapControl = aLineCells[el];
                }
            }

            if (!nMeasurementValue) {
                oControl.setValueState("None");
                oGapControl.setText("");
            }
        },

        _handleValueChange: function(oEvent) {
            var oControl = oEvent.getSource(),
                oObjectContext = oEvent.getSource().getBindingContext().getObject(),
                nTheoreticalValue = Number(oObjectContext.DESIR),
                nMeasurementValue = oEvent.getParameter("value").replace(",", "."),
                aLineCells = oEvent.getSource().getParent().getAggregation("cells"),
                nEcart = 0,
                oGapControl,
                nMinValue = Number(oObjectContext.MRMIN),
                nMaxValue = Number(oObjectContext.MRMAX);

            //fetch the gap text control
            for (var el in aLineCells) {
                if (aLineCells[el].getName && aLineCells[el].getName() === "Difference") {
                    oGapControl = aLineCells[el];
                }
            }

            // case the ipnut value is empty&nbsp;
            if (nMeasurementValue === "") {
                oControl.setValueState("None");
                oGapControl.setText("");
                return;
            }

            //case theoretical value equal 0 no gap calculation
            if (nTheoreticalValue === 0 || ((oObjectContext.MRMIN === '') && (oObjectContext.MRMAX === ''))) {
                return;
            }

            //case of range exceed&nbsp;&nbsp;
            if (nMeasurementValue > nMaxValue && (oObjectContext.MRMAX !== '')) {
                //calculate and assign gap to input&nbsp;
                nEcart = this._calculateGap(nMeasurementValue, nTheoreticalValue, true).toFixed(2) + "%";
                oGapControl.setText(nEcart);
                //modify input state parameters
                this._setInputValueState(oControl, "Error", "rateNotRespected");
                //create order
                this._navigateToCreateOrderApp(oObjectContext, true);
            } else if (nMeasurementValue < nMinValue && (oObjectContext.MRMIN !== '')) {
                //calculate and assign gap to input&nbsp;
                nEcart = this._calculateGap(nMeasurementValue, nTheoreticalValue, false).toFixed(2) + "%";
                oGapControl.setText(nEcart);
                //modify input state parameters
                this._setInputValueState(oControl, "Error", "rateNotRespected");
                //create order
                this._navigateToCreateOrderApp(oObjectContext, true);
            } else {
                //initialize gap value&nbsp;
                oGapControl.setText("");
                //initialize input state parameters
                this._setInputValueState(oControl, "None", "");
            }
        },

        _calculateGap: function(nValue, NThValue, bIsG) {
            var nResult;
            if (bIsG) {
                nResult = ((nValue - NThValue) / NThValue) * 100;
            } else {
                nResult = ((NThValue - nValue) / NThValue) * 100;
            }
            return nResult;
        },

        _setInputValueState: function(oControl, sValueState, sValueStateText) {
            var oRessourceBundle = this.getView().getModel("i18n").getResourceBundle();
            oControl.setValueState(sValueState);
            oControl.setValueStateText(oRessourceBundle.getText(sValueStateText));
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        _catchStartupParameters: function() {
            var oComponentData = this.getOwnerComponent().getComponentData(),
                oModel = this.getView().getModel("measurementPoint"),
                bIsmandatoryFilled = false;
            this._hasStartupParameters = false;

            if (oComponentData) {
                var oStartupParams = oComponentData.startupParameters;

                if (oStartupParams.AUFNR) {
                    oModel.setProperty("/AUFNR", oStartupParams.AUFNR[0]);
                    bIsmandatoryFilled = true;
                }

                if (oStartupParams.KTEXT && oStartupParams.KTEXT[0]) {
                    oModel.setProperty("/KTEXT", decodeURIComponent(oStartupParams.KTEXT[0]));
                }

                if (oStartupParams.QMNUM) {
                    oModel.setProperty("/QMNUM", oStartupParams.QMNUM[0]);
                    bIsmandatoryFilled = true;
                }

                if (oStartupParams.QMTXT && oStartupParams.QMTXT[0]) {
                    oModel.setProperty("/QMTXT", decodeURIComponent(oStartupParams.QMTXT[0]));
                }

                if (oStartupParams.QMART && oStartupParams.QMART[0]) {
                    oModel.setProperty("/ATWRT", decodeURIComponent(oStartupParams.QMART[0]));
                }

                if (oStartupParams.TPLNR && oStartupParams.TPLNR[0]) {
                    oModel.setProperty("/TPLNR", oStartupParams.TPLNR[0]);
                    bIsmandatoryFilled = true;
                }
                if (oStartupParams.PLTXT && oStartupParams.PLTXT[0]) {
                    oModel.setProperty("/PLTXT", decodeURIComponent(oStartupParams.PLTXT[0]));
                }

                if (oStartupParams.EQUNR && oStartupParams.EQUNR[0]) {
                    oModel.setProperty("/EQUNR", oStartupParams.EQUNR[0]);
                    bIsmandatoryFilled = true;

                }
                if (oStartupParams.EQKTX && oStartupParams.EQKTX[0]) {
                    oModel.setProperty("/EQKTX", decodeURIComponent(oStartupParams.EQKTX[0]));
                }
            }

            if (bIsmandatoryFilled) {
                this._setInputStateToError(true);

                this.onSearchMeasurmentPointFilter();

            }
        },
        onPressCreateOrderButton: function() {
            /********************************* GMAO-340 ***************************/
            this.CheckUnsavedData(false, false, true);
			/*
            // Récupération du point de mesure sélectionné
            var oItem = this.getView().byId("measure-point-table").getTable().getSelectedItem();

            if (oItem) {
                var oObject = oItem.getBindingContext().getObject();
                // Navigation vers l'application de création des ordres
                this._navigateToCreateOrderApp(oObject, false);
            }
            */
            /***********************************End GMAO-340*************************** */
        },

        _navigateToCreateOrderApp: function(oObject, bIsOver) {
            var oRessourceBundle = this.getView().getModel("i18n").getResourceBundle(),
                sPopUpTitle = oRessourceBundle.getText("createCorOrder"),
                sPopUpMessage = oRessourceBundle.getText("wouldYouCreateCorOrder"),
                oIcon = sap.m.MessageBox.Icon.INFORMATION,
                oData = {
                    "ILART": "COR",
                    "ILART_TXT": "CORRECTIF",
                    "TPLNR": oObject.TPLNR,
                    "VAPLZ": "",
                    "WAWRK": "",
                    "EQUNR": oObject.EQUNR,
                    "EQKTX": "",
                    "PLTXT": oObject.PLTXT

                };

            this.oObject = oData;

            if (bIsOver) {
                sPopUpMessage = oRessourceBundle.getText("overValueMessage");
                oIcon = sap.m.MessageBox.Icon.ERROR;
            }

            sap.m.MessageBox.show(sPopUpMessage, {
                title: sPopUpTitle,
                icon: oIcon,
                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                onClose: this._handleMessageBoxButtonPress.bind(this)
            });

        },

        _handleMessageBoxButtonPress: function(oAction) {
            if (oAction === sap.m.MessageBox.Action.YES) {
                this.bNavigate = true;
                this.onPressSaveButton();
            }
        },

        _PrepareDataForNavigation: function() {
            var oCreationModel = this.getModel("CreationSearchModel"),
                aFilters = [],
                sFUnctionalLocation = this.oObject.TPLNR,
                sEquipement = this.oObject.EQUNR,
                sPath = "/FunctionalLocationSet",
                bIsCompleted = false;

            if (sFUnctionalLocation) {
                aFilters.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, sFUnctionalLocation));
                bIsCompleted = true;
            }

            if (sEquipement && !bIsCompleted) {
                aFilters.push(new sap.ui.model.Filter("EQUNR", sap.ui.model.FilterOperator.EQ, sEquipement));
                sPath = "/EquipementSet";
                bIsCompleted = true;
            }

            if (!bIsCompleted) {
                this._NavigateToCreationOrderTile(this.oObject);
            }

            oCreationModel.read(sPath, {
                filters: aFilters,
                success: this._handleReadSuccess.bind(this),
                error: this._handleReadError.bind(this)
            });

        },

        _handleReadSuccess: function(oData, Oresponse) {

            if (oData && oData.results[0]) {
                if (oData.results[0].TPLNR) {
                    this.oObject.TPLNR = oData.results[0].TPLNR;
                    this.oObject.PLTXT = oData.results[0].PLTXT;
                }
                if (oData.results[0].EQUNR) {
                    this.oObject.EQUNR = oData.results[0].EQUNR;
                    this.oObject.EQKTX = oData.results[0].EQKTX;
                }
                if (oData.results[0].ARBPL) {
                    this.oObject.VAPLZ = oData.results[0].ARBPL;
                }
                if (oData.results[0].WERKS) {
                    this.oObject.WAWRK = oData.results[0].WERKS;
                }
            }
            this._NavigateToCreationOrderTile(this.oObject);

        },

        _handleReadError: function(oError) {
            var sMessage = this.getModel("i18n").getResourceBundle().getText("NoDataForTechObject");
            sap.m.MessageToast.show(sMessage);
            this._NavigateToCreationOrderTile(this.oObject);

        },

        _NavigateToCreationOrderTile: function(oData) {
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZCreation_OT",
                        action: "display"
                    },
                    params: {
                        "ILART": "COR",
                        "ILART_TXT": "CORRECTIF",
                        "TPLNR": oData.TPLNR,
                        "VAPLZ": oData.VAPLZ,
                        "WAWRK": oData.WAWRK,
                        "EQUNR": oData.EQUNR,
                        "EQKTX": oData.EQKTX,
                        "PLTXT": oData.PLTXT
                    }

                })) || ""; // generate the Hash to display the order creation app 	
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            });

        },

        _getSpecificCell: function(aCells, sName) {
            var oControl;
            for (var el in aCells) {

                if (aCells[el].getName && aCells[el].getName() === sName) {
                    oControl = aCells[el];
                }

            }
            return oControl;
        },
        _getDateTime: function(aCells) {
            var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "YYYYMMdd"
            }),
                sDate = dateFormatter.format(this._getSpecificCell(aCells, "selectedDate").getDateValue()),
                stime = this._getSpecificCell(aCells, "selectedTime").getValue(),
                sFormattedTime = stime.substring(0, 2) + stime.substring(3, 5) + stime.substring(6, 8);
            return [sDate, sFormattedTime];
        },
        isEquivalent: function(a, b) {

            // Create arrays of property names
            var aProps = Object.getOwnPropertyNames(a);
            var bProps = Object.getOwnPropertyNames(b);

            for (var i = 0; i < aProps.length; i++) {
                var propName = aProps[i];

                if (propName === "ITIME") {
                    b[propName] = b[propName].substring(0, 2) + b[propName].substring(3, 5) + b[propName].substring(6, 8);
                }
                if (propName === "IDATE") {
                    a[propName] = a[propName].substring(6, 8) + "." +
                        a[propName].substring(4, 6) + "." + a[propName].substring(0, 4);
                }

                if (propName === "RECDC") {
                    a[propName] = parseFloat(a[propName]).toFixed(2);
                    b[propName] = parseFloat(b["READG"]).toFixed(2);
                }

                // If values of same property are not equal,
                // objects are not equivalent
                if (a[propName] !== b[propName]) {
                    return false;
                }
            }

            // If we made it this far, objects
            // are considered equivalent
            return true;

        },

        onPressSaveButton: function(oEvent) {
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            /*
            TICKET JIRA GMAO-221
            Il est impossible de créer un ordre correctif s'il n'y a pas de saisie de point de mesure.
            Désormais, si l'utilisateur clique sur une ligne de point de mesure sans effectuer de saisie,
            l'utilisateur sera redirigé faire l'application de création des ordres.
            Liste des modifications :
            - Vérifie s'il existe une saisie de point de mesure ou non
            Fait le  : 10/02/2021
            Fait par : Alexandre PISSOTTE (APY)
            */
            var hasToSubmitChanges = false; // GMAO-221 Alexandre PISSOTTE (APY) (1)

            var oTable = this.getView().byId("measure-point-table").getTable(),
                oResourceBundle = this.getModel("i18n").getResourceBundle(),
                items = oTable.getAggregation("items"),
                aContexts = items.map(function(item) {
                    return item.getBindingContext();
                }),
                oModel = this.getView().getModel(),
                sNotificationNumber = this.getModel("measurementPoint").getProperty("/QMNUM");
            this.messages = [];

            for (var i = 0; i < items.length; i++) {
                if (items[i].getMetadata().getName() === "sap.m.GroupHeaderListItem") {
                    continue;
                }
                var aCells = items[i].getCells(),
                    nMesureValue = this._getSpecificCell(aCells, "measureValue").getValue(),
                    oContextObject = items[i].getBindingContext().getObject(),
                    oErrorText = oResourceBundle.getText("timeErrorTextSave") + " " + oContextObject.POINT + " n'est pas valide.",
                    oTimePicker = this._getSpecificCell(aCells, "selectedTime"),
                    oDatePicker = this._getSpecificCell(aCells, "selectedDate"),
                    oChangedObject = {};

                if (nMesureValue === "") {
                    continue;
                }
                if (oTimePicker.getValueState() === "Error" || oDatePicker.getValueState() === "Error") {
                    sap.m.MessageBox.error(oErrorText);
                    return;
                }

                if (!sNotificationNumber || sNotificationNumber === "") {
                    sNotificationNumber = oContextObject.QMNUM;
                }

                oChangedObject = {
                    MDOCM: sNotificationNumber,
                    POINT: oContextObject.POINT,
                    MRNGU: oContextObject.MRNGU,
                    ITIME: this._getDateTime(aCells)[1],
                    IDATE: this._getDateTime(aCells)[0],
                    RECDC: nMesureValue.replace(".", ",")
                };

                if (!this.isEquivalent(oChangedObject, oContextObject)) {
                    hasToSubmitChanges = true; // GMAO-221 Alexandre PISSOTTE (APY) (2)

                    oModel.create("/MeasurementDocumentSet", oChangedObject, {
                        success: this._handleCreateSuccess.bind(this),
                        groupId: "inputModelGroup"
                    });
                }
            }
            oModel.setDeferredGroups(["inputModelGroup"]);

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-221 (3)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if (hasToSubmitChanges) {
                oModel.submitChanges({
                    groupId: "inputModelGroup",
                    success: this._handleSubmitChangeSuccess.bind(this)
                });
            } else {
                this._handleSubmitChangeSuccess();
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-221 (3)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        },
        _handleCreateSuccess: function(oData, oResponse) {
            var oMessage = $.parseJSON(oResponse.headers["sap-message"]);
            if (oMessage) {
                this.messages.push(oMessage);
            }
            if (this.dialog) {
                this.dialog.destroy();
            }
            this._constructDialogMessage(this.messages);

            this.bSaved = true; // GMAO-340
            this.getView().byId("smartFilterBar").fireSearch();
        },

        _handleSubmitChangeSuccess: function(oData, oResponse) {
            if (this.bNavigate) {
                this._PrepareDataForNavigation();
                this.bNavigate = false;
                return;
            }
        },
        _constructDialogMessage: function(aMessages) {
            var oRessourceModel = this.getView().getModel("i18n").getResourceBundle();
            var that = this;
            this.dialog = new sap.m.Dialog({
                title: "création des documents de mesures",
                type: 'Message',
                beginButton: new sap.m.Button({
                    text: 'OK',
                    press: function() {
                        that.dialog.close();
                    }
                }),
                afterClose: function() {
                    that.dialog.destroy();
                }
            });
            var verticallayout = new sap.ui.layout.VerticalLayout();
            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
            for (var i = 0; i < aMessages.length; i++) {
                var sMessageLine = "\u2022" + this.messages[i].message + "\n",
                    oTextControl = new sap.m.Text({
                        text: sMessageLine
                    });
                verticallayout.addContent(oTextControl);
                verticallayout.addContent(new sap.ui.layout.VerticalLayout());
            }
            this.dialog.addContent(verticallayout);
            this.dialog.open();
        },
        // _constructDialogMessage: function (aMessages) {
        //     var oRessourceModel = this.getView().getModel("i18n").getResourceBundle();
        //     var dialog = new sap.m.Dialog({
        //         title: "création des documents de mesures",
        //         type: 'Message',
        //         beginButton: new sap.m.Button({
        //             text: 'OK',
        //             press: function () {
        //                 dialog.close();
        //             }
        //         }),
        //         afterClose: function () {
        //             dialog.destroy();
        //         }
        //     });
        //     var verticallayout = new sap.ui.layout.VerticalLayout();
        //     verticallayout.addContent(new sap.ui.layout.VerticalLayout());
        //     for (var i = 0; i < aMessages.length; i++) {
        //         var sMessageLine = "\u2022" + this.messages[i].message + "\n",
        //             oTextControl = new sap.m.Text({
        //                 text: sMessageLine
        //             });
        //         verticallayout.addContent(oTextControl);
        //         verticallayout.addContent(new sap.ui.layout.VerticalLayout());
        //     }
        //     dialog.addContent(verticallayout);
        //     dialog.open();
        // },
        /*------------GMAO-248---------------------*/
        onHandleChange: function(oEvent) {
            var oValue = oEvent.getParameter("newValue"),
                bValid = oEvent.getParameter("valid"),
                oTimePicker = oEvent.getSource(),
                oResourceBundle = this.getModel("i18n").getResourceBundle(),
                oErrorText = oResourceBundle.getText("timeErrorText"),
                sMessage = "",
                sState = "None";

            if (!oValue || !bValid) {
                sMessage = oErrorText;
                sState = "Error";
            }
            oTimePicker.setValueState(sState);
            oTimePicker.setValueStateText(sMessage);
        },

        /*--------------------------- GMAO-248-------------------*/
        /*--------------------------- GMAO-340------------------ */
        /***************************************GMAO 340 *******************************************
         *************************************** Done By Hajer Cheikhrouhou on 30/08/2021 
         */
        SearchMeasurmentPointFilter: function() {
            var aProperties = ["/QMNUM", "/AUFNR", "/TPLNR", "/EQUNR", "/MELNR", "/ATWRT"], // GMAO-226 Alexandre PISSOTTE (APY)
                aFilters = [],
                oTemplate,
                oModel = this.getView().getModel("measurementPoint"),
                oSmartTable = this.getView().byId("measure-point-table").getTable(),
                sNotificationNumber = oModel.getProperty("/QMNUM"),
                sOrderNumber = oModel.getProperty("/AUFNR"), // GMAO-226 Alexandre PISSOTTE (APY)
                sFuncLocationNumber = oModel.getProperty("/TPLNR"),
                sEquipmentNumber = oModel.getProperty("/EQUNR"),
                sEntryListNumber = oModel.getProperty("/MELNR"),
                sNotificationType = oModel.getProperty("/ATWRT");

            if (this.getView().byId("hiearchy-options").getSelectedItem() != null) {
                var sOption = this.getView().byId("hiearchy-options").getSelectedItem().getKey();
            }

            // Si l'utilisateur n'a rien saisi
            if (!sNotificationNumber && !sFuncLocationNumber && !sEquipmentNumber && !sEntryListNumber && !sOrderNumber) { // GMAO-226 Alexandre PISSOTTE (APY)
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("noFiltersSearch"));
                return;
            }
            if (sNotificationNumber) {
                aFilters.push(new sap.ui.model.Filter("QMNUM", sap.ui.model.FilterOperator.EQ, sNotificationNumber));
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // DEBUT MODIFICATION GMAO-226 (6)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if (sOrderNumber) {
                aFilters.push(new sap.ui.model.Filter("AUFNR", sap.ui.model.FilterOperator.EQ, sOrderNumber));
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            // FIN MODIFICATION GMAO-226 (6)
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if (sFuncLocationNumber) {
                aFilters.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, sFuncLocationNumber));
            }
            if (sEquipmentNumber) {
                aFilters.push(new sap.ui.model.Filter("EQUNR", sap.ui.model.FilterOperator.EQ, sEquipmentNumber));
            }
            if (sEntryListNumber) {
                aFilters.push(new sap.ui.model.Filter("MELNR", sap.ui.model.FilterOperator.EQ, sEntryListNumber));
            }
            if (sNotificationType) {
                aFilters.push(new sap.ui.model.Filter("ATWRT", sap.ui.model.FilterOperator.EQ, sNotificationType));
            }
            if (sFuncLocationNumber || sEntryListNumber) {
                switch (sOption) {
                    case "RB-1": // Liste
                        aFilters.push(new sap.ui.model.Filter("LIST", sap.ui.model.FilterOperator.EQ, "X"));
                        break;
                    case "RB-2": // Hiérarchie descendante
                        aFilters.push(new sap.ui.model.Filter("HIERARCHY", sap.ui.model.FilterOperator.EQ, "X"));
                        break;
                    case "RB-3": // Sans hiérarchie
                        aFilters.push(new sap.ui.model.Filter("HIERARCHY", sap.ui.model.FilterOperator.EQ, ""));
                        break;
                    default:
                }
            }

            this._filters = aFilters;
            if (oSmartTable.getBindingInfo("items") && oSmartTable.getBindingInfo("items").template) {
                oTemplate = oSmartTable.getBindingInfo("items").template;
            } else {
                oTemplate = sap.ui.xmlfragment("pm-SaisieDesPointsDeMesure.view.fragments.tableTemplate", this);
            }

            oSmartTable.bindAggregation("items", {
                path: "/MeasurementPointSet",
                //	template: oSmartTable.getBindingInfo("items").template,
                template: oTemplate,
                filters: aFilters,
                sorter: this.oSorter,
                    events: {
                dataReceived: function() {
                    oSmartTable.setBusy(false);
                }.bind(this)
            }
            });
},

    CheckUnsavedData: function(bNavBack, bSearch, bOrderCreate) {
        var bUnsaved = false;
        var oTable = this.getView().byId("measure-point-table").getTable(),
            oResourceBundle = this.getModel("i18n").getResourceBundle();
        var sPopUpMessage = oResourceBundle.getText("UnsavedData");
        var sTitle = oResourceBundle.getText("UnsavedDataTitle");
        var oIcon = sap.m.MessageBox.Icon.QUESTION;
        var items = oTable.getAggregation("items");
        var oModel = this.getView().getModel(),
            sNotificationNumber = this.getModel("measurementPoint").getProperty("/QMNUM");
        this.messages = [];
        if (items) {
            for (var i = 0; i < items.length; i++) {
                if (items[i].getMetadata().getName() === "sap.m.GroupHeaderListItem") {
                    continue;
                }
                var aCells = items[i].getCells(),
                    nMesureValue = this._getSpecificCell(aCells, "measureValue").getValue();

                if (nMesureValue !== "") {
                    bUnsaved = true;
                }
            }
        }
        if (bUnsaved) {
            var oDest = {};
            oDest.bNavBack = bNavBack;
            oDest.bSearch = bSearch;
            oDest.bOrderCreate = bOrderCreate;
            this.Dest = oDest;
            sap.m.MessageBox.show(sPopUpMessage, {
                title: sTitle,
                icon: oIcon,
                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                onClose: this._handleMessagesave.bind(this)
            });
        }

        else {
            if (bNavBack) {
                this._NavBack();
            }
            if (bOrderCreate) {
                this._PressCreateOrderButton();
            }
            if (bSearch) {
                this.SearchMeasurmentPointFilter();
            }


        }
    },



    _handleMessagesave: function(oAction) {
        if (oAction === sap.m.MessageBox.Action.CANCEL) {
            return;
        }

        if (this.Dest.bNavBack) {
            this._NavBack();
        }
        if (this.Dest.bOrderCreate) {
            this._PressCreateOrderButton();
        }
        if (this.Dest.bSearch) {
            this.SearchMeasurmentPointFilter();
        }
    },
    _NavBack: function() {
        this.bNavigate = false;
        var sPreviousHash = History.getInstance().getPreviousHash(),
            oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

        if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
            history.go(-1);
        } else {
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: "#Shell-home"
                }
            });
        }
    },
    _PressCreateOrderButton: function() {
        // Récupération du point de mesure sélectionné
        var oItem = this.getView().byId("measure-point-table").getTable().getSelectedItem();

        if (oItem) {
            var oObject = oItem.getBindingContext().getObject();
            // Navigation vers l'application de création des ordres
            this._navigateToCreateOrderApp(oObject, false);

        }
    }
        /*--------------------------- END GMAO-340------------------  */
    });
});
sap.ui.define([
    "sap/ui/base/Object",
    "../control/TextWithName",
    "../model/formatter",
    "../model/models",
    "./Utility"
], function (oObject, TextWithName, formatter, Model, Utility) {
    "use strict";

    return oObject.extend("grtgaz.puma.PointsDeMesures.controller.DialogSimoneMeasurementPoint", {
        open: function (oController, oBindingContext) {
            var oFragment = this._getFragment(oController, oBindingContext);
            oFragment.open();
        },

        destroy: function () {
            if (this._oFragment) {
                this._oFragment.destroy();
            }
        },

        _getFragment: function (oController, oBindingContext) {
            this._oView = oController.getView();
            this._oController = oController;
            this.bNavigate = false;

            // Création du fragment de façon lazy
            if (!this._oFragment) {
                //Création du fragment
                this._oFragment = sap.ui.xmlfragment(this._getId(),
                    "grtgaz.puma.PointsDeMesures.view.fragments.DialogSimonMeasurementPoint", this);

                Utility.handleDependent(this);
            }

            // Configuration du sap.m.Dialog
            var oDialog = sap.ui.core.Fragment.byId(this._getId(), "SimonDialog");
            oDialog.bindElement({
                path: oBindingContext.getPath()
            });
            var oModel = new sap.ui.model.json.JSONModel({
                "createOrdre": true
            });
            this._oFragment.setModel(oModel, "ofragmentModel");
            // Configuration du sap.m.Table
            var oData = [];
            oData.push({
                MDOCM: "", // Document de mesure
                POINT: "", // Numéro du point de mesure
                MRNGU: "", // Unité
                IDATE: new Date(new Date().getTime() - 10 * 60000), // Date de mesure
                ITIME: new Date(new Date().getTime() - 10 * 60000), // Heure de mesure
                RECDC: "", // Valeur de mesure
                MRMIN: "", // Valeur minimale
                MRMAX: "" // Valeur maximale
            });


            oModel.setData(oData);
            oDialog.setModel(oModel, "oSimoneModel");

            var that = this;
            var oTable = sap.ui.core.Fragment.byId(this._getId(), "SimonInputTable");
            oTable.bindAggregation("items", {
                path: "/",
                model: "oSimoneModel",
                factory: function (sId, oContext) {
                    return new sap.m.ColumnListItem({
                        type: "Inactive",
                        cells: [
                            // Valeur de saisie du point de mesure + Unité de saisie
                            new sap.m.Input({
                                name: "measureValue",
                                maxLength: 22,
                                type: sap.m.InputType.Number,
                                submit: [that._handleValueChange, that],
                                change: [that._handleValueChange, that],
                                liveChange: [that._handleLiveChange, that]
                            }),
                            new sap.m.Input({
                                name: "measureValue",
                                maxLength: 22,
                                type: sap.m.InputType.Number,
                                submit: [that._handleValueChange, that],
                                change: [that._handleValueChange, that],
                                liveChange: [that._handleLiveChange, that]
                            }),


                            // Date de saisie
                            new sap.m.DatePicker({
                                name: "selectedDate",
                                dateValue: new Date(),
                                change: [that._onHandleChange, that],
                                valueFormat: "dd.MM.yyyy",
                                displayFormat: "dd.MM.yyyy"
                            }),
                            // Heure de saisie
                            new sap.m.TimePicker({
                                name: "selectedTime",
                                dateValue: new Date(),
                                change: [that._onHandleChange, that],
                                valueFormat: "HH:mm:ss",
                                displayFormat: "HH:mm:ss"
                            }),
                            // Text pour l'écart de mesure
                            new TextWithName({
                                name: "Difference"
                            })

                        ]
                    });
                }
            });

            return this._oFragment;
        },

        _getId: function () {
            if (!this._id) {
                this._id = "MULTIPLE_INPUT_MEA_PNT_FRAG";
            }
            return this._id;
        },

        onCancel: function () {
            this._oFragment.close();
        },
        _onHandleChange: function (oEvent) {
            var oValue = oEvent.getParameter("newValue"),
                bValid = oEvent.getParameter("valid"),
                oTimePicker = oEvent.getSource(),
                oResourceBundle = this._oFragment.getModel("i18n").getResourceBundle(),
                oErrorText = oResourceBundle.getText("timeErrorText"),
                sMessage = "",
                sState = "None";

            if (!oValue || !bValid) {
                sMessage = oErrorText;
                sState = "Error";
            }
            oTimePicker.setValueState(sState);
            oTimePicker.setValueStateText(sMessage);
        },
        _handleLiveChange: function (oEvent) {
            var oControl = oEvent.getSource(),
                nMeasurementValue = oEvent.getParameter("value"),
                aLineCells = oControl.getParent().getAggregation("cells"),
                oGapControl;
            //fetch the gap text control
            for (var el in aLineCells) {

                if (aLineCells[el].getName && aLineCells[el].getName() === "Difference") {
                    oGapControl = aLineCells[el];
                }

            }
            if (!nMeasurementValue) {
                oControl.setValueState("None");
                oGapControl.setText("");
            }
        },
        _handleValueChange: function (oEvent) {
            var oControl = oEvent.getSource(),
                sBindingPath = oControl.getParent().getBindingContextPath(),
                oObjectContext = oEvent.getSource().getBindingContext().getObject(),
                nTheoreticalValue = Number(oObjectContext.DESIR),
                nMeasurementValue = oEvent.getParameter("value").replace(",", "."),
                aLineCells = oEvent.getSource().getParent().getAggregation("cells"),
                nEcart = 0,
                oGapControl,
                nMinValue = Number(oObjectContext.MRMIN),
                nMaxValue = Number(oObjectContext.MRMAX);
            var nValueEtalonee = aLineCells[0].getValue();
            var nValueRelevee = aLineCells[1].getValue();

            if (nValueEtalonee === "" || nValueRelevee === "" || nValueEtalonee === "0") {
                return;
            }

            var nErreur = (nValueRelevee - nValueEtalonee) / nValueEtalonee * 100;
            aLineCells[4].setText(nErreur + " %");
            this._navigateToCreateOrderApp(oObjectContext, true);

        },
        _navigateToCreateOrderApp: function (oObject, bIsOver) {
            var oRessourceBundle = this._oFragment.getModel("i18n").getResourceBundle(),
                sPopUpTitle = oRessourceBundle.getText("createCorOrder"),
                sPopUpMessage = oRessourceBundle.getText("wouldYouCreateCorOrder"),
                oIcon = sap.m.MessageBox.Icon.INFORMATION,

                oData = {
                    "ILART": "COR",
                    "ILART_TXT": "CORRECTIF",
                    "TPLNR": oObject.TPLNR,
                    "VAPLZ": "",
                    "WAWRK": "",
                    "EQUNR": oObject.EQUNR,
                    "EQKTX": "",
                    "PLTXT": oObject.PLTXT

                };

            this.oObject = oData;

        },
        _handleMessageBoxButtonPress: function (oAction) {
            if (oAction === sap.m.MessageBox.Action.YES) {
                this.bNavigate = true;
                this.save();
            }

        },


        _getSpecificCell: function (aCells, sName) {
            var oControl;
            for (var el in aCells) {

                if (aCells[el].getName && aCells[el].getName() === sName) {
                    oControl = aCells[el];
                }

            }
            return oControl;
        },
        _getDateTime: function (aCells) {
            var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "YYYYMMdd"
            }),
                sDate = dateFormatter.format(this._getSpecificCell(aCells, "selectedDate").getDateValue()),
                stime = this._getSpecificCell(aCells, "selectedTime").getValue(),
                sFormattedTime = stime.substring(0, 2) + stime.substring(3, 5) + stime.substring(6, 8);
            return [sDate, sFormattedTime];
        },
        isEquivalent: function (a, b) {

            // Create arrays of property names
            var aProps = Object.getOwnPropertyNames(a);
            var bProps = Object.getOwnPropertyNames(b);

            for (var i = 0; i < aProps.length; i++) {
                var propName = aProps[i];

                if (propName === "ITIME") {
                    b[propName] = b[propName].substring(0, 2) + b[propName].substring(3, 5) + b[propName].substring(6, 8);
                }
                if (propName === "IDATE") {
                    a[propName] = a[propName].substring(6, 8) + "." +
                        a[propName].substring(4, 6) + "." + a[propName].substring(0, 4);
                }

                if (propName === "RECDC") {
                    a[propName] = parseFloat(a[propName]).toFixed(2);
                    b[propName] = parseFloat(b["READG"]).toFixed(2);
                }

                // If values of same property are not equal,
                // objects are not equivalent
                if (a[propName] !== b[propName]) {
                    return false;
                }
            }

            // If we made it this far, objects
            // are considered equivalent
            return true;

        },

        onPressSave: function () {
            // Récupération de la table
            var nErreur;
            var oTable = sap.ui.core.Fragment.byId(this._getId(), "SimonInputTable"),
                oResourceBundle = this._oView.getModel("i18n").getResourceBundle(),
                // Récupération des items de la table
                aItems = oTable.getItems(),
                oModel = this._oFragment.getModel();
            this.messages = [];

            // calculate the error hajer
            var nValueEtalonee = aItems[0].getCells()[0].getValue();
            var nValueRelevee = aItems[0].getCells()[1].getValue();

            if (!nValueEtalonee || !nValueRelevee || Number (nValueEtalonee) === 0) {
                sap.m.MessageBox.error(oResourceBundle.getText("noValEtNoValRe"));
                return;
            }

            if (nValueEtalonee !== "" && nValueRelevee !== "" && nValueEtalonee !== "0") {
                nErreur = (nValueRelevee - nValueEtalonee) / nValueEtalonee * 100;
            }

            if (nErreur > 1) {

                var oRessourceBundle = this._oFragment.getModel("i18n").getResourceBundle(),
                    sPopUpTitle = oRessourceBundle.getText("createCorOrder"),
                    sPopUpMessage = oRessourceBundle.getText("wouldYouCreateCorOrder"),
                    oIcon = sap.m.MessageBox.Icon.INFORMATION;
                sPopUpMessage = oRessourceBundle.getText("ErrorCalculé");
                oIcon = sap.m.MessageBox.Icon.ERROR;


                sap.m.MessageBox.show(sPopUpMessage, {
                    title: sPopUpTitle,
                    icon: oIcon,
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: this._handleMessageBoxButtonPress.bind(this)
                });

            }
            else {
                this.save();
            }

        },

        save: function () {
            var oTable = sap.ui.core.Fragment.byId(this._getId(), "SimonInputTable"),
                oResourceBundle = this._oView.getModel("i18n").getResourceBundle(),
                // Récupération des items de la table
                aItems = oTable.getItems(),
                oModel = this._oFragment.getModel();
            this.messages = [];

            // calculate the error 
            var nValueEtalonee = aItems[0].getCells()[0].getValue();
            var nValueRelevee = aItems[0].getCells()[1].getValue();

            if (nValueEtalonee !== "" && nValueRelevee !== "" && nValueEtalonee !== "0") {
                var nErreur = (nValueRelevee - nValueEtalonee) / nValueEtalonee * 100;
            }

            var aCells = aItems[0].getCells(),
                //nMesureValue = this._getSpecificCell(aCells, "measureValue").getValue(),
                oContextObject = this._oFragment.getBindingContext().getObject(),
                oErrorText = oResourceBundle.getText("timeErrorTextSave") + " " + oContextObject.POINT + " n'est pas valide.",
                oTimePicker = this._getSpecificCell(aCells, "selectedTime"),
                oDatePicker = this._getSpecificCell(aCells, "selectedDate"),
                oChangedObject = {};

            if (oTimePicker.getValueState() === "Error" || oDatePicker.getValueState() === "Error") {
                sap.m.MessageBox.error(oErrorText);
                return;
            }

            oChangedObject = {
                MDOCM: oContextObject.MDOCM,
                POINT: oContextObject.POINT,
                MRNGU: oContextObject.MRNGU,
                ITIME: this._getDateTime(aCells)[1],
                IDATE: this._getDateTime(aCells)[0],
                RECDC: nErreur.toString().replace(".", ",")
            };

            if (!this.isEquivalent(oChangedObject, oContextObject)) {

                oModel.create("/MeasurementDocumentSet", oChangedObject, {
                    success: this._handleCreateSuccess.bind(this),
                    groupId: "inputModelGroup"
                });
            }
            oModel.setDeferredGroups(["inputModelGroup"]);

            oModel.submitChanges({
                groupId: "inputModelGroup",
                success: this._handleSubmitChangeSuccess.bind(this)
            });
        },

        _handleCreateSuccess: function (oData, oResponse) {
            var oMessage = $.parseJSON(oResponse.headers["sap-message"]);
            if (oMessage) {
                this.messages.push(oMessage);
            }
        },

        _handleSubmitChangeSuccess: function (oData, oResponse) {
            this._oFragment.close();

            if (this.bNavigate) {
                this._PrepareDataForNavigation();
                this.bNavigate = false;
            }

            if (this.messages.length !== 0) {
                this._constructDialogMessage(this.messages);
            }
            this._oView.byId("measure-point-table").getTable().getBinding("items").refresh();

        },
        _PrepareDataForNavigation: function () {
            var oCreationModel = this._oView.getModel("CreationSearchModel"),
                aFilters = [],
                sFUnctionalLocation = this.oObject.TPLNR,
                sEquipement = this.oObject.EQUNR,
                sPath = "/FunctionalLocationSet",
                bIsCompleted = false;

            if (sFUnctionalLocation) {
                aFilters.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, sFUnctionalLocation));
                bIsCompleted = true;
            }

            if (sEquipement && !bIsCompleted) {
                aFilters.push(new sap.ui.model.Filter("EQUNR", sap.ui.model.FilterOperator.EQ, sEquipement));
                sPath = "/EquipmentSet";
                bIsCompleted = true;
            }

            if (!bIsCompleted) {
                this._NavigateToCreationOrderTile(this.oObject);
            }

            oCreationModel.read(sPath, {
                filters: aFilters,
                success: this._handleReadSuccess.bind(this),
                error: this._handleReadError.bind(this)
            });

        },

        _handleReadSuccess: function (oData, Oresponse) {

            if (oData && oData.results[0]) {
                if (oData.results[0].TPLNR) {
                    this.oObject.TPLNR = oData.results[0].TPLNR;
                    this.oObject.PLTXT = oData.results[0].PLTXT;
                }
                if (oData.results[0].EQUNR) {
                    this.oObject.EQUNR = oData.results[0].EQUNR;
                    this.oObject.EQKTX = oData.results[0].EQKTX;
                }
                if (oData.results[0].ARBPL) {
                    this.oObject.VAPLZ = oData.results[0].ARBPL;
                }
                if (oData.results[0].WERKS) {
                    this.oObject.WAWRK = oData.results[0].WERKS;
                }
            }
            this._NavigateToCreationOrderTile(this.oObject);

        },

        _handleReadError: function (oError) {
            var sMessage = this._oView.getModel("i18n").getResourceBundle().getText("NoDataForTechObject");
            sap.m.MessageToast.show(sMessage);
            this._NavigateToCreationOrderTile(this.oObject);

        },
        _NavigateToCreationOrderTile: function (oData) {
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZCreation_OT",
                        action: "display"
                    },
                    params: {
                        "ILART": "COR",
                        "ILART_TXT": "CORRECTIF",
                        "TPLNR": oData.TPLNR,
                        "VAPLZ": oData.VAPLZ,
                        "WAWRK": oData.WAWRK,
                        "EQUNR": oData.EQUNR,
                        "EQKTX": oData.EQKTX,
                        "PLTXT": oData.PLTXT
                    }

                })) || ""; // generate the Hash to display the order creation app 	
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            });

        },

        _constructDialogMessage: function (aMessages) {
            var oRessourceModel = this._oFragment.getModel("i18n").getResourceBundle();
            var dialog = new sap.m.Dialog({
                title: oRessourceModel.getText("documentCreation"),
                type: 'Message',
                beginButton: new sap.m.Button({
                    text: 'OK',
                    press: function () {
                        dialog.close();
                    }
                }),
                afterClose: function () {
                    dialog.destroy();
                }
            });
            var verticallayout = new sap.ui.layout.VerticalLayout();
            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
            for (var i = 0; i < aMessages.length; i++) {
                var sMessageLine = "\u2022" + this.messages[i].message + "\n",
                    oTextControl = new sap.m.Text({
                        text: sMessageLine
                    });
                verticallayout.addContent(oTextControl);
                verticallayout.addContent(new sap.ui.layout.VerticalLayout());
            }
            dialog.addContent(verticallayout);
            dialog.open();
        },
        formatValue: function (sValue, sUnit) {
            return formatter.formatValue(sValue, sUnit);
        }
    });
});
## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Thu Jun 02 2022 10:10:46 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>@sap/generator-fiori-freestyle|
|**App Generator Version**<br>1.6.1|
|**Generation Platform**<br>SAP Business Application Studio|
|**Floorplan Used**<br>1worklist|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://vpce-0b6044784749c09f5-id8llpzd.vpce-svc-0b1300bed60c69f3d.eu-west-1.vpce.amazonaws.com:44301/sap/opu/odata/sap/ZFIORI_HISTO_IMPUTATIONS_SRV
|**Module Name**<br>zhistorique.imputation|
|**Application Title**<br>Historique Imputation|
|**Namespace**<br>com.grtgaz.puma.fiori|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>1.84.13|
|**Enable Code Assist Libraries**<br>False|
|**Add Eslint configuration**<br>False|
|**Object collection**<br>PosteDeTravailSet|
|**Object collection key**<br>ARBPL|
|**Object ID**<br>ARBPL|
|**Object unit of measure**<br>KTEXT|

## zhistorique.imputation

application de gestion d&#39;historique d&#39;imputation

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)



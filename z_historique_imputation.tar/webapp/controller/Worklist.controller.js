sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator) {
    "use strict";

    return BaseController.extend("com.grtgaz.puma.fiori.zhistorique.imputation.controller.Worklist", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function () {
            var oViewModel,
                iOriginalBusyDelay,
                oTable = this.byId("table");

            // Put down worklist table's original value for busy indicator delay,
            // so it can be restored later on. Busy handling on the table is
            // taken care of by the table itself.
            iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
            this._oTable = oTable;
            // keeps the search state
            this._oTableSearchState = [];

            // Model used to manipulate control states
            oViewModel = new JSONModel({
                worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
                saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
                shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
                shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
                shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
                tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
                tableBusyDelay: 0
            });
            this.setModel(oViewModel, "worklistView");

            // Make sure, busy indication is showing immediately so there is no
            // break after the busy indication for loading the view's meta data is
            // ended (see promise 'oWhenMetadataIsLoaded' in AppController)
            oTable.attachEventOnce("updateFinished", function () {
                // Restore original busy indicator delay for worklist's table
                oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
            });

            //	this.setModel(oModel, "worklistView");

            var tab = this.getView().byId("table").getTable();

            /*Read the selected Date */
            //this.getView().byId("Pick1") ;
            /*get todays date*/
            var sToday = new Date();
            var lundi = new Date();
            var mardi = new Date();
            var mercredi = new Date();
            var jeudi = new Date();
            var vendredi = new Date();
            switch (sToday.getDay()) {
                case (0): //dimanche
                    lundi.setDate(sToday.getDate() + 1);
                    mardi.setDate(sToday.getDate() + 2);
                    mercredi.setDate(sToday.getDate() + 3);
                    jeudi.setDate(sToday.getDate() + 4);
                    vendredi.setDate(sToday.getDate() + 5);
                    break;
                case (1): //lundi
                    lundi = sToday;
                    mardi.setDate(sToday.getDate() + 1);
                    mercredi.setDate(sToday.getDate() + 2);
                    jeudi.setDate(sToday.getDate() + 3);
                    vendredi.setDate(sToday.getDate() + 4);
                    break;
                case (2):
                    lundi.setDate(sToday.getDate() - 1);
                    mardi = sToday;
                    mercredi.setDate(sToday.getDate() + 1);
                    jeudi.setDate(sToday.getDate() + 2);
                    vendredi.setDate(sToday.getDate() + 3);
                    break;
                case (3):
                    lundi.setDate(sToday.getDate() - 2);
                    mardi.setDate(sToday.getDate() - 1);
                    mercredi = sToday;
                    jeudi.setDate(sToday.getDate() + 1);
                    vendredi.setDate(sToday.getDate() + 2);
                    break;
                case (4):
                    lundi.setDate(sToday.getDate() - 3);
                    mardi.setDate(sToday.getDate() - 2);
                    mercredi.setDate(sToday.getDate() - 1);
                    jeudi = sToday;
                    vendredi.setDate(sToday.getDate() + 1);
                    break;
                case (5):
                    lundi.setDate(sToday.getDate() - 4);
                    mardi.setDate(sToday.getDate() - 3);
                    mercredi.setDate(sToday.getDate() - 2);
                    jeudi.setDate(sToday.getDate() - 1);
                    vendredi = sToday;
                    break;
                case (6):
                    lundi.setDate(sToday.getDate() - 5);
                    mardi.setDate(sToday.getDate() - 4);
                    mercredi.setDate(sToday.getDate() - 3);
                    jeudi.setDate(sToday.getDate() - 2);
                    vendredi.setDate(sToday.getDate() - 1);
                    break;
                default:
                    break;
            }
            //*** Set the start and endDate 
            this.getView().StartDate = lundi;
            this.getView().EndDate = vendredi;
            //

            var sDateText = new String;
            var text = this.getView().byId("txt1");

            sDateText = "lundi " + lundi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt2");

            sDateText = "Mardi " + mardi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt3");

            sDateText = "Mercredi " + mercredi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt4");

            sDateText = "Jeudi " + jeudi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt5");

            sDateText = "Vendredi " + vendredi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt0");
            // sDateText = lundi.getMonth() + " " + lundi.getFullYear(); "(-) AAA GMAO 184
            sDateText = " "; //(+) AAA GMAO184
            text.setText(sDateText);

            // set the actuel date by default 
            var oDatePicker = this.getView().byId("Pick1");
            oDatePicker.setDateValue(sToday);

            // Put values in the select 
            var oSelect = this.getView().byId("Select");
            var type = [{
                key: 1,
                Label: 'Ordre de maintenance'
            }];
            oSelect.bindItems('/', new sap.ui.core.ListItem({
                key: '{key}',
                text: '{Label}'
            }));

            var oModel3 = new sap.ui.model.json.JSONModel();
            oModel3.setData(type);
            oSelect.setModel(oModel3);

        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        /**
         * Triggered by the table's 'updateFinished' event: after new table
         * data is available, this handler method updates the table counter.
         * This should only happen if the update was successful, which is
         * why this handler is attached to 'updateFinished' and not to the
         * table's list binding's 'dataReceived' method.
         * @param {sap.ui.base.Event} oEvent the update finished event
         * @public
         */
        onUpdateFinished: function (oEvent) {
            // update the worklist's object counter after the table update
            var sTitle,
                oTable = oEvent.getSource(),
                iTotalItems = oEvent.getParameter("total");
            // only update the counter if the length is final and
            // the table is not empty
            if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
                sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
            } else {
                sTitle = this.getResourceBundle().getText("worklistTableTitle");
            }
            this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
        },

        /**
         * Event handler when a table item gets pressed
         * @param {sap.ui.base.Event} oEvent the table selectionChange event
         * @public
         */
        onPress: function (oEvent) {
            // The source is the list item that got pressed
            this._showObject(oEvent.getSource());
        },

        /**
         * Event handler when the share in JAM button has been clicked
         * @public
         */
        onShareInJamPress: function () {
            var oViewModel = this.getModel("worklistView"),
                oShareDialog = sap.ui.getCore().createComponent({
                    name: "sap.collaboration.components.fiori.sharing.dialog",
                    settings: {
                        object: {
                            id: location.href,
                            share: oViewModel.getProperty("/shareOnJamTitle")
                        }
                    }
                });
            oShareDialog.open();
        },

        onSearch: function (oEvent) {
            if (oEvent.getParameters().refreshButtonPressed) {
                // Search field's 'refresh' button has been pressed.
                // This is visible if you select any master list item.
                // In this case no new search is triggered, we only
                // refresh the list binding.
                this.onRefresh();
            } else {
                var oTableSearchState = [];
                var sQuery = oEvent.getParameter("query");

                if (sQuery && sQuery.length > 0) {
                    oTableSearchState = [new Filter("AUFNR", FilterOperator.Contains, sQuery)];
                }
                this._applySearch(oTableSearchState);
            }

        },

        /**
         * Event handler for refresh event. Keeps filter, sort
         * and group settings and refreshes the list binding.
         * @public
         */
        onRefresh: function () {
            this._oTable.getBinding("items").refresh();
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        /**
         * Shows the selected item on the object page
         * On phones a additional history entry is created
         * @param {sap.m.ObjectListItem} oItem selected Item
         * @private
         */
        _showObject: function (oItem) {
            this.getRouter().navTo("object", {
                objectId: oItem.getBindingContext().getProperty("MANUM")
            });
        },

        /**
         * Internal helper method to apply both filter and search state together on the list binding
         * @param {object} oTableSearchState an array of filters for the search
         * @private
         */
        _applySearch: function (oTableSearchState) {
            var oViewModel = this.getModel("worklistView");
            this._oTable.getBinding("items").filter(oTableSearchState, "Application");
            // changes the noDataText of the list in case there are no filter results
            if (oTableSearchState.length !== 0) {
                oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
            }
        },

        onChangePick: function (oEvent) {

            var tab = this.getView().byId("table").getTable();

            // 		var oJson = [{
            // 	Day0:"Heures à imputer",
            // 	Day1: "8h",
            // 	Day2: "8h",
            // 	Day3: "4h",
            // 	Day4: "8h",
            // 	Day5: "4h", 
            // 	State1:"None",
            // 	State2:"None",
            // 	State3:"None",
            // 	State4:"None",
            // 	State5:"None"
            // }, {
            //   Day0:"Heures imputée",
            // 	Day1: "8h",
            // 	Day2: "6h",
            // 	Day3: "4h",
            // 	Day4: "8h",
            // 	Day5: "0h",
            // 	State1:"None",
            // 	State2:"None",
            // 	State3:"None",
            // 	State4:"None",
            // 	State5:"None"
            // }
            // , {
            // 	Day0:"Ecart",
            // 	Day1: "0h",
            // 	Day2: "2h",
            // 	Day3: "0h",
            // 	Day4: "0h",
            // 	Day5: "8h", 
            // 	State1:"Success",
            // 	State2:"Error",
            // 	State3:"Success",
            // 	State4:"Success",
            // 	State5:"Error"
            // }
            // ]
            // ;
            //	var oModel2= new JSONModel({myItems : oJson}) ;
            //	this.getView().setModel(oModel2);

            //	var col = this.getView().byId("col1");

            /*Read the selected Date */
            //this.getView().byId("Pick1") ;
            /*get todays date*/
            var sToday = this.getView().byId("Pick1").getDateValue();
            var lundi = new Date(sToday);
            var mardi = new Date(sToday); //new Date();
            var mercredi = new Date(sToday); //new Date();
            var jeudi = new Date(sToday); //new Date();
            var vendredi = new Date(sToday); //new Date();
            switch (sToday.getDay()) {
                case (0): //dimanche
                    lundi.setDate(sToday.getDate() + 1);
                    mardi.setDate(sToday.getDate() + 2);
                    mercredi.setDate(sToday.getDate() + 3);
                    jeudi.setDate(sToday.getDate() + 4);
                    vendredi.setDate(sToday.getDate() + 5);
                    break;
                case (1): //lundi
                    lundi = sToday;
                    mardi.setDate(sToday.getDate() + 1);
                    mercredi.setDate(sToday.getDate() + 2);
                    jeudi.setDate(sToday.getDate() + 3);
                    vendredi.setDate(sToday.getDate() + 4);
                    break;
                case (2):
                    lundi.setDate(sToday.getDate() - 1);
                    mardi = sToday;
                    mercredi.setDate(sToday.getDate() + 1);
                    jeudi.setDate(sToday.getDate() + 2);
                    vendredi.setDate(sToday.getDate() + 3);
                    break;
                case (3):
                    lundi.setDate(sToday.getDate() - 2);
                    mardi.setDate(sToday.getDate() - 1);
                    mercredi = sToday;
                    jeudi.setDate(sToday.getDate() + 1);
                    vendredi.setDate(sToday.getDate() + 2);
                    break;
                case (4):
                    lundi.setDate(sToday.getDate() - 3);
                    mardi.setDate(sToday.getDate() - 2);
                    mercredi.setDate(sToday.getDate() - 1);
                    jeudi = sToday;
                    vendredi.setDate(sToday.getDate() + 1);
                    break;
                case (5):
                    lundi.setDate(sToday.getDate() - 4);
                    mardi.setDate(sToday.getDate() - 3);
                    mercredi.setDate(sToday.getDate() - 2);
                    jeudi.setDate(sToday.getDate() - 1);
                    vendredi = sToday;
                    break;
                case (6):
                    lundi.setDate(sToday.getDate() - 5);
                    mardi.setDate(sToday.getDate() - 4);
                    mercredi.setDate(sToday.getDate() - 3);
                    jeudi.setDate(sToday.getDate() - 2);
                    vendredi.setDate(sToday.getDate() - 1);
                    break;
                default:
                    break;
            }

            this.getView().StartDate = lundi;
            this.getView().EndDate = vendredi;
            var sDateText = new String;
            var text = this.getView().byId("txt1");

            sDateText = "lundi " + lundi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt2");

            sDateText = "Mardi " + mardi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt3");

            sDateText = "Mercredi " + mercredi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt4");

            sDateText = "Jeudi " + jeudi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt5");

            sDateText = "Vendredi " + vendredi.getDate();
            text.setText(sDateText);

            text = this.getView().byId("txt0");
            // sDateText = lundi.getMonth() + 1 + " " + lundi.getFullYear(); "(-) AAA GMAO 184
            sDateText = " "; //(+) AAA GMAO184
            text.setText(sDateText);
        },

        // onChange: function(oEvent) {

        // 	var oCalendar = this.getView().byId("date1");
        // 	oCalendar.intervalSelection = "true";
        // 	oCalendar.removeSelectedDate(1);
        // 	oCalendar.removeSelectedDate(0);
        // 	var oModel = new sap.ui.model.json.JSONModel([{
        // 		myDate: new Date("2020-10-18")
        // 	}, {
        // 		myDate: new Date("2020-10-19")
        // 	}, {
        // 		myDate: new Date("2020-10-20")
        // 	}]);
        // 	sap.ui.getCore().setModel(oModel, "MyData3");
        // 	var oItemTemplate = new sap.ui.unified.DateRange({
        // 		startDate: new Date("2020-10-19"),
        // 		endDate: new Date("2020-10-23")
        // 	});
        // 	oCalendar.bindAggregation("selectedDates", {
        // 		path: "MyData3>/",
        // 		template: oItemTemplate
        // 	});
        // 	oCalendar.setModel(oModel, "MyData3");

        // 	var i;
        // },
        // afficher le "selectdialog" pour rechercher un poste responsable
        PosteResonsableDivision: function () {
            if (!this._posteResponsableHelp) {
                this._posteResponsableHelp = new sap.ui.xmlfragment("com.grtgaz.puma.fiori.zhistorique.imputation.view.fragments.posteResponsableSelection", this);
                this.getView().addDependent(this._posteResponsableHelp);
                this._posteResponsableHelp.setModel(this.getModel());

            }
            // Set the Filtre by default 
            var sValue = this.getView().byId("Matricule").getValue().toUpperCase();
            var oFilter = new sap.ui.model.Filter("PERNR", "EQ", sValue);
            var oBinding = this._posteResponsableHelp.getBinding("items");
            oBinding.filter([oFilter]);
            this._posteResponsableHelp.open();

        },

        PersonResonsableDivision: function () {
            if (!this._personResponsableHelp) {
                this._personResponsableHelp = new sap.ui.xmlfragment("com.grtgaz.puma.fiori.zhistorique.imputation.view.fragments.personResponsable", this);
                this.getView().addDependent(this._personResponsableHelp);
                this._personResponsableHelp.setModel(this.getModel(), "");

            }
            this._personResponsableHelp.open();

        },
        ConfirmPosteTravailSelection: function (oEvent) {
            var selectedItems = oEvent.getParameter("selectedItems");
            var valInput = sap.ui.getCore().byId("PersonResp");
            var oModel = this.getView().getModel();
            oModel.division = selectedItems[0].getBindingContext().getObject().WERKS;
            valInput.setValue(selectedItems[0].getBindingContext().getObject().ARBPL);
            //	valInput.removeAllTokens();
            // for (var i = 0; i < selectedItems.length; i++) {
            // 	var PosteResponsable = selectedItems[i].getBindingContext().getObject().ARBPL;
            // 	var Division = selectedItems[i].getBindingContext().getObject().WERKS;
            // 	var token = new sap.m.Token({
            // 		key: Division,
            // 		text: PosteResponsable
            // 	});

            // 	valInput.addToken(token);
            // }
            //	valInput.set
        },
        ConfirmPosteResponsableSelection: function (oEvent) {
            var selectedItems = oEvent.getParameter("selectedItems");
            var valInput = this.getView().byId("PosteResponsable");
            valInput.removeAllTokens();
            for (var i = 0; i < selectedItems.length; i++) {
                var PosteResponsable = selectedItems[i].getBindingContext().getObject().ARBPL;
                var Division = selectedItems[i].getBindingContext().getObject().WERKS;
                var token = new sap.m.Token({
                    key: Division,
                    text: PosteResponsable
                });

                valInput.addToken(token);
            }
        },

        // Afficher l'aide à la recherche du poste technique 
        //instantiate  xml fragment 
        _instantiateFragment: function (FragmentName) {
            var FragmentInstance;
            FragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
            //this.getView().addDependent(this.FragmentInstance);
            FragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
            FragmentInstance.setModel(this.getView().getModel("researchModel"));
            FragmentInstance.setModel(this.getView().getModel(), "");

            return FragmentInstance;

        },

        _instantiateFragment2: function (FragmentName) {
            var FragmentInstance;
            FragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
            this.getView().addDependent(this.FragmentInstance);
            FragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
            //	FragmentInstance.setModel(this.getView().getModel("researchModel"));
            FragmentInstance.setModel(this.getView().getModel(), "");
            return FragmentInstance;
        },
        OnTplnrRequest: function () {
            if (!this._technicalObjectHelp) {
                this._technicalObjectHelp = this._instantiateFragment("com.grtgaz.puma.fiori.zhistorique.imputation.view.fragments.MatriculeHelp");
                // new sap.ui.xmlfragment("project.view.fragments.technicalObjectHelp", this);
                this.getView().addDependent(this._technicalObjectHelp);
                this._technicalObjectHelp.setModel(this.getView().getModel("matriculeSearchModel"), "matriculeSearchModel");
            }
            this._technicalObjectHelp.open();
        },
        handleCloseTechnicalObjectHelp: function () {
            this._technicalObjectHelp.close();
        },

        onfilter: function (oEvent) {
            var tab = this.getView().byId("table").getTable();
            /*******Fill the filters Values */
            this.filters = [];
            var filters = this._filterConstructor(oEvent);
            if (filters.length === 0) {
                sap.m.MessageBox.error("vous devez au moins saisir un critÃ©re de recherche", {
                    title: "Erreur" // default
                });
            } else {

                tab = this.getView().byId("table").getTable();
                var template = this.getView().byId("table").getTable().getBindingInfo("items").template;
                tab.bindAggregation("items", {
                    path: "/Cat3HistorySet",
                    events: {
                        requestFailed: function (e) { }

                    },
                    filters: filters,
                    template: template
                });
                this.filters = filters;
            }
        },

        handlePosteResSearch: function (oEvent) {
            var sValue = this.getView().byId("Matricule").getValue().toUpperCase();
            //	var oFilter = new sap.ui.model.Filter("PERNR", sap.ui.model.FilterOperator'.EQ, sValue);
            var oFilter = new sap.ui.model.Filter("PERNR", 'EQ', sValue);
            var oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },

        handlePersonResSearch: function (oEvent) {
            var sValue = oEvent.getParameter("value").toUpperCase();
            var oFilter = new sap.ui.model.Filter("ARBPL", sap.ui.model.FilterOperator.Contains, sValue);
            var oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////Technical Object search && selection  ///////////////////////////////////////////////////////////
        searchTechnicalObject: function () {

            var filterCriteria = ["VORNA", "NACHN", "PERNR", "ARBPL"],
                //	VORNM
                aFilters = [];
            for (var i = 0; i < filterCriteria.length; i++) {
                var modelProperty = "/" + filterCriteria[i];
                var propertyValue = this.getView().getModel("matriculeSearchModel").getProperty(modelProperty);
                if (propertyValue) {
                    propertyValue = propertyValue.toUpperCase();
                    aFilters.push(new sap.ui.model.Filter(filterCriteria[i], sap.ui.model.FilterOperator.EQ, propertyValue));
                }

            }
            // var sLength = sap.ui.getCore().byId("PersonResp").getTokens().length ;
            // for (var i = 0 ; i < sLength ; i++)
            // {
            //  var sTextPersResp =	sap.ui.getCore().byId("PersonResp").getTokens()[i].getText();
            //  var sTextDivision =	sap.ui.getCore().byId("PersonResp").getTokens()[i].getKey();
            //  var FilterPersonResp = new sap.ui.model.Filter("ARBPL", 'EQ', sTextPersResp);
            //  var FilterDivision = new sap.ui.model.Filter("WERKS", 'EQ', sTextDivision);

            // 	aFilters.push(FilterPersonResp);
            // 	aFilters.push(FilterDivision);
            // }

            var sDivision = this.getView().getModel().division;
            if (sDivision !== null) {
                var FilterDivision = new sap.ui.model.Filter("WERKS", 'EQ', sDivision);
                aFilters.push(FilterDivision);
            }

            if (aFilters.length === 0) {
                sap.m.MessageBox.error(
                    this.getView().getModel("i18n").getResourceBundle().getText("noFilterValueArticle")

                );
                return;
            }

            sap.ui.getCore().byId("MatriculeTable").bindAggregation("items", {
                path: "/MatriculeSet",
                factory: function () {
                    return new sap.m.ColumnListItem({
                        type: "Active",
                        cells: [
                            new sap.m.Text({
                                text: "{PERNR}"
                            }),
                            new sap.m.Text({
                                text: "{NACHN}"
                            }),
                            new sap.m.Text({
                                text: "{VORNA}"
                            })
                        ]
                    });
                },
                filters: aFilters
            });

        },

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        _filterConstructor: function (oEvent) {
            var aFilters = [];
            var FilterMatricule, FilterTypeOder, FilterPersonResp, Filterdivision, PostResp, division;

            // gÃ©rer le filtre Matricule
            var MatriculeInput = this.getView().byId("Matricule");
            //	var MatriculeInputValue = "'"+MatriculeInput.getValue()+"'";
            var MatriculeInputValue = MatriculeInput.getValue();
            if ((MatriculeInputValue !== null) && (MatriculeInputValue !== undefined) && (MatriculeInputValue !== "")) {
                FilterMatricule = new sap.ui.model.Filter("PERNR", 'EQ', MatriculeInputValue);
                aFilters.push(FilterMatricule);
            }

            // filtre PersResp
            var PosteRespInput = this.getView().byId("PosteResponsable");

            // gÃ©rer les valeurs selectionÃ©es du "select dialog" 
            var PosteResps = PosteRespInput.getTokens();
            for (var i = 0; i < PosteResps.length; i++) {
                //PostResp = "'"+PosteResps[i].getText()+"'";
                //division = "'"+PosteResps[i].getKey()+"'";
                PostResp = PosteResps[i].getText();
                division = PosteResps[i].getKey();
                FilterPersonResp = new sap.ui.model.Filter("ARBPL", 'EQ', PostResp);
                Filterdivision = new sap.ui.model.Filter("WERKS", 'EQ', division);
                aFilters.push(FilterPersonResp);
                aFilters.push(Filterdivision);
            }

            // gÃ©rer les dates dÃ©but et fin 

            var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "dd.MM.YYYY"
            });

            var startDate = dateFormatter.format(this.getView().StartDate);
            var endDate = dateFormatter.format(this.getView().EndDate);

            //	if ((startDate !== null) && (startDate !== undefined) && (startDate !== "")) {
            //	var filterStartDate = new sap.ui.model.Filter("LOW_DATE", 'EQ' , "'"+"22.06.2020"+"'");
            //	var filterStartDate = new sap.ui.model.Filter("LOW_DATE", 'EQ' , "'"+startDate+"'");
            var filterStartDate = new sap.ui.model.Filter("LOW_DATE", 'EQ', startDate);
            aFilters.push(filterStartDate);
            //	}
            //	if ((endDate !== null) && (endDate !== undefined) && (endDate !== "")) {
            //	var filterEndDate = new sap.ui.model.Filter("HIGH_DATE", 'EQ' , "'"+"28.06.2020"+"'");
            //	var filterEndDate = new sap.ui.model.Filter("HIGH_DATE", 'EQ' , "'"+endDate+"'");
            var filterEndDate = new sap.ui.model.Filter("HIGH_DATE", 'EQ', endDate);
            aFilters.push(filterEndDate);
            //	}

            //gÃ©rer les types de travail 

            return aFilters;

        },

        onMatriculeSelection: function (oEvent) {
            var selectedObject, functionalObject;
            selectedObject = oEvent.getParameter("listItem").getBindingContext().getObject();
            functionalObject = selectedObject.PERNR;
            // assign technical object 
            this.getView().byId("Matricule").setValue(functionalObject);
            //this.getModel("equipementSearchModel").setProperty("/TPLNR", functionalObject);
            this._technicalObjectHelp.close();

        }
    });
}

);
/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/grtgaz/puma/fiori/zhistorique/imputation/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
/* global QUnit */

sap.ui.require([
	"com/grtgaz/puma/fiori/zhistorique/imputation/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});
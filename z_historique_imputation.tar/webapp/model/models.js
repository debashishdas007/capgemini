sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device"
], 
    /**
     * provide app-view type models (as in the first "V" in MVVC)
     * 
     * @param {typeof sap.ui.model.json.JSONModel} JSONModel
     * @param {typeof sap.ui.Device} Device
     * 
     * @returns {Function} createDeviceModel() for providing runtime info for the device the UI5 app is running on
     */
    function (JSONModel, Device) {
        "use strict";

        return {
            createDeviceModel: function () {
                var oModel = new JSONModel(Device);
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            },
    
            createFLPModel: function () {
                var fnGetUser = ObjectPath.get("sap.ushell.Container.getUser"),
                    bIsShareInJamActive = fnGetUser ? fnGetUser().isJamActive() : false,
                    oModel = new JSONModel({
                        isShareInJamActive: bIsShareInJamActive
                    });
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            },
            // create the technical object search model
            createMatriculeSearchModel: function () {
                var data = {
                    "NACHN": "",
                    "VORNA": "",
                    "PERNR": "",
                    "ARBPL": ""
                };
                var oModel = new JSONModel(data);
                return oModel;
            },
            createComponentSearchModel: function () {
                var oModel = new JSONModel();
                return oModel;
            }
        };
    });
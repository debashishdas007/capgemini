sap.ui.define([], function () {
    "use strict";

    return {

       	/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
        numberUnit: function (sValue) {
            if (!sValue) {
                return "";
            }
            return parseFloat(sValue).toFixed(2);
        },
        formatterStatus: function (stype, sVal) {
            var sStatus;
            var sSign = sVal.substr(0, 1);
            if (stype == 4) {
                // if (parseInt(sVal) <= 0) { "(-) AAA 28/01/21 GMAO184
                if (sSign === "+") { // (+) AAA 28/01/21 GMAO184
                    sStatus = "Success";
                } else if (sSign === "-") {
                    sStatus = "Error";
                }
            }
            return sStatus;
        },

        // (+) AAA 01/02/21 GMAO184 {
        formatterSign: function (stype, sVal) {
            var sText;
            if (stype == 4) {
                if (parseInt(sVal) >= 0) {
                    sText = "+" + sVal;
                } else {
                    sText = sVal;
                }
            }
            return sText;
        },
        // } (+) AAA 01/02/21 GMAO184

        formatterText: function (sType, sPERNR, sDiv, sDesc) {

            var sText;
            switch (sType) {
                case "1":
                    sText = this.getResourceBundle().getText("Text_Type1");
                    break;
                case "2":
                    //	sText = sPERNR + "-" +sDiv;
                    break;
                case "3":
                    sText = this.getResourceBundle().getText("Text_Type3");
                    break;
                case "4":
                    sText = this.getResourceBundle().getText("Text_Type4");
                    break;
                default:
                    break;
            }

            return sText;

        },

        formatterText2: function (sType, sPERNR, sDiv) {

            var sText;
            switch (sType) {

                case "2":
                    // sText = sPERNR + "-" +sDiv; (-) AAA 27/01/2021
                    sText = sPERNR;
                    break;
                default:
                    break;
            }

            return sText;

        },
        formatterTitle: function (sType, sLTXA2, sAUFNR, sKTEXT) {

            var sText;
            switch (sType) {

                case "2":
                    // sText = sAUFNR + "-" + sLTXA2 ; //(-) AAA GMAO184
                    //(+) AAA GMAO184 { 
                    sText = sAUFNR + " - " + sKTEXT + " - " + sLTXA2;
                    // } (+) AAA GMAO184
                    break;
                default:
                    break;
            }

            return sText;

        }

    };

});
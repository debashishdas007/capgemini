sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		formatss: function(oObject) {

		},
		formatDate: function(sValue) {
			var day, month, year, sReturn;
			if (sValue) {
				day = sValue.slice(6, 8);
				month = sValue.slice(4, 6);
				year = sValue.slice(0, 4);
				sReturn = day + "-" + month + "-" + year;
			} else {
				sReturn = "";
			}
			return sReturn;
		},
		formatDateComment: function(sDate, sTime) {
			var sReturn, sD, sT;
			sD = sDate;
			sT = sTime;
			if (!sD) {
				sD = "";
			}

			if (!sT) {
				sT = "";
			}

			sReturn = "Date:" + sD + "  Heure:" + sT;
			return sReturn;
		},
		formatUser: function(sUser, sFullUser) {
			if (sFullUser && sUser) {
				return sFullUser + "(" + sUser + ")";
			} else {
				return "";
			}
		},

		formatterStatusSystemZV: function(sValue) {
			switch (sValue) {
				case "I0070":
					return this.getModel("i18n").getResourceBundle().getText("AENC");
				case "I0072":
					return this.getModel("i18n").getResourceBundle().getText("ACLO");
				case "I0068":
					return this.getModel("i18n").getResourceBundle().getText("AOUV");
				default:
					return "";
			}
		},

        /**
         * Formate les statuts systèmes.
         * 
         * @private
         * @param {string} sValue
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-501
         * Par : Alexandre PISSOTTE (APY)
         * Date : 23/11/2021
         * Motif : Afficher les statuts systèmes et utiliseurs pour les avis.
         * Il est faut vérifier la présence d'une valeur dans sValue à cause du 
         * bindView (chargement différé).
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
		formatterStatus: function(sValue) {
			var aStatus = [];
			var sReturn = "";
            
            if (sValue) {
                aStatus = sValue.split(" ");
            }
			
			for (var i = 0; i < aStatus.length; i++) {
				switch (aStatus[i]) {
					case "I0070":
						if (!sReturn) {
							sReturn = this.getModel("i18n").getResourceBundle().getText("AENC");
						} else {
							sReturn = sReturn + "-" + this.getModel("i18n").getResourceBundle().getText("AENC");
						}
						break;
					case "I0072":
						if (!sReturn) {
							sReturn = this.getModel("i18n").getResourceBundle().getText("ACLO");
						} else {
							sReturn = sReturn + "-" + this.getModel("i18n").getResourceBundle().getText("ACLO");
						}
						break;
					case "I0068":
						if (!sReturn) {
							sReturn = this.getModel("i18n").getResourceBundle().getText("AOUV");
						} else {
							sReturn = sReturn + "-" + this.getModel("i18n").getResourceBundle().getText("AOUV");
						}
						break;
					default:
				}
			}
			return sReturn;
		},

		formatterTime: function(sVAlue) {
			var HH, MM, SS;
			if (sVAlue) {
				HH = sVAlue.slice(0, 2);
				MM = sVAlue.slice(2, 4);
				SS = sVAlue.slice(4, 6);
				return HH + ":" + MM + ":" + SS;
			} else {
				return "";
			}

		},
        
        /**
         * Formate les statuts utilisateurs.
         * 
         * @private
         * @param {string} sValue
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-501
         * Par : Alexandre PISSOTTE (APY)
         * Date : 23/11/2021
         * Motif : Afficher les statuts systèmes et utiliseurs pour les avis.
         * Il est faut vérifier la présence d'une valeur dans sValue à cause du 
         * bindView (chargement différé).
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
		formatUserStatut: function(sVAlue, sType) {
			var sText, sStatut;

            if (sVAlue) {
                sStatut = sVAlue.trim();
            }

			switch (sStatut) {
				case "E0001":
					if (sType === "ZV") {
						sText = this.getModel("i18n").getResourceBundle().getText("E0001ZV");
					} else {
						sText = this.getModel("i18n").getResourceBundle().getText("E0001");
					}
					break;
				case "E0002":
					if (sType === "ZV") {
						sText = this.getModel("i18n").getResourceBundle().getText("E0002ZV");
					} else {
						sText = this.getModel("i18n").getResourceBundle().getText("E0002");
					}
					break;
				case "E0003":
					if (sType === "ZV") {
						sText = this.getModel("i18n").getResourceBundle().getText("E0003ZV");
					} else {
						sText = this.getModel("i18n").getResourceBundle().getText("E0003");
					}
					break;
				default:
			}
			return sText;
		},

		formatFailureProfilDate: function(date, time) {
			var sReturn;
			if (date) {
				sReturn = date;
			}
			if (time) {

				sReturn = sReturn + " " + time.slice(0, 5);
			}
			return sReturn;
		},
		formatStopTime: function(time) {
			if (time) {
				var sTime = time;
				return sTime.trim();
			}
		},
		formatVerificationStauts: function(acronym, desc) {
			if (acronym && desc) {
				return acronym + "-" + desc;
			} else {
				return "";
			}
		},
		formatZzmop: function(sMop, sMopText) {
			var sMessage = "";
			if (sMop) {
				sMessage = sMop + "-" + sMopText;
			}
			return sMessage;

		},
        compressionhistoryAvis : function(sAvis){
            var sBindedAvis = this.getView().getBindingContext().getProperty("QMNUM");
            if(sAvis === sBindedAvis){
                return false;
            }else{
                return true;                
            }
        },
        compressionhistoryDates : function(sDate,sTime){
            var day = "", month = "", year = "", sDateReturn = "";
            var sHoure = "" ,sMin = "",sSec = "", sTimeReturn = "";
			if (sDate !== "00000000") {
				day = sDate.slice(6, 8);
				month = sDate.slice(4, 6);
				year = sDate.slice(0, 4);
				sDateReturn = day + "/" + month + "/" + year;
			}
				sSec = sTime.slice(4, 6);
				sMin = sTime.slice(2, 4);
				sHoure = sTime.slice(0, 2);
                sTimeReturn = sHoure + ":" + sMin;
            var sReturn = sDateReturn ? sDateReturn + " " + sTimeReturn : "";
			return sReturn ;
        }
	};

});
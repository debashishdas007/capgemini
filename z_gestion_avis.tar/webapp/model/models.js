sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/base/util/ObjectPath"
], function (JSONModel, Device, ObjectPath) {
	"use strict";

	return {

		createDeviceModel : function () {
			var oModel = new JSONModel(Device);
            oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createFLPModel : function () {
			var fnGetUser = ObjectPath.get("sap.ushell.Container.getUser"),
				bIsShareInJamActive = fnGetUser ? fnGetUser().isJamActive() : false,
				oModel = new JSONModel({
					isShareInJamActive: bIsShareInJamActive
				});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		createStatutModel: function(data) {
			var oModel = new JSONModel(data);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		// create the technical object search model
		createTechnicalObjectSearchModel: function() {
			var data = {
				"INGRP": "",
				"SWERK": "",
				"STORT": "",
				"BEBER": "",
				"CLASS": "",
				"KLART": "",
				"PLTXT": "",
				"TPLNR": "",
				"EQFNR": "",
				"ARBPL": ""
			};
			var oModel = new JSONModel(data);
			return oModel;
		},

		//create equipement research model 
		createEquipementSearchModel: function() {
			var data = {
				"CLASS": "",
				"MATNR": "",
				"LGORT": "",
				"KLART": "",
				"TPLNR": "",
				"SERNR": "",
				"EQUNR": "",
				"EQKTX": "",
				"ARBPL": "",
				"INGRP": ""
			};
			var oModel = new JSONModel(data);
			return oModel;
		},
		createMediaMetadataModel: function(oElementBindingObject, oLineObject) {
			var user = "";
			if (sap.ushell.Container) {
				user = sap.ushell.Container.getUser().getEmail().split("@")[0];
			}
			var oObject = {
				"puma_numero_ot":  oElementBindingObject.AUFNR,
				"puma_otdesignation": oElementBindingObject.KTEXT,
				"puma_type_de_travail": oElementBindingObject.AUART,
				"puma_numero_avis": oElementBindingObject.QMNUM,
				"puma_poste_technique": oElementBindingObject.TPLNR,
				"puma_poste_techniquedesignation": oElementBindingObject.PLTXT,
				"puma_observations": [{
					"id": Number(oLineObject.ID_TERME_M)
				}],
				"puma_groupe_gestionnaire": oElementBindingObject.INGRP,
				"puma_poste_responsable": oElementBindingObject.VAPLZ,
				"puma_lien_gmao": this._constructUrl(),
				"commun_contexte": oLineObject.TITRE_MOP,
				"commun_date_heure":  sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd'T'HH:mm:ss"
				}).format(new Date()),
				"commun_fonction_technique": oElementBindingObject.ATWRT,
				"commun_source": "GMAO",
				"commun_auteur": user,
				 "ID_FOLDER_M": oLineObject.ID_FOLDER_M

			};
			return oObject;
        },
        _constructUrl:function(){
          var oWindowLocation = window.location,
              aLocationParts  = window.location.search.split("&"),
              sUrl = oWindowLocation.origin + "/site" + aLocationParts[0] + "&sap-language=fr-FR"+ oWindowLocation.hash;
              return sUrl;           


        }

	};

});
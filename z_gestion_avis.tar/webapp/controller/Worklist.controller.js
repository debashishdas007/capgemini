// jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../PumaFioriLibrary.grtgazpumaFioriLibrary");
jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.NotificationTypeSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.OrderSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.MultiSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.WorkCenterSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.MaintenancePlantSearchHelp");
sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/NotificationTypeSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/OrderSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/MultiSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/WorkCenterSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/MaintenancePlantSearchHelp"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, NotificationTypeSearchHelp, OrderSearchHelp,
    EquipmentSearchHelp,
    FunctionalLocationSearchHelp, MultiSelectionMode, ObjectSimpleSelectionMode, WorkCenterSearchHelp, MaintenancePlantSearchHelp) {
    "use strict";

    return BaseController.extend("grtgaz.puma.GestionDesAvis.controller.Worklist", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called upon initialization of the view Worklist
         * 
         * @public
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-527
         * Par : Alexandre PISSOTTE (APY)
         * Date : 14/12/2021
         * Motif : Coches statuts systèmes bloquées
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onInit: function() {
            var oViewModel,
                oFunctionalLocationModel,
                orderModel,
                notificationModel,
                EquipementModel,
                oStatusFilter,
                articleModel,
                oFilter,
                that,
                iOriginalBusyDelay,
                oTable = this.byId("notifications-table").getTable();

            // // Put down worklist table's original value for busy indicator delay,
            // // so it can be restored later on. Busy hand,ling on the table is
            // // taken care of by the table itself.
            // iOriginalBusyDelay = oTable.getBusyIndicatorDelay();

            // // keeps the search state
            // this._oTableSearchState = [];

            // Model used to manipulate control states
            oViewModel = new JSONModel({
                worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
                tableNoDataText: this.getResourceBundle().getText("tableNoDataInitialText"),
                functLocationClassSearch: "",
                functionalLocationDefinition: "",
                equipementDefinition: "",
                maintPlanWorklist: "",
                ArticleDefinition: "",
                orderDefinition: "",
                tableBusyDelay: 0
            });

            this.setModel(oViewModel, "worklistView");

            // model used for functional location research
            oFunctionalLocationModel = new JSONModel();
            this.setModel(oFunctionalLocationModel, "FunctionalLocation");

            // model used for order research
            orderModel = new JSONModel();
            this.setModel(orderModel, "orderModel");

            // model used for equipement research
            EquipementModel = new JSONModel();
            this.setModel(EquipementModel, "Equipement");

            // model used for article research
            articleModel = new JSONModel();
            this.setModel(articleModel, "articleModel");

            // model used for notification research
            notificationModel = new JSONModel();
            this.setModel(notificationModel, "Avis");

            // this.setModel(this.getOwnerComponent().getModel(), ""); // GMAO-527 (-) APY 14/12/2021

            // Make sure, busy indication is showing immediately so there is no
            // break after the busy indication for loading the view's meta data is
            // ended (see promise 'oWhenMetadataIsLoaded' in AppController)
            oTable.attachEventOnce("updateFinished", function() {
                // Restore original busy indicator delay for worklist's table
                oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
            });

            // change the search button label from "lancer" to "rechercher"
            oFilter = this.getView().byId("notification-filter");
            this._changeSearchButtonLabel(oFilter);

            // this._setStatusFilterDefaultValue(); // GMAO-527 (-) APY 14/12/2021

            // Variant management handler
            oFilter.attachBeforeVariantSave(this._onBeforeVariantSave, this);
            oFilter.attachAfterVariantLoad(this._onAfterVariantLoad, this);

            //	sap.ui.getCore().getEventBus().subscribe("FragChannel","InstantiationFragEvent", this._instantiateFragment,this); 
            var startupParams = this.getOwnerComponent().getComponentData()?.startupParameters;

            if (startupParams?.QMNUM) {
                var oGlobalBusyDialog = new sap.m.BusyDialog();
                oGlobalBusyDialog.open();
                var sObjectPath = "/PMNotificationDetailsSet(" + "'" + startupParams.QMNUM[0] + "')";
                this._getinfo(sObjectPath, oGlobalBusyDialog);

            }
            this.getOwnerComponent().getModel().attachBatchRequestSent(this._onBatchRequestSent, this);
            this.getOwnerComponent().getModel().attachBatchRequestCompleted(this._onBatchRequestCompleted, this);
            this.getOwnerComponent().getModel("researchModel").attachBatchRequestCompleted(this._onBatchRequestCompleted, this);
            this.getOwnerComponent().getModel("researchModel").attachBatchRequestSent(this._onBatchRequestSent, this);
        },
        _onBatchRequestSent: function() {
            if (!this._oGlobalBusyIndicator) {
                this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            }
            this._oGlobalBusyIndicator.open();
        },
        _onBatchRequestCompleted: function() {
            this._oGlobalBusyIndicator.close();
        },

        _onBeforeVariantSave: function(oEvent) {
            var oFilterCriteriaValues = {},
                oFilter;

            // get the smartfilter
            oFilter = oEvent.getSource();

            //get filter criteria values 
            oFilterCriteriaValues._CUSTOM = this._prepareDefaultValue(oFilter);

            oEvent.getSource().setFilterData(oFilterCriteriaValues, true);
        },

        _onAfterVariantLoad: function(oEvent) {
            var oVariantData = JSON.parse(oEvent.getSource().fetchVariant().filterBarVariant)["_CUSTOM"];
            if (oVariantData) {
                this._setFilterCriteriaData(oVariantData);
            } else {
                this._initializeFilterCriteria();
            }
            var filterBar = this.getView().byId("notification-filter");
            if (this.getView().byId("notification-filter").getVariantManagement().oSelectedItem.getExecuteOnSelection()) {
                filterBar.fireSearch();
            }
        },

        _initializeFilterCriteria: function() {
            var aFiltersSingleParameters = ["QMNUM", "QMTXT", "AUFNR", "VAPLZ", "WAWRK", "SWERK"],
                sProperty;
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                this.getView().getModel("Avis").setProperty(sProperty, "");
            }
            this.getView().byId("start-date").setValue("");
            this.getView().byId("end-date").setValue("");
            this.getView().byId("work-center").setValueState("Error");
            this.getView().byId("equipement").removeAllTokens();
            this.getView().byId("functional-location").removeAllTokens();
            this.getView().byId("statusComboBox").clearSelection();
            this.getView().byId("notification-type").removeAllTokens();
        },

        _setFilterCriteriaData: function(oObject) {
            var aFiltersSingleParameters = ["QMNUM", "QMTXT", "AUFNR", "VAPLZ", "WAWRK", "SWERK"],
                sValue, sProperty;
            // set single value filter criteria 	
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                sValue = oObject[aFiltersSingleParameters[i]];
                if (sValue) {
                    this.getView().getModel("Avis").setProperty(sProperty, sValue);
                } else {
                    this.getView().getModel("Avis").setProperty(sProperty, "");
                }
            }

            if (!oObject["VAPLZ"] || oObject["VAPLZ"] === "") {
                this.getView().byId("work-center").setValueState("Error");
            } else {
                this.getView().byId("work-center").setValueState("None");
            }

            this._setNotificationType(oObject);

            this._setSystemStatus(oObject);

            this._setFunctLocations(oObject);

            this._setEquipements(oObject);

            this._setStartEndDate(oObject);

        },

        _setStartEndDate: function(oObject) {
            var startDate = oObject["AUSVN"];

            if (startDate) {
                this.getView().byId("start-date").setValue(startDate);
            } else {
                this.getView().byId("start-date").setValue("");
            }

            var endDate = oObject["AUSBS"];
            if (endDate) {
                this.getView().byId("end-date").setValue(endDate);
            } else {
                this.getView().byId("end-date").setValue("");
            }
        },

        _setEquipements: function(oObject) {
            // set equipements 
            var aEquipements = oObject["EQUNR"],
                oEquipMultiInput = this.getView().byId("equipement");
            oEquipMultiInput.removeAllTokens();
            if (aEquipements) {
                for (var i = 0; i < aEquipements.length; i++) {

                    var token = new sap.m.Token({
                        key: aEquipements[i],
                        text: aEquipements[i]
                    });

                    oEquipMultiInput.addToken(token);
                }
            }
        },
        _setFunctLocations: function(oObject) {
            // set functional Locations 
            var aFuncLocations = oObject["TPLNR"],
                oFuncLocMultiInput = this.getView().byId("functional-location");
            oFuncLocMultiInput.removeAllTokens();
            if (aFuncLocations) {
                for (var i = 0; i < aFuncLocations.length; i++) {

                    var token = new sap.m.Token({
                        key: aFuncLocations[i],
                        text: aFuncLocations[i]
                    });

                    oFuncLocMultiInput.addToken(token);
                }
            }
        },

        _setSystemStatus: function(oObject) {
            var aSystemStatus = oObject["SYSTEMSTATUS"],
                oStatusFilter = this.getView().byId("statusComboBox");
            oStatusFilter.clearSelection();
            if (aSystemStatus) {
                oStatusFilter.setSelectedKeys(aSystemStatus);
            }
        },

        _setNotificationType: function(oObject) {
            // set notiffication Type 
            var aNotifTypes = oObject["QMART"],
                NotifTypeMultiInput = this.getView().byId("notification-type");
            NotifTypeMultiInput.removeAllTokens();
            if (aNotifTypes) {
                for (var i = 0; i < aNotifTypes.length; i++) {
                    var NotifType = aNotifTypes[i];
                    var token = new sap.m.Token({
                        key: NotifType,
                        text: NotifType
                    });

                    NotifTypeMultiInput.addToken(token);
                }
            }

        },

        _prepareDefaultValue: function(oFilter) {

            var aFiltersSingleParameters = ["QMNUM", "QMTXT", "AUFNR", "VAPLZ", "WAWRK", "SWERK"],
                _custom = {},
                sProperty, sValue, aNotifTypes = [],
                aStatus = [],
                aFuncLocations = [],
                aEquipements = [];

            // save single value filter criteria 	
            for (var i = 0; i < aFiltersSingleParameters.length; i++) {
                sProperty = "/" + aFiltersSingleParameters[i];
                sValue = this.getView().getModel("Avis").getProperty(sProperty);
                if (sValue) {
                    _custom[aFiltersSingleParameters[i]] = sValue;
                }
            }

            var startDate = this.getView().byId("start-date").getValue();
            if (startDate) {
                _custom["AUSVN"] = startDate;
            }

            var endDate = this.getView().byId("end-date").getValue();
            if (endDate) {
                _custom["AUSBS"] = endDate;
            }

            // save Multiple value filter criteria 
            aNotifTypes = this._getNotifTypes();
            if (aNotifTypes.length !== 0) {
                _custom["QMART"] = aNotifTypes;
            }

            aStatus = this._getSystemStatus();
            if (aStatus.length !== 0) {
                _custom["SYSTEMSTATUS"] = aStatus;
            }

            aFuncLocations = this._getFuncLocations();
            if (aFuncLocations.length !== 0) {
                _custom["TPLNR"] = aFuncLocations;
            }

            aEquipements = this._getEquipements();
            if (aEquipements.length !== 0) {
                _custom["EQUNR"] = aEquipements;
            }

            return _custom;

        },

        onAddNotification: function() {
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
            var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: "ZCreation_AVIS",
                    action: "display"
                }

            })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order creation app 	
        },
        _getFuncLocations: function() {
            //get functional Location values  
            var aFuncLocTokens = this.getView().byId("functional-location").getTokens(),
                aFuncLocations = [];

            for (var i = 0; i < aFuncLocTokens.length; i++) {
                aFuncLocations.push(aFuncLocTokens[i].getKey());
            }
            return aFuncLocations;
        },

        _getEquipements: function() {
            //get equipements values  
            var aEquipementTokens = this.getView().byId("equipement").getTokens(),
                aEquipements = [];

            for (var i = 0; i < aEquipementTokens.length; i++) {
                aEquipements.push(aEquipementTokens[i].getKey());
            }
            return aEquipements;
        },

        _getSystemStatus: function() {

            // get system Status value
            var sStatusInput = this.getView().byId("statusComboBox"),
                aSelectedKeys = sStatusInput.getSelectedKeys(),
                aStatus = [];
            for (var i = 0; i < aSelectedKeys.length; i++) {
                aStatus.push(aSelectedKeys[i]);
            }

            return aStatus;

        },

        _getNotifTypes: function() {

            //get notification type filter values   
            var aTypesNotif = this.getView().byId("notification-type").getTokens(),
                aNotifTypes = [],
                sTypeNotif;

            for (var ii = 0; ii < aTypesNotif.length; ii++) {
                sTypeNotif = aTypesNotif[ii].getText();
                aNotifTypes.push(sTypeNotif);
            }
            return aNotifTypes;
        },

        _getinfo: function(sobject, oGlobalBusyDialog) {
            this.getOwnerComponent().getModel().read(sobject, {
                success: function(odata, oresp) {
                    var sType = odata.QMART;
                    var sNotifNumber = odata.QMNUM;
                    var oObjectId = {};
                    oObjectId.QMNUM = sNotifNumber;
                    oObjectId.QMART = sType;
                    oGlobalBusyDialog.close();
                    this._showObject(oObjectId);
                }.bind(this),
                error: function(error) {

                }
            });
        },

        onExit: function() {
            var aFragments = [this._oFunctLocationValueHelp, this._oClassValueHelp,
            this._oOrderValueHelp, this._oOrderTypeValueHelp, this._oEquipementValueHelp, this._oPlanGroupValueHelp, this._oMaintPlantValueHelp,
            this._oLocalisationValueHelp, this._oPlantSectionValueHelp, this._oStoreValueHelp, this._oArticleValueHelp
            ];
            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }

        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
        onUpdateFinished: function(oEvent) {
            // update the worklist's object counter after the table update
            var sTitle,
                oTable = oEvent.getSource(),
                iTotalItems = oEvent.getParameter("total");
            // only update the counter if the length is final and
            // the table is not empty
            if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
                sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
            } else {
                sTitle = this.getResourceBundle().getText("worklistTableTitle");
            }
            this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
        },

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
        onPress: function(oEvent) {
            // The source is the list item that got pressed*

            this._showObject(this._prepareObjectId(oEvent));
        },

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
        onNavBack: function() {
            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: "#Shell-home"
                    }
                });
            }
        },

        onNotifTypeRequest: function() {
            var aNotifTypeMultiInput = this.getView().byId("notification-type");
            if (!this._oNotifTypeValueHelp) {
                var oMultiSelectionMode = new MultiSelectionMode(new JSONModel(), function(aTokens) {
                    aNotifTypeMultiInput.setTokens(aTokens);
                });
                this._oNotifTypeValueHelp = new NotificationTypeSearchHelp(this, oMultiSelectionMode).open();
            }

            this._oNotifTypeValueHelp.open();

            //

        },

		/**
		 * Event handler for opening the value help dialog of the functional location.
		 * On Phone the framgment stretchs to adapt the view
		 * @public
		 */
        onFunctLocationRequest: function() {
            var oFunctionalLocation = this.getView().byId("functional-location");
            if (!this._oFunctLocationValueHelp) {
                var oMultiSelectMode = new MultiSelectionMode(new JSONModel(), function(aTokens) {
                    oFunctionalLocation.setTokens(aTokens);
                });
                this._oFunctLocationValueHelp = new FunctionalLocationSearchHelp(this, oMultiSelectMode);
            }
            this._oFunctLocationValueHelp.open();
        },

        onOrderRequest: function() {
            var oNotifModel = this.getModel("Avis");
            if (!this._oOrderValueHelp) {
                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
                    oNotifModel.setProperty("/AUFNR", oObject.AUFNR);

                });

                this._oOrderValueHelp = new OrderSearchHelp(this, oObjectSelectionMode);

            }
            this._oOrderValueHelp.open();

        },

        onEquipementRequest: function() {
            var oEquipement = this.getView().byId("equipement");
            if (!this._oEquipementValueHelp) {
                var oMultiSelectMode = new MultiSelectionMode(new JSONModel(), function(aTokens) {
                    oEquipement.setTokens(aTokens);
                });
                this._oEquipementValueHelp = new EquipmentSearchHelp(this, oMultiSelectMode);
            }
            this._oEquipementValueHelp.open();


        },

		/**
		 * Event handler for opening  the maintenance plant value help from the worklist page   .
		 * @public
		 */
        oMaintPlantRequest: function() {
            var oNotifModel = this.getView().getModel("Avis");

            if (!this._oMaintPlantValueHelp) {
                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
                    oNotifModel.setProperty("/SWERK", oObject.WERKS);
                });
                this._oMaintPlantValueHelp = new MaintenancePlantSearchHelp(this, oObjectSelectionMode);
            }
            this._oMaintPlantValueHelp.open();
        },

        onWorkCenterRequest: function() {
            var oPosteResponsable = this.getView().byId("work-center"),
                oAvisObject = this.getView().getModel("Avis");

            if (!this._oWorkCenterValueHelp) {

                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
                    oPosteResponsable.setValue(oObject.ARBPL);
                    oAvisObject.setProperty("/WAWRK", oObject.WERKS);
                    oPosteResponsable.setValueState("None");
                });
                this._oWorkCenterValueHelp = new WorkCenterSearchHelp(this, oObjectSelectionMode);

            }
            this._oWorkCenterValueHelp.open();

        },

        onWorkCenterChange: function(oEvent) {
            var sWorkCenter = this.getView().getModel("Avis").getProperty("/VAPLZ");
            if (!sWorkCenter || sWorkCenter === "") {
                this.getView().byId("work-center").setValueState("Error");
            } else {
                this.getView().byId("work-center").setValueState("None");
            }

        },

        /**
         * Effectue la recherche des points de mesure
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-512
         * Par : Alexandre PISSOTTE (APY)
         * Date : 14/01/2022
         * Motif : Tri de la table des avis
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onfilter: function(oEvent) {
            this.filters = [];
            var filters,
                sWorkCenter = this.getView().getModel("Avis").getProperty("/VAPLZ");
            if (!sWorkCenter) {
                sap.m.MessageBox.error(this.getResourceBundle().getText("noFilterSelected"), {
                    title: "Erreur" // default

                });
            } else {
                filters = this._filterConstructor(oEvent);
                var tab = this.getView().byId("notifications-table").getTable();

                var template = this.getView().byId("notifications-table").getTable().getBindingInfo("items").template;
                tab.bindAggregation("items", {
                    path: "/PMNotificationDetailsSet",
                    filters: filters,
                    template: template,
                    sorter: this.oSorter, // GMAO-512
                    events: {
                        dataReceived: function() {
                            tab.setBusy(false);
                        }
                    }
                });
                this.filters = filters;

            }
        },

        _filterConstructor: function(oEvent) {
            var AfiltersParameters, otTypesNotifInput, sStatusInput, sStartDate, sEndDate, aTypesNotif, aSelectedKeys, sTypeNotif,
                aFuncLocations, aEquipements, oFuncLocMultiInput, oEquipement, oFilterFuncLocation, oEquipementMultiInput, oFilterEquipement,
                oFiltertypeNotif, sProperty, sValue,
                aFilters = [];

            // prepare filters for notification (code ,designation ) ,order number,functional location,work center,work center division,maintenance plant
            AfiltersParameters = ["QMNUM", "QMTXT", "AUFNR", "WAWRK", "VAPLZ", "SWERK"];
            for (var i = 0; i < AfiltersParameters.length; i++) {
                sProperty = "/" + AfiltersParameters[i];
                sValue = this.getView().getModel("Avis").getProperty(sProperty);
                if (sValue) {
                    aFilters.push(new sap.ui.model.Filter(AfiltersParameters[i], sap.ui.model.FilterOperator.EQ, sValue));
                }
            }

            //add notification type filter  
            otTypesNotifInput = this.getView().byId("notification-type");
            aTypesNotif = otTypesNotifInput.getTokens();
            for (var ii = 0; ii < aTypesNotif.length; ii++) {
                sTypeNotif = aTypesNotif[ii].getText();
                oFiltertypeNotif = new sap.ui.model.Filter("QMART", sap.ui.model.FilterOperator.EQ, sTypeNotif);
                aFilters.push(oFiltertypeNotif);
            }

            // functional Location  
            oFuncLocMultiInput = this.getView().byId("functional-location");
            aFuncLocations = oFuncLocMultiInput.getTokens();
            for (var j = 0; j < aFuncLocations.length; j++) {
                oFilterFuncLocation = new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, aFuncLocations[j].getKey());
                aFilters.push(oFilterFuncLocation);
            }

            //equipement 
            oEquipementMultiInput = this.getView().byId("equipement");
            aEquipements = oEquipementMultiInput.getTokens();
            for (var k = 0; k < aEquipements.length; k++) {
                oFilterEquipement = new sap.ui.model.Filter("EQUNR", sap.ui.model.FilterOperator.EQ, aEquipements[k].getKey());
                aFilters.push(oFilterEquipement);
            }

            // sManueltypeNotifValue = otTypesNotifInput.getValue();
            // if (sManueltypeNotifValue) {
            // 	oFiltertypeNotif = new sap.ui.model.Filter("QMART", sap.ui.model.FilterOperator.EQ, sManueltypeNotifValue);
            // 	aFilters.push(oFiltertypeNotif);
            // }

            // add system Status filter
            sStatusInput = this.getView().byId("statusComboBox");
            aSelectedKeys = sStatusInput.getSelectedKeys();
            for (var jj = 0; jj < aSelectedKeys.length; jj++) {
                aFilters.push(new sap.ui.model.Filter("SYSTEMSTATUS", sap.ui.model.FilterOperator.EQ, aSelectedKeys[jj]));
            }

            // g�rer les dates d�but et de fin   
            sStartDate = this._prepareDateForFilter(this.getView().byId("start-date").getProperty("dateValue"));
            sEndDate = this._prepareDateForFilter(this.getView().byId("end-date").getProperty("dateValue"));

            if (sStartDate && !sEndDate) {
                aFilters.push(new sap.ui.model.Filter("QMDAT", sap.ui.model.FilterOperator.GE, sStartDate));
            }
            if (sEndDate && !sStartDate) {
                aFilters.push(new sap.ui.model.Filter("QMDAT", sap.ui.model.FilterOperator.LE, sEndDate));
            }
            if (sEndDate && sStartDate) {
                aFilters.push(new sap.ui.model.Filter("QMDAT", sap.ui.model.FilterOperator.BT, sStartDate, sEndDate));
            }

            return aFilters;

        },

        _prepareDateForFilter: function(sValue) {
            var dateformatter = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "dd.MM.YYYY"
            });
            return dateformatter.format(sValue);
        },

        /**
         * Recupère les filtres et les tris
         * 
         * @public
         * @param {sap.ui.base.Event} oEvent 
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-512
         * Par : Alexandre PISSOTTE (APY)
         * Date : 14/01/2022
         * Motif : Tri de la table des avis
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onBeforeRebindTable: function(oEvent) {
            if (this.filters) {
                oEvent.getParameter("bindingParams").filters = this.filters;
            }

            if (!this.oSorter && oEvent.getParameter("bindingParams").sorter.length == 0) {
                // Sorter par défaut
                this.oSorter = new sap.ui.model.Sorter("QMNUM", true);
            } else {
                // Sorter sélectionné
                this.oSorter = oEvent.getParameter("bindingParams").sorter;
            }
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @return{object}  key object for navigation 
		 * @public
		 */
        _prepareObjectId: function(oEvent) {
            var oObject, oObjectId = {};
            oObject = oEvent.getParameter("listItem").getBindingContext().getObject();
            oObjectId.QMNUM = oObject.QMNUM;
            oObjectId.QMART = oObject.QMART;
            return oObjectId;

        },

		/**
		 * Shows the selected item on the object page
		 * @param {jsObject} oObjectId selected item key 
		 * @private
		 */
        _showObject: function(oObjectId) {

            switch (oObjectId.QMART) {
                case "ZC":
                    this.getRouter().navTo("zcDetails", oObjectId);
                    break;
                case "ZA":
                    this.getRouter().navTo("zaDetails", oObjectId);
                    break;
                case "ZP":
                    this.getRouter().navTo("ZpDetails", oObjectId);
                    break;
                case "ZV":
                    this.getRouter().navTo("ZvDetails", oObjectId);
                    break;
                case "ZM":
                    this.getRouter().navTo("ZmDetails", oObjectId);
                    break;
                default:
                    break;
            }

        },

		/**
		 * instantiate the fragment and return the fragment instance 
		 * @param {string} FragmentName : name of the fragment
		 * @return {xmlfragment} instance of the fragment
		 * @private
		 */
        // _instantiateFragment: function(FragmentName) {
        // 	var oFragmentInstance;
        // 	oFragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
        // 	this.getView().addDependent(this.oFragmentInstance);
        // 	oFragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
        // 	oFragmentInstance.setModel(this.getView().getModel(""));
        // 	return oFragmentInstance;
        // },

		/**
		 * instantiate the fragment and return the fragment instance 
		 * @param {string} FragmentName name of the fragment
		 * @return {xmlfragment} instance of the fragment
		 * @private
		 */
        _instantiateExternalFragment: function(FragmentName) {
            var oFragmentInstance;
            oFragmentInstance = this._instantiateFragment(FragmentName);
            oFragmentInstance.setModel(this.getModel("researchModel"), "researchModel");
            return oFragmentInstance;
        },

		/**
		 * instantiate the class help value fragment
		 * @private
		 */
        _instantiateClassHelpFrag: function() {
            if (!this._oClassValueHelp) {
                this._oClassValueHelp = this._instantiateExternalFragment("puma.pm.notifications.view.fragments.classValueHelp");
            }
            this._oClassValueHelp.open();
        },

		/**
		 * search the the entered value from the list
		 * @param {event} oEvent   event triggered when searching for a value 
		 * @param {string} FilterName the property name for filtering 
		 * @private
		 */
        _searchElementFromSelectDialogList: function(oEvent, FilterName) {
            var sValue, oFilter, oBinding;
            sValue = oEvent.getParameter("value").toUpperCase();
            oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
            oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },

		/**
		 * retruns the selected item's title  
		 * @param {event} oEvent : event triggered once item selected 
		 * @return {string } item's title 
		 * @private
		 */
        _getSelectedItemTitle: function(oEvent) {
            return oEvent.getParameter("selectedItem").getTitle();
        },

		/**
		 * prepare the class category filter   
		 * @param {string} sValue : value of class category 
		 * @return {string[] } table of filters 
		 * @private
		 */
        _prepareClassHelpFilter: function(sValue) {
            var aFilters = [];
            aFilters.push(new sap.ui.model.Filter("KLART", sap.ui.model.FilterOperator.EQ, sValue));
            return aFilters;
        },

		/**
		 * bind the select dialog to the class list  
		 * @param {string[] } aFilters table of filters 
		 * @private
		 */
        _bindClassHelpList: function(aFilters) {
            sap.ui.getCore().byId("classHelp").bindAggregation("items", {
                path: "researchModel>/ClassSet",
                factory: function() {
                    return new sap.m.StandardListItem({
                        selected: false,
                        title: "{researchModel>CLASS}",
                        description: "{researchModel>KLART}",
                        type: "Active"
                    });
                },
                filters: aFilters
            });
        },

		/**
		 * Apply filter and bind the functional location table with results   
		 * @param {string[] } aFilters table of filters 
		 * @private
		 */
        _filterTable: function(oFilter, fragmentInstance, entityset, firstCellBinding, secondCellBinding) {
            var oValueHelpDialog, oTable;

            // get the  table of the value dialog help   
            oValueHelpDialog = fragmentInstance;
            oTable = oValueHelpDialog.getTable();

            // case the value help dialog table  is  a sap.ui.table 

            if (oTable.bindRows) {
                oTable.bindRows({
                    path: entityset,
                    filters: oFilter

                });

            }

            //case the value help dialog table  is  a sap.m.table
            if (oTable.bindItems) {
                oTable.bindAggregation("items", {
                    path: entityset,
                    factory: function() {
                        return new sap.m.ColumnListItem({
                            type: "Active",
                            cells: [

                                new sap.m.Text({
                                    text: firstCellBinding
                                }),
                                new sap.m.Text({
                                    text: secondCellBinding
                                })
                            ]
                        });
                    },
                    filters: oFilter

                });
            }

            oValueHelpDialog.update();

        },

		/**
		 * Define the structure of the functional location table   
		 * @private
		 */
        _defineTable: function(fragmentInstance, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
            var oValueHelpDialog, oTable, sTableType;

            // get the  table of the value dialog help   
            oValueHelpDialog = fragmentInstance;
            oTable = oValueHelpDialog.getTable();
            oTable.setEnableBusyIndicator(true);

            // Add the table columns' properties and binding 
            sTableType = this._returnControlName(oTable);

            if (sTableType === "sap.ui.table.Table") {
                this._addUiTableColumns(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding);

            }

            if (sTableType === "sap.m.Table") {
                this._addRespTableColumns(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding);
            }

        },

		/**
		 * change the label of the functional location filterBar search button from "lancer" to "rechercher" 
		 * @param {Object } oFilterBar filter bar  
		 * @private
		 */
        _changeSearchButtonLabel: function(oFilterBar) {
            var that = this;
            oFilterBar.addEventDelegate({
                "onAfterRendering": function(oEvent) {
                    var oResourceBundle, oButton;
                    oResourceBundle = that.getResourceBundle();
                    oButton = oEvent.srcControl._oSearchButton;
                    oButton.setText(oResourceBundle.getText("search"));
                }
            });
        },

		/**
		 * Set the default value for the status filter criteria 
		 * @private
         * @deprecated GMAO-527
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-527
         * Par : Alexandre PISSOTTE (APY)
         * Date : 14/12/2021
         * Motif : Coches statuts systèmes bloquées 
         * Depuis la version SAPUI5 1.97.0 il ne faut plus utiliser cette méthode
         * pour ajouter les items sélectionnées car le contrôle peut être invalidé.
         * Ici, cela provoque un freeze du composant.
         * Ticket SAP : 867915 / 2021 Fiori MultiCombox cannot unselect or select any items
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
		 */
        _setStatusFilterDefaultValue: function() {
            /*var oStatusFilter, that;
            oStatusFilter = this.getView().byId("statusComboBox");
            that = this;
			oStatusFilter.addEventDelegate({
				"onAfterRendering": function(oEvent) {
					oEvent.srcControl.setSelectedKeys(that.getModel("statutSysteme").getProperty("/selected"));
				}
			});*/
        },

		/**
		 * Redefine the structure of the functional location filterBar   
		 * @private
		 */
        _reDefineFilterBar: function(fragmentInstance) {
            var oValueHelpDialog, oFilterBar;

            // get the filter bar of the value dialog help   
            oValueHelpDialog = fragmentInstance;
            oFilterBar = oValueHelpDialog.getFilterBar();
            if (sap.ui.Device.system.phone) {
                oFilterBar.setShowGoOnFB(false);
            }
            //change the filter bar search button  label from "lancer" to "rechercher"
            this._changeSearchButtonLabel(oFilterBar);

        },

		/**
		 * add functional location filter bar ui table columns   
		 * @param{object} oTable filter bar table 
		 * @private
		 */
        _addUiTableColumns: function(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
            var oColumn;
            oColumn = new sap.ui.table.Column({
                label: new sap.m.Label({
                    text: this.getResourceBundle().getText(firsColumnName)
                }),
                template: new sap.m.Text().bindProperty("text", firstColumnBinding),
                sortProperty: firstColumnBinding,
                filterProperty: firstColumnBinding,
                width: "100px"
            });
            oTable.addColumn(oColumn);

            oColumn = new sap.ui.table.Column({
                label: new sap.m.Label({
                    text: this.getResourceBundle().getText(secondColumnName)
                }),
                template: new sap.m.Text().bindProperty("text", SecondColumnBinding),
                sortProperty: SecondColumnBinding,
                filterProperty: SecondColumnBinding,
                width: "100px"
            });
            oTable.addColumn(oColumn);
        },

		/**
		 * add functional location filter bar responsive table columns   
		 * @param{object} oTable filter bar table 
		 * @private
		 */
        _addRespTableColumns: function(oTable, firsColumnName, firstColumnBinding, secondColumnName, SecondColumnBinding) {
            var oColumn;
            oColumn = new sap.m.Column({
                header: new sap.m.Label({
                    text: this.getResourceBundle().getText(firsColumnName)
                }),
                template: new sap.m.Text().bindProperty("text", firstColumnBinding),
                sortProperty: firstColumnBinding,
                filterProperty: firstColumnBinding,
                width: "100px"
            });
            oTable.addColumn(oColumn);

            oColumn = new sap.m.Column({
                header: new sap.m.Label({
                    text: this.getResourceBundle().getText(secondColumnName)
                }),
                template: new sap.m.Text().bindProperty("text", SecondColumnBinding),
                sortProperty: SecondColumnBinding,
                filterProperty: SecondColumnBinding,
                width: "100px"
            });
            oTable.addColumn(oColumn);
        },

		/**
		 * return the control name  
		 * @param{object} oControl the control instance  
		 * @return {string} the control name 
		 * @private
		 */
        _returnControlName: function(oControl) {
            return oControl.getMetadata().getName();
        },

		/**
		 * value selection from search help  
		 * @param{Event} oEvent triggered when selecting a value 
		 * @private
		 */

        _onsearchHelpOkPress: function(oEvent, fragmentInstance, fragmentModel, propertyName, worklistModel) {
            var sPropertyValue, sProperty, oTable, sTableType, oBindingContext;
            switch (propertyName) {
                case "TPLNR":
                    this._setTokensValues(oEvent, "TPLNR", "functional-location");
                    break;
                case "EQUNR":
                    this._setTokensValues(oEvent, "EQUNR", "equipement");
                    break;
                default:
                    oTable = oEvent.getSource().getTable();
                    sTableType = this._returnControlName(oTable);

                    if (sTableType === "sap.ui.table.Table") {
                        //	sPropertyValue = oEvent.getParameter("tokens")[0].getKey();
                        sPropertyValue = oTable.getContextByIndex(oTable.getSelectedIndex()).getProperty(propertyName);
                    }

                    if (sTableType === "sap.m.Table") {
                        oBindingContext = oTable.getSelectedItem().getBindingContext(fragmentModel);
                        sPropertyValue = oBindingContext.getProperty(propertyName);

                    }
                    sProperty = "/" + propertyName;
                    this.getView().getModel(worklistModel).setProperty(sProperty, sPropertyValue);
            }

            this._closeFragmentInstance(fragmentInstance);
        },

        _setTokensValues: function(oEvent, sKey, sControlId) {
            var aTokens = oEvent.getParameter("tokens"),
                oMultiInput = this.getView().byId(sControlId);
            oMultiInput.removeAllTokens();
            for (var i = 0; i < aTokens.length; i++) {
                oMultiInput.addToken(aTokens[i]);
            }

        },
        onOrderNumberRefresh: function() {
            this.getView().getModel("Avis").setProperty("/AUFNR", "");
        },
        onWorkCenterRefresh: function() {
            this.getView().getModel("Avis").setProperty("/VAPLZ", "");
            this.getView().getModel("Avis").setProperty("/WAWRK", "");
            this.getView().byId("work-center").setValueState("Error");
        },
        onMaintenancePlantRefresh: function() {
            this.getView().getModel("Avis").setProperty("/SWERK", "");
        },

        /**
         * @deprecated GMAO-512
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-512
         * Par : Alexandre PISSOTTE (APY)
         * Date : 14/01/2022
         * Motif : Tri de la table des avis
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        /*onSortNotifPress: function() {
            if (!this._notifSortFragment) {
                this._notifSortFragment = this._instantiateFragment("grtgaz.puma.GestionDesAvis.view.fragments.notifSort");
            }
            this._notifSortFragment.open();
        },*/

        onNotifSortConfirmation: function(oEvent) {
            var oTable = this.getView().byId("notifications-table").getTable(),
                mParams = oEvent.getParameters(),
                oBinding = oTable.getBinding("items"),
                sPath,
                bDescending,
                oSorter;

            sPath = mParams.sortItem.getKey();
            bDescending = mParams.sortDescending;
            oSorter = new sap.ui.model.Sorter(sPath, bDescending);
            this.oSorter = oSorter;
            oBinding.sort(oSorter);
        },
        onMandFilterCriteriaChange: function(oEvent) {
            var sValueState = "None",
                sValueMessage = "",
                oTechObjModel = this.getModel("FunctionalLocation"),
                sInputName = oEvent.getSource().getProperty("name"),
                sValue = oTechObjModel.getProperty("/BEBER");

            if (sInputName === "BEBER") {
                sValue = oTechObjModel.getProperty("/INGRP");
            }

            if (!oEvent.getParameter("newValue") && !sValue) {
                sValueState = "Error";
                sValueMessage = this.getModel("i18n").getResourceBundle().getText("FilterCriteriaValueMessage");
            }
            oTechObjModel.setProperty("/FilterCriteriaStatueValue", sValueState);
            oTechObjModel.setProperty("/FilterCriteriaValueMessage", sValueMessage);
        }

    });
});
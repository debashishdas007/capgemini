/*global location*/
// jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../PumaFioriLibrary.grtgazpumaFioriLibrary");
jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.FunctionalLocationSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.MultiSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.table.CauseSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.table.DefaillanceSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.MultiSelectionMode");

sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/models",
    "../model/formatter",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/FunctionalLocationSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/MultiSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/table/CauseSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/table/DefaillanceSearchHelp",
    "sap/ui/core/Fragment"
], function(
	BaseController,
	JSONModel,
	History,
	models,
    formatter,
    EquipmentSearchHelp ,
    FunctionalLocationSearchHelp ,
    MultiSelectionMode,
    ObjectSimpleSelectionMode,
    CauseSearchHelp , 
   DefaillanceSearchHelp,
   Fragment
) {
	"use strict";

	return BaseController.extend("grtgaz.puma.GestionDesAvis.controller.AvisZP", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
             /*************************************** GMAO340 ******************************/
            // Implement the Navigation
            this.getOwnerComponent().getService("ShellUIService").then(function(oShellService) {
             oShellService.setBackNavigation(function() {
                 this.Unsaved_note = this.getView().byId("commentNotif").getValue();
               if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne|| this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general)
               {
                this._CheckUnsavedData("NAVBACK");
                return;
               }
               this._onNavBack();
            }.bind(this));
          }.bind(this));
            /*************************************** END GMAO340 ******************************/
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0,
					researchFuncLoc: ""
				}),
				oCompressionData = new JSONModel({
					ZZETAT_COMP: "",
					ZZDISPO: ""
				}),
				oFailureProfil = new JSONModel({
					FECOD: "",
					FECODEGRUPPE: "",
					URCOD: "",
					URCODEGRUPPE: ""
				}),
				oDate = new JSONModel({
					startDate: "",
					endDate: ""

				});
			var oCommentModel = new JSONModel();
			this.setModel(oCommentModel, "CommentModel");

			var oNotifCommentModel = new JSONModel();
			this.setModel(oNotifCommentModel, "NotifCommentModel");

			this.getRouter().getRoute("ZpDetails").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.setModel(oCompressionData, "CompressionData");
			this.setModel(oFailureProfil, "FailureProfil");
			this.setModel(oDate, "FailureDate");
			this.setModel(models.createTechnicalObjectSearchModel(), "TechnicalObjectSearchModel");
			this.setModel(models.createEquipementSearchModel(), "equipementSearchModel");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			var noteCreation = new JSONModel();
			this.setModel(noteCreation, "noteCreation");
			this.setModel(this.getOwnerComponent().getModel(), "");

		},

		onExit: function() {
			var aFragments = [this._oGroupStateValueHelp, this._oAvailImpactValueHelp, this._failureValueHelp, this._causeValueHelp, this._oAddNote,
				this._articleHelp, this._EquipementValueHelp, this._storeHelp, this._equipementClassHelp, this._technicalObjectHelp,
				this._pmPlannerGroupHelp, this._ClassFuncLocHelp, this._LocalisationPlantHelp, this._LocalisationHelp, this._OperatingSectorHelp
			];
			for (var i = 0; i < aFragments.length; i++) {
				if (aFragments[i]) {
					this._destroyFragmentInstance(aFragments[i]);
				}
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},
        // /**
		//  * Event handler for showing compression history - GMAO230.
		//  * Permet Accéder à l'historique données compression.
		//  * @public
		//  */
        // onShowCompressionHistory: function (oEvent) {
        //     var that = this;
        //     var oBindedAvis = oEvent.getSource().getBindingContext(),
        //         sNumAvis = oBindedAvis.getProperty("QMNUM"),
        //         oView = this.getView();
        //     if (!this._compressionHistoryPromise) {
        //         this._compressionHistoryPromise = Fragment.load({
        //             id: oView.getId(),
        //             name: "grtgaz.puma.GestionDesAvis.view.fragments.compressionHistory",
        //             controller: this
        //         }).then(function (oDialog) {
        //             oView.addDependent(oDialog);
        //             that._compressionHistoryDialog = oDialog;
        //             return oDialog;
        //         });
        //     }
        //     this._compressionHistoryPromise.then(function (oDialog) {
        //         oDialog.open();
        //     });

        // },
        // onCloseCompressionHistory : function(){
        //     this._compressionHistoryDialog.close();
        // },

		onFailureValueHelp: function() {
				var oFunctionalLocation = this.getView().byId("func-loc-ZP"),
				oEquipement = this.getView().byId("equipement-ZP"),
				oFailureInput = this.getView().byId("failure-code"),
				oCauseCode = this.getView().byId("cause-code"),
				oProfilModel = this.getView().getModel("FailureProfil");
			this._failureValueHelp = new DefaillanceSearchHelp(
				this,
				new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
					var sFailureCode = oObject.CODE,
						sFailureCodeGroup = oObject.CODEGRUPPE,
						sFailurelabel = oObject.KURZTEXT;

					oFailureInput.setValue(sFailurelabel);
					oProfilModel.setProperty("/FECOD", sFailureCode);
					oProfilModel.setProperty("/FECODEGRUPPE", sFailureCodeGroup);

					oCauseCode.setValue("");
					oProfilModel.setProperty("/URCOD", "");
                    oProfilModel.setProperty("/URCODEGRUPPE", "");
                    
                    this.Unsaved_panne = true;

				}.bind(this)),
				oFunctionalLocation.getValue(),
				oEquipement.getValue()
			);
			this._failureValueHelp.open();
		},

		

		onFailureLabelChange: function(oEvent) {
			if (oEvent.getParameter("value").length === 0) {

				this.getView().byId("failure-code").setValue("");
				this.getView().getModel("FailureProfil").setProperty("/FECOD", "");
				this.getView().getModel("FailureProfil").setProperty("/FECODEGRUPPE", "");

				this.getView().byId("cause-code").setValue("");
				this.getView().getModel("FailureProfil").setProperty("/URCOD", "");
                this.getView().getModel("FailureProfil").setProperty("/URCODEGRUPPE", "");
                this.Unsaved_panne = true ;
			}

		},

		

		//open cause value help dialog 
		onCauseValueHelp: function() {
			var oCause = this.getView().byId("cause-code"),
				oProfilModel = this.getView().getModel("FailureProfil"),
				LabelFailure = this.getView().byId("failure-code").getValue();

			if (!LabelFailure) {
				sap.m.MessageBox.error(
					this.getView().getModel("i18n").getResourceBundle().getText("noFailureSelected")

				);
				return;
			}

			this._causeValueHelp = new CauseSearchHelp(
				this,
				new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
					var sCauseCode = oObject.CODE,
						sCauseCodeGroup = oObject.CODEGRUPPE,
						sLabelCause = oObject.KURZTEXT;

					oCause.setValue(sLabelCause);
					oProfilModel.setProperty("/URCOD", sCauseCode);
                    oProfilModel.setProperty("/URCODEGRUPPE", sCauseCodeGroup);
                    this.Unsaved_panne = true ; 

				}.bind(this)),
				oProfilModel.getProperty("/FECODEGRUPPE"),
				oProfilModel.getProperty("/FECOD")

			);
			this._causeValueHelp.open();

		},

		

		onCauseLabelChange: function(oEvent) {
			if (oEvent.getParameter("value").length === 0) {

				this.getView().byId("cause-code").setValue("");
				this.getView().getModel("FailureProfil").setProperty("/URCOD", "");
                this.getView().getModel("FailureProfil").setProperty("/URCODEGRUPPE", "");
                this.Unsaved_panne = true;
			}
		},

		// //search an input value from a list of elements 
		// _searchElementFromSelectDialogList: function(oEvent, FilterName) {
		// 	var sValue, oFilter, oBinding;
		// 	sValue = oEvent.getParameter("value").toUpperCase();
		// 	oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
		// 	oBinding = oEvent.getSource().getBinding("items");
		// 	oBinding.filter([oFilter]);
		// },

		onStopSelectionChange: function(oEvent) {
            this.Unsaved_panne = true ;
			var isSelected, returnResponse;
			var startDay = this.getView().byId("pickerDatdebID").getDateValue();
			var endDay = this.getView().byId("pickerDateEndID").getDateValue();
			isSelected = oEvent.getParameter("selected");

			if (isSelected === false) {
				this.getView().byId("stopTimeInput").setValue("");
				this.getView().byId("failure-profil-save").setEnabled(true);
			} else {
				if (!startDay || !endDay) {
					sap.m.MessageBox.error(
						this.getView().getModel("i18n").getResourceBundle().getText("emptyDates")
					);
					this.getView().byId("stopTimeInput").setValue("");
					this.getView().byId("failure-profil-save").setEnabled(false);

				} else if (startDay && endDay && (startDay > endDay)) {
					sap.m.MessageBox.error(
						this.getView().getModel("i18n").getResourceBundle().getText("dateInconsistency")
					);
					this.getView().byId("stopTimeInput").setValue("");
					this.getView().byId("failure-profil-save").setEnabled(false);

				} else {
					this.getView().byId("stopTimeInput").setValue(this._calculateDatesdifference());
					this.getView().byId("failure-profil-save").setEnabled(true);
				}
			}

			// returnResponse = this._performDatesCheck(isSelected);

			// if (returnResponse === false) {
			// 	this.getView().byId("stopTimeInput").setValue("");
			// 	this.getView().byId("failure-profil-save").setEnabled(false);

			// 	return;
			// }

			// this.getView().byId("stopTimeInput").setValue(this._calculateDatesdifference());
			// this.getView().byId("failure-profil-save").setEnabled(true);
		},

		//calculate dates difference unit hour  
		_calculateDatesdifference: function() {
			var startDay, endDay, oneDay, def;

			startDay = this.getView().byId("pickerDatdebID").getDateValue();

			endDay = this.getView().byId("pickerDateEndID").getDateValue();

			oneDay = 1000 * 60 * 60;
			def = (endDay - startDay) / oneDay;
			return def.toFixed(2);
		},

		//verify check box selection and dates
		_performDatesCheck: function(isSelected) {
			var response = true;
			var startDay = this.getView().byId("pickerDatdebID").getDateValue();
			var endDay = this.getView().byId("pickerDateEndID").getDateValue();
			if (isSelected === false) {
				this.getView().byId("stopTimeInput").setValue("");

			} else {

				if (!startDay || !endDay) {
					sap.m.MessageBox.error(
						this.getView().getModel("i18n").getResourceBundle().getText("emptyDates")
					);

					response = false;
					return response;
				}

				if (startDay > endDay) {
					sap.m.MessageBox.error(
						this.getView().getModel("i18n").getResourceBundle().getText("dateInconsistency")
					);

					response = false;
					return response;
				}

			}
			return response;
		},
		onDateChange: function() {
			this.getView().byId("stopTimeInput").setValue("");
			this.getView().byId("stopInput").setSelected(false);
			var startDay = this.getView().byId("pickerDatdebID").getDateValue();
			var endDay = this.getView().byId("pickerDateEndID").getDateValue();

			if (endDay && (startDay > endDay)) {
				sap.m.MessageBox.error(
					this.getView().getModel("i18n").getResourceBundle().getText("dateInconsistency")
				);
				this.getView().byId("failure-profil-save").setEnabled(false);
			} else {
                this.getView().byId("failure-profil-save").setEnabled(true);
                this.Unsaved_panne = true;
			}

		},

		onFailureModificationSave: function() {
           
			sap.m.MessageBox.show(
				this.getView().getModel("i18n").getResourceBundle().getText("confirmationProfil"), {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: this.getView().getModel("i18n").getResourceBundle().getText("messageBoxConfirmation"),
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function(oAction) {
						switch (oAction) {
							case "YES":
                                this._saveProfilModification();
                                this.Unsaved_objtech = false ;
                                this.Unsaved_panne   = false ;
								break;
							case "NO":
								this.getView().getElementBinding().refresh(true);
								break;
							default:

						}
					}.bind(this)
				}
			);

		},

		/**
		 * Shows the selected item on the note detail page
		 * @param {jsObject} oObjectId selected item key 
		 * @private
		 */
		_showObject: function(oObjectId) {
			this.getRouter().navTo("noteDetails", oObjectId);
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").QMNUM;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("PMNotificationDetailsSet", {
					QMNUM: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				parameters: {
					expand: "ToNote"
				},

				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding(),
				aNotes = oElementBinding.getBoundContext().getProperty("ToNote");

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			//enable/disable add button 
			//	this._enableAddNoteButton(aNotes.length);

			// Everything went fine.
			oViewModel.setProperty("/busy", false);

			this._bindCompData(oElementBinding);
			this._bindNotifCommentList(oElementBinding.getBoundContext().getObject().QMNUM);

			this.getView().getModel("CompressionData").
			setProperty("/ZZETAT_COMP", oElementBinding.getBoundContext().getObject().ZZETAT_COMP);
			this.getView().getModel("CompressionData").
			setProperty("/ZZDISPO", oElementBinding.getBoundContext().getObject().ZZDISPO);

			this.getView().getModel("FailureProfil").
			setProperty("/FECOD", oElementBinding.getBoundContext().getObject().FECOD);
			this.getView().getModel("FailureProfil").
			setProperty("/URCOD", oElementBinding.getBoundContext().getObject().URCOD);

			this.getView().getModel("FailureProfil").
			setProperty("/FECODEGRUPPE", oElementBinding.getBoundContext().getObject().FEGRP);
			this.getView().getModel("FailureProfil").
			setProperty("/URCODEGRUPPE", oElementBinding.getBoundContext().getObject().URGRP);

			this.getView().getModel("FailureProfil").
			setProperty("/FECODEGRUPPE", oElementBinding.getBoundContext().getObject().FEGRP);
			this.getView().getModel("FailureProfil").
			setProperty("/URCODEGRUPPE", oElementBinding.getBoundContext().getObject().URGRP);

		},

		// _processDateChange: function(sDate) {
		// 	var sDateChange = sap.ui.core.format.DateFormat.getDateTimeInstance({
		// 			pattern: "dd.MM.yyyy HH:mm"
		// 		}).format(sDate).split(" "),
		// 		aDateTime = [];
		// 	// format date 
		// 	if (sDateChange[0]) {
		// 		aDateTime[0] = sDateChange[0].replace(".", "").replace(".", "");
		// 	} else {
		// 		aDateTime[0] = "00000000";
		// 	}
		// 	// format Time 
		// 	if (sDateChange[1]) {
		// 		aDateTime[1] = sDateChange[1].replace(":", "") + "00";
		// 	} else {
		// 		aDateTime[1] = "000000";
		// 	}
		// 	return aDateTime;

		// },

		_prepareCheckBox: function() {
			var sCheckBoxStop, sStop;
			sCheckBoxStop = this.getView().byId("stopInput").getSelected();
			if (sCheckBoxStop === true) {
				sStop = "X";
			} else {
				sStop = "";
			}
			return sStop;

		},

		_saveProfilModification: function() {
			var oObject, oModel, sPath, pickerDatdebID = [],
				pickerDateEndID = [],
				oGlobalBusyDialog;

			// Initialization part 
			oObject = this.getView().getBindingContext().getObject();
			oModel = this.getModel();
			sPath = this.getView().getBindingContext().getPath();
			oGlobalBusyDialog = new sap.m.BusyDialog();

			// prepare date for modification
			pickerDatdebID = this._processDateChange(this.getView().byId("pickerDatdebID").getDateValue());
			pickerDateEndID = this._processDateChange(this.getView().byId("pickerDateEndID").getDateValue());

			// fill the modified caracteristics
			oObject.FECOD = this.getView().getModel("FailureProfil").getProperty("/FECOD");
			oObject.TXTFECOD = this.getView().byId("failure-code").getValue();
			oObject.FEGRP = this.getView().getModel("FailureProfil").getProperty("/FECODEGRUPPE");
			oObject.URCOD = this.getView().getModel("FailureProfil").getProperty("/URCOD");
			oObject.TXTURCOD = this.getView().byId("cause-code").getValue();
			oObject.URGRP = this.getView().getModel("FailureProfil").getProperty("/URCODEGRUPPE");
			oObject.AUSVN = pickerDatdebID[0];
			oObject.AUZTV = pickerDatdebID[1];
			oObject.AUSBS = pickerDateEndID[0];
			oObject.AUZTB = pickerDateEndID[1];
			oObject.MSAUS = this._prepareCheckBox();
			oObject.AUSZT = this.getView().byId("stopTimeInput").getValue();
			oObject.ZZDISPO = "";
			oObject.ZZETAT_COMP = "";

			var sTPLNR = this.getView().byId("func-loc-ZP").getValue(),
				sEQUNR = this.getView().byId("equipement-ZP").getValue();

			if (oObject.TPLNR === sTPLNR) {
				oObject.TPLNR = "";
			} else {
				oObject.TPLNR = this.getView().byId("func-loc-ZP").getValue();
			}
			if (oObject.EQUNR === sEQUNR) {
				oObject.EQUNR = "";
			} else {
				oObject.EQUNR = this.getView().byId("equipement-ZP").getValue();
			}

			delete oObject.ToNote;

			oGlobalBusyDialog.open();
			oModel.update(sPath, oObject, {
				success: function(data, resp) {
					if (resp.headers["sap-message"]) {
						var message = $.parseJSON(resp.headers["sap-message"]).message;
						sap.m.MessageBox.warning(message);
					}
					this.getView().getElementBinding().refresh(true);
					this._bindCompData(this.getView().getElementBinding());
					oGlobalBusyDialog.close();
				}.bind(this),
				error: function(data, resp) {
					oGlobalBusyDialog.close();
				}
			});

		},

		//Equipement value help 
		onEquipementRequest: function() {
				
			var oEquipement = this.getView().byId("equipement-ZP"),
				oFuncloc = this.getView().byId("func-loc-ZP"),
				oFailureInput = this.getView().byId("failure-code"),
				oCauseCode = this.getView().byId("cause-code"),
				oProfilModel = this.getView().getModel("FailureProfil"),
				oBindingObject = this.getView().getBindingContext().getObject(),
				oFuncLocValue = oFuncloc.getValue();
			var oSimpleSelectMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
				oFuncloc.setValue(oObject.TPLNR);
				oFuncloc.setDescription(oObject.PLTXT);
				oEquipement.setValue(oObject.EQUNR);
                oEquipement.setDescription(oObject.EQKTX);
                this.Unsaved_objtech = true ; 

				if (oBindingObject.EQUNR !== oObject.EQUNR) {
					oFailureInput.setValue("");
					oProfilModel.setProperty("/FECOD", "");
					oProfilModel.setProperty("/FECODEGRUPPE", "");

					oCauseCode.setValue("");
					oProfilModel.setProperty("/URCOD", "");
					oProfilModel.setProperty("/URCODEGRUPPE", "");
				}

			}.bind(this));
			this._EquipementValueHelp = new EquipmentSearchHelp(this, oSimpleSelectMode, oFuncLocValue);
			this._EquipementValueHelp.open();

		},

				onFuncLocRequest: function() {
			var oFunctionLoc = this.getView().byId("func-loc-ZP"),
				oEquipement = this.getView().byId("equipement-ZP"),
				oFailureInput = this.getView().byId("failure-code"),
				oProfilModel = this.getView().getModel("FailureProfil"),
				oCauseCode = this.getView().byId("cause-code"),
				oBindingObject = this.getView().getBindingContext().getObject(),
                oFuncLocValue = oFunctionLoc.getValue(),
                that = this;

			var oSimpleSelectMode = new ObjectSimpleSelectionMode(new JSONModel(), function(oObject) {
				oFunctionLoc.setValue(oObject.TPLNR);
				oFunctionLoc.setDescription(oObject.PLTXT);
				oEquipement.setValue("");
                oEquipement.setDescription("");
                this.Unsaved_objtech = true;

				if (oBindingObject.TPLNR !== oObject.TPLNR) {
					oFailureInput.setValue("");
					oProfilModel.setProperty("/FECOD", "");
					oProfilModel.setProperty("/FECODEGRUPPE", "");

					oCauseCode.setValue("");
					oProfilModel.setProperty("/URCOD", "");
					oProfilModel.setProperty("/URCODEGRUPPE", "");
				}

			}.bind(this));
			this._technicalObjectHelp = new FunctionalLocationSearchHelp(this, oSimpleSelectMode, oFuncLocValue);

			this._technicalObjectHelp.open();
        },
        
        	_instantiateExternalFragment: function(FragmentName) {
			var oFragmentInstance;
			oFragmentInstance = this._instantiateFragment(FragmentName);
			oFragmentInstance.setModel(this.getModel("researchModel"), "researchModel");
			return oFragmentInstance;
        }
        
	});

});
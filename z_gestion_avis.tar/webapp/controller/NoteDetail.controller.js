/*global location*/
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter"
], function(
	BaseController,
	JSONModel,
	History,
	formatter
) {
	"use strict";

	return BaseController.extend("grtgaz.puma.GestionDesAvis.controller.NoteDetail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,

				oViewModel = new JSONModel({
					busy: true,
					delay: 0
				}),
				oCommentModel = new JSONModel();

			this.getRouter().getRoute("noteDetails").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();

			this.setModel(oCommentModel, "CommentModel");
			this.setModel(oViewModel, "noteDetailView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
			this.setModel(this.getOwnerComponent().getModel(), "");

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},
		/**
		 * Binds the view to the note detail path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'noteDetail'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var oObjectId = oEvent.getParameter("arguments");

			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("noteSet", {
					QMNUM: oObjectId.QMNUM,
					MANUM: oObjectId.ID
				});
				this._bindView("/" + sObjectPath, oObjectId);
			}.bind(this));
		},

		/**
		 * Binds the view to the note detail path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath, oObjectId) {
			var oViewModel = this.getModel("noteDetailView"),
				oCommentModel = this.getModel("CommentModel"),
				oDataModel = this.getModel(),
				aResults = [],
				oComment = {},
				oData = {},
				aComments = new Array(),
				model = new JSONModel(),
				sPath = oDataModel.sServiceUrl + sObjectPath + "/toComment";

			oData.QMNUM = oObjectId.QMNUM;
			oData.MANUM = oObjectId.ID;
			oCommentModel.setData(oData);

			model.loadData(sPath, null, false);
			aResults = model.getData().d.results;
			if (aResults.length !== 0) {
				oComment.TDFDATE = aResults[0].TDFDATE;
				oComment.TDFTIME = aResults[0].TDFTIME;
				oComment.TDFUSER = aResults[0].TDFUSER;
				oComment.TDFUSERFULL = aResults[0].TDFUSERFULL;
				oComment.TDLINE = aResults[0].TDLINE;

				for (var i = 1; i < aResults.length; i++) {
					if (oComment.TDFDATE === aResults[i].TDFDATE && oComment.TDFTIME === aResults[i].TDFTIME && oComment.TDFUSERFULL === aResults[i].TDFUSERFULL) {
						oComment.TDLINE = oComment.TDLINE + aResults[i].TDLINE;
					} else {
						aComments.push(oComment);
						oComment = {};
						oComment.TDFDATE = aResults[i].TDFDATE;
						oComment.TDFTIME = aResults[i].TDFTIME;
						oComment.TDFUSER = aResults[i].TDFUSER;
						oComment.TDFUSERFULL = aResults[i].TDFUSERFULL;
						oComment.TDLINE = aResults[i].TDLINE;
					}

				}

				aComments.push(oComment);

			}
			oData.commentSet = aComments;
			oCommentModel.setData(oData);
			this.getView().byId("commentList").bindItems({
				path: "CommentModel>/commentSet",
				
				factory: function() {
					return new sap.m.FeedListItem({
						text: "{CommentModel>TDLINE}",
						showIcon: false,
						sender: "{CommentModel>TDFUSERFULL}",
						timestamp: "{parts:[{path: 'CommentModel>TDFDATE'},{path: 'CommentModel>TDFTIME'}]}"

					});
				}
			});

			// this.getView().bindElement({
			// 	path: sObjectPath,
			// 	parameters: {
			// 		expand: "ToNote"
			// 	},

			// 	events: {
			// 		change: this._onBindingChange.bind(this),
			// 		dataRequested: function() {
			// 			oDataModel.metadataLoaded().then(function() {
			// 				// Busy indicator on view should only be set if metadata is loaded,
			// 				// otherwise there may be two busy indications next to each other on the
			// 				// screen. This happens because route matched handler already calls '_bindView'
			// 				// while metadata is loaded.
			// 				oViewModel.setProperty("/busy", true);
			// 			});
			// 		},
			// 		dataReceived: function() {
			// 			oViewModel.setProperty("/busy", false);

			// 		}.bind(this)
			// 	}
			// });
		},

		// operationFactory: function(sId, oContext) {
		// 	var oObject = oContext.getObject(),
		// 		oInitObject = {
		// 			"TDFDATE": "",
		// 			"TDFTIME": "",
		// 			"TDFUSER": ""
		// 		},
		// 		oListItem,
		// 		sCommentLength = this.getView().getBindingContext().getProperty("toComment").length,
		// 		sProcessedItem = this._calculateItemIndex(sId),
		// 		bIsInitial = this._isListItemEqualObject(oInitObject);

		// 	switch (bIsInitial) {

		// 		case true:
		// 			this._initializeListItem(oObject);
		// 			if (sCommentLength === 1) {
		// 				oListItem = this._createListeItem();
		// 			}
		// 			break;

		// 		case false:
		// 			oListItem = this._processListItem(oObject, sProcessedItem, sCommentLength);

		// 			break;

		// 		default:
		// 			break;

		// 	}
		// 	if (oListItem) {
		// 		return oListItem;
		// 	}

		// },

		// _calculateItemIndex: function(sID) {
		// 	var sIndex = sID.lastIndexOf("-"),
		// 		id = sID.slice(sIndex + 1, sID.length);
		// 	return id + 1;
		// },

		// _processListItem: function(oObject, sProcessedItem, sCommentLength) {
		// 	var oListItem;
		// 	if (this._isListItemEqualObject(oObject)) {
		// 		this._listItem.TDLINE = this._listItem.TDLINE + oObject.TDLINE;
		// 		if (sProcessedItem === sCommentLength) {
		// 			oListItem = this._createListeItem();
		// 		}
		// 	} else {
		// 		oListItem = this._createListeItem();
		// 		this._initializeListItem(oObject);
		// 	}

		// 	return oListItem;
		// },

		// _createListeItem: function() {
		// 	return new sap.m.FeedListItem({
		// 		text: this._listItem.TDLINE
		// 	});

		// },

		// _initializeListItem: function(oObject) {
		// 	this._listItem.TDFDATE = oObject.TDFDATE;
		// 	this._listItem.TDFTIME = oObject.TDFTIME;
		// 	this._listItem.TDFUSER = oObject.TDFUSER;
		// 	this._listItem.TDLINE = oObject.TDLINE;
		// },

		// _isListItemEqualObject: function(oObject) {
		// 	var bResult = false;
		// 	if (this._listItem.TDFDATE === oObject.TDFDATE && this._listItem.TDFTIME === oObject.TDFTIME && this._listItem.TDFUSER === oObject.TDFUSER) {
		// 		bResult = true;
		// 	}
		// 	return bResult;
		// },

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("noteDetailView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			// Everything went fine.
			oViewModel.setProperty("/busy", false);

		},

		onPost: function(oEvent) {
			var oObject = {},
				oModel, sComment, aCommentLines = [];
			sComment = oEvent.getParameter("value");

			oObject.QMNUM = this.getModel("CommentModel").getProperty("/QMNUM");
			oObject.MANUM = this.getModel("CommentModel").getProperty("/MANUM");
			oObject.LineSet = this._constructCommentLines(aCommentLines, sComment);

			oModel = this.getView().getModel("");
			oModel.create("/CommentSet", oObject, {
				success: function(data, resp) {
					if (resp.headers["sap-message"]) {
						var messageHeader = $.parseJSON(resp.headers["sap-message"]);
						var message = messageHeader.message;
						var severity = messageHeader.severity;
						if (severity === "error") {
							sap.m.MessageBox.error(message);
						} else {
							sap.m.MessageBox.information(message);
							var aLines = data.LineSet.results,
								sComment = "",
								oObject = {},
								aComments = new Array(),
								oData = {};

							if (aLines.length !== 0) {
								for (var i = 0; i < aLines.length; i++) {
									sComment = sComment + aLines[i].TDLINE;
								}
								oObject.TDFDATE = data.TDFDATE;
								oObject.TDFTIME = data.TDFTIME;
								oObject.TDFUSER = data.TDFUSER;
								oObject.TDFUSERFULL = data.TDFUSERFULL;
								oObject.TDLINE = sComment;
								aComments = this.getModel("CommentModel").getProperty("/commentSet");
								if (aComments) {
									aComments.push(oObject);
									oData.commentSet = aComments;
								} else {
									oData.commentSet = [oObject];
								}

								oData.QMNUM = this.getModel("CommentModel").getProperty("/QMNUM");
								oData.MANUM = this.getModel("CommentModel").getProperty("/MANUM");
								this.getModel("CommentModel").setData(oData);

							}

						}
					}
					this.getView().getModel("CommentModel").refresh();

				}.bind(this),
				error: function(data, resp) {

				}
			});

		}

	});

});
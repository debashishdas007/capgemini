/*global location*/
// jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../PumaFioriLibrary.grtgazpumaFioriLibrary");
jQuery.sap.registerModulePath("com/grtgaz/puma/fiori/zpumafiorilibrary", "../../com-grtgaz-puma-fiori-zpumafiorilibrary.comgrtgazpumafiorizpumafiorilibrary");

jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.combined.EquipmentSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.selectionMode.ObjectSimpleSelectionMode");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.VerificateurSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.TypeInspectionSearchHelp");
jQuery.sap.require("com/grtgaz/puma/fiori/zpumafiorilibrary.controller.searchHelp.unitary.IntervenantGRTSearchHelp");

sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/models",
    "../model/formatter",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/combined/EquipmentSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/selectionMode/ObjectSimpleSelectionMode",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/VerificateurSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/TypeInspectionSearchHelp",
    "com/grtgaz/puma/fiori/zpumafiorilibrary/controller/searchHelp/unitary/IntervenantGRTSearchHelp"
], function (
    BaseController,
    JSONModel,
    History,
    models,
    formatter,
    EquipmentSearchHelp,
    ObjectSimpleSelectionMode,
    VerificateurSearchHelp,
    TypeInspectionSearchHelp,
    IntervenantGRTSearchHelp
) {
    "use strict";

    /**
     * Contrôleur de la vue AvisZV
     *
     * @public
     * @class
     * @name grtgaz.puma.GestionDesAvis.controller.AvisZV
     * @extends BaseController
     * 
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * LISTE DE MODIFICATIONS
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     * Ticket : GMAO-322
     * Par : Alexandre PISSOTTE (APY)
     * Date : 04/08/2021
     * Motif : La recherche doit se faire en même temps sur code et désignation.
     * Attention, la condition logique utilisée entre le code et la désignation
     * est le ET/AND et non le OU/OR. Ainsi, les filtres sont remontées par l'
     * oData dans le paramètre IT_FILTER_SELECT_OPTIONS.
     * Le résultat de la recherche doit être pré-filtré sur la division et le
     * poste de travail.
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
     */
    return BaseController.extend("grtgaz.puma.GestionDesAvis.controller.AvisZV", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function () {
            /*************************************** GMAO340 ******************************/
            // Implement the Navigation
            this.getOwnerComponent().getService("ShellUIService").then(function (oShellService) {
                oShellService.setBackNavigation(function () {
                    if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne || this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general) {
                        this._CheckUnsavedData("NAVBACK");
                        return;
                    }
                    this._onNavBack();
                }.bind(this));
            }.bind(this));
            /*************************************** END GMAO340 ******************************/
            // Model used to manipulate control states. The chosen values make sure,
            // detail page is busy indication immediately so there is no break in
            // between the busy indication for loading the view's meta data
            var iOriginalBusyDelay,
                oViewModel = new JSONModel({
                    busy: true,
                    delay: 0,
                    mfgroup: ""
                });
           /************ GMAO-411 ***************/     
           var odate = new JSONModel();
           // odate.setProperty("/maxDate", new Date());
           // odate.setProperty("/initDate", new Date());
           this.setModel(odate, "dateModel");
           /************ End GMAO-411 ***************/   

            this.getRouter().getRoute("ZvDetails").attachPatternMatched(this._onObjectMatched, this);

            // Store original busy indicator delay, so it can be restored later on
            iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
            this.setModel(oViewModel, "objectView");
            this.getOwnerComponent().getModel().metadataLoaded().then(function () {
                // Restore original busy indicator delay for the object view
                oViewModel.setProperty("/delay", iOriginalBusyDelay);
            });

            var noteCreation = new JSONModel();
            this.setModel(noteCreation, "noteCreation");
            this.setModel(this.getOwnerComponent().getModel(), "");
            this.setModel(models.createTechnicalObjectSearchModel(), "TechnicalObjectSearchModel");
            this.setModel(models.createEquipementSearchModel(), "equipementSearchModel");

            this.getOwnerComponent().getModel("researchModel").attachBatchRequestCompleted(this._onBatchRequestCompleted, this);
            this.getOwnerComponent().getModel("researchModel").attachBatchRequestSent(this._onBatchRequestSent, this);
        },

        _onBatchRequestSent: function () {
            if (!this._oGlobalBusyIndicator) {
                this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            }
            this._oGlobalBusyIndicator.open();
        },

        _onBatchRequestCompleted: function () {
            this._oGlobalBusyIndicator.close();
        },

        onExit: function () {
            var aFragments = [this._addNonConformityCauseDialog, this._NonConformityCauseValueHelp, this._inspectorValueHelp,
            this._grtContributorValueHelp, this._inspectionTypeValueHelp, this._articleHelp, this._EquipementValueHelp, this._storeHelp,
            this._equipementClassHelp, this._technicalObjectHelp,
            this._pmPlannerGroupHelp, this._ClassFuncLocHelp, this._LocalisationPlantHelp, this._LocalisationHelp, this._OperatingSectorHelp
            ];
            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
        onNavBack: function () {
            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);
            }
        },

        onAddCauseButPress: function () {
            var oModel = new JSONModel({
                CODE: "",
                KURZTEXT: "",
                CODEGRUPPE: ""
            });

            if (!this._addNonConformityCauseDialog) {
                this._addNonConformityCauseDialog = this._instantiateFragment("grtgaz.puma.GestionDesAvis.view.fragments.causeAdd");
            }
            this._addNonConformityCauseDialog.open();
            this._addNonConformityCauseDialog.setModel(oModel, "nonConformityCauseAdd");
        },

        onConformityCauseValueHelp: function () {
            if (!this._NonConformityCauseValueHelp) {
                this._NonConformityCauseValueHelp = this._instantiateFragment("grtgaz.puma.GestionDesAvis.view.fragments.nonConformityCauseValueHelp");
            }
            this._NonConformityCauseValueHelp.open();
        },

        handleNonConformitySelection: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem").getBindingContext().getObject(),
                oConformityModel = this._addNonConformityCauseDialog.getModel("nonConformityCauseAdd"),
                sValue;

            oConformityModel.setProperty("/CODE", oSelectedItem.CODE);
            oConformityModel.setProperty("/KURZTEXT", oSelectedItem.KURZTEXT);
            oConformityModel.setProperty("/CODEGRUPPE", oSelectedItem.CODEGRUPPE);
            sValue = oSelectedItem.CODE + "(" + oSelectedItem.KURZTEXT + ") - " + oSelectedItem.CODEGRUPPE;
            sap.ui.getCore().byId("non-conformity-cause-add").setValue(sValue);
        },

        handleNonConformitySearch: function (oEvent) {
            this._searchElementFromSelectDialogList(oEvent, "CODE");
        },

        onNonConformityCauseClose: function () {
            this._addNonConformityCauseDialog.close();
        },

        onNonConformityCauseAdd: function () {
            var oConformityModel = this._addNonConformityCauseDialog.getModel("nonConformityCauseAdd"),
                sCode = oConformityModel.getProperty("/CODE"),
                oObject = {},
                oStartDate, oEndDate, aStartDate = [],
                aEndDate = [];

            if (!sCode) {
                sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("NoConformityCauseSelected"), {
                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default

                });
                return;
            }

            oStartDate = sap.ui.getCore().byId("start-date-conformity").getDateValue();
            if (oStartDate) {
                aStartDate = this._processDateChange(oStartDate);
                oObject.PSTER = aStartDate[0];
                oObject.PSTUR = aStartDate[1];
            }

            oEndDate = sap.ui.getCore().byId("end-date-conformity").getDateValue();
            if (oEndDate) {
                aEndDate = this._processDateChange(oEndDate);
                oObject.PETER = aEndDate[0];
                oObject.PETUR = aEndDate[1];
            }

            oObject.QMNUM = this.getView().getBindingContext().getObject().QMNUM;
            oObject.MFGRP = oConformityModel.getProperty("/CODEGRUPPE");
            oObject.MFCOD = sCode;
            oObject.TXTMFCOD = oConformityModel.getProperty("/KURZTEXT");
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();

            this.getModel().create("/NonComplianceCauseSet", oObject, {
                success: function (oData, response) {
                    if (response.headers["sap-message"]) {
                        var message = $.parseJSON(response.headers["sap-message"]).message;
                        sap.m.MessageBox.warning(message);
                    }
                    this.getView().getModel("").refresh();
                    oGlobalBusyDialog.close();
                    this._addNonConformityCauseDialog.close();
                }.bind(this),
                error: function (Error) {
                    oGlobalBusyDialog.close();
                }.bind(this)
            });
        },

        // open Fragment for inspector value help 
        onInspectorValueHelp: function () {
            if (!this._inspectorValueHelp) {
                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function (oObject) {
                    var oInspector = this.getView().byId("inspector");
                    oInspector.setValue(oObject.ZENTREPRISE);
                    oInspector.setDescription(oObject.ZLIBELLE);
                    this._enableDisableGrtContributor(oObject.ZENTREPRISE);
                    this.Unsaved_general = true;

                }.bind(this));

                this._inspectorValueHelp = new VerificateurSearchHelp(this, oObjectSelectionMode);
            }
            this._inspectorValueHelp.open();
        },

        _enableDisableGrtContributor: function (SInspector) {
            var sValue = SInspector.toUpperCase(),
                sEntreprise = this.getView().getModel("i18n").getResourceBundle().getText("GRT"),
                oContributorInput = this.getView().byId("grt-contributor");
            if (sValue.startsWith(sEntreprise)) {
                oContributorInput.setEnabled(true);
            } else {
                oContributorInput.setEnabled(false);
                oContributorInput.setValue("");
                oContributorInput.setDescription("");
            }
        },

        /**
         * GMAO-322 (APY) 04/08/2021
         * Destruction du fragment à chaque appel du fragment afin de s'assurer que le poste responsable et
         * la division passés soient les derniers sélectionnés
         */
        onGrtContributorValueHelp: function () {
            // GMAO-322
            if (this._grtContributorValueHelp) {
                this._destroyFragmentInstance(this._grtContributorValueHelp);
            }

            var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function (oObject) {
                var oContributor = this.getView().byId("grt-contributor");
                oContributor.setValue(oObject.PERNR);
                oContributor.setDescription(oObject.NACHN + " " + oObject.VORNA);
                this.Unsaved_general = true;

            }.bind(this));

            this._grtContributorValueHelp = new IntervenantGRTSearchHelp(this, oObjectSelectionMode,
                // GMAO-322 
                this.getView().getBindingContext().getProperty("ARBPL"),
                this.getView().getBindingContext().getProperty("WAWRK")
            );

            this._grtContributorValueHelp.open();
        },

        onInspectionTypeValueHelp: function () {
            if (!this._inspectionTypeValueHelp) {

                var oObjectSelectionMode = new ObjectSimpleSelectionMode(new JSONModel(), function (oObject) {
                    var oViewModel = this.getModel("objectView"),
                        oInspectionType = this.getView().byId("inspection-type");
                    oInspectionType.setValue(oObject.CODE);
                    oInspectionType.setDescription(oObject.KURZTEXT);
                    oViewModel.setProperty("/mfgroup", oObject.CODEGRUPPE);
                    this.Unsaved_general = true;

                }.bind(this));
                this._inspectionTypeValueHelp = new TypeInspectionSearchHelp(this, oObjectSelectionMode);
            }
            this._inspectionTypeValueHelp.open();
        },

        handleInspectionTypeSelection: function (oEvent) {
            var sSelectedItem = oEvent.getParameter("selectedItem").getBindingContext().getObject(),
                oViewModel = this.getModel("objectView"),
                oInspectionType = this.getView().byId("inspection-type");
            oInspectionType.setValue(sSelectedItem.CODE);
            oInspectionType.setDescription(sSelectedItem.KURZTEXT);
            oViewModel.setProperty("/mfgroup", sSelectedItem.CODEGRUPPE);

        },

        handleInspectionTypeSearch: function (oEvent) {
            this._searchElementFromSelectDialogList(oEvent, "CODE");
        },

        onDataCheckSave: function () {
            /****** GMAO-441 *******/
            var CompletionDay = this.getView().byId("completion-Date-time").getDateValue();
            var ActualDate = new Date();
            if (CompletionDay > ActualDate) {
                sap.m.MessageBox.error(
                    this.getView().getModel("i18n").getResourceBundle().getText("dateInconsistencyCompletion")
                );
            }
            else {
                /*******END GMAO-411 */
                sap.m.MessageBox.show(
                    this.getView().getModel("i18n").getResourceBundle().getText("DataCheckSave"), {
                    icon: sap.m.MessageBox.Icon.INFORMATION,
                    title: this.getView().getModel("i18n").getResourceBundle().getText("messageBoxConfirmation"),
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function (oAction) {
                        switch (oAction) {
                            case "YES":
                                this._saveGeneralData();
                                this.Unsaved_general = false;
                                this.Unsaved_objtech = false;
                                break;
                            case "NO":
                                this.getView().getElementBinding().refresh(true);
                                break;
                            default:

                        }
                    }.bind(this)
                }
                );
            }
        },

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
        _onObjectMatched: function (oEvent) {
            var sObjectId = oEvent.getParameter("arguments").QMNUM;
            this.getModel().metadataLoaded().then(function () {
                var sObjectPath = this.getModel().createKey("PMNotificationDetailsSet", {
                    QMNUM: sObjectId
                });
                this._bindView("/" + sObjectPath);
            }.bind(this));
        },

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
        _bindView: function (sObjectPath) {
            var oViewModel = this.getModel("objectView"),
                oDataModel = this.getModel();

            this.getView().bindElement({
                path: sObjectPath,
                parameters: {
                    expand: "ToNonComplianceCause"
                },
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oDataModel.metadataLoaded().then(function () {
                            // Busy indicator on view should only be set if metadata is loaded,
                            // otherwise there may be two busy indications next to each other on the
                            // screen. This happens because route matched handler already calls '_bindView'
                            // while metadata is loaded.
                            oViewModel.setProperty("/busy", true);
                        });
                    },
                    dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
                    }
                }
            });
        },

        _onBindingChange: function () {
            var oView = this.getView(),
                oViewModel = this.getModel("objectView"),
                oElementBinding = oView.getElementBinding();


            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("objectNotFound");
                return;
            }

            var oObject = oElementBinding.getBoundContext().getObject();

            this._enableDisableGrtContributor(oElementBinding.getBoundContext().getObject().ZENTREPRISE);

            // Everything went fine.
            oViewModel.setProperty("/busy", false);
            oViewModel.setProperty("/mfgroup", oElementBinding.getBoundContext().getObject().MFGRP);

            // this.getView().byId("completion-Date-time").setDateValue(this._prepareCompletionDate(oObject));




            this.getModel("dateModel").setProperty("/initDate", this._prepareCompletionDate(oObject));

        },
        _prepareCompletionDate: function (oObject) {
            var aDate = oObject.QMDAT.split("."),
                aTime = oObject.MZEIT.split(":"),
                oDate = new Date(aDate[2], aDate[1], aDate[0], aTime[0], aTime[1], aTime[2]);

            return oDate;

        },

        _enableDisableConformityStatus: function (sStatus) {
            if (sStatus === this.getView().getModel("i18n").getResourceBundle().getText("nonConformStatus")) {
                this.getView().byId("add-cause-button").setEnabled(true);
            } else {
                this.getView().byId("add-cause-button").setEnabled(false);
            }
        },

        _saveGeneralData: function () {
            var oObject, oModel, sPath, pickerCompletionDate = [],
                oGlobalBusyDialog, oInspectorInput, oGrtContributor, aName = [],
                oDateTime, oCheckResult, oDateValue,
                oConstat, oInspectionType;

            // Initialization part 
            oObject = this.getView().getBindingContext().getObject();
            if (!this.getView().byId("resultCheck").getSelectedItem()) {
                oCheckResult = "";
            } else {
                oCheckResult = this.getView().byId("resultCheck").getSelectedItem().getKey();
            }

            if (!this._verifyConformityCause(this.getView().byId("cause-table").getTable().getItems().length, oCheckResult)) {
                sap.m.MessageBox.show(
                    this.getView().getModel("i18n").getResourceBundle().getText("ErrorCauses"), {
                    icon: sap.m.MessageBox.Icon.ERROR,
                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error")

                }

                );
                return;
            }

            oInspectionType = this.getView().byId("inspection-type");
            if (!oInspectionType.getValue()) {
                sap.m.MessageBox.show(
                    this.getView().getModel("i18n").getResourceBundle().getText("inspectionTypeError"), {
                    icon: sap.m.MessageBox.Icon.ERROR,
                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error")

                }

                );
                return;
            }

            oDateTime = this.getView().byId("completion-Date-time").getDateValue(),
                oDateValue = this.getView().byId("completion-Date-time").getValue();

            if (!oDateTime && !oDateValue) {
                sap.m.MessageBox.show(
                    this.getView().getModel("i18n").getResourceBundle().getText("dateError"), {
                    icon: sap.m.MessageBox.Icon.ERROR,
                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error")

                }

                );
                return;
            }

            oModel = this.getModel();
            sPath = this.getView().getBindingContext().getPath();
            oInspectorInput = this.getView().byId("inspector");

            oGrtContributor = this.getView().byId("grt-contributor");
            oConstat = this.getView().byId("report-number-pv-checker");

            aName = oGrtContributor.getDescription().split(" ");

            oGlobalBusyDialog = new sap.m.BusyDialog();

            // prepare date for modification
            if (oDateTime) {
                pickerCompletionDate = this._processDateChange(oDateTime);
                oObject.QMDAT = pickerCompletionDate[0];
                oObject.MZEIT = pickerCompletionDate[1];
            }

            /*** GMAO-510 : Date could be entered manually , check its value ***********/
            else if (oDateValue) {
                pickerCompletionDate = oDateValue.split(" ");
                oObject.QMDAT = pickerCompletionDate[0];
                oObject.MZEIT = pickerCompletionDate[1];
            }
            /*** Ned GMAO-510 ********/

            oObject.ZENTREPRISE = oInspectorInput.getValue();
            oObject.ZLIBELLE = oInspectorInput.getDescription();

            oObject.PERNR = oGrtContributor.getValue();
            if (oGrtContributor.getDescription()) {
                oObject.NACHN = aName[0];
                oObject.VORNA = aName[1];
            } else {
                oObject.NACHN = "";
                oObject.VORNA = "";
            }

            var sTPLNR = this.getView().byId("func-loc-ZV").getValue(),
                sEQUNR = this.getView().byId("equipement-ZV").getValue();

            if (sTPLNR && sTPLNR !== oObject.TPLNR) {
                oObject.TPLNR = sTPLNR;
            }

            if (sEQUNR && sEQUNR !== oObject.EQUNR) {
                oObject.EQUNR = sEQUNR;
            }

            oObject.ZCONSTAT = oConstat.getValue();

            oObject.MFGRP = this.getModel("objectView").getProperty("/mfgroup");
            oObject.MFCOD = oInspectionType.getValue();
            oObject.TXTMFCOD = oInspectionType.getDescription();

            oObject.USERSTATUS = oCheckResult;

            delete oObject.ToNonComplianceCause;
            delete oObject.ToNote;
            oGlobalBusyDialog.open();
            oModel.update(sPath, oObject, {
                success: function (data, resp) {
                    if (resp.headers["sap-message"]) {
                        var message = $.parseJSON(resp.headers["sap-message"]).message;
                        sap.m.MessageBox.warning(message);
                    }
                    this.getView().getElementBinding().refresh(true);
                    oGlobalBusyDialog.close();

                }.bind(this),
                error: function (data, resp) {
                    oGlobalBusyDialog.close();
                }
            });
        },
        _verifyConformityCause: function (oConformityCausesLength, sResultCheck) {
            var bResult = true;
            if (sResultCheck === "E0003" && oConformityCausesLength === 0) {
                bResult = false;
            }
            return bResult;
        },
        _checkInspectorIsNotNull: function () {
            var bNotNull = true;
            var inspectorInputValue = this.getView().byId("inspector").getValue();
            if (inspectorInputValue === undefined || inspectorInputValue === null || inspectorInputValue === "") {
                bNotNull = false;
            }
            return bNotNull;
        },

        _checkResultCheckIsNotNull: function () {
            var bNotNull = true;
            var ResultCheckInputValue = this.getView().byId("resultCheck").getSelectedKey();
            if (ResultCheckInputValue === undefined || ResultCheckInputValue === null || ResultCheckInputValue === "") {
                bNotNull = false;
            }
            return bNotNull;
        },
        _showUpdateEquipementStatusRequest: function (oContext) {
            sap.m.MessageBox.show(
                this.getView().getModel("i18n").getResourceBundle().getText("equipementStatusUpdate"), {
                icon: sap.m.MessageBox.Icon.INFORMATION,
                title: this.getView().getModel("i18n").getResourceBundle().getText("messageBoxConfirmation"),
                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                onClose: function (oAction) {
                    switch (oAction) {
                        case "YES":
                            this._terminateNotification(oContext, true);
                            break;
                        case "NO":
                            this._terminateNotification(oContext, false);
                            break;
                        default:

                    }
                }.bind(this)
            }
            );
        },

        _terminateNotification: function (oContext, bValue) {
            var Notification = {
                // "EQUI_USERSTATUS": oContext.EQUI_USERSTATUS,     // GMAO-356 (APY) 11/06/2021
                "QMNUM": oContext.QMNUM,
                // "USERSTATUS": oContext.USERSTATUS,               // GMAO-356 (APY) 11/06/2021
                "ZZ_MAJ_EQUI": bValue
            };

            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();
            this.getView().getModel().callFunction("/TerminateNotif", // function import name
                {
                    method: "GET", // http method
                    urlParameters: Notification, // function import parameters
                    context: null,
                    success: function (oData, response) { // callback function for success
                        this._oGlobalBusyIndicator.close();
                        if (response.headers["sap-message"]) {
                            var oResponse = $.parseJSON(response.headers["sap-message"]);
                            if (oResponse.severity === "success") {
                                sap.m.MessageBox.success(this.getView().getModel("i18n").getResourceBundle().getText("TerminateSuccess"), {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("success"),
                                    onClose: function () {
                                        this.getView().getModel().refresh();
                                    }.bind(this)

                                });
                            } else {
                                sap.m.MessageBox.error(oResponse.message, {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default

                                });
                            }
                        }
                    }.bind(this),
                    error: function (oError) { // callback function for error
                        this._oGlobalBusyIndicator.close();
                    }
                }
            );
        },

        onEndButtonPress: function () {
            if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne || this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general) {
                this._CheckUnsavedData_Close().
                    return;
            }
            var oContext = this.getView().getBindingContext().getObject();

            // verify if inspector is not null  
            if (!this._checkInspectorIsNotNull()) {
                sap.m.MessageBox.warning(this.getModel("i18n").getResourceBundle().getText("inspectorWarning"));
                return;
            }

            // verify if result check is not null  
            if (!this._checkResultCheckIsNotNull()) {
                sap.m.MessageBox.warning(this.getModel("i18n").getResourceBundle().getText("resultCheckWarning"));
                return;
            }

            // case Notificaction Status CONF OR NCNF
            if (oContext.USERSTATUS === "E0002" || oContext.USERSTATUS === "E0003") {
                this._terminateNotification(oContext, true);
                return;
            }

            // case Notification status CNFT Equipement CONF
            if (oContext.USERSTATUS === "E0001" && oContext.EQUI_USERSTATUS === "E0010") {
                this._terminateNotification(oContext, false);
                return;
            }

            //case notification status CNFT equip status undefined or NCNF 
            if ((oContext.EQUI_USERSTATUS === "E0011" || oContext.EQUI_USERSTATUS === "") && oContext.USERSTATUS === "E0001") {
                this._showUpdateEquipementStatusRequest(oContext);
            } else {
                this._terminateNotification(oContext, false);
            }
        },

        //Equipement value help 
        onEquipementRequest: function () {
            var oEquipement = this.getView().byId("equipement-ZV"),
                oFuncloc = this.getView().byId("func-loc-ZV"),
                oFuncLocValue = oFuncloc.getValue();
            var oSimpleSelectMode = new ObjectSimpleSelectionMode(new JSONModel(), function (oObject) {
                oFuncloc.setValue(oObject.TPLNR);
                oFuncloc.setDescription(oObject.PLTXT);
                oEquipement.setValue(oObject.EQUNR);
                oEquipement.setDescription(oObject.EQKTX);
                this.Unsaved_objtech = true;
            }.bind(this));
            this._EquipementValueHelp = new EquipmentSearchHelp(this, oSimpleSelectMode, oFuncLocValue);
            this._EquipementValueHelp.open();

        },
        _instantiateExternalFragment: function (FragmentName) {
            var oFragmentInstance;
            oFragmentInstance = this._instantiateFragment(FragmentName);
            oFragmentInstance.setModel(this.getModel("researchModel"), "researchModel");
            return oFragmentInstance;
        },
        /********************************* GMAO340 ************************************/
        onPVchecker: function () {
            this.Unsaved_general = true;
        },
        onDateChange: function () {
            this.Unsaved_general = true;
            /****** GMAO-441 *******/
            var CompletionDay = this.getView().byId("completion-Date-time").getDateValue();
            /*** GMAO-510 : Date could be entered manually , check its value ***********/
            if (CompletionDay == null) {
                var CompletionDayValue = this.getView().byId("completion-Date-time").getValue();
                var CompletionDayValueParts = CompletionDayValue.split(" ");
                var aDate = CompletionDayValueParts[0].split(".");
                var aTime = CompletionDayValueParts[1].split(":");
                if (aDate[2] == undefined || aDate[1] == undefined || aDate[0] == undefined || aTime[0] == undefined || aTime[1] == undefined) {
                    this.byId("completion-Date-time").setValueState("Error");
                    return;
                }
                CompletionDay = new Date(aDate[2], aDate[1] - 1, aDate[0], aTime[0], aTime[1]);
            }
            /****End GMAO510 ***********/
            var ActualDate = new Date();

            if (CompletionDay > ActualDate) {
                this.byId("completion-Date-time").setValueState("Error");
                sap.m.MessageBox.error(
                    this.getView().getModel("i18n").getResourceBundle().getText("dateInconsistencyCompletion")
                );
            }
            else {
                this.byId("completion-Date-time").setValueState("Success");
            }
            /*******END GMAO-411 */
        },
        onDateNavigate : function(oEvent){
            oEvent.getSource()._oOKButton.setEnabled(true);
        },
        onSelectionChange: function () {
            this.Unsaved_general = true;
        },
        _CheckUnsavedData_Close: function () {

            var oResourceBundle = this.getModel("i18n").getResourceBundle();
            var sPopUpMessage = oResourceBundle.getText("UnsavedData");
            var oIcon = sap.m.MessageBox.Icon.WARNING;

            var sPopUpTitle = "Sauvegardez ";

            if (this.Unsaved_comp) { sPopUpTitle = sPopUpTitle + "Données de Compression "; }
            if (this.Unsaved_objtech) { sPopUpTitle = sPopUpTitle + "Objets Techniques "; }
            if (this.Unsaved_panne) { sPopUpTitle = sPopUpTitle + "Profil Panne "; }
            if (this.Unsaved_mop) { sPopUpTitle = sPopUpTitle + "Annexe MOP "; }
            if (this.Unsaved_general) { sPopUpTitle = sPopUpTitle + "Données Générales "; }


            sap.m.MessageBox.show(sPopUpMessage, {
                title: sPopUpTitle,
                icon: oIcon,
                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                onClose: this._handleMessagesaveClose.bind(this)
            });
        },
        _handleMessagesaveClose: function (oAction) {
            if (oAction === sap.m.MessageBox.Action.CANCEL) {
                this.sSource = "";
                return;
            }
            /*Clear the flags of unsaved data */
            this.Unsaved_objtech = false;
            this.Unsaved_note = false;
            this.Unsaved_panne = false;
            this.Unsaved_comp = false;
            this.Unsaved_mop = false;
            this.Unsaved_general = false;
            /*Proceed the Navigation */
            this._endButtonPress();

        },
        _endButtonPress: function () {
            var oContext = this.getView().getBindingContext().getObject();

            // verify if inspector is not null  
            if (!this._checkInspectorIsNotNull()) {
                sap.m.MessageBox.warning(this.getModel("i18n").getResourceBundle().getText("inspectorWarning"));
                return;
            }

            // verify if result check is not null  
            if (!this._checkResultCheckIsNotNull()) {
                sap.m.MessageBox.warning(this.getModel("i18n").getResourceBundle().getText("resultCheckWarning"));
                return;
            }

            // case Notificaction Status CONF OR NCNF
            if (oContext.USERSTATUS === "E0002" || oContext.USERSTATUS === "E0003") {
                this._terminateNotification(oContext, true);
                return;
            }

            // case Notification status CNFT Equipement CONF
            if (oContext.USERSTATUS === "E0001" && oContext.EQUI_USERSTATUS === "E0010") {
                this._terminateNotification(oContext, false);
                return;
            }

            //case notification status CNFT equip status undefined or NCNF 
            if ((oContext.EQUI_USERSTATUS === "E0011" || oContext.EQUI_USERSTATUS === "") && oContext.USERSTATUS === "E0001") {
                this._showUpdateEquipementStatusRequest(oContext);
            } else {
                this._terminateNotification(oContext, false);
            }
        },




    });
});
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "sap/m/library",
    "sap/ui/core/routing/History",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox",
    "grtgaz/puma/GestionDesAvis/model/formatter"
], function(Controller, UIComponent, JSONModel, mobileLibrary, History, Fragment, MessageBox, formatter) {
    "use strict";

    // shortcut for sap.m.URLHelper
    var URLHelper = mobileLibrary.URLHelper;

    return Controller.extend("grtgaz.puma.GestionDesAvis.controller.BaseController", {

        /**
         * Formatteurs
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-561
         * Par : Alexandre PISSOTTE (APY)
         * Date : 25/01/2022
         * Motif : Pas de date de fin génère pleins de zéro à la sauvegarde
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        formatter: formatter,

        constructor: function(sName) {
            Controller.call(this, sName); // Appel le contructeur parent de Controller

            this.Unsaved_objtech = false;
            this.Unsaved_note = false;
            this.Unsaved_panne = false;
            this.Unsaved_comp = false;
            this.Unsaved_mop = false;
            this.Unsaved_general = false;

        },
        /**
        * Called when the worklist controller is instantiated.
        * @public
        */
        onInit: function() {
            this.getOwnerComponent().getService("ShellUIService").then(function(oShellService) {
                oShellService.setBackNavigation(function() {
                    //   this.Unsaved_note = this.getView().byId("commentNotif").getValue();
                    if (this.getView().byId("commentNotif")) { this.Unsaved_note = this.getView().byId("commentNotif").getValue(); }
                    else { this.Unsaved_note = false; }
                    if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne || this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general) {
                        this._CheckUnsavedData("NAVBACK");
                        return;
                    }
                    this._onNavBack();
                }.bind(this));
            });
        },
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
        getRouter: function() {
            return UIComponent.getRouterFor(this);
        },

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
        getModel: function(sName) {
            return this.getView().getModel(sName);
        },

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
        setModel: function(oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
        getResourceBundle: function() {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
        onShareEmailPress: function() {
            var oViewModel = (this.getModel("objectView") || this.getModel("worklistView"));
            URLHelper.triggerEmail(
                null,
                oViewModel.getProperty("/shareSendEmailSubject"),
                oViewModel.getProperty("/shareSendEmailMessage")
            );
        },




        /**
		 * instantiate the fragment and return the fragment instance 
		 * @param {string} FragmentName : name of the fragment
		 * @return {xmlfragment} instance of the fragment
		 * @private
		 */
        _instantiateFragment: function(FragmentName) {
            var oFragmentInstance;
            oFragmentInstance = new sap.ui.xmlfragment(FragmentName, this);
            this.getView().addDependent(this.oFragmentInstance);
            oFragmentInstance.setModel(this.getView().getModel("i18n"), "i18n");
            oFragmentInstance.setModel(this.getView().getModel(""));
            return oFragmentInstance;
        },

		/**
		 * destroy the fragment instance using the name  
		 * @param {string} FragmentInstance: instance of the fragment
		 * @private
		 */
        _destroyFragmentInstance: function(FragmentInstance) {
            var oFragmentInstance = FragmentInstance;
            oFragmentInstance.destroy();
        },

		/**
		 * close the fragment instance using the name  
		 * @param {string} FragmentInstance: instance of the fragment
		 * @private
		 */
        _closeFragmentInstance: function(FragmentInstance) {
            var oFragmentInstance = FragmentInstance;
            oFragmentInstance.close();
        },

        // onNavBack: function() {
        // 	var sPreviousHash = History.getInstance().getPreviousHash(),
        // 		oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

        // 	if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
        // 		history.go(-1);
        // 	} else {
        // 		this.getRouter().navTo("worklist", {}, true);
        // 	}
        // },

        //search an input value from a list of elements 
        _searchElementFromSelectDialogList: function(oEvent, FilterName) {
            var sValue, oFilter, oBinding;
            sValue = oEvent.getParameter("value").toUpperCase();
            oFilter = new sap.ui.model.Filter(FilterName, sap.ui.model.FilterOperator.Contains, sValue);
            oBinding = oEvent.getSource().getBinding("items");
            oBinding.filter([oFilter]);
        },

        onOrderPress: function(oEvent) {
            if (this.getView().byId("commentNotif")) { this.Unsaved_note = this.getView().byId("commentNotif").getValue(); }
            else { this.Unsaved_note = false; }
            // this.Unsaved_note = this.getView().byId("commentNotif").getValue();
            if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne || this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general) //this.Unsaved)
            {
                this._CheckUnsavedData("ORDER");
                return;
            }
            var sOrder = oEvent.getSource().getText(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZGESTION_OT",
                        action: "display"
                    },
                    params: {
                        "AUFNR": sOrder
                    }

                })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	

        },

        onMesurePointPress: function() {
            if (this.getView().byId("commentNotif")) { this.Unsaved_note = this.getView().byId("commentNotif").getValue(); }
            else { this.Unsaved_note = false; }
            if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne || this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general) //this.Unsaved)
            {
                this._CheckUnsavedData("MEASUREMENTPOINTS");
                return;
            }
            var oObject = this.getView().getBindingContext().getObject(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZPTS_DE_MESURE",
                        action: "display"
                    },
                    params: {
                        "QMNUM": oObject.QMNUM,
                        "QMTXT": oObject.QMTXT,
                        "QMART": oObject.QMART
                    }

                })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	
        },

        onGroupStateValueHelp: function() {
            if (!this._oGroupStateValueHelp) {
                this._oGroupStateValueHelp = this._instantiateFragment(
                    "grtgaz.puma.GestionDesAvis.view.fragments.groupStateHelp");
            }

            this._oGroupStateValueHelp.open();
        },

        handleGroupStateSelection: function(oEvent) {
            this.getView().byId("group-state").setValue(oEvent.getParameter("selectedItem").getTitle());
            this.getView().getModel("CompressionData").setProperty("/ZZETAT_COMP", oEvent.getParameter("selectedItem").getDescription());

        },
        handleImpactDispoSelection: function(oEvent) {
            this.getView().byId("impact-dispo").setValue(oEvent.getParameter("selectedItem").getTitle());
            this.getView().getModel("CompressionData").setProperty("/ZZDISPO", oEvent.getParameter("selectedItem").getDescription());
        },

        onAvailImpactValueHelp: function() {
            if (!this._oAvailImpactValueHelp) {
                this._oAvailImpactValueHelp = this._instantiateFragment(
                    "grtgaz.puma.GestionDesAvis.view.fragments.impactDispoHelp");
            }

            this._oAvailImpactValueHelp.open();
        },

        onSaveModification: function() {
            var bResult;

            bResult = this._isModified();

            if (bResult) {
                sap.m.MessageBox.show(
                    this.getView().getModel("i18n").getResourceBundle().getText("confirmation"), {
                    icon: sap.m.MessageBox.Icon.INFORMATION,
                    title: this.getView().getModel("i18n").getResourceBundle().getText("messageBoxConfirmation"),
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                    onClose: function(oAction) {
                        switch (oAction) {
                            case "YES":
                                this._saveNotifModification();
                                break;
                            case "NO":
                                this.getView().getElementBinding().refresh(true);
                                break;
                            default:

                        }
                    }.bind(this)
                }
                );
            } else {
                sap.m.MessageBox.warning(this.getView().getModel("i18n").getResourceBundle().getText("sameData"));
            }

        },

        onAddNoteButPress: function() {

            if (!this._oAddNote) {
                this._oAddNote = this._instantiateFragment(
                    "grtgaz.puma.GestionDesAvis.view.fragments.addNote");

                this._oAddNote.setModel(this.getView().getModel("noteCreation"), "noteCreation");

            }

            // initialise creation model for each creation 
            this.getView().getModel("noteCreation").setData({
                "Description": "",
                "Comment": ""
            });

            // set the state for the description input
            sap.ui.getCore().byId("note-description").setValueState("Error");

            // set the create button to disabled 
            sap.ui.getCore().byId("create-note").setEnabled(false);

            this._oAddNote.open();
        },

        onNoteDescriptionChange: function(oEvent) {
            var value = oEvent.getParameter("value");
            if (value.length === 0) {
                oEvent.getSource().setValueState("Error");
                sap.ui.getCore().byId("create-note").setEnabled(false);
            } else {
                oEvent.getSource().setValueState("None");
                sap.ui.getCore().byId("create-note").setEnabled(true);
            }
        },

        onCancelButPress: function() {
            this._closeFragmentInstance(this._oAddNote);
        },

        onCreateNoteButPress: function() {
            var oObject = {},
                aCommentLines = [],
                sComment, oModel, oNoteCreationObject, oBindingObject;

            oNoteCreationObject = this.getView().getModel("noteCreation").getData();
            oBindingObject = this.getView().getBindingContext().getObject();

            oObject.QMNUM = oBindingObject.QMNUM;
            oObject.MATXT = oNoteCreationObject.Description;

            sComment = oNoteCreationObject.Comment;
            if (sComment) {
                oObject.LineSet = this._constructCommentLines(aCommentLines, sComment);
            } else {
                oObject.LineSet = new Array([]);
            }

            oModel = this.getView().getModel("");
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();
            oModel.create("/noteSet", oObject, {
                success: function(data, resp) {
                    if (resp.headers["sap-message"]) {
                        var message = $.parseJSON(resp.headers["sap-message"]).message;
                        sap.m.MessageBox.warning(message);
                    }
                    this.getView().getElementBinding().refresh(true);
                    this._closeFragmentInstance(this._oAddNote);
                    oGlobalBusyDialog.close();
                }.bind(this),
                error: function(data, resp) {
                    oGlobalBusyDialog.close();
                }
            });

        },

        onBeforeRebindTable: function(oEvent) {

            //	this.getView().getElementBinding().refresh(true);
            //			this._enableAddNoteButton();

        },

        onDelNoteButPress: function() {
            var oNotePath, aSelectedItem;
            aSelectedItem = this.getView().byId("note-table").getTable().getSelectedItem();
            if (aSelectedItem) {
                oNotePath = aSelectedItem.getBindingContext().getPath();
                this._deleteNote(oNotePath);
            } else {
                sap.m.MessageBox.warning(this.getView().getModel("i18n").getResourceBundle().getText("selectionError"));
            }
        },

        _constructCommentLines: function(aCommentLines, sComment) {
            var aLines = aCommentLines;

            if (sComment.length <= 132) {
                aLines.push(this._createObjectTable(sComment));
            } else {
                aLines.push(this._createObjectTable(sComment.slice(0, 131)));
                aLines = this._constructCommentLines(aLines, sComment.slice(132, sComment.length));
            }
            return aLines;
        },

        _createObjectTable: function(sString) {
            var oObject = {};
            if (sString) {
                oObject.TDLINE = sString;
            }
            return oObject;

        },

		/**
		 * Check if compression data has changed 
		 * @return {Boolean} bResult modification flag    
		 * @private
		 */
        _isModified: function() {
            var oObject, sImpactDispo, sGroupState, bResult = true;

            // Get values of the compression data 
            oObject = this.getView().getBindingContext().getObject();
            sGroupState = this.getView().byId("group-state").getValue();
            sImpactDispo = this.getView().byId("impact-dispo").getValue();

            //compare values of the inputs with their binding context  
            if ((oObject.ZZDISPO_T === sImpactDispo) && (oObject.ZZETAT_COMP_T === sGroupState)) {
                bResult = false;
            }
            return bResult;
        },

		/**
		 * save the notification modification  
		 * @function
		 * @private
		 */
        _saveNotifModification: function() {
            var oObject, oModel, sPath, sImpactDispo, sGroupState, sGroupStateText, sImpactDispoText;

            // Get the new values of compression data 
            sGroupState = this.getView().getModel("CompressionData").getProperty("/ZZETAT_COMP");
            sImpactDispo = this.getView().getModel("CompressionData").getProperty("/ZZDISPO");
            sGroupStateText = this.getView().byId("group-state").getValue();
            sImpactDispoText = this.getView().byId("impact-dispo").getValue();

            //change the compression data in the object 
            oObject = this.getView().getBindingContext().getObject();
            oObject.ZZDISPO = sImpactDispo;
            oObject.ZZETAT_COMP = sGroupState;
            oObject.ZZETAT_COMP_T = sGroupStateText;
            oObject.ZZDISPO_T = sImpactDispoText;
            oObject.AUZTV = oObject.AUZTV.replace(":", "").replace(":", "");
            oObject.AUZTB = oObject.AUZTB.replace(":", "").replace(":", "");
            delete oObject.ToNote;

            oModel = this.getModel();
            sPath = this.getView().getBindingContext().getPath();
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();
            oModel.update(sPath, oObject, {
                success: function(data, resp) {
                    if (resp.headers["sap-message"]) {
                        var message = $.parseJSON(resp.headers["sap-message"]).message;
                        sap.m.MessageBox.warning(message);
                    }
                    this.getView().getModel("").refresh();
                    oGlobalBusyDialog.close();
                }.bind(this),
                error: function(data, resp) {
                    oGlobalBusyDialog.close();
                }
            });

        },

		/**
		 * delete internal note from the notification 
		 * @function
		 * @param {string} sPath note path 
		 * @private
		 */
        _deleteNote: function(sPath) {
            var oModel;
            oModel = this.getModel();
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();
            oModel.remove(sPath, {
                success: function(oData, oresp) {
                    if (oresp.headers["sap-message"]) {
                        var messageHeader = $.parseJSON(oresp.headers["sap-message"]);
                        var message = messageHeader.message;
                        var severity = messageHeader.severity;
                        if (severity === "error") {
                            sap.m.MessageBox.error(message);
                        } else {
                            sap.m.MessageBox.information(message);
                        }

                    }

                    this.getView().getElementBinding().refresh(true);
                    oGlobalBusyDialog.close();
                }.bind(this),
                error: function(oError) {
                    oGlobalBusyDialog.close();
                }
            });
        },
        _enableAddNoteButton: function(sLength) {

            if (sLength === 0) {
                this.getView().byId("add-note-button").setEnabled(true);
            } else {
                this.getView().byId("add-note-button").setEnabled(false);
            }

        },
        onPress: function(oEvent) {
            this._showNoteDetail(this._prepareObjectId(oEvent));
        },

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @return{object}  key object for navigation 
		 * @public
		 */
        _prepareObjectId: function(oEvent) {
            var oObject, oObjectId = {};
            oObject = oEvent.getParameter("listItem").getBindingContext().getObject();
            oObjectId.QMNUM = oObject.QMNUM;
            oObjectId.ID = oObject.MANUM;
            return oObjectId;

        },
		/**
		 * Shows the selected item on the note detail page
		 * @param {jsObject} oObjectId selected item key 
		 * @private
		 */
        _showNoteDetail: function(oObjectId) {
            this.getRouter().navTo("noteDetails", oObjectId);
        },
        _processDateChange: function(sDate) {
            var sDateChange = sap.ui.core.format.DateFormat.getDateTimeInstance({
                pattern: "dd.MM.yyyy HH:mm"
            }).format(sDate).split(" "),
                aDateTime = [];
            // format date 
            if (sDateChange[0]) {
                aDateTime[0] = sDateChange[0];
            } else {
                aDateTime[0] = "00.00.0000";
            }
            // format Time 
            if (sDateChange[1]) {
                aDateTime[1] = sDateChange[1] + ":00";
            } else {
                aDateTime[1] = "00.00.00";
            }
            return aDateTime;

        },
        _bindCompData: function(oElementBinding) {
            var aFilters = [],
                oContextObject = oElementBinding.getBoundContext().getObject();

            //prepare filter  
            aFilters.push(new sap.ui.model.Filter("TPLNR", sap.ui.model.FilterOperator.EQ, oContextObject.TPLNR));
            aFilters.push(new sap.ui.model.Filter("QMNUM", sap.ui.model.FilterOperator.EQ, oContextObject.QMNUM));

            // bind compression data table 
            this.getView().byId("table-compression").bindAggregation("items", {
                path: "/CompresseurSet",
                factory: function(sId, oContext) {
                    // get zdipo property
                    var sZdispo = oContext.getObject().ZDISPO,
                        oElementBindingObject = this.getView().getBindingContext().getObject(),
                        oLine = new sap.m.ColumnListItem({
                            type: "Active",
                            cells: [
                                //repere site
                                new sap.m.Text({
                                    text: "{EQFNR}"
                                }),
                                //impact disponibilité
                                new sap.m.CheckBox({
                                    tooltip: "{i18n>toolTipImpactEq}",
                                    selected: "{= ${ZDISPO} === 'X' ? true : false}",
                                    select: this._checkZdispoBox.bind(this)
                                }),
                                //etat du compresseur
                                new sap.m.ComboBox({
                                    enabled: "{= ${ZDISPO} === 'X' ? true : false}",
                                    selectedKey: "{ZETAT_COMP}",
                                    items: {
                                        path: "/GroupStateSet",
                                        template: new sap.ui.core.ListItem({
                                            text: "{KTEXT}",
                                            key: "{CODE}"
                                        })
                                    },
                                    change: function(oEvent) { this.Unsaved_comp = true; }.bind(this)
                                })

                            ]
                        });

                    // // Create line according to zdispo value
                    if (sZdispo === "X") {
                        oLine = this._createEnabledLine(oLine);
                    } else {
                        oLine = this._createDisabledLine(oLine, oElementBindingObject);
                    }

                    return oLine;

                }.bind(this),
                filters: aFilters
            });
        },
        _checkZdispoBox: function(oEvent) {
            this.Unsaved_comp = true;
            var bIsChecked = oEvent.getSource().getSelected();
            // oElementBindingObject = this.getView().getBindingContext().getObject(),
            // oLine = oEvent.getSource().getParent(),
            // oInitialDate = {};
            if (bIsChecked === true) {
                this._enableDisableTableCells(oEvent, true);
            } else {
                this._enableDisableTableCells(oEvent, false);
                // oInitialDate = this._parseDate(this._concatanateDateTimeValue(oElementBindingObject));
                // oLine.getCells()[2].setSelectedKey();
                // oLine.getCells()[3].setDateValue(oInitialDate);
                // oLine.getCells()[4].setValue(" ");
            }
        },

        /**
         * 
         * @param {*} oLine 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-561
         * Par : Alexandre PISSOTTE (APY)
         * Date : 25/01/2022
         * Motif : Pas de date de fin génère pleins de zéro à la sauvegarde
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _createEnabledLine: function(oLine) {
            //date/heure de début  
            var oStart = new sap.m.DateTimePicker({
                enabled: true,
                placeHolder: " ",
                value: { parts: [{ path: 'ZDATE_DEB' }, { path: 'ZTIME_DEB' }], formatter: this.formatter.compressionhistoryDates },
                displayFormat: "short"
            });
            oLine.addCell(oStart);

            //date/heure fin
            var oEnd = new sap.m.DateTimePicker({
                enabled: true,
                placeHolder: " ",
                value: { parts: [{ path: 'ZDATE_FIN' }, { path: 'ZTIME_FIN' }], formatter: this.formatter.compressionhistoryDates },
                displayFormat: "short"
            });
            oLine.addCell(oEnd);

            oStart.setPlaceholder(" ");
            oEnd.setPlaceholder(" ");

            return oLine;
        },

        _createDisabledLine: function(oLine, oElementBindingObject) {

            var oDate = {};

            oDate = this._parseDate(this._concatanateDateTimeValue(oElementBindingObject));
            //date/heure de début  
            oLine.addCell(new sap.m.DateTimePicker({
                enabled: false,
                placeHolder: " ",
                dateValue: oDate,
                displayFormat: "short"
            }));

            //date/heure fin
            oLine.addCell(new sap.m.DateTimePicker({
                enabled: false,
                placeHolder: " ",
                value: " ",
                displayFormat: "short"
            }));
            return oLine;
        },
        _parseDate: function(sDate) {
            var sDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                pattern: "dd.MM.yyyy HH:mm:ss"
            });
            return sDateFormat.parse(sDate);
        },

        _concatanateDateTimeValue: function(oElementBindingObject) {
            var sStartDate = oElementBindingObject.QMDAT,
                sStartTime = oElementBindingObject.MZEIT;

            if (!sStartDate) {
                sStartDate = "00.00.0000";
            }
            if (!sStartTime) {
                sStartTime = "00:00:00";
            }

            return sStartDate + " " + sStartTime;

        },

        /**
         *
         * @param {*} oEvent 
         * @param {*} bValue 
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-561
         * Par : Alexandre PISSOTTE (APY)
         * Date : 25/01/2022
         * Motif : Pas de date de fin génère pleins de zéro à la sauvegarde
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _enableDisableTableCells: function(oEvent, bValue) {
            var aCells = oEvent.getSource().getParent().getCells();
            aCells.forEach(function(element, index) {
                if (index >= 2) {
                    element.setEnabled(bValue);
                    element.setPlaceholder(" ");
                }

            });
        },

        _processOdataCallSuccess: function(odata, oResponse) {
            var oMessage = {};
            if (oResponse.headers["sap-message"] && $.parseJSON(oResponse.headers["sap-message"]).severity === "error") {

                oMessage.message = $.parseJSON(oResponse.headers["sap-message"]).message;
                this.messages.push(oMessage);
            }
        },
        onCompDataSave: function() {
            this.Unsaved_comp = false;
            var oTable = this.getView().byId("table-compression"),
                oItems = oTable.getItems(),
                oModel = this.getModel(),
                sDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "YYYYMMdd HHmmss"
                });
            this.messages = [];

            for (var i = 0; i < oItems.length; i++) {

                var oContext = oItems[i].getBindingContext().getObject(),
                    aStartTable = sDateFormat.format(oItems[i].getCells()[3].getDateValue()).split(" "),
                    aEndTable = sDateFormat.format(oItems[i].getCells()[4].getDateValue()).split(" "),
                    sPath = oItems[i].getBindingContext().getPath(),
                    sZetatComp = oItems[i].getCells()[2].getSelectedKey(),
                    sErrorMessage = "";

                var oObj = {
                    QMNUM: oContext.QMNUM,
                    EQFNR: oContext.EQFNR,
                    TPLNR: oContext.TPLNR,
                    EQUNR: oContext.EQUNR,
                    ZETAT_COMP: sZetatComp,
                    ZDATE_DEB: aStartTable[0],
                    ZTIME_DEB: aStartTable[1],
                    ZDATE_FIN: aEndTable[0],
                    ZTIME_FIN: aEndTable[1]
                };

                if (oItems[i].getCells()[1].getSelected() === true) {
                    if (!sZetatComp) {
                        sErrorMessage = this.getView().getModel("i18n").getResourceBundle().getText("emptyZetatComp") + oContext.EQFNR;
                        sap.m.MessageBox.error(sErrorMessage);
                        return;
                    }

                    // if (!oContext.EQFNR) {
                    // 	sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("emptyRepereSite"));
                    // 	return;
                    // }

                    oModel.update(sPath, oObj, {
                        changeSetId: "changeSetId",
                        groupId: "UpdateGroup",
                        success: this._processOdataCallSuccess.bind(this),
                        error: function(error) {

                        }
                    });
                } else {
                    oModel.remove(sPath, {
                        changeSetId: "changeSetId",
                        groupId: "UpdateGroup",
                        success: this._processOdataCallSuccess.bind(this),
                        error: function(error) {

                        }
                    });
                }
            }

            oModel.submitChanges({
                groupId: "UpdateGroup",
                success: function(data, resp) {
                    if (this.messages.length !== 0) {

                        var dialog = new sap.m.Dialog({
                            title: this.getView().getModel("i18n").getResourceBundle().getText("erreurSauvgarde"),
                            type: 'Message',
                            beginButton: new sap.m.Button({
                                text: 'OK',
                                press: function() {
                                    dialog.close();
                                }
                            }),
                            afterClose: function() {
                                dialog.destroy();
                            }
                        });
                        var verticallayout = new sap.ui.layout.VerticalLayout();
                        verticallayout.addContent(new sap.m.Text({
                            text: this.getView().getModel("i18n").getResourceBundle().getText("messageErreur") + ":"
                        }));

                        verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        for (var i = 0; i < this.messages.length; i++) {
                            var msg = "\u2022 " + this.messages[i].message + "\n";
                            var x = new sap.m.Text({
                                text: msg
                            });
                            verticallayout.addContent(new sap.ui.layout.HorizontalLayout());
                            verticallayout.addContent(x);
                            verticallayout.addContent(new sap.ui.layout.VerticalLayout());
                        }
                        dialog.addContent(verticallayout);
                        dialog.open();

                    } else {
                        sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("dataSaved"));
                        this.getView().byId("table-compression").getBinding("items").refresh();
                    }

                }.bind(this),
                error: function(error) { }
            });
        },
        _bindNotifCommentList: function(sNotif) {
            var oNotifCommentModel = this.getView().getModel("NotifCommentModel"),
                sPath = this.getModel("thirdService").sServiceUrl + "/commentSet?$filter=QMNUM eq '" + sNotif + "'",
                aResults = [],
                oComment = {},
                oData = {},
                aComments = new Array(),
                model = new JSONModel();

            model.loadData(sPath, null, false);
            aResults = model.getData().d.results;
            if (aResults.length !== 0) {
                oComment.TDFDATE = aResults[0].TDFDATE;
                oComment.TDFTIME = aResults[0].TDFTIME;
                oComment.TDFUSER = aResults[0].TDFUSER;
                oComment.TDFUSERFULL = aResults[0].TDFUSERFULL;
                oComment.TDLINE = aResults[0].TDLINE;
                oComment.MANUM = aResults[0].MANUM;

                for (var i = 1; i < aResults.length; i++) {
                    if (oComment.MANUM === aResults[i].MANUM && oComment.TDFDATE === aResults[i].TDFDATE && oComment.TDFTIME === aResults[i].TDFTIME &&
                        oComment.TDFUSERFULL === aResults[i].TDFUSERFULL) {
                        oComment.TDLINE = oComment.TDLINE + aResults[i].TDLINE;
                    } else {
                        aComments.push(oComment);
                        oComment = {};
                        oComment.TDFDATE = aResults[i].TDFDATE;
                        oComment.TDFTIME = aResults[i].TDFTIME;
                        oComment.TDFUSER = aResults[i].TDFUSER;
                        oComment.TDFUSERFULL = aResults[i].TDFUSERFULL;
                        oComment.TDLINE = aResults[i].TDLINE;
                        oComment.MANUM = aResults[0].MANUM;
                    }

                }

                aComments.push(oComment);

            }
            oData.QMNUM = sNotif;
            oData.commentSet = aComments;
            oNotifCommentModel.setData(oData);

            // var oSorter = [
            // 	new sap.ui.model.Sorter('NotifCommentModel>MANUM', true),
            // 	new sap.ui.model.Sorter('NotifCommentModel>TDFDATE', true),
            // 	new sap.ui.model.Sorter('NotifCommentModel>TDFTIME', true)
            // ];

            this.getView().byId("commentNotifList").bindItems({
                path: "NotifCommentModel>/commentSet",
                factory: function() {
                    return new sap.m.FeedListItem({
                        text: "{NotifCommentModel>TDLINE}",
                        showIcon: false,
                        sender: "{NotifCommentModel>TDFUSERFULL}",
                        timestamp: "{parts:[{path: 'NotifCommentModel>TDFDATE'},{path: 'NotifCommentModel>TDFTIME'}]}"

                    });
                }
            });

        },
        onCommentAddPress: function(oEvent) {
            var sComment = oEvent.getParameter("value"),
                aCommentLines = [],
                nListItems = this.getView().byId("commentNotifList").getItems().length,
                aCommentTable = this._constructCommentLines(aCommentLines, sComment);

            if (nListItems === 0) {
                this._createNote(aCommentTable);
            } else {
                this._addNoteToNotif(aCommentTable);
            }
        },
        _createNote: function(aList) {
            var oObject = {},
                oModel;

            oObject.QMNUM = this.getView().getModel("NotifCommentModel").getProperty('/QMNUM');
            oObject.MATXT = "Note";
            oObject.lineSet = aList;
            this.oNoteComment = oObject;
            oModel = this.getView().getModel("thirdService");
            this.oNoteGlobalBusyDialog = new sap.m.BusyDialog();
            this.oNoteGlobalBusyDialog.open();
            oModel.create("/noteSet", oObject, {
                success: this._ProcessNoteCreationSuccess.bind(this),
                error: function(oError) {
                    this.oNoteGlobalBusyDialog.close();
                }
            });

        },
        _addNoteToNotif: function(aList) {
            var oObject = {},
                oModel;
            oObject.QMNUM = this.getView().getModel("NotifCommentModel").getProperty('/QMNUM');
            oObject.lineSet = aList;
            this.oNoteComment = oObject;
            oModel = this.getView().getModel("thirdService");
            this.oNoteGlobalBusyDialog = new sap.m.BusyDialog();
            this.oNoteGlobalBusyDialog.open();
            oModel.create("/commentSet", oObject, {
                success: this._ProcessNoteCreationSuccess.bind(this),
                error: function(oError) {
                    this.oNoteGlobalBusyDialog.close();
                }
            });
        },
        _ProcessNoteCreationSuccess: function(data, resp) {
            this.oNoteGlobalBusyDialog.close();
            if (resp.headers["sap-message"]) {
                var messageHeader = $.parseJSON(resp.headers["sap-message"]);
                var message = messageHeader.message;
                var severity = messageHeader.severity;
                if (severity === "error") {
                    sap.m.MessageBox.error(message);
                } else {
                    sap.m.MessageToast.show(message);
                }
            }

            if (data.QMNUM) {
                this._bindNotifCommentList(data.QMNUM);

            }

        },
        /**************************************     GMAO 340 ************************************/

        _CheckUnsavedData: function(sSource) {

            var oResourceBundle = this.getModel("i18n").getResourceBundle();
            var sPopUpMessage = oResourceBundle.getText("UnsavedData");
            var oIcon = sap.m.MessageBox.Icon.QUESTION;
            this.sSource = sSource;
            var sPopUpTitle = "Sauvegardez ";

            if (this.Unsaved_comp) { sPopUpTitle = sPopUpTitle + oResourceBundle.getText("DONNCOMP"); }
            if (this.Unsaved_objtech) { sPopUpTitle = sPopUpTitle + oResourceBundle.getText("TECHOBJ"); }
            if (this.Unsaved_panne) { sPopUpTitle = sPopUpTitle + oResourceBundle.getText("PROFILPAN"); }
            if (this.Unsaved_mop) { sPopUpTitle = sPopUpTitle + oResourceBundle.getText("AnnexeMOP"); }
            if (this.Unsaved_general) { sPopUpTitle = sPopUpTitle + oResourceBundle.getText("DONNGEN"); }
            if (this.Unsaved_note) { sPopUpTitle = sPopUpTitle + oResourceBundle.getText("UNSNOTE"); }


            sap.m.MessageBox.show(sPopUpMessage, {
                title: sPopUpTitle,
                icon: oIcon,
                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                onClose: this._handleMessagesave.bind(this)
            });
        },
        _handleMessagesave: function(oAction) {
            if (oAction === sap.m.MessageBox.Action.CANCEL) {
                this.sSource = "";
                return;
            }

            /*Clear the flags of unsaved data */
            this.Unsaved_objtech = false;
            this.Unsaved_note = false;
            this.Unsaved_panne = false;
            this.Unsaved_comp = false;
            this.Unsaved_mop = false;
            this.Unsaved_general = false;

            /*Proceed the navigation */
            switch (this.sSource) {

                case ("MEASUREMENTPOINTS"):
                    this._mesurePointPress();
                    break;
                case ("DEPOSE"):
                    this._deposeButtPress();
                    break;
                case ("ORDER"):
                    this._orderPress();
                    break;
                case ("CLOSEORDER"):
                    this._clotureOrderButton();
                    break;
                case ("NAVBACK"):
                    this._onNavBack();
                    break;
                case ("END"):
                    this._endButtonPress();
                    break;
            }

        },

        _mesurePointPress: function() {

            var oObject = this.getView().getBindingContext().getObject(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZPTS_DE_MESURE",
                        action: "display"
                    },
                    params: {
                        "QMNUM": oObject.QMNUM,
                        "QMTXT": oObject.QMTXT,
                        "QMART": oObject.QMART
                    }

                })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	
        },

        _orderPress: function(oEvent) {
            var sOrder = this.getView().getBindingContext().getObject().AUFNR,//oEvent.getSource().getText(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"), // get a handle on the global XAppNav service
                hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ZGESTION_OT",
                        action: "display"
                    },
                    params: {
                        "AUFNR": sOrder
                    }

                })) || ""; // generate the Hash to display the order creation app 
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); // navigate to order app 	

        },
        _onNavBack: function() {

            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);
            }
        },



        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // CLÔTURE DE L'AVIS
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        /*
        * Ticket : GMAO-498
        * Par : Hajer cheikhrouhou
        * Date : 02/12/2021
        * Motif : Clôture d'un avis ZC aprés verification des données non sauvegardées .
        * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
        */
        onEndButtonPress: function() {
            if (this.getView().byId("commentNotif")) { this.Unsaved_note = this.getView().byId("commentNotif").getValue(); }
            else { this.Unsaved_note = false; }

            if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne || this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general) {
                this._CheckUnsavedData("END");
                return;
            }

            /*var oContext = this.getView().getBindingContext().getObject();
            this._terminateNotification(oContext, false);*/
            this._loadAndOpenClotureFrg();
        },

        /**
         * Instancie et ouvre le fragment de clôture de l'avis
         * 
         * @private
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-574
         * Par : Alexandre PISSOTTE (APY)
         * Date : 08/02/2022
         * Motif : Proposer une date de référence pour les avis ZC 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _loadAndOpenClotureFrg: function() {
            this.loadFragment({
                name: "grtgaz.puma.GestionDesAvis.view.fragments.Cloture"
            }).then(function(oFragment) {
                this._oClotureFrg = oFragment;

                // Positionne la date et l'heure à maintenant
                this.getView().byId("pickerDatdebID").setDateValue(new Date())

                this._oClotureFrg.open();
            }.bind(this))
        },

        /**
         * Ferme et detruit le fragment de clôture de l'avis
         * 
         * @private
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-574
         * Par : Alexandre PISSOTTE (APY)
         * Date : 08/02/2022
         * Motif : Proposer une date de référence pour les avis ZC 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - * 
         */
        _closeAndDestroyClotureFrg: function() {
            this._oClotureFrg.close();
            this._oClotureFrg.destroy();
        },

        /**
         * Met à jour le modèle objectView pour s'assurer de la validité de la date de clôture de l'avis
         * 
         * @public
         * @param {sap.ui.Event} oEvent 
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-574
         * Par : Alexandre PISSOTTE (APY)
         * Date : 08/02/2022
         * Motif : Proposer une date de référence pour les avis ZC 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onDateTimePickerChangeClotureFrg: function(oEvent) {
            const bValid = oEvent.getParameter("valid");
            this.getView().getModel("objectView").setProperty("/isValid", bValid);
        },

        /**
         * Procède à la clôture de l'avis
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-574
         * Par : Alexandre PISSOTTE (APY)
         * Date : 08/02/2022
         * Motif : Proposer une date de référence pour les avis ZC 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onYesButtonPressClotureFrg: function() {
            let sClotureDate = this.getView().byId("pickerDatdebID")
                .getDateValue()
                .toLocaleDateString(undefined, { hour12: false, year: "numeric", month: '2-digit', day: '2-digit' });

            sClotureDate = sClotureDate.substring(6).concat(sClotureDate.substring(3, 5)).concat(sClotureDate.substring(0, 2));

            let sClotureTime = this.getView().byId("pickerDatdebID")
                .getDateValue()
                .toLocaleTimeString("fr-FR", { hour12: false })
                .replaceAll(':', '');

            this._closeAndDestroyClotureFrg()

            this._terminateNotification(this.getView().getBindingContext().getObject(), false, sClotureDate, sClotureTime);
        },

        /**
         * Ferme et détruit le fragment de clôture de l'avis
         * 
         * @public
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-574
         * Par : Alexandre PISSOTTE (APY)
         * Date : 08/02/2022
         * Motif : Proposer une date de référence pour les avis ZC 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onNoButtonPressClotureFrg: function() {
            this._closeAndDestroyClotureFrg();
        },

        /**
         * Clôture l'avis
         * 
         * @public
         * @param {*} oContext 
         * @param {*} bValue 
         * @param {string} sClotureDate 
         * @param {string} sClotureTime 
         * 
         * @author Alexandre PISSOTTE (APY)
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-574
         * Par : Alexandre PISSOTTE (APY)
         * Date : 08/02/2022
         * Motif : Proposer une date de référence pour les avis ZC 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *         
         */
        _terminateNotification: function(oContext, bValue, sClotureDate, sClotureTime) {
            var Notification = {
                "QMNUM": oContext.QMNUM,
                "ZZ_MAJ_EQUI": bValue,
                "BEZDT": sClotureDate,
                "BEZUR": sClotureTime,
            };

            this._oGlobalBusyIndicator = new sap.m.BusyDialog();
            this._oGlobalBusyIndicator.open();
            this.getView().getModel().callFunction("/TerminateNotif", // function import name
                {
                    method: "GET", // http method
                    urlParameters: Notification, // function import parameters
                    context: null,
                    success: function(oData, response) { // callback function for success
                        this._oGlobalBusyIndicator.close();
                        if (response.headers["sap-message"]) {
                            var oResponse = $.parseJSON(response.headers["sap-message"]);
                            if (oResponse.severity === "success") {
                                sap.m.MessageBox.success(this.getView().getModel("i18n").getResourceBundle().getText("TerminateSuccess"), {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("success"),
                                    onClose: function() {
                                        this.getView().getModel().refresh();
                                    }.bind(this)

                                });
                            } else {
                                sap.m.MessageBox.error(oResponse.message, {
                                    title: this.getView().getModel("i18n").getResourceBundle().getText("Error") // default

                                });
                            }
                        }
                    }.bind(this),
                    error: function(oError) { // callback function for error
                        this._oGlobalBusyIndicator.close();
                    }
                }
            );
        },

        _endButtonPress: function() {
            var oContext = this.getView().getBindingContext().getObject();
            this._terminateNotification(oContext, false);

        },
        /*End GMAO-498 */

        /**
         * Event handler for showing compression history - GMAO230.
		 * Permet Accéder à l'historique données compression.
		 * 
         * @public
         * 
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-230
         * Par : 
         * Date : 
         * Motif : Afficher la miniature des photos des MOP
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-588
         * Par : Alexandre PISSOTTE (Atos)
         * Date : 23/03/2022
         * Motif : Afficher la miniature des photos des MOP
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        onShowCompressionHistory: function(oEvent) {
            const frgNameId = "grtgaz.puma.GestionDesAvis.view.fragments.compressionHistory";

            if (!this.oHistoryDialog) {
                this.loadFragment({
                    name: "grtgaz.puma.GestionDesAvis.view.fragments.compressionHistory"
                }).then(function(oDialog) {
                    this.oHistoryDialog = oDialog;
                    this.getView().addDependent(oDialog);
                    this.oHistoryDialog.open();
                }.bind(this))
            } else {
                var sHistoryTable = this.byId("compressionHistorySTable") // sap.ui.core.Fragment.byId("compressionHistoryFragment", "compressionHistorySTable");
                sHistoryTable.rebindTable(true);
                this.oHistoryDialog.open();
            }
        },

        onCloseCompressionHistory: function() {
            this.oHistoryDialog.close();
        },
        onCompressorHistoBeforeRebind: function(oEvent) {

            var obindedObject = this.getView().getBindingContext();

            var sCompressGroup = obindedObject.getProperty("TPLNR"),
                oCompressGrpFilter = new sap.ui.model.Filter("COMPR", sap.ui.model.FilterOperator.EQ, sCompressGroup),

                sFirstDayInYear = new Date().getFullYear().toString() + '01' + '01',
                oFirstDayInearFilter = new sap.ui.model.Filter("ZDATE_DEB", sap.ui.model.FilterOperator.EQ, sFirstDayInYear);

            var aFilters = [oCompressGrpFilter, oFirstDayInearFilter];

            oEvent.getParameter("bindingParams").filters = aFilters;

        },
        onCompressionHistoAvisPress: async function(oEvent) {
            var sCurrentAvisNum = this.getView().getBindingContext().getProperty("QMNUM");
            var sAvisTarget = oEvent.getSource().getBindingContext().getProperty("QMNUM");
            if (sCurrentAvisNum !== sAvisTarget) {
                var oNavigationPayload = await this.prepareNavigationPayload(oEvent);
                var bUserDecision = await this.goToSelectedAvis(sAvisTarget);
                if (bUserDecision) {
                    this.navToAvis(oNavigationPayload);
                    this.oHistoryDialog.close();
                    this.oHistoryDialog.destroy(true);
                    delete this.oHistoryDialog;
                }
            }
        },
        prepareNavigationPayload: async function(oEvent) {
            var sAvisNum = oEvent.getSource().getBindingContext().getProperty("QMNUM");
            var sObjectPath = this.getModel().createKey("PMNotificationDetailsSet", {
                QMNUM: sAvisNum
            });
            var oAvis = await this.getSelectedAvisData(sObjectPath);
            var sAvisType = oAvis.QMART;
            return {
                QMART: sAvisType,
                QMNUM: sAvisNum
            };

        },
        getSelectedAvisData: async function(sObjectPath) {
            var that = this;
            return new Promise(function(resolve, reject) {
                that.getOwnerComponent().getModel().read("/" + sObjectPath, {
                    success: function(oData) {
                        resolve(oData);
                    },
                    error: reject
                })
            });
        },
        goToSelectedAvis: async function(sTargetAvisNum) {
            var oI18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            return new Promise(function(resolve, reject) {
                MessageBox.confirm(oI18n.getText(oI18n.getText("ContinuerNavigation") + " " + sTargetAvisNum + " ?"), {
                    icon: MessageBox.Icon.INFORMATION,
                    title: oI18n.getText("redirection"),
                    actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                    emphasizedAction: MessageBox.Action.YES,
                    onClose: function(sAction) {
                        if (sAction === MessageBox.Action.YES) {
                            resolve(true);
                        } else {
                            reject(false);
                        }
                    }
                })
            });
        },
        navToAvis: function(oNavPayload) {
            switch (oNavPayload.QMART) {
                case "ZC":
                    this.getRouter().navTo("zcDetails", oNavPayload);
                    break;
                case "ZA":
                    this.getRouter().navTo("zaDetails", oNavPayload);
                    break;
                case "ZP":
                    this.getRouter().navTo("ZpDetails", oNavPayload);
                    break;
                default:
                    break;
            }
        }
    });

});


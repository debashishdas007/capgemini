/*global location*/
sap.ui.define([
    "./BaseController",
    "../model/models",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter",
    "sap/ui/core/Element",
    "sap/m/GroupHeaderListItem",
    "sap/ui/core/IconPool",
    "sap/m/Dialog",
    "sap/m/DialogType",
    "sap/m/Button",
    "sap/m/ButtonType",
    "sap/m/List",
    "sap/m/StandardListItem",
    "sap/m/Text",
    "sap/m/MessageBox",
    "../util/KeepeekManager"

], function (
    BaseController,
    models,
    JSONModel,
    History,
    formatter,
    Element,
    GroupHeaderListItem,
    IconPool,
    Dialog,
    DialogType,
    Button,
    ButtonType,
    List,
    StandardListItem,
    Text,
    MessageBox,
    KeepeekManager
) {
    "use strict";

    var oController;

    return BaseController.extend("grtgaz.puma.GestionDesAvis.controller.AvisZM", {

        formatter: formatter,
        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function () {
            /*************************************** GMAO340 ******************************/
            // Implement the Navigation
            this.getOwnerComponent().getService("ShellUIService").then(function (oShellService) {
                oShellService.setBackNavigation(function () {
                    this.Unsaved_note = this.getView().byId("commentNotif").getValue();
                    if (this.Unsaved_objtech || this.Unsaved_note || this.Unsaved_panne || this.Unsaved_comp || this.Unsaved_mop || this.Unsaved_general) {
                        this._CheckUnsavedData("NAVBACK");
                        return;
                    }
                    this._onNavBack();
                }.bind(this));
            }.bind(this));
            /*************************************** END GMAO340 ******************************/
            var iOriginalBusyDelay,
                oViewModel = new JSONModel({
                    busy: true,
                    delay: 0
                });

            // Store original busy indicator delay, so it can be restored later on
            iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
            this.setModel(oViewModel, "objectView");

            this.getRouter().getRoute("ZmDetails").attachPatternMatched(this._onObjectMatched, this);

            oController = this;
            var oCommentModel = new JSONModel();
            this.setModel(oCommentModel, "CommentModel");

            var oNotifCommentModel = new JSONModel();
            this.setModel(oNotifCommentModel, "NotifCommentModel");

            // GMAO-586
            this.aAnnexeMOPItems = [];
        },

        onExit: function () {
            var aFragments = [this._uploadFileFrag, this._oAddNote];
            for (var i = 0; i < aFragments.length; i++) {
                if (aFragments[i]) {
                    this._destroyFragmentInstance(aFragments[i]);
                }
            }
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
        onNavBack: function () {
            var sPreviousHash = History.getInstance().getPreviousHash(),
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);
            }
        },

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
        _onObjectMatched: function (oEvent) {
            var sObjectId = oEvent.getParameter("arguments").QMNUM;
            this.getModel().metadataLoaded().then(function () {
                var sObjectPath = this.getModel().createKey("PMNotificationDetailsSet", {
                    QMNUM: sObjectId
                });
                this._bindView("/" + sObjectPath);
            }.bind(this));
        },

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
        _bindView: function (sObjectPath) {
            var oViewModel = this.getModel("objectView"),
                oDataModel = this.getModel();

            this.getView().bindElement({
                path: sObjectPath,
                parameters: {
                    expand: "ToNote"
                },

                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oDataModel.metadataLoaded().then(function () {
                            // Busy indicator on view should only be set if metadata is loaded,
                            // otherwise there may be two busy indications next to each other on the
                            // screen. This happens because route matched handler already calls '_bindView'
                            // while metadata is loaded.
                            oViewModel.setProperty("/busy", true);
                        });
                    },
                    dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
                    }
                }
            });
        },

        _onBindingChange: function () {
            var oView = this.getView(),
                oViewModel = this.getModel("objectView"),
                oElementBinding = oView.getElementBinding(),
                aNotes = oElementBinding.getBoundContext().getProperty("ToNote");

            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("objectNotFound");
                return;
            }
            this._bindNotifCommentList(oElementBinding.getBoundContext().getObject().QMNUM);

            //enable/disable add button 
            //this._enableAddNoteButton(aNotes.length);

            // Everything went fine.
            oViewModel.setProperty("/busy", false);

            this._bindAnnexeMOP(oElementBinding);

        },

		/**
		 * Shows the selected item on the note detail page
		 * @param {jsObject} oObjectId selected item key 
		 * @private
		 */
        // _showObject: function(oObjectId) {
        // 	this.getRouter().navTo("noteDetails", oObjectId);
        // },

        /**
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * LISTE DE MODIFICATIONS
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         * Ticket : GMAO-305
         * Par : Alexandre PISSOTTE (APY)
         * Date : 15/12/2021
         * Motif : Afficher la miniature des photos des MOP
         * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
         */
        _bindAnnexeMOP: function (oElementBinding) {
            var aPath = "/AnnexeMOPSet",
                aFilters = [],
                oContextObject = oElementBinding.getBoundContext().getObject(),
                oTemplate = sap.ui.xmlfragment("grtgaz.puma.GestionDesAvis.view.fragments.annexeMopTemplate", this);

            // prepare filter
            aFilters.push(new sap.ui.model.Filter("QMNUM", sap.ui.model.FilterOperator.EQ, oContextObject.QMNUM));

            // bind annexemop table (entitySet = AnnexeMOPSet)
            this.getView().byId("annexemop-table").getTable().bindAggregation("items", {
                path: aPath,
                filters: aFilters,
                sorter: new sap.ui.model.Sorter("CODEGRUPPE", null, function (oContext) {
                    return {
                        key: oContext.getProperty("CODEGRUPPE"),
                        text: oContext.getProperty("KURZTEXT_G")
                    };
                }),
                groupHeaderFactory: function (oSorter) {
                    return new sap.m.GroupHeaderListItem({
                        title: oSorter.text
                    }).addStyleClass("zbold");
                },
                template: oTemplate
            });
        },

        // GMAO-XXX
        onUpdateFinishedAnnexeMopTable: function () {
            const oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();

            if (this.Unsaved_mop && this._aAnnexeMOPState) {
                const aItems = this.getView().byId("annexemop-table").getTable().getItems()
                    .filter(oItem => oItem.getMetadata().getName() === "sap.m.ColumnListItem");

                this._aAnnexeMOPState.forEach((bState, index) => aItems[index].getCells()[1].setSelected(bState));
            }

            oGlobalBusyDialog.close();
        },
        // GMAO-XXX

        /* ========================================== */
        // getGroup: function(oContext) {
        // 	return oContext.getProperty("CODEGRUPPE");
        // },

        // getGroupHeader: function(oGroup) {
        // 	return new GroupHeaderListItem({
        // 		title: oGroup.key
        // 	});
        // },

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        /*
            TICKET JIRA GMAO-155
            Chaque groupe de code d'annexe de MOP doit avoir au moins un code sélectionné.
            Si cela est le cas, l'enregistrement s'effectue ;
            Sinon, un message confirmant l'enregistrement apparaît
        	
            Liste des modifications :
            - Découpe de la méthode onSaveButPress en deux méthodes (onSaveButPress et saveAndUpdateAnnexeMOP)
        	
            Fait le  : 04/01/2021
            Fait par : APY
        */
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-155
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        onSaveButPress: function (oEvent) {
            // Récupération du tableau des annexes de MOP
            var tab = this.getView().byId("annexemop-table-content");

            // Récupération des items du tableu des annexes de MOP
            var items = this.getView().byId("annexemop-table-content").getAggregation("items");

            // Récupération des contexts de chaque items du tableau des annexes de MOP
            var aContexts = tab.getItems().map(function (item) {
                return item.getBindingContext();
            });

            // Indique que l'application est occupée
            var oGlobalBusyDialog = new sap.m.BusyDialog();
            oGlobalBusyDialog.open();

            // Copie de la variable items
            var itemsCopy = items;

            // Création d'un objet vérifiant si chaque CODEGRUPPE à au moins une sélection
            // Les propriétés de l'objet créé correspondent à un CODEGRUPPE
            var aItemsGroupByAnnexeMOP = itemsCopy.reduce(function (accumulator, currentObj) {
                // Récupération de la clé
                var key = currentObj.getBindingContext().getObject().CODEGRUPPE || undefined;

                // Si la récupération s'est bien passée
                if (key) {
                    // Si le tableau final n'est pas de clé, on l'ajoute
                    if (!accumulator[key]) {
                        // Par défaut, le groupe de code n'a pas d'élément sélectionné
                        accumulator[key] = false;
                    }

                    // Indique que le groupe de code a au moins un code sélectionné
                    if (currentObj.getCells()[1].getSelected() === true) {
                        accumulator[key] = true;
                    }
                }
                return accumulator;
            }, {}); // Le paramètre accumulateur est de type literral Object

            // Rend la variable itemsCopy non définie et inutilisable
            itemsCopy = undefined;

            // Vérifie que chaque annexe de MOP possède au moins un code coché
            var hasFalse = false;
            for (var prop in aItemsGroupByAnnexeMOP) {
                if (!aItemsGroupByAnnexeMOP[prop]) {
                    hasFalse = true;
                }
            }

            // La sauvegarde ou la modification nécessite une confirmation de l'utilisateur
            if (hasFalse) {
                // Affiche un message de confirmation
                sap.m.MessageBox.show(this.getView().getModel("i18n").getResourceBundle().getText("continueAsThis"), {
                    icon: sap.m.MessageBox.Icon.WARNING,
                    title: this.getView().getModel("i18n").getResourceBundle().getText("incompleteInput"),
                    actions: [
                        sap.m.MessageBox.Action.YES,
                        sap.m.MessageBox.Action.NO
                    ],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: function (oAction) {
                        switch (oAction) {
                            case sap.m.MessageBox.Action.YES: // L'utilisateur clique sur OUI
                                // Procède à l'enregistrement des changements des annexes de MOP
                                this.Unsaved_mop = false
                                this.createOrUpdateAnnexeMOP(items, aContexts, oGlobalBusyDialog);
                                ///// Rajouter 535
                                this.CheckAndCreateOrdre();
                                break;
                            case sap.m.MessageBox.Action.NO: // L'utilisateur clique sur NON
                                // L'application n'est plus occupée
                                oGlobalBusyDialog.close();
                                break;
                        }
                    }.bind(this)
                });
            } else {
                // Procède à l'enregistrement des changements des annexes de MOP
                this.Unsaved_mop = false;
                this.createOrUpdateAnnexeMOP(items, aContexts, oGlobalBusyDialog);
                this.CheckAndCreateOrdre(); // GMAO-535
            }
        },

        createOrUpdateAnnexeMOP: function (items, aContexts, oGlobalBusyDialog) {
            var oModel = this.getView().getModel();

            /************************************  GMAO-411 ***************************************/
            //var lTitle = this.getView().byId("id_qmnum").getObjectTitle();
            //var lStr = lTitle.split(":");
            var sQMNUM = this.getView().getBindingContext().getObject().QMNUM;

            /**********************************  End Of GMAO 411 *********************************/


            var somethingHasChanged = false;

            for (var i = 0; i < items.length; i++) {
                if (items[i].getMetadata().getName() === "sap.m.GroupHeaderListItem") {
                    continue;
                }
                var lSelected = null;
                if (items[i].getCells()[1].getSelected() === false) {
                    lSelected = "";
                } else {
                    lSelected = "X";
                }

                //Décocher une ligne
                if ((items[i].getCells()[1].getSelected() === false) && (aContexts[i].getObject().IS_SELECTED === "X")) {
                    var changedObject = {
                        IS_SELECTED: lSelected,
                        KATALOGART: aContexts[i].getObject().KATALOGART,
                        CODEGRUPPE: aContexts[i].getObject().CODEGRUPPE,
                        KURZTEXT: aContexts[i].getObject().KURZTEXT,
                        KURZTEXT_G: aContexts[i].getObject().KURZTEXT_G,
                        CODE: aContexts[i].getObject().CODE,
                        //QMNUM: lStr[1]
                        QMNUM: sQMNUM
                    };

                    somethingHasChanged = true;

                    oModel.update("/AnnexeMOPSet(CODEGRUPPE='" + changedObject.CODEGRUPPE + "',CODE='" + changedObject.CODE + "',QMNUM='" +
                        changedObject.QMNUM + "')", changedObject, {
                        success: function (data, resp) {
                            if (resp.headers["sap-message"]) {
                                var message = $.parseJSON(resp.headers["sap-message"]).message;
                                sap.m.MessageBox.warning(message);
                            }
                            this.getView().getElementBinding().refresh(true);
                            this.getView().byId("annexemop-table-content").getBinding("items").refresh();

                            oGlobalBusyDialog.close();
                            sap.m.MessageToast.show("Liste mise à jour avec succès");

                        }.bind(this),
                        error: function (data, resp) {
                            oGlobalBusyDialog.close();
                        }
                    });
                } else if ((items[i].getCells()[1].getSelected() === true) && (aContexts[i].getObject().IS_SELECTED === "")) {
                    var changedObject = {
                        IS_SELECTED: lSelected,
                        KATALOGART: aContexts[i].getObject().KATALOGART,
                        CODEGRUPPE: aContexts[i].getObject().CODEGRUPPE,
                        KURZTEXT: aContexts[i].getObject().KURZTEXT,
                        KURZTEXT_G: aContexts[i].getObject().KURZTEXT_G,
                        CODE: aContexts[i].getObject().CODE,
                        //QMNUM: lStr[1]
                        QMNUM: sQMNUM
                    };

                    somethingHasChanged = true;

                    oModel.create("/AnnexeMOPSet", changedObject, {
                        success: function (data, resp) {
                            if (resp.headers["sap-message"]) {
                                var message = $.parseJSON(resp.headers["sap-message"]).message;
                                sap.m.MessageBox.warning(message);
                            }
                            this.getView().getElementBinding().refresh(true);
                            this.getView().byId("annexemop-table-content").getBinding("items").refresh();

                            oGlobalBusyDialog.close();

                            sap.m.MessageToast.show("Liste mise à jour avec succès");

                        }.bind(this),
                        error: function (data, resp) {
                            oGlobalBusyDialog.close();
                        }
                    });
                }
            }

            oModel.setDeferredGroups(["/AnnexeMOPSet"]);
            oModel.submitChanges({
                groupId: "/AnnexeMOPSet",
                success: function (data, resp) { }.bind(this)
            });

            if (!somethingHasChanged) {
                oGlobalBusyDialog.close();
            }
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-155
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        /*
            TICKET JIRA GMAO-162
            Gestion des photos pour les annexes MOP
        	
            Liste des modifications :
            - 
        	
            Fait le  : 20/01/2021
            Fait par : APY
        */
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-162
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        /** 
         * Affiche la miniature attachée au code d'annexe MOP
         * 
         * @param {Event} oEvent Evénement
         * 
         * Fait le : 21/01/2021
         * Fait par : AAA
         */
        onLightBoxDialogPress: function (oEvent) {
            // Préparation des filtres
            var aFilters = [],
                sQMNUM = this.getView().getBindingContext().getObject().QMNUM;

            aFilters.push(new sap.ui.model.Filter("QMNUM", sap.ui.model.FilterOperator.EQ, sQMNUM));
            aFilters.push(new sap.ui.model.Filter("CODEGRUPPE", sap.ui.model.FilterOperator.EQ, oEvent.getSource().getBindingContext().getObject()
                .CODEGRUPPE));
            aFilters.push(new sap.ui.model.Filter("CODE", sap.ui.model.FilterOperator.EQ, oEvent.getSource().getBindingContext().getObject().CODE));
            aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "M"));

            // Création d'un carrousel
            var oCarousel = new sap.m.Carousel({
                height: "300px",
                width: "500px"
            });

            var oLightBoxDialog = new Dialog({
                title: "{i18n>apercuMiniature}",
                endButton: new Button({
                    text: "{i18n>close}",
                    press: function () {
                        oLightBoxDialog.close();
                    }.bind(this)
                })
            });

            // to get access to the controller's model
            oController.getView().addDependent(oLightBoxDialog);

            oLightBoxDialog.addContent(oCarousel);
            // Effectue le bind pour l'aggrégation pages
            oCarousel.bindAggregation("pages", {
                path: "/AnnexeMOP_PHOTOSet",
                filters: aFilters,
                template: new sap.m.Image({
                    src: "{LIEN}",
                    title: "{TITRE_M}"
                })
            });

            // Ouvre le dialogue
            oLightBoxDialog.open();
        },

        /** 
         * Affiche les photos ajoutées par l'utilsateur, attachées au code de d'annexe MOP
         * 
         * @param {Event} oEvent
         * 
         * Fait le : 20/01/2021
         * Fait par : AAA
         */
        onPhotoDialogPress: function (oEvent) {
            // Préparation des filtres
            var aFilters = [];
            aFilters.push(new sap.ui.model.Filter("QMNUM", sap.ui.model.FilterOperator.EQ, oEvent.getSource().getParent().getParent().getBindingContext()
                .getObject().QMNUM));
            aFilters.push(new sap.ui.model.Filter("CODEGRUPPE", sap.ui.model.FilterOperator.EQ, oEvent.getSource().getBindingContext().getObject()
                .CODEGRUPPE));
            aFilters.push(new sap.ui.model.Filter("CODE", sap.ui.model.FilterOperator.EQ, oEvent.getSource().getBindingContext().getObject().CODE));
            aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "P"));

            // Création du carrousel
            var oCarousel = new sap.m.Carousel({
                height: "500px",
                width: "700px"
            });

            var oDefaultDialog = new Dialog({
                title: "{i18n>listePhotos}",
                endButton: new Button({
                    text: "{i18n>close}",
                    press: function () {
                        oDefaultDialog.close();
                    }.bind(this)
                })
            });

            // to get access to the controller's model
            oController.getView().addDependent(oDefaultDialog);

            oDefaultDialog.addContent(oCarousel);
            // Effectue le binding pour l'aggregation pages
            oCarousel.bindAggregation("pages", {
                path: "/AnnexeMOP_PHOTOSet",
                filters: aFilters,
                template: new sap.m.Image({
                    src: "{LIEN}",
                    title: "{TITRE}"
                })
            });

            // Ouvre le dialogue
            oDefaultDialog.open();
        },

        /** 
         * Permet d'ajouter une photo sur keepeek à partir du FileUploader
         * Enregistre le lien sur le backend
         * 
         * Fait le 12/01/2021
         * Fait par : AAA
         * Mis à jour le 22/01/2021
         * Par Omar mahmoudi
         */

        onAddPhotoButPress: function (oEvent) {
            var oObject = oEvent.getSource().getBindingContext().getObject();

            if (!this._uploadFileFrag) {
                this._uploadFileFrag = this._instantiateFragment("grtgaz.puma.GestionDesAvis.view.fragments.addPhoto");
            }

            this._uploadFileFrag.setModel(this.getModel("device"),"device");
            this.getView().getModel("objectView").setProperty("/oBindingObject", oObject);

            this._uploadFileFrag.open();
        },

        OnPathValueChange: function (oEvent) {
            const oModel = this.getModel("objectView"),
                  oBeginButton = oEvent.getSource().getParent().getParent().getBeginButton();
            let oFile = oEvent.getParameters("files").files[0];

            if (oFile) {
                oModel.setProperty('/file',oFile);
                oBeginButton.setEnabled(true);
            } else {
                oModel.setProperty('/file',undefined);
                oBeginButton.setEnabled(false);
            }

        },


        /** 
		 * Permet d'ajouter une photo sur keepeek à partir du FileUploader
		 * Enregistre le lien sur le backend
		 * 
		 * Fait le 12/01/2021
		 * Fait par : AAA
		 * Mis à jour le 22/01/2021
		 * Par Omar mahmoudi
		 */
        handleUploadPress: function (oEvent) {
            var oModel = this.getView().getModel(),
                oViewModel =  this.getModel('objectView'),
                oElementBinding = this.getView().getElementBinding(),
                oElementBindingObject = this.getView().getBindingContext().getObject(),
                oLineObject = oViewModel.getProperty("/oBindingObject"),
                oObject = models.createMediaMetadataModel(oElementBindingObject, oLineObject),
                that = this,
                oFile = oViewModel.getProperty('/file'),
                oFileReader = new FileReader();


                if (!oFile){
                    sap.m.MessageBox.error(this.getModel('i18n').getResourceBundle().getText('noPathError'));
                    return;
                }

                // // Enregistrement sur Keepeek
                // // Récupération du sap.ui.unified.FileUploader
                // oFileUploader = sap.ui.getCore().byId("fileUploader"),

                // // Récupération de l'objet HTML
                // domRef = oFileUploader.getFocusDomRef(),

                // // Récupération du fichier
                // oFile = domRef.files[0], // Type: File
              

            // Début GMAO-XXX
            if (this.Unsaved_mop) {
                // Copie de l'état des coches pour les annexes MOP
                this._aAnnexeMOPState = this.getView().byId("annexemop-table").getTable().getItems()
                    .filter(oItem => oItem.getMetadata().getName() === "sap.m.ColumnListItem")
                    .map(oColumn => oColumn.getCells()[1].getSelected());
            }
            // Fin GMAO-XXX

            oFileReader.onloadend = function () {
                // Utilisation du manager pour Keepeek
                new KeepeekManager(this.getView().getModel("i18n"), oObject).addPicture(oFile, oFileReader.result, function (sUrlImageLarge,
                    sTitleImage) {
                    var changedObject = {
                        TYPE: "P",
                        QMNUM: oElementBindingObject.QMNUM,
                        CODEGRUPPE: oLineObject.CODEGRUPPE,
                        CODE: oLineObject.CODE,
                        ID_FOLDER: oLineObject.ID_FOLDER_M,
                        ID_TERME: oLineObject.ID_TERME_M,
                        LIEN: sUrlImageLarge, // URL récupérée depuis Keepeek
                        TITRE: sTitleImage
                    };

                    // L'application devient occupée
                    var oGlobalBusyDialog = new sap.m.BusyDialog();
                    oGlobalBusyDialog.open();

                    // Ajout de l'URL au backend
                    oModel.create("/AnnexeMOP_PHOTOSet", changedObject, {
                        success: function (data, resp) {
                            if (resp.headers["sap-message"]) {
                                var message = $.parseJSON(resp.headers["sap-message"]).message;
                                sap.m.MessageBox.warning(message);
                            }

                            that._bindAnnexeMOP(oElementBinding);

                            // L'application n'est plus occupée
                            oGlobalBusyDialog.close();

                            sap.m.MessageToast.show("Liste de photos mise à jour avec succès");
                        },
                        error: function (oError) {
                            // if (oError.headers["sap-message"]) {
                            // 	var message = $.parseJSON(resp.headers["sap-message"]).message;
                            // 	sap.m.MessageBox.error(message);
                            // }

                            // L'application n'est plus occupée
                            oGlobalBusyDialog.close();
                        }
                    });
                });
            }.bind(this);

            // Lecture de l'image
            oFileReader.readAsArrayBuffer(oFile);

            // Ferme le fragment
            this._uploadFileFrag.close();
        },

		/**
		 * Permet de ferme le fragment contenant le FileUploader
		 * 
		 * Fait le : 19/01/2021
		 * Fait par : AAA
		 */
        handleCancelPress: function () {
            this._uploadFileFrag.close();
        },
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-162
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //


        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        /*
        TICKET JIRA GMAO-535
        Création d'un sous Ordre d'inspection conditionelle si la MOP 'Validation Hierachique' est approuvée ;
        ceci se fait lors de la sauvegarde des MOP  
        */
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // DEBUT MODIFICATION GMAO-535
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

        onSelectMop: function (oEvent) {
            //this.Unsaved_mop = true ;
            var oObject;
            this.Unsaved_mop = true;

            /**Vérifier si la ligne sélectionnée 'OUI' est dans le groupe Recommandation d'inspection   */
            if (oEvent.getSource().getBindingContext().getObject().CODEGRUPPE.endsWith('R')) {
                if (oEvent.getSource().getBindingContext().getObject().CODE === 'MOUI') {

                    for (var i = 1; i < this.getView().byId("annexemop-table").getTable().getItems().length; i++) {
                        oObject = this.getView().byId("annexemop-table").getTable().getItems()[i].getBindingContext().getObject();
                        // Déselectionner  la ligne 'NO'  dans le groupe Recommandation d'inspection
                        if (
                            oObject.CODEGRUPPE
                            && oObject.CODEGRUPPE.endsWith('R')
                            && oObject.CODE === 'MNON') {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setSelected(false);
                        }
                        // Déselectionner et griser la coche de la ligne 'SO'  dans le groupe 'Validation Hiérarchique'
                        if (
                            oObject.CODEGRUPPE
                            && oObject.CODEGRUPPE.endsWith('V')
                            && oObject.CODE === 'SO') {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setSelected(false);
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setEnabled(false);
                        }
                        // dégriser la coche de la ligne 'OUI' et la ligne 'NON'  dans le groupe 'Validation Hiérarchique'
                        if (
                            (oObject.CODEGRUPPE
                                && oObject.CODEGRUPPE.endsWith('V')
                                && (oObject.CODE === 'MOUI')
                                || oObject.CODE === 'MNON')) {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setEnabled(true);
                        }
                    }
                }
                /**Vérifier si la ligne sélectionnée 'NON' est dans le groupe Recommandation d'inspection   */
                if (oEvent.getSource().getBindingContext().getObject().CODE === 'MNON') {
                    for (var i = 1; i < this.getView().byId("annexemop-table").getTable().getItems().length; i++) {
                        oObject = this.getView().byId("annexemop-table").getTable().getItems()[i].getBindingContext().getObject();
                        if (oObject.CODEGRUPPE
                            && oObject.CODEGRUPPE.endsWith('R')
                            && oObject.CODE === 'MOUI') {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setSelected(false);
                        }
                        // Selectionner et griser la coche de la ligne 'SO'  dans le groupe 'Validation Hiérarchique'
                        if (
                            oObject.CODEGRUPPE
                            && oObject.CODEGRUPPE.endsWith('V')
                            && oObject.CODE === 'SO') {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setSelected(true);
                        }
                        // Griser et deselectionner la coche de la ligne 'OUI' et la ligne 'NON'  dans le groupe 'Validation Hiérarchique'
                        if (
                            oObject.CODEGRUPPE
                            && oObject.CODEGRUPPE.endsWith('V')
                            && ((oObject.CODE === 'MOUI')
                                || (oObject.CODE === 'MNON'))) {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setSelected(false);
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setEnabled(false);
                        }
                    }
                }
            }

            /**Vérifier si la ligne selectionnée est dans le groupe 'Validation hiérarchique'   */
            if (oEvent.getSource().getBindingContext().getObject().CODEGRUPPE.endsWith('V')) {
                if (oEvent.getSource().getBindingContext().getObject().CODE === 'MOUI') {
                    for (i = 1; i < this.getView().byId("annexemop-table").getTable().getItems().length; i++) {
                        oObject = this.getView().byId("annexemop-table").getTable().getItems()[i].getBindingContext().getObject();
                        if (oObject.CODEGRUPPE
                            && oObject.CODEGRUPPE.endsWith('V')
                            && oObject.CODE === 'MNON') {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setSelected(false);
                        }
                    }
                }


                if (oEvent.getSource().getBindingContext().getObject().CODE === 'MNON') {
                    for (i = 1; i < this.getView().byId("annexemop-table").getTable().getItems().length; i++) {
                        oObject = this.getView().byId("annexemop-table").getTable().getItems()[i].getBindingContext().getObject();
                        if (oObject.CODEGRUPPE
                            && oObject.CODEGRUPPE.endsWith('V')
                            && oObject.CODE === 'MOUI') {
                            this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].setSelected(false);
                        }
                    }
                }
            }
        },

        CheckAndCreateOrdre: function () {
            var bValidate_Creation;
            var oObject;
            bValidate_Creation = false;
            // Vérifier si la ligne 'Oui' du groupe 'Validation hiérarchique' est selectionnée         
            for (var i = 1; i < this.getView().byId("annexemop-table").getTable().getItems().length; i++) {
                oObject = this.getView().byId("annexemop-table").getTable().getItems()[i].getBindingContext().getObject();
                if (
                    oObject.CODEGRUPPE
                    && oObject.CODEGRUPPE.endsWith('V')
                    && oObject.CODE === 'MOUI'
                    && this.getView().byId("annexemop-table").getTable().getItems()[i].getCells()[1].getSelected()) {
                    bValidate_Creation = true;
                }
            }

            // Vérifier si l'avis contient déja un OT 
            if (this.getView().getBindingContext().getObject().ZZAUFNR !== '' && bValidate_Creation) {
                sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("Avis_Contient_Ordre") + this.getView().getBindingContext().getObject().ZZAUFNR);
            }
            else if (bValidate_Creation) {
                var oModel;
                var oObject = {};
                oModel = this.getView().getModel();
                var OrderCreation = this._prepareOrderCreationObject();
                oModel.create("/OrderSet", OrderCreation, {
                    success: function (data, resp) {
                        if (resp.headers["sap-message"]) {
                            var message = $.parseJSON(resp.headers["sap-message"]).message;
                            sap.m.MessageBox.warning(message);
                        }

                        var msg, messagePart1, label1, link1,
                            Order = data.AUFNR;
                        if (Order) {
                            /********* ajouter le numéro d'ordre à l'avis   */
                            var oModel = this.getView().getModel();
                            var sPath = this.getView().getBindingContext().getPath();
                            var oObject = this.getView().getBindingContext().getObject();
                            delete oObject.ToNote;
                            oObject.ZZAUFNR = Order;
                            oModel.update(sPath, oObject, {
                                success: function (data, resp) {
                                    if (resp.headers["sap-message"]) {
                                        var message = $.parseJSON(resp.headers["sap-message"]).message;
                                        sap.m.MessageBox.warning(message);
                                    }
                                    this.getView().getModel().refresh();
                                }.bind(this),
                                error: function (data, resp) {
                                    oGlobalBusyDialog.close();
                                }
                            });
                            msg = this.getView().getModel("i18n").getResourceBundle().getText("Cond_Ordre");
                            messagePart1 = this.getView().getModel("i18n").getResourceBundle().getText("Cond_Ordre_Creation");
                            // @ts-ignore
                            label1 = new sap.m.Label({
                                text: messagePart1
                            });
                            // @ts-ignore
                            link1 = new sap.m.Link({
                                text: Order,
                                press: function (oEvent) {
                                    var sOrder = oEvent.getSource().getText();
                                    var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
                                    var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                        target: {
                                            semanticObject: "ZGESTION_OT",
                                            action: "display"
                                        },
                                        params: {
                                            "AUFNR": Order
                                        }

                                    })) || ""; // generate the Hash to display the order creation app 
                                    oCrossAppNavigator.toExternal({
                                        target: {
                                            shellHash: hash
                                        }
                                    }); // navigate to order app 
                                    this._messageDialog.close();
                                }.bind(this)
                            });

                            var that = this;
                            this._messageDialog = new sap.m.Dialog({
                                title: this.getView().getModel("i18n").getResourceBundle().getText("Ordre_Cre_success"),
                                type: 'Message',
                                state: 'Success',
                                // @ts-ignore
                                beginButton: new sap.m.Button({
                                    text: 'OK',
                                    press: function () {
                                        /*  var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
                                          var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                                              target: {
                                                  semanticObject: "Shell",
                                                  action: "home"
                                              }
  
                                          })) || ""; // generate the Hash to display the order creation app 
                                          oCrossAppNavigator.toExternal({
                                              target: {
                                                  shellHash: hash
                                              }
                                          }); // navigate to order creation app */
                                        that._messageDialog.close();
                                    }.bind(this)
                                }),
                                afterClose: function () {
                                    that._messageDialog.destroy();
                                }

                            });
                            var horizontalLayout = new sap.ui.layout.HorizontalLayout();
                            horizontalLayout.addContent(label1);
                            horizontalLayout.addContent(link1);
                            this._messageDialog.addContent(horizontalLayout);
                            this._messageDialog.open();
                        }

                    }.bind(this),
                    error: function (data, resp) {

                    }
                });

            }
        },

        _prepareOrderCreationObject: function () {

            var OrderCreation = {};
            var oObjectAvis;
            oObjectAvis = this.getView().getBindingContext().getObject();
            OrderCreation.KTEXT = this.getView().getModel("i18n").getResourceBundle().getText("Ordre_Cre_source") + oObjectAvis.QMNUM;
            OrderCreation.AUART = "ZPR1";
            OrderCreation.TPLNR = oObjectAvis.TPLNR;
            OrderCreation.EQUNR = oObjectAvis.EQUNR;
            OrderCreation.SWERK = oObjectAvis.SWERK;
            OrderCreation.VAWRK = oObjectAvis.VAWRK;
            OrderCreation.MAUFNR = oObjectAvis.AUFNR;
            OrderCreation.COND_MQMNUM = oObjectAvis.QMNUM;
            return OrderCreation;
        }

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
        // FIN MODIFICATION GMAO-535
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //


    });
});
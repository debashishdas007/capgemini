sap.ui.define([
    "sap/ui/base/Object",
    "sap/m/MessageBox"
], function(Object, MessageBox) {
    "use strict";

    var oKeepeekManager = Object.extend("grtgaz.puma.GestionDesAvis.util.KeepeekManager", {
		/** 
		 * Constructeur de la classe
		 * 
		 * @public
		 * @constructor
		 * 
		 * Fait le : 17/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 */
        constructor: function(i18nModel, oObject) {
            Object.call(this);
			/**
			 * URL du serveur Keepeek
			 * TODO Passer par une destination dans le SAP Cloud Platform
			 */
            var sOrigin = window.location.origin;
            if (sOrigin === "https://grtgaz-gai-dev.cpp.cfapps.eu10.hana.ondemand.com" || sOrigin === "https://gai-int.cpp.cfapps.eu10.hana.ondemand.com") {
                this._baseURL = "https://grtgaz.2.keepeek-dev.com";
                this._username = "SVC_GAI-SCP@tera-int.infragaz.com";
            }
            if (sOrigin === "https://puma-prd.cpp.cfapps.eu10.hana.ondemand.com") {
                this._baseURL = "https://phototheque-grtgaz.keepeek.com";
                this._username = "SVC_GAI-SCP@tera.infragaz.com";
            }

            // L'application devient occupée
            this.oGlobalBusyDialog = new sap.m.BusyDialog();
            this.oGlobalBusyDialog.open();

			/**
			 * Nom d'utilisateur pour se connecter au serveur Keepeek
			 * TODO Référencer le nom d'utilisateur dans la destination du SCP
			 */

			/**
			 * Mot de passe pour se connecter au serveur Keepeek
			 * TODO Référencer le mot de passe dans la destination du SCP
			 */
            this._password = "Pum@2021";

			/**
			 * The context object for the respectif mop 
			 */
            this._mopObject = oObject;

			/**
			 * form url 
			 */
            this._formUrl = this._baseURL + "/api/dam/forms/10";
            this._formProperties = [];

            this._communFonctionTechnique = "";

			/**
			 * Type de l'image
			 * Exemple :
			 *  - image/png
			 *  - image/jpeg
			 */
            this._imageType = "";
			/**
			 * Image sous forme d'un array buffer
			 */
            this._image = "";
			/**
			 * Nom du fichier pour l'image
			 */
            this._imageName = "";
			/**
			 * Type de l'image
			 */
            this._imageSize = 0;

			/**
			 * URL de l'image sur le serveur Keepeek
			 */
            this._urlFile = "";
			/**
			 * URL du panier dans lequelle l'image sera déposée
			 */
            this._urlBasketMedia = "";

            this.aObjectURL = [];

            this._callback = undefined;

            this._i18nModel = i18nModel;
            //getFormProperties
            this._getFormsProperties();
            //get communfonctionProperty
            this._getCommunFonctionTechnique();

        },

        destroy: function() {
            this.aObjectURL.forEach(function(objectURL) {
                URL.revokeObjectURL(objectURL);
            });
        },

        _getCommunFonctionTechnique: function() {
            $.ajax({
                type: "GET",
                url: this._baseURL + "/api/dam/forms/lookups/4",
                crossDomain: true,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                }.bind(this)
            })
                .done(function(oData) {
                    if (oData && oData._embedded && Array.isArray(oData._embedded.value)) {
                        var aProertiesId = oData._embedded.value;
                        for (var i in aProertiesId) {
                            if (aProertiesId[i].value === this._mopObject.commun_fonction_technique) {
                                this._communFonctionTechnique = aProertiesId[i].label;

                            }
                        }
                    }

                }.bind(this))
                .fail(function() {
                    console.log("failed to get common function technique");
                }.bind(this));

        },

        _getFormsProperties: function() {
            $.ajax({
                type: "GET",
                url: this._formUrl,
                crossDomain: true,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                }.bind(this)
            })
                .done(function(oData) {
                    if (oData && oData._embedded && Array.isArray(oData._embedded.field)) {
                        var aProertiesId = oData._embedded.field;
                        for (var i in aProertiesId) {
                            this._formProperties.push(aProertiesId[i].id);
                        }
                    } else {
                        this._throwError(this._i18nModel.getResourceBundle().getText("unavailableFormProperties"));
                    }

                }.bind(this))
                .fail(function() {
                    this._throwError(this._i18nModel.getResourceBundle().getText("unavailableForm"));
                }.bind(this));

        },

		/** 
		 * Permet d'ajouter au serveur keepeek une image décrite sous forme d'array buffer.
		 * @see FileReader.readAsDataURL()
		 * 
		 * @public
		 * @param {File} oFile Fichier correspondant à l'image uploader
		 * @param {ArrayBuffer} aBufferImage Image découpée en un array buffer
		 * 
		 * Fait le : 18/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 */
        addPicture: function(oFile, aBufferImage, fCallback) {
            this._image = aBufferImage;
            this._imageName = oFile.name;
            this._imageType = oFile.type;

            this._callback = fCallback;

            // 1. Création du fichier dans Keepeek
            this._createFileOnServer();
        },

		/** 
		 * Récupère une image à partir d'une url
		 * @param {string} sURL URL de l'image
		 * 
		 * @returns {Promise} Promise ayant pour paramètre un ObjectURL
		 * 
		 * Fait le : 20/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 */
        getPicture: function(sURL) {
            return $.ajax({
                type: "GET",
                url: sURL,
                xhrFields: {
                    responseType: "blob"
                },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Content-Type", "*");
                    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                    xhr.setRequestHeader("Access-Control-Allow-Headers", "*");
                }
            }).then(
                function(data, textStatus, jqXHR) {
                    return URL.createObjectURL(data);
                },
                function(jqXHR, textStatus, errorThrown) {
                    this._throwError(this._i18nModel.getResourceBundle().getText("unableToRetrieveImage"));
                }.bind(this)
            );
        },

		/** 
		 * Crée une image sur le serveur Keepeek et récupère l'url de l'image sur le serveur
		 * ainsi que la taille de l'iamge.
		 * 
		 * @private
		 * 
		 * Fait le : 20/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 */
        _createFileOnServer: function() {
            var sURL = "/api/dam/files";

            $.ajax({
                type: "POST",
                url: this._baseURL + sURL,
                data: this._image,
                processData: false,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("X-KPK-FileName", this._imageName);
                    xhr.setRequestHeader("Content-Type", this._imageType);
                    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                }.bind(this)
            })
                .done(function(oData) {
                    // Récupération du lien du fichier
                    if (oData._links.self.href) {
                        this._urlFile = oData._links.self.href;
                    }

                    // Récupération de la taille de l'image
                    if (oData.size) {
                        this._imageSize = oData.size;
                    }

                    if (this._urlFile && this._urlFile !== "") {
                        // 2. Détermination du dossier
                        this._getTargetedFolder();
                    } else {
                        this._throwError(this._i18nModel.getResourceBundle().getText("unableToRetrieveFileLink"));
                        this.oGlobalBusyDialog.close();
                    }
                }.bind(this))
                .fail(function(jqXHR, textStatus, errorThrown) {
                    this._throwError(this._i18nModel.getResourceBundle().getText("unableToCreateFileOnServer"));
                    this.oGlobalBusyDialog.close();
                }.bind(this));
        },
        
		/** 
		 * 
		 * Déterminer le dossier qui contiendra l'image à stocker 
		 * 
		 * @private
		 * 
		 * Fait le : 22/01/2021
		 * Fait par :Omar Mahmoudi 
		 */
        _getTargetedFolder: function() {

            if (!this._mopObject.ID_FOLDER_M) {
                this._throwError(this._i18nModel.getResourceBundle().getText("unavailableFolderId"));
                return;
            }

            var sURL = "/api/dam/folders/" + this._mopObject.ID_FOLDER_M;

            $.ajax({
                async: true,
                type: "GET",
                url: this._baseURL + sURL,
                crossDomain: true,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                }.bind(this)
            })
                .done(function(oData) {
                    if (oData._links["kpk:medias"].href) {
                        this._urlFolderMedia = oData._links["kpk:medias"].href;
                        this._linkFileToMedia();

                    } else {
                        this._throwError(this._i18nModel.getResourceBundle().getText("unableToRetriveFolderMediaLink"));
                        this.oGlobalBusyDialog.close();
                    }

                }.bind(this))
                .fail(function() {
                    this._throwError(this._i18nModel.getResourceBundle().getText("unavailableFolderId"));
                    this.oGlobalBusyDialog.close();
                }.bind(this));

        },

		/** 
		 * Dépose le fichier créé sur le serveur Keepeek au panier par défaut.
		 * 
		 * @private
		 * 
		 * Fait le : 19/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 * Modifié le 22/01/2021
		 * Modifié par :Omar MAHMOUDI
		 */
        _linkFileToMedia: function() {
            var oMedia = {
                "_links": {
                    "from": {
                        "href": this._urlFile
                    },
                    "kpk:form": {
                        "href": this._formUrl
                    }
                }
            };

            $.ajax({
                async: true,
                type: "POST",
                url: this._urlFolderMedia,
                data: JSON.stringify(oMedia),
                crossDomain: true,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Content-Type", "application/json");
                }.bind(this)
            })
                .done(function(data, textStatus, jqXHR) {
                    var sLocation = jqXHR.getResponseHeader("location");
                    if (sLocation && sLocation !== "") {
                        this._urlMedia = sLocation;
                        this._updateMetadataProperties(0);

                    } else {
                        this._throwError(this._i18nModel.getResourceBundle().getText("unableToRetrieveLocationLink"));
                        this.oGlobalBusyDialog.close();
                    }
                }.bind(this))
                .fail(function(jqXHR, textStatus, errorThrown) {
                    this._trowError(this._i18nModel.getResourceBundle().getText("unableToLinkFileAndBasket"));
                    this.oGlobalBusyDialog.close();
                }.bind(this));
        },

		/** 
		 * mise à jour des metadatas du media 
		 * 
		 * @private
		 * 
		 * Fait le : 22/01/2021
		 * Fait par : Omar MAHMOUDI
		 * 
		 */
        _updateMetadataProperties: function(i) {

            if (this._formProperties && i < this._formProperties.length) {
                this._updateMetadataProperty(i);
            } else {
                this._getLargeImageFromLocation();
            }

        },

		/** 
		 * mise à jour d'un metadata du media 
		 * 
		 * @private
		 * 
		 * Fait le : 22/01/2021
		 * Fait par : Omar MAHMOUDI
		 * 
		 */
        _updateMetadataProperty: function(i) {
            var sProperty = this._formProperties[i],
                sMetadataUrl = this._urlMedia + "/metadatas/" + sProperty,
                oMetadata = {
                    "value": ""
                },
                oData;
            this._propertyIndex = i + 1;

            if (this._mopObject && this._mopObject[sProperty]) {

                switch (sProperty) {
                    case "commun_fonction_technique":
                        oMetadata.value = this._communFonctionTechnique;
                        break;
                    default:
                        oMetadata.value = this._mopObject[sProperty];
                        break;
                }

                oData = JSON.stringify(oMetadata);
                $.ajax({
                    async: true,
                    type: "PUT",
                    url: sMetadataUrl,
                    data: oData,
                    crossDomain: true,
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                        xhr.setRequestHeader("Content-Type", "application/json");
                    }.bind(this)
                })
                    .done(function() {
                        this._updateMetadataProperties(this._propertyIndex);

                    }.bind(this))
                    .fail(function() {
                        this._updateMetadataProperties(this._propertyIndex);
                        var ErrorIndex = Number(this._propertyIndex) - 1;
                        console.log("failed at property update  index : " + ErrorIndex);
                    }.bind(this));
            } else {
                this._updateMetadataProperties(this._propertyIndex);
            }

        },

        _updateStatus: function() {
            var sMetadataUrl = this._urlMedia,
                oMetadata = {
                    "_links": {
                        "kpk:custom-status": {
                            "href": this._baseURL + "/api/dam/medias/custom-statuses/2"
                        }
                    }
                },


                oData;
            oData = JSON.stringify(oMetadata);
            $.ajax({
                async: true,
                type: "PUT",
                url: sMetadataUrl,
                data: oData,
                crossDomain: true,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Content-Type", "application/json");
                }.bind(this)

            }).fail(function() {
                console.log("failed to update status to Published ");
            }.bind(this));

        },

        _getLargeImageFromLocation: function() {
            $.ajax({
                type: "GET",
                url: this._urlMedia,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                }.bind(this)
            })
                .done(function(oData) {

                    this._updateStatus();
                    var slink, sTitre;
                    if (oData && oData._links && oData._links["kpk:xlarge"].href) {
                        slink = oData._links["kpk:xlarge"].href;
                        sTitre = oData.title;

                        if (this._callback) {
                            this.oGlobalBusyDialog.close();
                            this._callback(slink, sTitre);
                        }

                    } else {
                        this._throwError(this._i18nModel.getResourceBundle().getText("unableToRetrieveLargeImageUrl"));
                        this.oGlobalBusyDialog.close();
                    }
                }.bind(this))
                .fail(function() {
                    this._throwError(this._i18nModel.getResourceBundle().getText("unableToGetImageDetail"));
                    this.oGlobalBusyDialog.close();
                }.bind(this));
        },

		/** 
		 * Détermine le panier par défaut pour ajouter l'image dans Keepeek	.
		 * RG : Le panier par défaut est le premier panier trouvé.
		 * 
		 * @private
		 * 
		 * Fait le : 20/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 */
        _getDefaultBasket: function() {
            var sURL = "/api/dam/baskets";

            $.ajax({
                async: true,
                type: "GET",
                url: this._baseURL + sURL,
                crossDomain: true,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Basic " + btoa(this._username + ":" + this._password));
                    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                }.bind(this)
            })
                .done(function(oData) {
                    // Vérifie que la réponse HTTP contienne des paniers
                    if (oData && oData._embedded && oData._embedded.basket) {
                        if (Array.isArray(oData._embedded.basket) && oData._embedded.basket.length > 0) {
                            // Détermination du panier par défaut
                            var oBasket = oData._embedded.basket[0];

                            // Récupération de l'adresse du média du panier
                            if (oBasket._links["kpk:medias"].href) {
                                this._urlBasketMedia = oBasket._links["kpk:medias"].href;
                            }
                        } else {
                            // 1 seul panier
                            if (oData._embedded.basket._links["kpk:medias"].href) {
                                this._urlBasketMedia = oData._embedded.basket._links["kpk:medias"].href;
                            }
                        }

                        if (this._urlBasketMedia && this._urlBasketMedia !== "") {
                            // 3. Ajout du média dans le panier
                            this._linkFileToBasket();
                        }
                    } else {
                        this._throwError(this._i18nModel.getResourceBundle().getText("unableToFindDefaultBasket"));
                    }
                }.bind(this))
                .fail(function() {
                    this._throwError(this._i18nModel.getResourceBundle().getText("unableToRetrieveBaskets"));
                }.bind(this));
        },

		/** 
		 * Notifie à l'utilisateur d'une erreur.
		 * 
		 * @private 
		 * @param {string} sMessage Texte explicite
		 * 
		 * Fait le : 20/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 */
        _throwError: function(sMessage) {
            MessageBox.show(
                sMessage, {
                icon: MessageBox.Icon.ERROR,
                title: this._i18nModel.getResourceBundle().getText("unableToConnectToKeepeek"),
                actions: [MessageBox.Action.OK],
                emphasizedAction: MessageBox.Action.YES
            }
            );
        },

		/** 
		 * Notifie à l'utilisateur d'un succès.
		 * 
		 * @private 
		 * @param {string} sMessage Texte explicite
		 * 
		 * Fait le : 20/01/2021
		 * Fait par : Alexandre PISSOTTE (APY)
		 */
        _throwSuccess: function(sMessage) {
            MessageBox.show(
                sMessage, {
                icon: MessageBox.Icon.SUCCESS,
                title: this._i18nModel.getResourceBundle().getText("imageUponBasket"),
                actions: [MessageBox.Action.OK],
                emphasizedAction: MessageBox.Action.YES
            }
            );
        }
    });

    return oKeepeekManager;
});
sap.ui.define([
	"grtgaz/zdms_create/test/unit/controller/App.controller"
], function () {
	"use strict";
});

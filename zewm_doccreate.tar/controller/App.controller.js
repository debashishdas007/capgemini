sap.ui.define([
    // "sap/ui/core/mvc/Controller"
    "com/grtgaz/ewm/zewmdoccreate/controller/BaseController"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController) {
        "use strict";

        return BaseController.extend("com.grtgaz.ewm.zewmdoccreate.controller.App", {
            onInit: function () {

            }
        });
    });

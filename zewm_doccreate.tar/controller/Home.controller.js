sap.ui.define([
    //"sap/ui/core/mvc/Controller",
    "com/grtgaz/ewm/zewmdoccreate/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/m/MessageItem",
    "sap/m/MessageView",
    "sap/m/Button",
    "sap/m/Dialog",
    "sap/m/Bar",
    "sap/m/Title",
    "sap/ui/core/IconPool",
    "sap/m/MessageBox",
    "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV",
    "../utils/formatter",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, JSONModel, Filter, MessageItem, MessageView, Button, Dialog, Bar, Title, IconPool, MessageBox, Export, ExportTypeCSV, formatter) {
        "use strict";
        var reader = new FileReader();
        return BaseController.extend("com.grtgaz.ewm.zewmdoccreate.controller.Home", {
            formatter: formatter,
            onInit: function () {
                var oViewModel = new JSONModel();
                oViewModel.setData({
                    sumLineItem: 0,
                    sommeQty: formatter.floatInstance(0.000),
                    checkButton: true,
                    savekButton: false,
                    error: 0,
                    errorText: ""
                });
                var batchViewModel = new JSONModel();
                // show message
                batchViewModel.setData({});
                this.getView().setModel(oViewModel, "viewModel");
                this.getView().setModel(batchViewModel, "batchViewModel");

            },

            onBeforeRendering: function () {
                this.batchModel = new JSONModel();
            },
            onPOKeyPress: function (oEvent) {
                if (oEvent.getSource().getValue().length > 10) {
                    oEvent.getSource().setValue(oEvent.getSource().getValue().substring(0, 10))
                }
            },
            onMaterialKeyPress: function (oEvent) {
                if (isNaN(oEvent.getSource().getValue())) {
                    oEvent.getSource().setValue(oEvent.getSource().getValue().substring(0, oEvent.getSource().getValue().length - 1));
                }
            },
            onGetDelivery: function () {
                let poNumber = this.getView().byId("PONumber").getValue();
                let materialNumber = this.getView().byId("material").getValue();
                let filters = [];

                if (poNumber === "" || materialNumber === "") {
                    this.onMessageBox(this.getModel("i18n").getResourceBundle().getText("poMatNumberMandatory"));
                    //MessageToast.show(this.getModel("i18n").getResourceBundle().getText("poMatNumberMandatory"));
                    return false;
                }

                if (poNumber !== "") {
                    filters.push(new Filter({
                        path: "PoNumber",
                        operator: sap.ui.model.FilterOperator.EQ,
                        value1: poNumber
                    }));
                }
                if (materialNumber !== "") {
                    filters.push(new Filter({
                        path: "Material",
                        operator: sap.ui.model.FilterOperator.EQ,
                        value1: materialNumber
                    }));
                }
                // var oBinding = this.getView().byId("items").getBinding("items");
                // oBinding.filter(filters);
                var itemtemplate = new sap.ui.core.ListItem({
                    key: "{DeliveryItem}",
                    //text: "{DeliveryItem} / {Quantity}",
                    text: {
                        parts: [{ path: 'DeliveryItem' }, { path: 'Quantity' }],
                        formatter: function (DeliveryItem, Quantity) {
                            return DeliveryItem + " / " + formatter.floatInstance(Quantity)
                        }.bind(formatter)
                    }
                });

                var oList = this.getView().byId("items");
                oList.bindItems({
                    path: '/DeliverySet',
                    template: itemtemplate,
                    filters: filters
                })
            },

            onChangeMaterial: function (oEvent) {
                let deliveryTable = this.getView().byId("deliveryTable");
                let data = new JSONModel();
                data.setData({
                    DeliveryTableSet: [oEvent.getParameters().selectedItem.getBindingContext().getObject()]
                });
                //deliveryTable.setModel(data);
                deliveryTable.setModel(data);
                var oTemplate = deliveryTable.getBindingInfo("items").template;

                deliveryTable.bindItems({
                    path: "/DeliveryTableSet",
                    template: oTemplate
                });

                this.materialNo = oEvent.getParameters().selectedItem.getBindingContext().getObject().Material;
                this.materialManagedXCHPF = oEvent.getParameters().selectedItem.getBindingContext().getObject().BmXCHPF;
                this.materialManagedXCHAR = oEvent.getParameters().selectedItem.getBindingContext().getObject().BmXCHAR;
                this.materialSerialized = oEvent.getParameters().selectedItem.getBindingContext().getObject().Serail;
                this.materialType = oEvent.getParameters().selectedItem.getBindingContext().getObject().MatType;
                this.quantity = oEvent.getParameters().selectedItem.getBindingContext().getObject().Quantity;

                var initialBatchData = [{ Quantity: 0.000 }];
                this.batchModel = new JSONModel();
                this.populateTable(initialBatchData);
                this.getView().getModel("viewModel").setProperty("/savekButton", true);
            },

            onComment: function (oEvent) {
                if (this.getView().byId("deliveryTable").getModel().getData() !== null) {
                    this.getView().byId("deliveryTable").getModel().getData().DeliveryTableSet[0].Comment = oEvent.getSource().getValue();
                }
            },

            onAdd: function (oEvent) {
                var oTable = this.getView().byId("batchRecord");
                let jsonData = oTable.getModel().getData();
                if (jsonData === null) {
                    return;
                }
                // else {
                //     jsonData.Batches.map(function (val) {
                //         if (isNaN(+val.Quantity)) {
                //             val.Quantity = +formatter.convertNonEuroCurrency(val.Quantity);
                //         }
                //         return val;
                //     });
                // }
                jsonData.Batches.push({
                    Quantity: 0.000
                });
                oTable.getModel().refresh(true);
                this.getView().getModel("viewModel").setProperty("/sumLineItem", +this.getView().getModel("viewModel").getProperty("/sumLineItem") + 1);
            },

            onDuplicate: function (oEvent) {
                var oTable = this.getView().byId("batchRecord");
                var selectedItems = oTable.getSelectedItems();
                if (selectedItems.length === 0) {
                    this.onMessageBox(this.getModel("i18n").getResourceBundle().getText("selectOneRecord"));
                    //MessageToast.show(this.getModel("i18n").getResourceBundle().getText("selectOneRecord"));
                    // console.log(this.getModel("i18n").getResourceBundle().getText("poMatNumberMandatory"));
                    return false;
                }
                var jsonData = oTable.getModel().getData();
                // Adding duplicate items                
                selectedItems.forEach(function (item) {
                    let copiedRecord = JSON.parse(JSON.stringify(item.getBindingContext().getObject()));
                    jsonData.Batches.push(copiedRecord);
                });
                oTable.getModel().refresh();
                this.getView().getModel("viewModel").setProperty("/sumLineItem", +this.getView().getModel("viewModel").getProperty("/sumLineItem") + selectedItems.length);
                this.calculateSommeQty(oTable.getModel().getData().Batches);

            },

            onDelete: function (oEvent) {
                var oTable = this.getView().byId("batchRecord");
                var selectedItems = oTable.getSelectedItems();
                if (selectedItems.length === 0) {
                    this.onMessageBox(this.getModel("i18n").getResourceBundle().getText("selectOneRecord"));
                    //MessageToast.show(this.getModel("i18n").getResourceBundle().getText("selectOneRecord"));
                    //console.log("Please select atleast one record");
                    return false;
                }
                var itemIndexs = selectedItems.map(function (item) {
                    var sBindingPath = item.getBindingContext().getPath();
                    var selectedIndex = +(sBindingPath.replace("/Batches/", "")).trim();
                    return selectedIndex;
                });

                for (var i = itemIndexs.length - 1; i >= 0; i--) {
                    oTable.getModel().getData().Batches.splice(itemIndexs[i], 1);
                }
                oTable.getModel().refresh();
                var jsonData = oTable.getModel().getData().Batches.map(function (val) {
                    return val;
                });
                this.populateTable(jsonData);
                this.calculateSommeQty(jsonData);

            },

            onUploadHeaderPV: function (oEvent) {
                var file = oEvent.getSource().getFocusDomRef().files[0];
                // get Base64 of the file
                let fileContent = formatter.convertToBase64(file);
                this.getView().byId("deliveryTable").getModel().getData().DeliveryTableSet[0].FileName = oEvent.getSource().getValue();
                fileContent.then(function (result) {
                    if (this.getView().byId("deliveryTable").getModel().getData() !== null) {
                        result = (result.replace("data:application/pdf;base64,", "")).trim();
                        this.getView().byId("deliveryTable").getModel().getData().DeliveryTableSet[0].headerPV = result;
                    }
                }.bind(this));

            },

            onRemoveHeaderPV: function () {
                this.getView().byId("headerPV").setValue("");
                if (this.getView().byId("deliveryTable").getModel().getData() !== null) {
                    this.getView().byId("deliveryTable").getModel().getData().DeliveryTableSet[0].headerPV = "";
                    this.getView().byId("deliveryTable").getModel().getData().DeliveryTableSet[0].FileName = "";
                }
            },

            populateTable: function (jsonData) {
                var that = this;
                var fromLiveChange = "";
                var oTable = this.getView().byId("batchRecord");
                oTable.destroyAggregation("items");
                this.batchModel.setData({
                    Batches: jsonData
                });
                oTable.setModel(this.batchModel);
                //oTable.getModel().refresh(true);
                var oTemplate = new sap.m.ColumnListItem({
                    cells: [
                        // Material 
                        new sap.m.Input({
                            value: "{Material}",
                            width: "0%",
                        }),
                        // Batch
                        new sap.m.Input({
                            //type: "Number",
                            // editable: formatter.fnEBatchManaged(this.materialManagedXCHPF, this.materialManagedXCHAR, this.materialSerialized, this.materialType),
                            editable: formatter.fnEBatchManaged(this.materialManagedXCHPF, this.materialSerialized, this.materialType),
                            width: "90%",
                            //value: "{BatchNo}",
                            value: {
                                parts: [{ path: 'BatchNo' }],
                                formatter: function (BatchNo) {
                                    if (fromLiveChange === "X") {
                                        fromLiveChange = "";
                                        return BatchNo;
                                    }
                                    else if (fromLiveChange == "") {
                                        // if (typeof formatter.fnEBatchManaged(that.materialManagedXCHPF, that.materialManagedXCHAR, that.materialSerialized, that.materialType) == "undefined" || typeof formatter.fnEBatchManaged(that.materialManagedXCHPF, that.materialManagedXCHAR, that.materialSerialized, that.materialType)) {
                                        if (typeof formatter.fnEBatchManaged(that.materialManagedXCHPF, that.materialSerialized, that.materialType) == "undefined" || typeof formatter.fnEBatchManaged(that.materialManagedXCHPF, that.materialSerialized, that.materialType)) {
                                            return BatchNo;
                                        }
                                        return "";
                                    } else {
                                        return "";
                                    }
                                    fromLiveChange = "";
                                }.bind(formatter),
                            },
                            liveChange: function (oEvent) {
                                if (oEvent.getParameters().value.length > 10) {
                                    oEvent.getSource().setValue(oEvent.getSource().getValue().substring(0, 10));
                                    oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
                                    //oEvent.getSource().setValueStateText("Maximum 10 Characters");
                                    oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("batchMaxCharacter", 10));
                                    return false;
                                }
                                fromLiveChange = "X";
                                oEvent.getSource()._getBindingContext().getModel().setProperty(oEvent.getSource()._getBindingContext().getPath() + "/BatchNo", oEvent.getSource().getValue().toUpperCase());
                                oEvent.getSource().setValueState(sap.ui.core.ValueState.None);

                            }
                        }), 
                        // SN
                        new sap.m.Input({
                            //type: "Number",
                            // editable: formatter.fnSerialized(this.materialManagedXCHPF, this.materialManagedXCHAR, this.materialSerialized, this.materialType),
                            editable: formatter.fnSerialized(this.materialManagedXCHPF, this.materialSerialized, this.materialType),
                            width: "90%",
                            value: {
                                parts: [{ path: 'SN' }],
                                formatter: function (SN) {
                                    if (fromLiveChange == "X") {
                                        fromLiveChange = "";
                                        return SN;
                                    }
                                    else if (fromLiveChange == "") {
                                        //if (typeof formatter.fnSerialized(that.materialManagedXCHPF, that.materialManagedXCHAR, that.materialSerialized, that.materialType) == "undefined" || typeof formatter.fnEBatchManaged(that.materialManagedXCHPF, that.materialManagedXCHAR, that.materialSerialized, that.materialType)) {
                                        if (typeof formatter.fnSerialized(that.materialManagedXCHPF, that.materialSerialized, that.materialType) == "undefined" || typeof formatter.fnSerialized(that.materialManagedXCHPF, that.materialSerialized, that.materialType)) {
                                            return SN;
                                        }
                                        return "";
                                    } else {
                                        return "";
                                    }
                                    fromLiveChange = "";
                                }.bind(formatter),
                            },
                            liveChange: function (oEvent) {
                                var snLength = 18;
                                // if (that.materialType == "ZPLS") {
                                if (that.materialSerialized == "TUBE") {
                                    snLength = 11;
                                }
                                if (oEvent.getParameters().value.length > snLength) {
                                    oEvent.getSource().setValue(oEvent.getSource().getValue().substring(0, snLength));
                                    oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
                                    oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("serialMaxCharacter", snLength));
                                    return false;
                                }
                                fromLiveChange = "X";
                                oEvent.getSource()._getBindingContext().getModel().setProperty(oEvent.getSource()._getBindingContext().getPath() + "/SN", oEvent.getSource().getValue().toUpperCase());
                                oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
                            }
                        }),
                        // Quantity
                        new sap.m.Input({
                            //type: "Number",
                            width: "60%",
                            value: {
                                parts: [{ path: "Quantity" }],
                                formatter: function (Quantity) {
                                    return formatter.floatInstance(Quantity);
                                }
                            },
                            change: function (oEvent) {
                                //console.log(oEvent.getSource().getValue().split(".")[0].length); 
                                var quantity = oEvent.getSource().getValue() != "" ? oEvent.getSource().getValue() : 0.000;
                                quantity = formatter.parse(quantity);

                                // if (that.materialType != 'ZPLS') {
                                if (that.materialSerialized != 'TUBE') {
                                    quantity = parseInt(quantity);
                                    // 02.09.2022 Check on quantity 
                                    if(quantity < 0){
                                        that.setError(1, this.getModel("i18n").getResourceBundle().getText("negativeQuantity"));
                                        return false;
                                    }
                                    oEvent.getSource().setValue(formatter.floatInstance(quantity));
                                }
                                let tmpQuantity = quantity.toString().includes(".") ? quantity.toString().split(".") : quantity.toString();
                                if (tmpQuantity[0].length > 7) {
                                    oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
                                    oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("maxDigits", 7));
                                    //oEvent.getSource().setValue( (tmpQuantity.split(",")[0]).slice(0, 13) );
                                    that.setError(1, this.getModel("i18n").getResourceBundle().getText("checkData"));
                                    return false;
                                }
                                if (tmpQuantity[1] !== undefined && tmpQuantity[1].length > 3) {
                                    oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
                                    oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("maxDecimal", 3));
                                    //oEvent.getSource().setValue( (tmpQuantity.split(",")[0]).slice(0, 13) );
                                    that.setError(1, this.getModel("i18n").getResourceBundle().getText("checkData"));
                                    return false;
                                }
                                that.setError(0, "");
                                oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
                                oEvent.getSource()._getBindingContext().getModel("/Batches").setProperty(oEvent.getSource()._getBindingContext().getPath() + "/Quantity", +quantity);
                                let quantityArr = oEvent.getSource()._getBindingContext().getModel("/Batches").getData().Batches;
                                that.calculateSommeQty(quantityArr);
                            }

                        }),
                        // File Upload
                        new sap.m.HBox({
                            width: "100%",
                            fitContainer: true,
                            items: [
                                new sap.ui.unified.FileUploader({
                                    fileType: "pdf",
                                    width: "100%",
                                    value: "{FileName}",
                                    //maxBodySize: '200MB',
                                    buttonText: "{i18n>uploadPV}", //  "Upload PV",
                                    change: function (oEvent) {
                                        let localEventSoruce = oEvent.getSource();
                                        let fileContent = formatter.convertToBase64(oEvent.getSource().getFocusDomRef().files[0]);
                                        fileContent.then(function (result) {
                                            result = (result.replace("data:application/pdf;base64,", "")).trim();
                                            localEventSoruce._getBindingContext().getModel().setProperty(localEventSoruce._getBindingContext().getPath() + "/ItemPV", result);
                                        });
                                    }
                                }),
                                new sap.m.Button({
                                    type: sap.m.ButtonType.Reject,
                                    icon: "sap-icon://decline",
                                    tooltip: "Remove File",
                                    press: function (oEvent) {
                                        oEvent.getSource().getModel().setProperty(oEvent.getSource()._getBindingContext().getPath() + "/FileName", "");
                                        oEvent.getSource().getModel().setProperty(oEvent.getSource()._getBindingContext().getPath() + "/ItemPV", "");
                                    }
                                }).addStyleClass("sapUiTinyMarginBegin")
                            ]
                        })
                    ]
                });

                oTable.bindAggregation("items", {
                    path: "/Batches",
                    template: oTemplate
                });

                this.getView().getModel("viewModel").setProperty("/sumLineItem", jsonData.length);
            },

            calculateSommeQty: function (quantities) {
                let sum = quantities.reduce(function (previousValue, currentValue) {
                    return Number(previousValue.toFixed(3)) + Number(currentValue.Quantity.toFixed(3));
                }, 0);
                sum = Number(sum.toFixed(3));
                this.getView().getModel("viewModel").setProperty("/sommeQty", formatter.floatInstance(sum));
            },

            onDownloadTemplate: function (oEvent) {
                const rows = [
                    //["BatchNo", "SN", "Quantity"]
                    ["Lot", "Num Serie", "Quantite"]
                ];

                let csvContent = "data:text/csv;charset=utf-8,";
                rows.forEach(function (rowArray) {
                    let row = rowArray.join(";");
                    csvContent += row + "\r\n";
                });
                var link = document.createElement("a");
                link.setAttribute("href", encodeURI(csvContent));
                link.setAttribute("download", "Modèle CSV.csv");
                document.body.appendChild(link);
                link.click();
                link.remove();
            },

            onImportCSV: function (oEvent) {
                var that = this;
                var file = oEvent.getSource().getFocusDomRef().files[0];
                var reader = new FileReader();
                reader.onload = function (e) {
                    var csvString = (e.currentTarget.result).trim();
                    if (csvString.includes("\r\n")) {
                        var arrOfCSV = csvString.split("\r\n");
                        var noOfCol = (arrOfCSV[0].split(";")).length;    // finding no. of columns
                        var headerRow = arrOfCSV[0].split(";");           // header columns  
                        headerRow[0] = "BatchNo"; headerRow[1] = "SN"; headerRow[2] = "Quantity";
                        var data = [];
                        for (let i = 1; i < arrOfCSV.length; i++) {
                            var singleRecord = arrOfCSV[i].split(";");
                            /* Merging two array into json key value pair */
                            var result = singleRecord.reduce(function (result, value, index) {
                                result[headerRow[index]] = value.toUpperCase();
                                return result;
                            }, {});
                            //console.log(result);
                            data.push(result);
                        }
                    }

                    if (data.length) {
                        data = data.map(function (currValue) {
                            // if (that.materialType != "ZPLS") {
                            //     if (that.materialManagedXCHPF != "" && that.materialSerialized == "") {
                            //         delete currValue.SN;
                            //     }
                            //     if (that.materialManagedXCHPF == "" && that.materialSerialized != "") {
                            //         delete currValue.BatchNo;
                            //     }
                            // }

                            if (!formatter.fnEBatchManaged(that.materialManagedXCHPF, that.materialSerialized, that.materialType)) {
                                delete currValue.BatchNo;
                            }

                            if (!formatter.fnSerialized(that.materialManagedXCHPF, that.materialSerialized, that.materialType)) {
                                delete currValue.SN;
                            }


                            if (currValue.Quantity == "") {
                                currValue.Quantity = 0;
                            } else {
                                currValue.Quantity = Number(formatter.convertNonEuroCurrency(currValue.Quantity)); //formatter.parse(currValue.Quantity);
                            }
                            return currValue;
                        });

                        var snLength = 18;
                        if (this.materialSerialized == "TUBE") {
                            snLength = 11;
                        }
                        for (let i = 0; i < data.length; i++) {
                            if (data[i].BatchNo != undefined && data[i].BatchNo.length > 10) {
                                this.onMessageBox(this.getModel("i18n").getResourceBundle().getText("batchMaxCharacter", 10));
                                return false;
                            }
                            if (data[i].SN != undefined && data[i].SN.length > snLength) {
                                this.onMessageBox(this.getModel("i18n").getResourceBundle().getText("serialMaxCharacter", snLength));
                                return false;
                            }

                            //if (this.materialType != 'ZPLS') {
                            if (this.materialSerialized == "" && this.materialSerialized != 'TUBE') {
                                data[i].Quantity = parseInt(data[i].Quantity);
                            } else {
                                if (data[i].Quantity != undefined) {
                                    let quantity = data[i].Quantity.toString();
                                    if (quantity.includes(".") && quantity.split(".")[0].length > 7) {
                                        this.onMessageBox("Batch: " + data[i].BatchNo + " SN: " + data[i].BatchNo + " " + this.getModel("i18n").getResourceBundle().getText("maxDigits", 7));
                                        return false;
                                    } else if (quantity.length > 7) {
                                        this.onMessageBox("Batch: " + data[i].BatchNo + " SN: " + data[i].BatchNo + " " + this.getModel("i18n").getResourceBundle().getText("maxDigits", 7));
                                        return false;
                                    }

                                    if (quantity.includes(".") && quantity.split(".")[1].length > 3) {
                                        this.onMessageBox("Batch: " + data[i].BatchNo + " SN: " + data[i].BatchNo + " " + this.getModel("i18n").getResourceBundle().getText("maxDecimal", 3));
                                        return false;
                                    }
                                }
                            }

                        }

                        this.populateTable(data);
                        this.calculateSommeQty(data);
                    }

                }.bind(this);
                //reader.readAsBinaryString(file);
                reader.readAsText(file);
                oEvent.getSource().clear();

            },

            setError: function (error, errorText) {
                this.getView().getModel("viewModel").setProperty("/error", error);
                this.getView().getModel("viewModel").setProperty("/errorText", errorText);
            },

            onCheck: function () {
                var that = this;
                var pvError = false;
                var errorString = "";
                var oneSNError = true;
                if (this.getView().getModel("viewModel").getProperty("/error") == 1) {
                    this.onMessageBox(this.getView().getModel("viewModel").getProperty("/errorText"));
                    return false;
                }

                let deliverySet = this.getView().byId("deliveryTable").getModel().getData().DeliveryTableSet[0];
                let batchSet = (this.getView().byId("batchRecord").getModel().getData().Batches).map(function (currValue) {
                    currValue.Material = that.materialNo;
                    return currValue;
                });

                if (batchSet.length === 0) {
                    that.onMessageBox(that.getModel("i18n").getResourceBundle().getText("emptyRecord"));
                    return false;
                }

                let error = batchSet.every(function (currValue, bIndex) {

                    // check if empty row is there in table
                    if (Object.keys(currValue).length === 0) {
                        //that.onMessageBox(that.getModel("i18n").getResourceBundle().getText("emptyRecord"));
                        errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptyRecord") + "\n";
                        return false;
                    }
                    // check if same SN record exists                     
                    batchSet.some(function (pValue, idx) {
                        if (idx !== bIndex && currValue.hasOwnProperty("SN")) {
                            if (JSON.stringify(currValue.BatchNo + currValue.SN) === JSON.stringify(pValue.BatchNo + pValue.SN)) {
                                if (oneSNError) {
                                    errorString = errorString + that.getModel("i18n").getResourceBundle().getText("sameSN") + "\n";
                                    oneSNError = false;
                                }
                                return false;
                            }
                        }
                    }, bIndex);
                    
                    //=== Checking on Mat Class TUBE
                    //if (that.materialType == "ZPLS") {
                    if (that.materialSerialized == "TUBE") {
                        // if (Object.keys(currValue).length > 0 && that.materialType == "ZPLS" && (currValue.BatchNo === undefined || currValue.SN === undefined)) {
                        if (Object.keys(currValue).length > 0 && that.materialSerialized == "TUBE" && (currValue.BatchNo === undefined || currValue.SN === undefined)) {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("zplsEmptyBatchSN") + "\n";
                            return false;
                        }

                        if (currValue.BatchNo.trim() == "") {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptyBatch") + "\n";
                            return false;
                        }
                        if (currValue.SN == "") {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptySN") + "\n";
                            return false;
                        }

                    }
                    // == checking on other material class
                    else {
                        // check on Batch
                        if (formatter.fnEBatchManaged(that.materialManagedXCHPF, that.materialSerialized, that.materialType) && (currValue.BatchNo === undefined || currValue.BatchNo.trim() == "")) {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptyBatch") + "\n";
                            return false;
                        }
                        // check on Serial
                        if (formatter.fnSerialized(that.materialManagedXCHPF, that.materialSerialized, that.materialType) && (currValue.SN === undefined || currValue.SN.trim() == "")) {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptySN") + "\n";
                            return false;
                        }
                    }
                    // check Quantity is blank                    
                    if (currValue.hasOwnProperty("Quantity") && currValue.Quantity == "" && currValue.Quantity <= 0) {
                        errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptyQuantity") + "\n";
                        return false;
                    }

                    // If material type is not TUBE and quantity of S/N is > 1 , add error message
                    if (currValue.hasOwnProperty("SN") && currValue.SN != "" && currValue.hasOwnProperty("Quantity") && that.materialSerialized != 'TUBE' && currValue.Quantity > 1) {
                        errorString = errorString + that.getModel("i18n").getResourceBundle().getText("snAndQuantity", currValue.SN) + "\n";
                        return false;
                    }

                    // Check if both having PV file or blank
                    if (deliverySet.headerPV != "") {  // check if header PV is not blank
                        if (currValue.hasOwnProperty("ItemPV") && currValue.ItemPV != "") {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("headerOrItemPV") + "\n";
                            return false;
                        }
                    } else {
                        if (!currValue.hasOwnProperty("ItemPV")) {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptyPV") + "\n";
                            return false;
                        }
                        if (currValue.hasOwnProperty("ItemPV") && currValue.ItemPV == "") {
                            errorString = errorString + that.getModel("i18n").getResourceBundle().getText("emptyPV") + "\n";
                            return false;

                        }
                    }

                    //return true;
                    if (errorString == "") {
                        return true;
                    }
                }, deliverySet.headerPV);

                if (!error) {
                    this.onMessageBox(errorString.trim());
                    return false;
                }

                // Check Quantity, except Tubes
                // if (this.materialType != "ZPLS" && formatter.parse(this.getView().getModel("viewModel").getProperty("/sommeQty")) > +this.quantity) {
                if (this.materialSerialized != "TUBE" && formatter.parse(this.getView().getModel("viewModel").getProperty("/sommeQty")) > +this.quantity) {
                    this.onMessageBox(that.getModel("i18n").getResourceBundle().getText("quantityVsMat"));
                    return false;
                }
                //return false;

                this.getView().getModel("viewModel").setProperty("/checkButton", true);
                this.getView().getModel("viewModel").setProperty("/savekButton", true);
                return true;
            },

            onSave: function () {
                if (!this.onCheck()) {
                    return false;
                }

                let deliverySet = this.getView().byId("deliveryTable").getModel().getData().DeliveryTableSet[0];
                let batchSet = this.getView().byId("batchRecord").getModel().getData().Batches;

                batchSet = batchSet.map(function (currValue) {
                    // currValue.Quantity = formatter.parse(currValue.Quantity);
                    currValue.Quantity = (currValue.Quantity).toString();
                    return currValue;
                });

                delete deliverySet.__metadata;
                deliverySet.Nav_Asc_DeliveryToBatch = batchSet;
                //return;
                let oModel = this.getOwnerComponent().getModel();
                sap.ui.core.BusyIndicator.show();
                oModel.create("/DeliverySet", deliverySet, {
                    method: "POST",
                    success: function (data) {
                        console.log(data);
                        sap.ui.core.BusyIndicator.hide();
                        this.populateMessage(data);
                    }.bind(this),
                    error: function (e) {
                        console.log(e);
                        sap.ui.core.BusyIndicator.hide();
                        this.onMessageBox(this.getModel("i18n").getResourceBundle().getText("somethingWrong"));
                        //MessageToast.show(this.getModel("i18n").getResourceBundle().getText("somethingWrong"));
                    }.bind(this)
                });
            },

            populateMessage: function (messages) {
                var that = this;
                let resuts = messages.Nav_Asc_DeliveryToBatch.results;
                let aMockMessages = resuts.map(function (message, value, index) {
                    if ((sap.ui.getCore().getConfiguration().getLanguage()).toLowerCase() == 'fr') {
                        message["Type"] = ((message["Type"]).toLowerCase() == "succès" ? "Success" : "Error");
                    }
                    message["Title"] = (message["Type"] == "Success" ? that.getModel("i18n").getResourceBundle().getText("successMsg") : that.getModel("i18n").getResourceBundle().getText("errorMsg")).trim();
                    message["Subtitle"] = (message["Description"]).trim();
                    return message;
                }, {});

                var oMessageTemplate = new MessageItem({
                    type: '{Type}',
                    title: '{Title}',
                    description: '{Description}',
                    subtitle: '{Subtitle}',
                    //counter: '{counter}',
                    //markupDescription: '{markupDescription}',                    
                });
                var oModel = new JSONModel();
                oModel.setData(aMockMessages);

                this.oMessageView = new MessageView({
                    showDetailsPageHeader: false,
                    itemSelect: function () {
                        oBackButton.setVisible(true);
                    },
                    items: {
                        path: "/",
                        template: oMessageTemplate
                    }
                });

                var oBackButton = new Button({
                    icon: IconPool.getIconURI("nav-back"),
                    visible: false,
                    press: function () {
                        that.oMessageView.navigateBack();
                        this.setVisible(false);
                    }
                });

                this.oMessageView.setModel(oModel);

                this.oDialog = new Dialog({
                    resizable: true,
                    content: this.oMessageView,
                    beginButton: new Button({
                        press: function () {
                            this.getParent().close();
                        },
                        text: "Close"
                    }),
                    customHeader: new Bar({
                        contentLeft: [oBackButton],
                        contentMiddle: [
                            new Title({ text: that.getModel("i18n").getResourceBundle().getText("response") })
                        ]
                    }),
                    contentHeight: "50%",
                    contentWidth: "50%",
                    verticalScrolling: false
                });

                this.oDialog.open();
                this.onClear();
            },

            onMessageBox: function (sText) {
                //var sText = "Error Message";
                MessageBox.error(sText)
            },

            onClear: function () {
                this.onInit();
                //this.populateTable(this.batchModel);
                this.getView().getModel().refresh();
                this.getView().byId("batchRecord").destroyItems();
                this.getView().byId("batchRecord").getModel().destroy();
                this.getView().byId("deliveryTable").destroyItems();
                this.getView().byId("deliveryTable").getModel().destroy();
                //this.onRemoveHeaderPV();
                this.getView().byId("headerPV").clear();
                this.getView().byId("comment").setValue("");
                this.getView().byId("PONumber").setValue("");
                this.getView().byId("material").setValue("");
                this.getView().byId("items").setValue("");
                this.getView().byId("items").removeAllItems();
                this.getView().byId("file").clear();
            }

        });
    });

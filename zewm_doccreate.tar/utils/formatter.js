
sap.ui.define([
    "sap/ui/core/format/NumberFormat"
], function (NumberFormat) {
    'use strict';
    var reader = new FileReader();
    let notationFormat = null;
    notationFormat = NumberFormat.getFloatInstance({
        groupingSeparator: " ",
        decimalSeparator: ","
    });

    return {

        fnEBatchManaged: function (matManagedXCHPF, matSerial, matType) {
            // if (matType == "ZPLS") {
            //     return true;
            // } else {     // If the material is Batch Managed ,the batch field should be editable
            //     if (matManagedXCHPF != "")
            //         return true;
            //     else
            //         return false;
            // }

            // if (matSerial == 'TUBE') {
            //     return true;
            // } else {
            //     // Non-Tube
            //     if (matSerial != 'TUBE' && matSerial != "") {
            //         return true;
            //     } else {
            //         if (matSerial == '' && matManagedXCHPF == 'X') {
            //             return true;
            //         }else{
            //             return false;
            //         }
            //     }

            // }
            if (matSerial == "TUBE") {
                return true;
            } else {     // If the material is Batch Managed ,the batch field should be editable
                if (matManagedXCHPF != "")
                    return true;
                else
                    return false;
            }

        },

        fnSerialized: function (matManagedXCHPF, matSerial, matType) {
            // if (matType == "ZPLS") {
            //     return true;
            // } else {     // If the material is Serialized ,the serial field should be editable
            //     if (matSerial != "")
            //         return true;
            //     else
            //         return false;
            // }
            // if (matSerial == 'TUBE') {
            //     return true;
            // } else {
            //     // Non-Tube
            //     if (matSerial != 'TUBE' && matSerial != "") {
            //         return true;
            //     } else {
            //         if (matSerial == '' && matManagedXCHPF == 'X') {
            //             return false;
            //         }else{
            //             return true;
            //         }
            //     }

            // }
            if (matSerial == "TUBE") {
                return true;
            } else {     // If the material is Serialized ,the serial field should be editable
                if (matManagedXCHPF == "")
                    return true;
                else
                    return false;
            }
        },

        convertToBase64: function (file) {
            return new Promise(function (resolve, reject) {
                reader.onload = function (e) {
                    //var csvString = e.currentTarget.result;
                    resolve(e.currentTarget.result);
                };
                reader.readAsDataURL(file);
            });
        },
        convertNonEuroCurrency: function (data) {
            data = data.replace(/ /g,'');
            //data = data.replaceAll(".", "");
            data = data.replaceAll(",", ".");
            return data;
        },

        floatInstance: function (value) {
            return notationFormat.format(value);
        },
        parse: function (value) {
            return notationFormat.parse(value.toString());
        }
    }
}); 